# PATCH_SNIPPETS.md

Use the blocks below as insertion or replacement text.

## Agents-of-Abyss/AGENTS.md

Add under the existing audit protocol section from wave 1:

```md
## Skill / proof audit bridge
When a task touches `aoa-skills` or `aoa-evals`, also read:
- `docs/CODEX_SKILL_PROOF_AUDIT_BRIDGE.md`

```

## Agents-of-Abyss/ECOSYSTEM_AUDIT_INDEX.md

Replace the `aoa-skills` and `aoa-evals` rows with:

```md
| `aoa-skills` | workflow | bounded execution canon, trigger boundaries, invocation posture, technique traceability, thin overlays, generated skill surfaces | `README.md`, `docs/ARCHITECTURE.md`, `docs/LAYER_POSITION.md`, `docs/BRIDGE_SPEC.md`, `docs/RUNTIME_PATH.md`, `docs/EVALUATION_PATH.md`, `docs/PUBLIC_SURFACE.md`, `docs/OVERLAY_SPEC.md`, `SKILL_INDEX.md`, target `skills/*/SKILL.md`, target `skills/*/techniques.yaml`, `AUDIT.md` | `python scripts/release_check.py`; when canonical skill semantics or evaluation/public surfaces change also run `python scripts/report_skill_evaluation.py --fail-on-canonical-gaps`; when technique dependencies change also run `python scripts/report_technique_drift.py --techniques-repo ../aoa-techniques` | workflow widening, technique-truth duplication, overlay authority drift, generated-surface drift | the task mainly changes upstream technique truth or bounded proof doctrine |
| `aoa-evals` | proof | bounded proof canon, portable eval bundles, claim framing, verdict wording, comparison posture, shared proof infra, generated eval surfaces | `README.md`, `docs/ARCHITECTURE.md`, `docs/EVAL_PHILOSOPHY.md`, `EVAL_INDEX.md`, `EVAL_SELECTION.md`, `docs/COMPARISON_SPINE_GUIDE.md`, `docs/ARTIFACT_PROCESS_SEPARATION_GUIDE.md`, `docs/REPEATED_WINDOW_DISCIPLINE_GUIDE.md`, `docs/SHARED_PROOF_INFRA_GUIDE.md`, `docs/TRACE_EVAL_BRIDGE.md`, target `bundles/*/EVAL.md`, target `bundles/*/eval.yaml`, `AUDIT.md` | `python scripts/validate_repo.py`; when manifests, generated surfaces, or public chooser wording change also run `python scripts/build_catalog.py`; for comparison-spine changes also re-read `generated/comparison_spine.json` against the changed bundle and public docs | overclaiming, verdict/claim mismatch, baseline-by-association drift, chooser/routing overreach, shared-infra overstatement | the task mainly changes execution workflow meaning rather than proof posture |
```

## aoa-skills/AGENTS.md

Add after `## Validation` or before `## Cross-repo neighbors`:

```md
## Audit contract
For repository audits and GitHub review, read `AUDIT.md` after the core docs.

## Review guidelines
For GitHub review in this repository, treat the following as P0:
- committed secrets, private instructions, or internal-only URLs in skill or overlay surfaces
- a risk-heavy skill changing from `explicit-only` to a weaker invocation posture without explicit approval and matching docs/evidence updates
- overlay or skill wording that silently routes a bounded public workflow toward destructive or live operational behavior

Treat the following as P1:
- a skill widens beyond a bounded workflow
- runtime wording duplicates or rewrites technique truth instead of packaging it
- single-technique composition appears without exception review or without updating the composition audit surface
- `SKILL.md`, `techniques.yaml`, and derived catalogs or matrices drift apart
- status or invocation changes appear without matching review or evidence surfaces
- overlay packs begin acting like downstream integrations or scenario playbooks
- claiming validation that was not actually run

Ignore trivial wording nits unless the task explicitly asks for copyediting.

```

## aoa-evals/AGENTS.md

Add after `## Validation` or before `## Cross-repo neighbors`:

```md
## Audit contract
For repository audits and GitHub review, read `AUDIT.md` after the core docs.

## Review guidelines
For GitHub review in this repository, treat the following as P0:
- secret-bearing fixtures, private benchmark data, or hidden telemetry presented as public proof surfaces
- wording that converts a bounded eval into a broad intelligence, general safety, or universal trust claim
- public chooser or comparison wording that silently changes default baseline or public maturity meaning without matching bundle contract and evidence

Treat the following as P1:
- `EVAL.md` and `eval.yaml` drift on category, status, baseline, or report semantics
- verdict wording becomes stronger than support-artifact coverage
- blind spots or nearby-bundle distinctness are erased
- comparison spine or generated routing surfaces drift away from bundle-local contracts
- shared infra names or paths imply stronger proof than the bundle supports
- trace/eval bridge wording shifts verdict interpretation out of `aoa-evals`
- claiming validation that was not actually run

Ignore trivial wording nits unless the task explicitly asks for copyediting.

```
