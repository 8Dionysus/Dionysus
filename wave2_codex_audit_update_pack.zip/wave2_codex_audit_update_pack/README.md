# Wave 2: Skill Layer and Proof Layer Audit Contracts

This pack prepares the second update wave for your repositories.

## Goal

Tighten the two repositories that most directly shape Codex behavior after the constitutional spine is in place:
- `aoa-skills` as the bounded execution canon
- `aoa-evals` as the bounded proof canon

This wave makes the seam between **workflow meaning** and **proof meaning** explicit so Codex can audit them without silently blending them together.

## Included files

### New files
- `Agents-of-Abyss/docs/CODEX_SKILL_PROOF_AUDIT_BRIDGE.md`
- `aoa-skills/AUDIT.md`
- `aoa-evals/AUDIT.md`

### Suggested patch updates
- `Agents-of-Abyss/AGENTS.md`
- `Agents-of-Abyss/ECOSYSTEM_AUDIT_INDEX.md`
- `aoa-skills/AGENTS.md`
- `aoa-evals/AGENTS.md`

See `PATCH_SNIPPETS.md` for exact insertion and replacement text.

## Why this wave now

- `aoa-skills` already owns bounded execution bundles, technique traceability, runtime/evaluation/public derived surfaces, and thin overlay rules.
- `aoa-evals` already owns bounded proof bundles, comparison posture, shared proof infra, chooser wording, and generated comparison surfaces.
- `aoa-skills` already exposes concrete repo checks such as `python scripts/release_check.py`, `python scripts/build_catalog.py`, `python scripts/validate_skills.py`, `python scripts/report_skill_evaluation.py`, and bridge drift helpers.
- `aoa-evals` already exposes concrete repo checks such as `python scripts/validate_repo.py` and `python scripts/build_catalog.py`, with validation tied to catalogs, capsules, sections, comparison spine alignment, and comparison bundle proof artifacts.
- Without an explicit seam, Codex can follow local rules yet still confuse execution meaning with proof meaning.

## What this wave changes conceptually

### `aoa-skills`
It now gets a repo-local audit contract that forces reviews to ask:
- did the skill stay bounded?
- did technique truth stay upstream?
- did overlays stay thin and public-safe?
- did generated runtime/evidence/public surfaces stay aligned with authored skill files?

### `aoa-evals`
It now gets a repo-local audit contract that forces reviews to ask:
- did the claim remain bounded?
- did verdict shape, category, and baseline semantics stay aligned?
- did public chooser wording stay weaker than the bundle contract?
- did shared proof infra remain weaker than bundle-local interpretation?

### `Agents-of-Abyss`
It gets a bridge doc for the seam itself so two-repo waves follow a fixed order:
1. patch skill meaning first when execution changes,
2. validate locally,
3. inspect proof surfaces,
4. only then patch eval wording if the proof surface no longer matches.

## Application order

1. Add the new files exactly as written.
2. Patch `AGENTS.md` in the three repositories.
3. Replace the `aoa-skills` and `aoa-evals` rows in `Agents-of-Abyss/ECOSYSTEM_AUDIT_INDEX.md` with the tighter versions from `PATCH_SNIPPETS.md`.
4. Run each repository's existing validation.
5. Only then start a wave that adds repo-local Codex skills or eval harnesses.

## Validation reminders

### aoa-skills
```bash
python scripts/release_check.py
python scripts/report_skill_evaluation.py --fail-on-canonical-gaps
```
When technique dependencies or bridge wording change:
```bash
python scripts/report_technique_drift.py --techniques-repo ../aoa-techniques
```

### aoa-evals
```bash
python scripts/build_catalog.py
python scripts/validate_repo.py
```
When comparison-spine or shared proof infrastructure surfaces change, also re-read the affected bundle dossier plus:
- `generated/comparison_spine.json`
- `EVAL_INDEX.md`
- `EVAL_SELECTION.md`
- `docs/COMPARISON_SPINE_GUIDE.md`

## What this wave still does not do

This wave does **not** yet add:
- repo-local `.agents/skills` packages for audit automation,
- Codex JSON-trace eval harnesses,
- `.codex/config.toml` profile specialization,
- cross-repo CI orchestration.

Those are better as the next wave after the audit seam is stable.

## Next wave after this one

Wave 3 should cover:
- repo-local Codex skills for repeatable audit/report work,
- a small eval harness for Codex behavior using structured traces,
- optional `.codex` profile tightening where it genuinely lowers error rate,
- proof packets for recurring review jobs in `aoa-evals`.
