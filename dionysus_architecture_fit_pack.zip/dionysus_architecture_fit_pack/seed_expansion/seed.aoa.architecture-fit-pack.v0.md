seed_id: seed.aoa.architecture-fit-pack.v0
title: AoA Architecture-Fit Pack
profile_anchor: 8Dionysus
projects:
- AoA
kind: seed-pack
status: prepared
priority: medium
parent_seed: null
tags:
- architecture-fit
- sas-first
- centralized-preflight
- coordination-budget
- single-writer
- validator-bottleneck
- eval-bundle
- memo-decay

# Seed Pack: AoA Architecture-Fit Pack

## Purpose
Этот pack вытягивает из research donor про scaling agent systems только то, что можно посадить в текущую форму `8Dionysus` без размывания ownership boundaries.

Он **не**:
- открывает `tenth_wave.manifest.json`;
- заменяет текущий `next_live_seed`;
- превращает один research donor в новый суверенный канон;
- подменяет repo-owned meaning скрытой runtime-идеологией.

Он нужен, чтобы сделать **architecture fit** явным:
- где AoA должен предпочитать `SAS`;
- где разрешён `MAS-Centralized`;
- где `MAS-Decentralized` допустим только под жёсткими caps;
- где `Independent` должен жить только как quarantine-режим без canonical write rights.

## Provenance
- donor source: Google Research / arXiv `Towards a Science of Scaling Agent Systems`
- grounding repos:
  - `Dionysus`
  - `Agents-of-Abyss`
  - `aoa-agents`
  - `aoa-routing`
  - `aoa-playbooks`
  - `aoa-evals`
  - `aoa-memo`
  - `abyss-stack`
- extraction goal: превратить один research donor в bounded repo-home follow-on seeds
- lifecycle posture: prepared draft pack; **do not register in `seed-registry.yaml` until actual planting happens or a maintainer explicitly promotes one of these seeds**

## Preserved Vocabulary
- `architecture fit`
- `sas_write`
- `single-writer`
- `centralized_preflight`
- `validator bottleneck`
- `bounded fanout`
- `coordination budget`
- `decentralized_capped`
- `independent_quarantined`
- `read many -> write one`
- `source repo owns meaning`
- `proof before widening`

## Anti-Goals
- превратить `aoa-routing` в автора смысла;
- превратить `Dionysus` в скрытый runtime-center;
- разрешить worker-агентам писать canonical surfaces;
- вшить vendor/model dogma как seed canon;
- перепутать `preflight` с `write authority`;
- превратить coordination chatter в durable memory canon;
- открыть новую wave-линейку stealth-способом.

## Protocol Spine (examples only)
Держать spine коротким и inspectable:
- `route -> architecture_hint -> preflight? -> single_writer -> validator_note -> distill`
- `read many -> write one`
- `workers may propose; only a single writer may land`
- `validator blocks contradiction propagation`
- `coordination trace decays unless checkpointed`

## Reference Scenarios
Использовать как bounded scenario references, а не как новые догмы:
- `Dionysus seed planting / registry / closure alignment`
- `cross-repo grounding for repo-home discovery`
- `open-web donor scouting`
- `high-risk tool preflight in abyss-stack`
- `restartable inquiry with explicit architecture mode`

---

## AOA-SEED-R6 Architecture-Fit Routing

### Purpose
Сделать выбор coordination mode явным в `aoa-routing`, но не повышать routing до роли суверенного архитектора.

`aoa-routing` должен уметь подсказать:
- когда задача похожа на `sas_write`;
- когда нужен `centralized_preflight`;
- когда допустим `decentralized_capped`;
- когда `independent_quarantined` разрешён только как candidate generator.

### Repo Homes
- `aoa-routing`

### First Artifact Hint
- `docs/ARCHITECTURE_FIT_ROUTING.md`
- `generated/task_to_architecture_hints.json`

### Preserved Vocabulary
- `architecture_fit`
- `sas_write`
- `centralized_preflight`
- `decentralized_capped`
- `independent_quarantined`
- `task_traits`
- `worker_write_rights`

### Explicit Non-Goals
- hidden runtime arbitration
- routing as truth authority
- model-brand doctrine
- direct write permissions
- implicit repo-home remapping

### What Stays In Neighboring Repos
- `aoa-agents` keeps role contracts and cohort semantics
- `aoa-playbooks` keeps scenario meaning
- `aoa-evals` keeps proof of whether mode choice works
- `Dionysus` keeps planting law and lineage
- `abyss-stack` keeps runtime caps and infra knobs

### Public Contract
Оставить contract маленьким и машиночитаемым:

```json
{
  "task_kind": "seed_planting",
  "traits": {
    "sequentiality": "high",
    "tool_density": "medium",
    "write_risk": "high",
    "decomposability": "low"
  },
  "recommended_mode": "sas_write",
  "preflight_mode": "centralized_preflight_optional",
  "worker_write_rights": false,
  "validator_required": true
}
```

### First Planting Slice
Один note + один generated surface с минимум четырьмя режимами:
- `seed_planting -> sas_write`
- `cross_repo_grounding -> centralized_preflight`
- `open_web_scout -> decentralized_capped`
- `brainstorm_candidates -> independent_quarantined`

---

## AOA-SEED-R7 Canonical Write Path Discipline

### Purpose
Зафиксировать правило, что canonical repo-owned write path в AoA / ToS экосистеме должен оставаться single-writer и inspectable.

Multi-agent composition допустима как:
- reading layer;
- synthesis preflight;
- contradiction discovery;
- risk review.

Но **не** как direct multi-writer canon.

### Repo Homes
- `Dionysus`
- `aoa-agents`

### First Artifact Hint
- `docs/codex/planting-protocol.md` addendum
- `aoa-agents/docs/CANONICAL_WRITE_PATH.md`
- `aoa-agents/generated/agent_write_rights.min.json`

### Preserved Vocabulary
- `single-writer`
- `read many -> write one`
- `worker_write_rights = false`
- `canonical write path`
- `preflight`
- `red-risk stop rule`

### Explicit Non-Goals
- equal-write swarm
- silent policy rewrite
- hidden merge authority
- reopening wave order through runtime convenience
- “many agents agreed” as substitute for source truth

### What Stays In Neighboring Repos
- `aoa-playbooks` may define the scenario that leads into the write path
- `aoa-routing` may suggest the mode
- `aoa-evals` may measure whether the discipline improves safety and clarity
- `aoa-memo` may record approved outcomes, not raw worker chatter

### Public Contract
Минимальный contract можно оставить почти в виде policy block:

```yaml
default_mode: sas_write
optional_mode: centralized_preflight
forbidden_on_canonical_writes:
  - independent
worker_write_rights: false
single_writer_required: true
validator_required_when_preflight: true
```

### First Planting Slice
- короткий addendum в `Dionysus/docs/codex/planting-protocol.md`
- role-rights surface в `aoa-agents`, где явно видно:
  - кто может только читать;
  - кто может только предлагать;
  - кто может валидировать;
  - кто может сделать финальный write

---

## AOA-SEED-R8 Centralized Preflight and Validator Bottleneck

### Purpose
Оформить тот bounded режим, где `MAS-Centralized` действительно полезен для AoA:
- cross-repo synthesis;
- donor refinement;
- high-risk preflight;
- contradiction hunting;
- evidence pack assembly.

Смысл не в “рое”, а в **validator bottleneck**:
несколько bounded workers читают и предлагают, но только orchestrator / validator пропускает итог дальше.

### Repo Homes
- `aoa-agents`
- `aoa-playbooks`

### First Artifact Hint
- `aoa-agents/docs/CENTRALIZED_PREFLIGHT.md`
- `aoa-playbooks/playbooks/cross-repo-grounding-preflight/PLAYBOOK.md`

### Preserved Vocabulary
- `orchestrator`
- `validator`
- `source_reader`
- `repo_cartographer`
- `risk_reviewer`
- `evidence_pack`
- `contradiction_check`
- `merge_gate`

### Explicit Non-Goals
- all-to-all debate by default
- worker-to-worker chatter as a virtue
- direct canonical writes from workers
- hidden autonomy theatre
- open-web wandering inside canonical write mode

### What Stays In Neighboring Repos
- `aoa-routing` selects or hints when preflight is appropriate
- `aoa-evals` scores catch rate, cost, and false escalation
- `aoa-memo` only receives checkpoint-shaped survivors
- `Dionysus` keeps planting and registry law

### Public Contract
Первый cohort может быть очень малым:

- `source_reader`
  - extracts exact refs
  - leaves citation pack
- `repo_cartographer`
  - maps ownership boundaries
  - identifies natural landing slice
- `risk_reviewer`
  - lists red-risk zones and stop points
- `validator`
  - resolves contradictions
  - blocks propagation
- `single_writer`
  - lands the change only after validator pass

### First Planting Slice
Один contract note + один playbook с явными decision points:
- when to spawn workers
- when to stop and fall back to SAS
- what artifact each worker owes
- what the validator must approve before any write

---

## AOA-SEED-R9 Coordination Budget and Fanout Caps

### Purpose
Сделать coordination не абстрактным “умом роя”, а бюджетируемым ресурсом.

Каждый coordination mode должен иметь:
- bounded worker count;
- bounded review rounds;
- stop rule when no new information appears;
- explicit fallback to `SAS`;
- explicit “deep call” budget.

### Repo Homes
- `abyss-stack`
- `aoa-agents`
- `aoa-playbooks`

### First Artifact Hint
- `abyss-stack/docs/COORDINATION_BUDGETS.md`
- `abyss-stack/config/coordination_budget_profiles.yaml`
- `aoa-agents/docs/COHORT_BUDGETS.md`

### Preserved Vocabulary
- `coordination budget`
- `bounded fanout`
- `max_workers`
- `max_rounds`
- `no_new_info_stop`
- `fallback_to_sas`
- `deep_budget`

### Explicit Non-Goals
- token heroics
- indefinite debate
- vendor-first tuning canon
- equating more messages with more intelligence
- hidden cost explosion

### What Stays In Neighboring Repos
- `aoa-evals` proves whether caps help or hurt
- `aoa-routing` recommends mode, not budget truth
- `aoa-memo` decides what survives after the run
- `Dionysus` remains outside runtime knob sprawl

### Public Contract
Первые caps должны быть deliberately small and proof-gated, for example:

```yaml
modes:
  sas_write:
    max_workers: 1
    max_rounds: 0
  centralized_preflight:
    max_workers: 3
    max_rounds: 1
    validator_required: true
  decentralized_capped:
    max_workers: 3
    max_rounds: 1
    canonical_writes: false
  independent_quarantined:
    max_workers: 2
    max_rounds: 0
    canonical_writes: false
stop_rules:
  - no_new_information
  - contradiction_unresolved
  - budget_exhausted
  - write_risk_without_confirmation
```

Эти caps не объявляются вечной истиной.
Они стартуют маленькими и могут расширяться только после eval-backed proof.

### First Planting Slice
Один profile file с именованными mode-caps и один note о stop rules:
- `when to stop debating`
- `when to cut to validator`
- `when to fall back to single writer`

---

## AOA-SEED-R10 Architecture-Fit Eval Bundle

### Purpose
Сделать выбор architecture mode доказуемым, а не красивым.

`aoa-evals` должен получить bundle, который проверяет:
- когда `SAS` выигрывает;
- когда `Centralized` окупается;
- когда `Decentralized` вообще допустим;
- когда `Independent` даёт только шум;
- насколько write safety, boundary adherence и catch rate меняются от режима.

### Repo Homes
- `aoa-evals`

### First Artifact Hint
- `bundles/aoa-architecture-fit/EVAL.md`
- `bundles/aoa-architecture-fit/cases/*.yaml`
- `bundles/aoa-architecture-fit/reports/template.md`

### Preserved Vocabulary
- `architecture fit`
- `overhead`
- `validator catch rate`
- `boundary adherence`
- `write safety`
- `false escalation`
- `restart fidelity`
- `proof before widening`

### Explicit Non-Goals
- leaderboard theatre
- one aggregate score pretending to explain everything
- final-text-only grading
- universal best architecture claims
- “more agents = more intelligence” mythology

### What Stays In Neighboring Repos
- `aoa-playbooks` supplies recurring scenarios
- `aoa-agents` supplies artifact contracts and role outputs
- `aoa-routing` may later consume bounded verdict hints
- `abyss-stack` supplies runtime budget traces

### First Case Families
- `seed_planting_write_path`
- `cross_repo_grounding`
- `open_web_scout_capped`
- `tool_heavy_preflight`
- `restartable_inquiry_mode_selection`

### First Metrics
- `quality_delta`
- `overhead_delta`
- `validator_catch_rate`
- `boundary_breach_rate`
- `write_risk_flag_rate`
- `restart_success_rate`

### First Planting Slice
Один eval bundle skeleton с повторяемым report language:
- what task class was tested
- what mode was selected
- what changed in quality
- what changed in cost / overhead
- what risks were caught
- what remained unresolved

---

## AOA-SEED-R11 Coordination Trace Decay

### Purpose
Усилить `Memory Thermodynamics` правилом:
**coordination chatter is not memory canon**.

Если multi-agent preflight и допускается, то выживать должны не raw conversations, а только:
- approved checkpoints;
- validator-approved summaries;
- artifact-backed decisions;
- review-passed distillations.

### Repo Homes
- `aoa-memo`

### First Artifact Hint
- `docs/COORDINATION_TRACE_DECAY.md`
- `schemas/memory_item.schema.json` field extension
- `docs/WRITEBACK_TEMPERATURE_POLICY.md` addendum

### Preserved Vocabulary
- `coordination trace`
- `ephemeral`
- `checkpoint survivor`
- `review-gated writeback`
- `promotion only from artifact`
- `chatter is not canon`

### Explicit Non-Goals
- raw transcript as durable memory
- automatic promotion because multiple agents repeated the same thing
- coordination redundancy as truth signal
- silent memory inflation from runtime noise

### What Stays In Neighboring Repos
- `aoa-agents` keeps runtime-local scratchpad
- `aoa-playbooks` defines checkpoint shapes
- `aoa-evals` proves whether writeback discipline preserves fidelity
- `Dionysus` keeps seed lineage, not runtime residue

### Public Contract
Первая mapping law может быть такой:
- worker chatter -> `ephemeral`, auto-expire
- validator summary -> candidate `episode`
- approved checkpoint -> candidate `state_capsule`
- approval / rejection record -> `decision`
- reviewed distillation -> candidate `claim` / `pattern` / `bridge`

### First Planting Slice
Один decay note + одно small schema extension, где видно:
- какие runtime traces не имеют права пережить run;
- какие могут стать memo-candidates;
- где нужен explicit review before promotion.

---

## Deferred Notes
Этот pack сознательно **не** открывает пока отдельные seeds для:
- `Decentralized web scout pack` как самостоятельного playbook pack
- `Independent brainstorming quarantine` как отдельного repo-home scenario
- `KAG multi-reader lift gate` beyond the already landed `AOA-SEED-R5`
- model-family-specific tuning laws
- UI dashboards for coordination budget visualization

Оставить их deferred до тех пор, пока не появится clean repo home и bounded proof.

## Success Sign
Pack посажен удачно, когда после реальных landings становится ясно:
- где AoA должен идти через `SAS`;
- где `Centralized` разрешён и зачем;
- где coordination must stay capped;
- почему workers не имеют canonical write rights;
- как runtime noise не распухает в memory canon;
- как выбор architecture mode перестаёт быть фольклором и становится inspectable.
