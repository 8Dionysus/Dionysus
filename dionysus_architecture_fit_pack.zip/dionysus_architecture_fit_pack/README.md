# Dionysus Architecture-Fit Pack

В этом пакете подготовлены seed-сурfaces для `Dionysus`, основанные на research donor про scaling agent systems и на текущих ownership boundaries твоих репозиториев.

## Что внутри
- `seed_expansion/seed.aoa.architecture-fit-pack.v0.md`

## Как это задумано
Пакет **не** трогает текущий `next_live_seed` и **не** открывает новую волну.
Он подготовлен как draft seed-pack в `seed_expansion/`, чтобы ты мог:
1. просмотреть и отредактировать seed-семена;
2. посадить отдельные slices в owning repos;
3. только после реальных landings решать, как отражать это в `seed-registry.yaml`.

## Почему без registry patch
Судя по текущему `schema/seed-registry.contract.yaml`, для `wave: null` seed-entries допускаются только `gated_next` или `landed_post_wave`.
Сейчас `next_live_seed` уже занят ToS-expansion surface, а этот pack ещё не landed.
Поэтому я оставил его как **prepared draft surface**, а не как готовую registry-вставку.
