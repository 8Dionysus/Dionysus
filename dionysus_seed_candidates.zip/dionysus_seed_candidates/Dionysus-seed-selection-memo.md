# Dionysus seed selection memo

## What I kept

I kept five seeds because each one has:
- a clear owning home,
- a smallest viable planting slice,
- a direct extension path from already-landed post-wave work,
- and a low risk of collapsing repo boundaries.

### 1. AOA-SEED-R6 Memory Namespace and Compression Discipline
Kept because the current AoA grammar already separates authored memory from derived substrate, but the next useful slice is finer control over namespaces, write-intent classes, and compaction.

### 2. AOA-SEED-R7 Eval Ladder and Judge Discipline
Kept because `AOA-SEED-R4` already opened the trace/eval bridge, and the next natural move is a disciplined ladder for deterministic checks, model graders, human review, and online monitoring.

### 3. AOA-SEED-R8 Skills as Contracted Execution Capsules
Kept because the runtime path is now clear enough that skills should stop being only “described workflows” and become explicit runtime capsules without swallowing playbooks.

### 4. AOA-SEED-R9 AI-Native Documentation Surface
Kept because current MCP and `llms.txt` practice gives a clean way to expose high-signal repo knowledge to agents without scraping chaos or replacing source-of-truth order.

### 5. AOA-SEED-R10 Tool Approval and Remote Boundary Policy
Kept because remote MCP and A2A are now practical, but only if trust, approval, and local-vs-remote discipline are explicit.

## What I rejected for now

### Rejected: generic GraphRAG / hybrid retrieval seed
Reason: too close to `aoa-kag`'s current ownership and too likely to duplicate `AOA-SEED-R5`.

### Rejected: generic protocolization seed
Reason: `AOA-SEED-R1` already owns the runtime seam.

### Rejected: UI / dashboard seed
Reason: useful later, but second-order. Docs, skills, and policy should settle first.

### Rejected: model hierarchy / router economics seed
Reason: `AOA-SEED-10 Model-Tier Orchestration` already owns that lane.

## Registration posture

Do not merge the registry snippet unchanged.

The clean options are:
1. choose one of the new seeds as the single `gated_next` entry and update `navigation.next_live_seed`, or
2. wait until the first planting actually lands, then register the planted seed as `landed_post_wave`.

Because the current registry already names the ToS wider-world-thought expansion seed as the official `gated_next`, I treated this pack as a draft candidate pack, not a ready-to-merge registry change.
