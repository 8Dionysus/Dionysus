seed_id: seed.aoa.memory-evals-skills-docs-pack.v0
title: AoA Memory, Evals, Skills, and AI Docs Pack
profile_anchor: 8Dionysus
projects:
  - AoA
  - ToS
kind: seed-pack
status: draft_candidate
priority: medium
parent_seed: null
tags:
  - memory
  - evals
  - skills
  - ai-docs
  - tools
  - protocol

# Seed Pack: AoA Memory, Evals, Skills, and AI Docs Pack

## Purpose

This pack harvests bounded future seeds from the March 2026 research stream on memory, evals, skill decomposition, AI-native documentation, and tool-boundary discipline.

It is intentionally selective. It does **not** reopen the ninth wave, replace the current `next_live_seed`, or rename ideas that already landed as `AOA-SEED-R1` through `AOA-SEED-R5`.

## Why These Seeds And Not Others

Keep only seeds that:
- have one clear owning home,
- can be planted as the smallest linked slice,
- extend existing Dionysus/AoA grammar instead of overwriting it,
- remain contract-first rather than vendor-first.

Do **not** keep seeds that:
- duplicate `AOA-SEED-R1` through `AOA-SEED-R5`,
- turn `aoa-kag` into a generic platform empire,
- make UI the center before contracts are stable,
- canonize one framework or model family.

## Provenance

- donor surfaces:
  - `seed_agents_1st.md`
  - `seed_expansion/seed.aoa.agents-runtime-pack.v0.md`
  - current `seed-registry.yaml`
- extraction goal:
  - turn current research on memory / evals / skills / docs into bounded seeds with explicit repo homes
- lifecycle posture:
  - **draft candidate pack**
  - do **not** register unchanged
  - promote only when either:
    - one seed becomes the official `gated_next`, or
    - a planting has actually landed and the entry can honestly become `landed_post_wave`
- next live seed unchanged:
  - `seed.tos.wider-world-thought-expansion.v0`

## Preserved Vocabulary

- `semantic / episodic / procedural`
- `state_capsule`
- `WitnessTrace`
- `route -> plan -> do -> verify -> deep? -> distill`
- `pick -> inspect -> expand`
- `source vs derived`
- `repo-owned meaning`
- `MCP resource / prompt / tool`
- `Agent Card`

## Anti-Goals

- reopen the ninth wave
- replace `navigation.next_live_seed`
- make vendor or framework names canonical
- move repo-owned meaning into Dionysus
- duplicate R1–R5 under fresher labels
- turn docs into a shadow source-of-truth
- expose every internal module on the network

## AOA-SEED-R6 Memory Namespace and Compression Discipline

### Purpose

Define an explicit memory namespace discipline in `aoa-memo` that separates:
- run-local state,
- semantic memory,
- episodic memory,
- procedural memory,
- review-required distillations.

Add a compression / compaction law so memory grows by governed distillation instead of quiet pile-up.

### Repo Homes

- `aoa-memo`
- `aoa-playbooks` (memory posture references only)
- `aoa-agents` (checkpoint / writeback caller only)

### First Artifact Hint

- memory namespace contract note
- write-path matrix for `state_capsule`, `episode`, `claim`, `decision`, `pattern`, `bridge`, `audit_event`
- one compression / decay / review policy surface

### Preserved Vocabulary

- `semantic`
- `episodic`
- `procedural`
- `state_capsule`
- `episode`
- `claim`
- `decision`
- `pattern`
- `bridge`
- `audit_event`
- `hot / warm / cool / cold / frozen`

### Explicit Non-Goals

- one vector store for everything
- moving scratchpad into canon
- encoding retrieval ranking rules as doctrine
- vendor-locked store / embedding obligations
- replacing `aoa-kag` with memo

### What Stays In Neighboring Repos

- `aoa-agents` keeps run-local scratchpad and checkpoint execution
- `aoa-playbooks` keeps memory posture and writeback timing
- `aoa-kag` keeps derived retrieval surfaces
- `abyss-stack` keeps storage and infra implementation choices

### First Planting Slice

- one note defining namespace boundaries
- one tiny machine-readable write-intent map
- one example mapping from runtime artifacts into memo objects

## AOA-SEED-R7 Eval Ladder and Judge Discipline

### Purpose

Define a layered evaluation doctrine in `aoa-evals`:
1. deterministic checks,
2. artifact-aware model graders,
3. trace-level verdicts,
4. human review lane,
5. online monitors.

Keep every non-deterministic judgment tied to explicit artifacts, explicit rubrics, and explicit datasets or trace targets.

### Repo Homes

- `aoa-evals`
- `aoa-playbooks` (eval anchors only)
- `aoa-agents` (bridge / emission only)

### First Artifact Hint

- eval ladder contract note
- grader contract schema
- one `WitnessTrace -> verdict` worked example

### Preserved Vocabulary

- `WitnessTrace`
- `verification_result`
- `transition_decision`
- `artifact-to-verdict hook`
- `dataset`
- `offline / online`
- `rubric`

### Explicit Non-Goals

- final-text-only judgment
- one giant hidden judge prompt
- no-dataset pre-merge changes
- letting online monitoring become semantic truth
- mixing memory writeback with proof logic

### What Stays In Neighboring Repos

- `aoa-playbooks` keeps scenario-level evaluation posture
- `aoa-agents` emits traces and tier artifacts
- `aoa-memo` stores reviewed deltas, not evaluator truth
- external evaluator frameworks remain examples, not canon

### First Planting Slice

- one ladder note
- one small grader schema with deterministic + model-based layers
- one CI-facing hook surface for a bounded eval bundle

## AOA-SEED-R8 Skills as Contracted Execution Capsules

### Purpose

Make `aoa-skills` runtime-usable without turning it into hidden orchestration.

A skill should become a bounded execution capsule with:
- declared inputs,
- declared outputs,
- preconditions,
- failure modes,
- eval hooks,
- allowed neighboring playbook roles.

### Repo Homes

- `aoa-skills`
- `aoa-playbooks`
- `aoa-techniques`

### First Artifact Hint

- skill capsule schema
- one converted canonical skill family
- one reference mapping from playbook requirements to a capsule

### Preserved Vocabulary

- `bounded workflow`
- `skill family`
- `pick -> inspect -> expand`
- `required_skill_families`
- `participating_agents`
- `evaluation_posture`

### Explicit Non-Goals

- put scenario orchestration inside skills
- hide prompts inside agent profiles
- turn skills into a code-executor monolith
- duplicate playbook meaning
- let `aoa-techniques` lose ownership of donor practice canon

### What Stays In Neighboring Repos

- `aoa-playbooks` keeps scenario composition
- `aoa-agents` binds roles and tiers to skill use at runtime
- `aoa-techniques` keeps practice canon
- `aoa-evals` keeps proof logic and score meaning

### First Planting Slice

- one schema
- one capsule example with input / output / failure surface
- one tiny bridge note: `playbook -> required_skill_families -> capsule`

## AOA-SEED-R9 AI-Native Documentation Surface

### Purpose

Give AoA and ToS repos an explicit AI-facing documentation surface that helps agents read the right things in the right order.

The surface should expose:
- source-of-truth order,
- key manifests / contracts / notes,
- bounded resources,
- bounded reusable prompts,
- high-signal repo docs for model consumption.

### Repo Homes

- `Agents-of-Abyss`
- `Tree-of-Sophia`
- `shared / interface / infra repos`

### First Artifact Hint

- docs-surface contract note
- one `llms.txt`
- one minimal MCP resource / prompt map for contracts, manifests, and readme surfaces

### Preserved Vocabulary

- `source-of-truth order`
- `resource`
- `prompt`
- `anchor`
- `audience`
- `priority`
- `lineage`

### Explicit Non-Goals

- make docs a second sovereign canon
- duplicate every human-facing document
- auto-ingest raw repo trees without curation
- flatten AoA and ToS into one portal
- replace manifests or source seed files

### What Stays In Neighboring Repos

- wave manifests keep order
- source seed files keep meaning
- `seed-registry.yaml` keeps navigation
- target repos keep local doctrine and implementation detail

### First Planting Slice

- one docs-surface note
- one `llms.txt` at a single root
- one small MCP map exposing only high-signal resources and prompts

## AOA-SEED-R10 Tool Approval and Remote Boundary Policy

### Purpose

Make tool-use and remote-boundary decisions explicit:
- when something stays a local sub-agent,
- when it becomes a remote MCP server,
- when it deserves an outward A2A boundary,
- what approval, trust, and auth posture applies.

### Repo Homes

- `aoa-agents`
- `abyss-stack`
- `shared / interface / infra repos`

### First Artifact Hint

- boundary policy note
- local-vs-remote decision table
- tool trust / approval matrix

### Preserved Vocabulary

- `local sub-agent`
- `remote agent`
- `MCP`
- `A2A`
- `Agent Card`
- `trusted server`
- `allowed_tools`
- `require_approval`

### Explicit Non-Goals

- auto-approve everything
- expose every internal module on the network
- trust every third-party MCP server by default
- hide auth / approval policy inside prompts only
- let transport policy overwrite repo ownership

### What Stays In Neighboring Repos

- `aoa-agents` decides who calls what
- `abyss-stack` implements auth, network, and runtime controls
- `aoa-playbooks` describes posture, not transport
- Dionysus remains a dispatch garden, not the enforcement layer

### First Planting Slice

- one policy note
- one server trust classification surface
- one local-vs-remote capability table

## Deferred On Purpose

These were considered and **not** kept in this pack:

- generic GraphRAG / hybrid retrieval platform seed  
  deferred because `aoa-kag` already owns the substrate question and `AOA-SEED-R5` already opened the handoff seam
- generic “protocolize everything” seed  
  deferred because `AOA-SEED-R1` already planted the runtime seam
- UI / dashboard seed  
  deferred because docs, skills, and tool policy should stabilize first
- model hierarchy / router economics seed  
  deferred because `AOA-SEED-10 Model-Tier Orchestration` already owns that architectural lane
