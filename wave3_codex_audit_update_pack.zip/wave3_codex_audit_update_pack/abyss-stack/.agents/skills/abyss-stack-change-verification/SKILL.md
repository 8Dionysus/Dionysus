---
name: abyss-stack-change-verification
description: Run the mandatory verification stack when changes affect compose modules, profiles, presets, scripts, systemd user units, config templates, env examples, bootstrap, first-run, doctor, render, or deployment behavior in abyss-stack. Skip for docs-only or repo-meta changes unless the user explicitly asks for the full verification stack.
---

# Overview

Use this skill to verify meaningful changes in `abyss-stack` without widening scope.

This is a **verification skill**, not a broad redesign skill.

## Read first

1. `AGENTS.md`
2. `AUDIT.md`
3. `README.md`
4. `BOUNDARIES.md`
5. the most relevant touched docs such as:
   - `docs/PROFILES.md`
   - `docs/PRESETS.md`
   - `docs/PROFILE_RECIPES.md`
   - `docs/RENDER_TRUTH.md`
   - `docs/PATHS.md`
   - `docs/SECRETS_BOOTSTRAP.md`
   - `docs/DOCTOR.md`
   - `docs/FIRST_RUN.md`
6. the touched scripts, compose files, templates, env files, or units

## Use when

Use this skill when changes affect:
- compose modules
- profiles or presets
- scripts
- systemd user units
- config templates or env examples
- bootstrap, first-run, doctor, render, or deployment behavior
- canonical path or layout mapping

## Do not use when

Do not use this skill as the main workflow for:
- docs-only changes,
- repo-meta edits with no behavior impact,
- ecosystem ownership questions that belong in `Agents-of-Abyss`,
- authored-meaning work that belongs in `Tree-of-Sophia`.

For exposure, secrets, canonical path, or runtime/body versus meaning boundary risk, pair or hand off to `abyss-stack-boundary-audit`.

## Steps

1. Decide whether the skill applies.
   - If the task is docs-only or repo-meta-only, explain why the full verification stack is being skipped.

2. Identify the touched infra surface.
   - compose?
   - profiles/presets?
   - scripts?
   - bootstrap/layout/env mapping?
   - render truth?

3. Run the baseline repository validation after meaningful changes:
```bash
python scripts/validate_stack.py
```

4. If shell scripts were touched, run `shellcheck` on every touched shell script.

5. If bootstrap, layout, env examples, or secrets mapping changed, add:
```bash
scripts/aoa-first-run --strict
scripts/aoa-check-layout --ignore-secrets
```

6. If profiles, modules, or render-truth surfaces changed, run the smallest relevant introspection/render checks.

### Example profile-scoped checks
```bash
scripts/aoa-profile-modules --profile core --paths
scripts/aoa-profile-endpoints --profile core
scripts/aoa-render-services --profile core
scripts/aoa-render-config --profile core >/dev/null
```

### Example preset-scoped checks
```bash
scripts/aoa-profile-modules --preset agent-full --paths
scripts/aoa-profile-endpoints --preset agent-full
scripts/aoa-render-services --preset agent-full
scripts/aoa-render-config --preset agent-full >/dev/null
```

7. Use the smallest relevant profile or preset.
   - Do not pretend to validate every preset if only one changed.
   - Report exactly which profile or preset was exercised.

8. Never claim:
   - `shellcheck` ran if it did not,
   - a render or bootstrap check ran if it did not,
   - a secret-safe output was verified if it was not.

9. Keep scope tight.
   - Do not widen host exposure.
   - Do not print secret-bearing values.
   - Do not redesign runtime/body versus meaning-layer boundaries without explicit approval.

## Output contract

Return:

### PLAN
- what infra surface changed
- which verification path applies

### DIFF
- what changed
- whether runtime posture changed or only docs/metadata changed

### VERIFY
- `python scripts/validate_stack.py` status
- any `shellcheck` commands actually run
- any render/profile/preset/bootstrap checks actually run
- what was not run and why

### REPORT
- current runtime contract after the change
- whether composition, exposure, path mapping, or secret posture changed

### RESIDUAL RISK
- unverified presets/profiles
- host assumptions not exercised
- bootstrap or lifecycle paths not tested
