---
name: abyss-stack-boundary-audit
description: Audit abyss-stack changes that could widen host exposure, alter secret posture, shift canonical path mapping, blur runtime-body versus meaning-layer boundaries, or make bootstrap and runtime actions destructive without rollback guidance. Use before finalizing such work or when reviewing a risky diff. Do not use for narrow docs-only or repo-meta edits.
---

# Overview

Use this skill for the **highest-risk boundary review path** in `abyss-stack`.

This is a **report-first audit skill**.
It should expose risk, not silently broaden infra behavior.

## Read first

1. `AGENTS.md`
2. `AUDIT.md`
3. `README.md`
4. `BOUNDARIES.md`
5. the most relevant touched docs such as:
   - `docs/PATHS.md`
   - `docs/STORAGE_LAYOUT.md`
   - `docs/DEPLOYMENT.md`
   - `docs/RENDER_TRUTH.md`
   - `docs/SECRETS_BOOTSTRAP.md`
   - `docs/FIRST_RUN.md`
   - `docs/DOCTOR.md`
   - `docs/LIFECYCLE.md`
6. the nearest nested `AGENTS.md` when working inside subdirectories such as `env/`

## Use when

Use this skill when the task or diff touches:
- host exposure or bind posture
- secret handling or internal-only probes
- canonical path mapping such as `/srv/abyss-stack`, `Configs`, or `Secrets`
- public-safe example files versus live runtime files
- render output that might expose secret-bearing values
- runtime/body versus meaning-layer boundaries
- bootstrap or runtime actions that could become destructive

## Do not use when

Do not use this skill as the main workflow for:
- low-risk docs-only edits,
- narrow refactors with no exposure, path, or boundary implications,
- public skill or proof doctrine questions that belong in `aoa-skills` or `aoa-evals`.

If code, scripts, compose, or runnable behavior changed, pair this skill with `abyss-stack-change-verification`.

## Steps

1. Determine whether the diff is boundary-relevant.
   If it is not, say so and return to the narrower workflow.

2. Audit exposure posture.
   Ask:
   - Was any bind widened from `127.0.0.1` toward broader host exposure?
   - Did internal-only probes become easier to expose publicly?
   - Did any new service or port appear without clear operator intent?

3. Audit secret posture.
   Ask:
   - Did real secrets or rendered config values become commit risks?
   - Did public-safe templates start behaving like live runtime files?
   - Did bootstrap or render paths start exposing secret-bearing output?

4. Audit canonical path mapping.
   Ask:
   - Is `/srv/abyss-stack` still treated as the deployed runtime root?
   - Are `Configs/` and `Secrets/` still mapped correctly?
   - Is a Windows source checkout path being confused with the Linux runtime root?

5. Audit repository boundaries.
   Ask:
   - Is infra substrate starting to author meaning that belongs in AoA or ToS?
   - Is a runtime helper silently becoming a source-of-truth layer?

6. Classify findings using the repo-local audit severity.
   - `P0` for exposure or secret failures, or destructive runtime shifts without rollback posture
   - `P1` for path drift, missing verification, hidden bootstrap breakage, or meaning-boundary bleed

7. If code or runnable behavior changed, explicitly require `abyss-stack-change-verification`.

8. Stay report-first by default.
   Do not make wide infra edits unless the user explicitly asks for implementation.

## Output contract

Return:

### PLAN
- what risky infra boundary is under review
- why this skill applies

### DIFF
- what changed in the risky path
- whether the change altered exposure, secrets, path mapping, or boundary posture

### VERIFY
- which verification commands have already been run
- which additional checks are still required
- whether `abyss-stack-change-verification` must also run

### REPORT
- boundary findings
- approval-required changes
- whether exposure, secret posture, path mapping, or infra/meaning boundaries changed

### RESIDUAL RISK
- host assumptions not exercised
- renders not checked
- presets or bootstrap paths still unverified
