# Repo-local Codex skills for abyss-stack

These skills are local workflow helpers for `abyss-stack`.

They are **not**:
- public AoA skill canon,
- proof bundles,
- replacements for `AGENTS.md` or `AUDIT.md`.

They exist to help Codex follow recurring infra-specific workflows inside this repository.

## Current helper skills

- `abyss-stack-change-verification`
- `abyss-stack-boundary-audit`

## Design rules

- one workflow per skill
- prefer instructions over scripts
- keep exposure and secret posture audits explicit-only
- keep reports in `PLAN / DIFF / VERIFY / REPORT / RESIDUAL RISK`
- do not claim a render, bootstrap, or shellcheck pass unless it actually ran
- do not let these helper skills redefine AoA, ToS, or public proof meaning
