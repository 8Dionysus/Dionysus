# PATCH_SNIPPETS.md

Use the blocks below as insertion text for the existing `AGENTS.md` files.

## Agents-of-Abyss/AGENTS.md

Add near the audit protocol or review guidance section:

```md
## Repo-local skills doctrine
When creating or reviewing repo-local Codex helper skills, also read:
- `docs/CODEX_REPO_LOCAL_SKILLS_PATTERN.md`

Do not let local `.agents/skills/` helper packs redefine:
- public AoA skill canon in `aoa-skills`
- public proof meaning in `aoa-evals`
- ecosystem ownership boundaries defined in this repository
```

## ATM10-Agent/AGENTS.md

Add near the top-level operational rules or after the audit contract:

```md
## Mandatory skill usage

### `$atm10-change-verification`
Run `$atm10-change-verification` before marking work complete when changes affect:
- runtime code, tests, smoke paths, or build/test behavior
- `scripts/`
- gateway/operator launch paths
- retrieval, KAG, voice, or cross-service benchmark flows
- profile-aware `combo_a` or operating-cycle behavior

Skip it for docs-only or repo-meta changes unless the user explicitly asks for the full verification stack.

### `$atm10-safe-automation-audit`
Run `$atm10-safe-automation-audit` before finalizing work that touches:
- automation safety
- dry-run behavior
- input-event routing
- operator actions
- service exposure or auth posture
- any path that could change game state or leak local runtime detail

Pair it with `$atm10-change-verification` whenever code or runnable behavior also changed.
```

## abyss-stack/AGENTS.md

Add near the top-level operational rules or after the audit contract:

```md
## Mandatory skill usage

### `$abyss-stack-change-verification`
Run `$abyss-stack-change-verification` before marking work complete when changes affect:
- compose modules, profiles, or presets
- scripts or systemd user units
- config templates or env examples
- bootstrap, first-run, doctor, render, or deployment behavior
- path/layout mapping or runtime composition helpers

Skip it for docs-only or repo-meta changes unless the user explicitly asks for the full verification stack.

### `$abyss-stack-boundary-audit`
Run `$abyss-stack-boundary-audit` before finalizing work that touches:
- host exposure, secret posture, or internal probes
- canonical path mapping such as `/srv/abyss-stack`, `Configs`, or `Secrets`
- public-safe example files versus live runtime files
- runtime/body versus meaning-layer boundaries
- bootstrap or runtime actions that could be destructive without rollback guidance

Pair it with `$abyss-stack-change-verification` whenever code, scripts, compose, or runnable behavior also changed.
```

## aoa-evals/AGENTS.md

Add after the audit contract or read-first docs section:

```md
## Repo-local helper skill evals
When creating or reviewing evals for repo-local Codex helper skills, read:
- `docs/CODEX_REPO_LOCAL_TRACE_HARNESS.md`

For these evals:
- treat behavior traces and hard checks as stronger than polished summary prose
- keep helper-skill proof weaker than public bundle doctrine
- avoid turning local helper behavior into omnibus scores or broad intelligence claims
```
