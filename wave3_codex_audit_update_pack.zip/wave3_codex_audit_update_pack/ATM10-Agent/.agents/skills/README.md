# Repo-local Codex skills for ATM10-Agent

These skills are local workflow helpers for `ATM10-Agent`.

They are **not**:
- public AoA skill canon,
- proof bundles,
- replacements for `AGENTS.md` or `AUDIT.md`.

They are here to make repeated local workflows easier for Codex to follow inside this repository.

## Current helper skills

- `atm10-change-verification`
- `atm10-safe-automation-audit`

## Design rules

- one workflow per skill
- prefer instructions over scripts
- keep safety-heavy skills explicit-only
- keep reports in `PLAN / DIFF / VERIFY / REPORT / RESIDUAL RISK`
- do not claim a check ran unless it actually ran
- do not let these helper skills redefine AoA ecosystem or proof-layer meaning
