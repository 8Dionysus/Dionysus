---
name: atm10-safe-automation-audit
description: Audit ATM10-Agent changes that touch automation safety, dry-run behavior, input-event routing, operator actions, service exposure, auth posture, or any path that could change game state or leak local runtime detail. Use before finalizing such work or when reviewing a risky diff. Do not use for narrow docs-only or repo-meta edits.
---

# Overview

Use this skill for the **highest-risk review path** in `ATM10-Agent`.

This is a **report-first audit skill**.
Its job is to identify boundary and safety risk, not to silently implement broad changes.

## Read first

1. `AGENTS.md`
2. `AUDIT.md`
3. `README.md`
4. `MANIFEST.md`
5. `docs/RUNBOOK.md`
6. `docs/SOURCE_OF_TRUTH.md`
7. the touched scripts, modules, tests, and public docs

## Use when

Use this skill when the task or diff touches:
- dry-run behavior
- real input-event routing
- automation intent -> plan -> dry-run flows
- operator actions or gateway action surfaces
- service exposure, loopback posture, or auth posture
- placeholders, logs, runs, paths, or public docs that could leak local runtime detail

## Do not use when

Do not use this skill as the main workflow for:
- ordinary low-risk refactors with no safety implications,
- docs-only work with no operational meaning,
- ecosystem-boundary questions that belong in `Agents-of-Abyss`,
- infra substrate work that belongs in `abyss-stack`.

If code or runnable behavior changed, pair this skill with `atm10-change-verification`.

## Steps

1. Determine whether the diff is safety-relevant.
   - If it is not, say so and hand back to the narrower workflow.

2. Audit the default posture.
   Check whether the change preserves:
   - local-first behavior
   - dry-run by default
   - no real input events by default
   - public-safe placeholders instead of workstation-specific detail
   - explicit env/config auth patterns instead of hardcoded tokens

3. Inspect the risky path.
   Ask:
   - Can a safe action now route to a game-state-changing input?
   - Did service exposure widen without a clear reason?
   - Did auth expectations change?
   - Did docs or examples start leaking private paths, hostnames, or runtime details?
   - Did new logs, run artifacts, or tokens become commit risks?

4. Classify findings using the repo-local audit severity.
   - `P0` for default-destructive or secret-leaking changes
   - `P1` for weakened dry-run, widened exposure, missing tests/docs updates, or unverified claims

5. If the task also changed code or runnable behavior, explicitly require `atm10-change-verification`.
   Do not pretend this audit skill replaces verification.

6. Stay report-first by default.
   Do not make silent broad edits unless the user explicitly asks for implementation.

## Output contract

Return:

### PLAN
- what risky surface is under review
- why this skill applies

### DIFF
- what changed in the risky path
- whether the change altered behavior, posture, docs, or all three

### VERIFY
- which verification commands have already been run
- which additional checks are still required
- whether `atm10-change-verification` must also run

### REPORT
- safety findings
- approval-required changes
- whether dry-run, input-event, service-exposure, or public-hygiene posture changed

### RESIDUAL RISK
- paths not exercised
- services not tested
- docs/examples still needing a privacy pass
