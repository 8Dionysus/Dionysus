---
name: atm10-change-verification
description: Run the mandatory verification stack when changes affect runtime code, tests, smoke paths, build or test behavior, scripts, gateway or operator entrypoints, retrieval, KAG, voice, or cross-service benchmark flows in ATM10-Agent. Skip for docs-only or repo-meta changes unless the user explicitly asks for the full verification stack.
---

# Overview

Use this skill to make sure work in `ATM10-Agent` is not reported complete before the right verification has been named and, when possible, run.

This is a **verification skill**, not a broad architecture skill.

## Read first

1. `AGENTS.md`
2. `AUDIT.md`
3. `README.md`
4. `MANIFEST.md`
5. `docs/RUNBOOK.md` when entrypoints or launch paths are touched
6. the touched scripts, modules, and tests

## Use when

Use this skill when changes affect:
- runtime code
- tests or test fixtures
- `scripts/`
- gateway or operator launch paths
- retrieval, KAG, voice, or benchmark flows
- build or test behavior
- profile-aware `combo_a` or operating-cycle logic

## Do not use when

Do not use this skill as the main workflow for:
- docs-only changes,
- repo-meta edits with no behavior impact,
- ecosystem-boundary questions that belong in `Agents-of-Abyss`,
- infra-runtime body work that belongs in `abyss-stack`.

For high-risk automation or exposure posture questions, pair or hand off to `atm10-safe-automation-audit`.

## Steps

1. Decide whether this skill applies.
   - If the task is docs-only or repo-meta-only, say so and explain why the full verification stack is being skipped.

2. Identify the touched surface.
   - Runtime code?
   - Tests?
   - Launch path?
   - Automation flow?
   - Cross-service or `combo_a` profile path?

3. Build the smallest correct verification stack.

4. Always include the baseline verification after meaningful code changes:
```powershell
cd <repo-root>
.\.venv\Scripts\Activate.ps1
python -m pytest
```

5. Add the nearest targeted check that matches the touched surface.

### Common targeted checks

#### General smoke path
```powershell
python scripts/phase_a_smoke.py
```

#### Gateway or operator launch path
```powershell
python scripts/start_operator_product.py --runs-dir runs
```

#### Automation intent chain
```powershell
python scripts/automation_intent_chain_smoke.py --intent-json tests/fixtures/intent_open_quest_book.json --runs-dir runs\smoke-intent
```

#### Cross-service benchmark or profile-aware service changes
```powershell
python scripts/cross_service_benchmark_suite.py --runs-dir runs\cross-service-suite --smoke-stub-voice-asr
```

#### `combo_a` operating-cycle or promotion logic
```powershell
python scripts/run_combo_a_operating_cycle.py --runs-dir runs --policy report_only --summary-json runs\nightly-combo-a-operating-cycle\operating_cycle_summary.json --summary-md runs\nightly-combo-a-operating-cycle\summary.md
```

6. If a relevant targeted check could not be run, say exactly why.
   - missing local dependency
   - no safe environment
   - task was report-first only
   - external service not available
   - user did not request an execution pass

7. Never claim a check ran unless it actually ran.

8. Keep the workflow narrow.
   - Do not widen into dependency changes, infra redesign, or new services without explicit human approval.
   - Do not enable real input events.
   - Do not weaken dry-run defaults.

## Output contract

Return:

### PLAN
- what the change touched
- which verification path applies

### DIFF
- what changed
- whether behavior changed or only docs/tests/metadata changed

### VERIFY
- `python -m pytest` status
- targeted checks actually run
- targeted checks not run and why

### REPORT
- current behavior after the change
- whether the default dry-run / local-first / public-safe posture changed

### RESIDUAL RISK
- untested entrypoints
- missing service dependencies
- profile paths not exercised
