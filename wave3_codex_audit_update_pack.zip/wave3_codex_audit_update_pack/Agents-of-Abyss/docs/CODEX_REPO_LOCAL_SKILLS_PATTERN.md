# CODEX_REPO_LOCAL_SKILLS_PATTERN.md

Pattern guide for repo-local Codex helper skills in AoA repositories.

## Purpose

This document defines how to add **repo-local helper skills** under `.agents/skills/` without confusing them with:
- public AoA skill canon in `aoa-skills`
- public proof canon in `aoa-evals`
- ecosystem ownership doctrine in `Agents-of-Abyss`

A repo-local helper skill is a **workflow helper** for a specific repository.
It is not automatically a public AoA skill, and it is not proof by itself.

## Why local helper skills exist

Use repo-local helper skills when a workflow is:
- repeated,
- repository-shaped,
- narrow enough to describe clearly,
- expensive to re-explain every time,
- valuable even when it stays instruction-only.

Good first candidates:
- change verification
- boundary or safety audit
- docs sync
- release/draft summary
- implementation strategy for one repo family

Bad first candidates:
- giant omnibus skills that try to do the whole repository
- skills that silently redefine public canon
- skills that depend on too many hidden assumptions
- skills that are really public `aoa-skills` candidates in disguise

## Path and scope

Repo-local helper skills should live under:

```text
<repo>/.agents/skills/
```

They are meant to be discovered only inside the repository where they belong.

Do not treat them as:
- user-global defaults,
- ecosystem-wide skill canon,
- proof objects,
- a reason to weaken `AGENTS.md`.

`AGENTS.md` still owns the always-on rules.
Local helper skills own repeatable workflows.

## First-wave skill families

The safest first wave is usually two skills:

### 1. Change verification
This skill should:
- activate for real code or runnable-behavior changes,
- gather the smallest mandatory verification stack,
- run or name the nearest relevant checks,
- report what was and was not run,
- stay narrow.

Usually:
- allow implicit invocation when the description is precise enough,
- stay instruction-first before adding scripts.

### 2. Boundary audit
This skill should:
- audit the most dangerous boundary surfaces,
- produce a report-first output,
- avoid hidden edits by default,
- escalate approvals and residual risk clearly.

Usually:
- stay explicit-only or near-explicit,
- be used before finalizing risky changes.

## Naming convention

Use this shape:

```text
<repo-slug>-<workflow-name>
```

Examples:
- `atm10-change-verification`
- `atm10-safe-automation-audit`
- `abyss-stack-change-verification`
- `abyss-stack-boundary-audit`

Keep names stable, descriptive, and repository-specific.

## Description rules

The `description` is one of the main routing signals.
Write it as a trigger contract, not a slogan.

A strong description says:
- when the skill should trigger,
- what surfaces it is for,
- what it should skip,
- which repository it belongs to.

### Good pattern
“Run the mandatory verification stack when changes affect runtime code, tests, build/test behavior, or named runnable paths in `<repo>`; skip for docs-only or repo-meta changes unless the user asks for full verification.”

### Weak pattern
“Verify the repository.”

## Invocation policy

Use `agents/openai.yaml` to decide whether a skill can activate implicitly.

### Good defaults
- `change-verification`: usually `allow_implicit_invocation: true`
- `boundary-audit`: usually `allow_implicit_invocation: false`

Why:
- verification is common and pattern-shaped
- boundary audits are higher risk and should be triggered deliberately

## Skill shape

Prefer this minimal structure first:

```text
.agents/skills/
└─ <skill-name>/
   ├─ SKILL.md
   └─ agents/
      └─ openai.yaml
```

Only add `scripts/`, `references/`, or `assets/` when they genuinely reduce ambiguity or make behavior more deterministic.

Prefer instructions over scripts until you have real evidence that scripts are needed.

## What every helper skill should contain

### In `SKILL.md`
Include:
- `name`
- `description`
- overview
- read-first surfaces
- use / do-not-use boundaries
- imperative steps
- output contract

### Output contract
For AoA repo-local helper skills, the default output shape should usually include:
- `PLAN`
- `DIFF`
- `VERIFY`
- `REPORT`
- `RESIDUAL RISK`

That keeps behavior reviewable and aligned with the repo-local audit contracts.

## Relationship to public AoA repositories

### `aoa-skills`
If a local helper keeps proving useful across repositories and can be made public-safe, bounded, and reusable, then it may become a candidate for `aoa-skills`.

But do not prematurely promote:
- highly repo-specific commands
- private path assumptions
- local operational quirks
- infra-sensitive or workstation-specific behavior

### `aoa-evals`
A local helper skill is **not** a proof surface by default.

If you want to evaluate it:
- define a bounded claim,
- capture traces,
- build deterministic checks,
- keep the proof weaker than the workflow itself.

### `Agents-of-Abyss`
This repository remains the constitutional owner of ecosystem boundaries.
Local helper skills cannot override those boundaries.

## AGENTS.md trigger pattern

Put the highest-value mandatory skill triggers near the top of `AGENTS.md`.

Use short if/then rules, for example:
- run `$repo-change-verification` before marking work complete when runtime or build behavior changed
- run `$repo-boundary-audit` before finalizing risky exposure, secret, or safety changes

Keep the trigger rules shorter than the skills themselves.

## Rollout order for AoA

Recommended order:
1. operationally risky repos first
2. report-first skills before apply-first skills
3. instruction-only skills before scripted skills
4. repeated real usage before public promotion
5. bounded evals before any comparative claims

Current first-wave targets:
- `ATM10-Agent`
- `abyss-stack`

Good second-wave targets later:
- `aoa-skills`
- `aoa-evals`

## Anti-patterns

Do not:
- put ecosystem-wide doctrine inside repo-local skills
- let `.agents/skills` rewrite public `aoa-skills` or `aoa-evals` meaning
- create a “super skill” that handles every repo
- hide missing verification behind polished prose
- make risk-heavy skills silently implicit
- treat one helper skill’s success as proof of general agent quality

## Minimal review checklist

Before adding a repo-local helper skill, ask:
1. Is the workflow narrow?
2. Does the skill belong only to this repo?
3. Does the description say when it should and should not trigger?
4. Is the output contract explicit?
5. Is invocation policy intentional?
6. Does `AGENTS.md` tell Codex when the skill is mandatory?
7. Is it still clearly weaker than public AoA canon and proof layers?

If the answer to any of those is “no”, tighten the skill before rollout.
