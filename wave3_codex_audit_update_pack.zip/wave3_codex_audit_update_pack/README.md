# Wave 3: Repo-Local Codex Skills and Trace Harness

This pack prepares the third update wave for your repositories.

## Goal

Turn the audit contracts from waves 1 and 2 into repeatable repo-local workflows.

This wave introduces:
- first-wave repo-local Codex helper skills under `.agents/skills/`
- a shared pattern doc for how these local helper skills should be designed
- a bounded trace-harness doc and starter fixtures in `aoa-evals`

The focus is deliberately narrow:
- `ATM10-Agent`
- `abyss-stack`
- `aoa-evals` as the proof bridge
- `Agents-of-Abyss` as the doctrine bridge

## Why this wave now

The earlier waves defined:
- the audit spine,
- the seam between execution meaning and proof meaning,
- repo-local audit contracts for the most operationally risky repositories.

Now the next smallest stable step is to install a few recurring workflows as local helper skills instead of re-explaining them in every prompt.

## Included files

### New doctrine / bridge files
- `Agents-of-Abyss/docs/CODEX_REPO_LOCAL_SKILLS_PATTERN.md`
- `aoa-evals/docs/CODEX_REPO_LOCAL_TRACE_HARNESS.md`

### New repo-local skill directories
- `ATM10-Agent/.agents/skills/README.md`
- `ATM10-Agent/.agents/skills/atm10-change-verification/`
- `ATM10-Agent/.agents/skills/atm10-safe-automation-audit/`
- `abyss-stack/.agents/skills/README.md`
- `abyss-stack/.agents/skills/abyss-stack-change-verification/`
- `abyss-stack/.agents/skills/abyss-stack-boundary-audit/`

### New starter proof surfaces
- `aoa-evals/examples/codex_repo_local_skill_seed.csv`
- `aoa-evals/examples/codex_repo_local_skill_report.schema.json`

### Suggested AGENTS.md additions
- `Agents-of-Abyss/AGENTS.md`
- `ATM10-Agent/AGENTS.md`
- `abyss-stack/AGENTS.md`
- `aoa-evals/AGENTS.md`

See `PATCH_SNIPPETS.md` for exact insertion text.

## What this wave changes conceptually

### ATM10-Agent
Two repeatable local helper skills get installed:
- one for mandatory verification,
- one for the highest-risk safety and automation audit posture.

### abyss-stack
Two repeatable local helper skills get installed:
- one for change verification,
- one for exposure / secret / path / boundary auditing.

### aoa-evals
A bounded trace-harness pattern is added so these local helper skills can later be evaluated through JSONL traces and schema-shaped reports without pretending they are public AoA skill canon.

### Agents-of-Abyss
A doctrine file is added so future local helper skills across other repos follow the same naming, boundary, invocation, and report-shape pattern.

## Application order

1. Add the new files exactly as written.
2. Patch the four `AGENTS.md` files.
3. Start by using the new skills manually on real work in `ATM10-Agent` and `abyss-stack`.
4. Only after a few real runs, materialize the first bounded proof bundles in `aoa-evals`.
5. Then roll the pattern out to `aoa-skills`, `aoa-evals`, or other AoA repos if still useful.

## Validation reminders

This wave mostly adds instructions and helper metadata rather than code, but after applying it:

### ATM10-Agent
Use the skill on a real or dummy diff and make sure Codex sees it in `/skills`.
Then run the repo’s normal validation path if you touched code:
```powershell
.\.venv\Scripts\Activate.ps1
python -m pytest
python scripts/phase_a_smoke.py
```

### abyss-stack
Use the skill on a real or dummy diff and make sure Codex sees it in `/skills`.
Then run the repo’s normal validation path if you touched code:
```bash
python scripts/validate_stack.py
```

### aoa-evals
No new bundle is required yet, but sanity-check the examples and doc links, then keep the first actual eval wave bounded.

## What this wave does not do

This wave does **not** yet:
- add local helper skills to every AoA repo,
- create public eval bundles for these helper skills,
- add CI or GitHub Action orchestration,
- specialize `.codex/config.toml` profiles,
- introduce scripts inside the skills.

The first pass stays instruction-first and reviewable.

## Next wave after this one

Wave 4 should cover one of these, but not both at once:
- repo-local skills for `aoa-skills` and `aoa-evals` themselves,
- or a first bounded `aoa-evals` bundle family for the repo-local helper skills introduced here.
