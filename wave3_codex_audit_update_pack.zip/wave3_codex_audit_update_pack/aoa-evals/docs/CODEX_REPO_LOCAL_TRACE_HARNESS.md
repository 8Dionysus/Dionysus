# CODEX_REPO_LOCAL_TRACE_HARNESS.md

Trace-harness pattern for evaluating repo-local Codex helper skills through bounded evidence.

## Purpose

This document defines how to evaluate repo-local helper skills such as:
- `atm10-change-verification`
- `atm10-safe-automation-audit`
- `abyss-stack-change-verification`
- `abyss-stack-boundary-audit`

without pretending that success on a few helper workflows proves general intelligence or universal repo competence.

## What this harness is for

Use this harness when you want bounded evidence about whether a repo-local helper skill:
- triggers in the right situations,
- reads the right source surfaces,
- names or runs the correct verification commands,
- stays inside its workflow boundary,
- produces reviewable reports with explicit unknowns.

## What this harness is not for

This harness is **not**:
- a global score for Codex,
- a proof surface for the whole AoA ecosystem,
- a replacement for bundle-local eval doctrine,
- permission to treat helper-skill success as broad trust.

## Recommended bounded claim families

### 1. Trigger adherence
Can the helper skill activate on in-scope prompts and stay quiet on out-of-scope prompts?

### 2. Source-of-truth adherence
Does the helper read the right repo-local source surfaces before making claims?

### 3. Verification correctness
Does the helper name the right baseline and nearest targeted verification path?

### 4. Anti-overclaim reporting
Does the helper report unknowns, skipped checks, and residual risk explicitly?

### 5. Boundary retention
Does the helper avoid drifting into broader ecosystem ownership or proof claims?

## Minimal artifact set

For each case keep:
- prompt row
- JSONL trace
- final structured report
- deterministic check results
- optional rubric notes

## Recommended two-pass harness

### Pass 1: behavior trace
Run Codex in non-interactive mode and capture JSONL:
```bash
codex exec --json "<prompt>" > traces/<case-id>.jsonl
```

Use this pass for deterministic checks on what actually happened.

### Pass 2: structured final report
Run a second pass with a schema-shaped final output:
```bash
codex exec "<prompt>" --output-schema examples/codex_repo_local_skill_report.schema.json -o reports/<case-id>.json
```

Use this pass for a stable final report object.

Keep deterministic checks stronger than the structured summary.

## Why the harness is two-pass

The trace pass is best for behavioral evidence.
The schema pass is best for stable final output fields.

Do not let a polished final summary erase failed hard checks from the trace pass.

## Deterministic checks that matter first

Start with small hard checks.

### Source-surface checks
Did the helper read the repo-local instruction surfaces it needed, such as:
- `AGENTS.md`
- `AUDIT.md`
- the target repo’s main read-first docs
- the touched scripts, compose files, tests, or templates

### Verification checks
Did it:
- name the baseline verification,
- name the nearest targeted verification,
- distinguish between commands named and commands actually run,
- avoid claiming verification that did not occur?

### Boundary checks
Did it:
- stay inside repo-local scope,
- avoid rewriting public AoA skill canon,
- avoid broad proof claims,
- avoid infra-versus-meaning confusion?

### Reporting checks
Did it:
- include unknowns,
- include residual risk,
- mark skipped checks clearly?

## Activation measurement

For explicit-invocation cases, activation is straightforward.

For implicit-trigger cases, prefer a **behavioral signature** over a fantasy event:
- did it follow the expected workflow shape?
- did it name the correct repo-local commands?
- did it privilege the right source surfaces?

If the runtime later surfaces explicit skill-use markers in JSONL, treat them as helpful evidence, not the whole proof.

## Suggested trace parser fields

Your deterministic grader will usually want to extract:
- agent messages
- command executions
- file-change events, if any
- plan updates
- explicit unknowns
- final report text

For report-only audit helpers, the strongest signal may be:
- which files were read,
- which commands were named,
- how residual risk was expressed.

## Starter fixture strategy

Start with a small seed:
- 2 to 3 in-scope cases per helper skill
- 1 out-of-scope case per helper family
- at least one docs-only skip case
- at least one overclaim-risk case

Grow only from real failures or false activations.

## Suggested grading layers

### Layer 1: hard checks
Examples:
- expected source surfaces mentioned
- expected baseline command mentioned
- forbidden scope widening absent
- unknowns present when checks were skipped

### Layer 2: lightweight rubric
Only after the hard checks exist, add a rubric pass for:
- report clarity
- semantic vs metadata-only judgment
- quality of residual-risk wording

The rubric should remain weaker than the hard checks.

## Output schema usage

See:
- `examples/codex_repo_local_skill_report.schema.json`
- `examples/codex_repo_local_skill_seed.csv`

The schema is not a verdict by itself.
It is only a stable final report container.

## Recommended first public bundle candidates later

Once real runs exist, likely candidates are:
- `aoa-codex-repo-local-trigger-adherence`
- `aoa-codex-repo-local-verification-discipline`
- `aoa-codex-repo-local-boundary-reporting`

Each should stay bounded to one claim family.

## Anti-patterns

Do not:
- build one omnibus benchmark for every helper skill
- let a helper-skill eval speak louder than repo-local doctrine
- replace deterministic checks with vibes
- treat one repository’s helper success as proof for all repositories
- hide skipped verification behind smooth prose

## Current seed surfaces

This wave includes:
- `examples/codex_repo_local_skill_seed.csv`
- `examples/codex_repo_local_skill_report.schema.json`

Use them as starter surfaces only.
