# Planting Report

Use one report per planted seed whenever possible.

## Metadata

- Date: 2026-03-24
- Wave: none / queued future pack
- Seed: dialogue-memory-pack
- Source ref: dialogue-derived seed pack prepared outside repo before registration
- Target repo: Dionysus
- Planting status: proposed
- PR / commit / issue: not yet opened
- Maintainer: prepared for 8Dionysus

## Contract being planted

This proposal turns the current dialogue into three bounded future seed surfaces for `Dionysus`.

The pack does not open a new wave and does not overrule the current ToS live-next gate.
It prepares a coherent next cluster around derived memory planes, typed provenance lifts, and differentiable hot-memory discipline.

## Landed surfaces

- Human-readable surface:
  - `README.md`
  - three seed files under `seed_expansion/`
- Structural surface:
  - `seed-registry.append.dialogue-memory-pack.yaml`
- Validation surface:
  - manual review against current Dionysus source-of-truth order and registry contract

## Structural artifact

A three-seed pack with one registry append snippet that can be adopted later without changing current wave sovereignty.

## Validation

- Command run: manual contract check only
- Result: proposed pack keeps current `next_live_seed` untouched and does not open `tenth_wave.manifest.json`
- Manual review notes:
  - seed scope stays inside Dionysus as seed soil
  - repo-owned meaning is deferred to later plantings
  - current ToS live-next gate remains sovereign

## Deferred zones / non-goals

- no registry mutation applied
- no manifest opened
- no target-repo planting performed
- no claim that these seeds outrank the current ToS live-next surface

## Risks / follow-ups

- If registered too early, the pack may create seed noise behind an already gated ToS next move.
- If planted out of order, diffmem could arrive before explicit lift and writeback contracts exist.
- Use time-scoped wording if any of these seeds remain queued for a long period.

## Vocabulary preserved

- derived memory
- chunk_face
- graph_face
- provenance
- lift surface
- source-linked
- additive profile
- baseline-first
- writeback
- hot-memory
- eval gate
