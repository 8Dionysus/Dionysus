# Dialogue-derived seed pack for Dionysus

Date: 2026-03-24

This pack turns the current dialogue about vector memory, graph memory, and differentiable external memory into bounded future seed surfaces for `Dionysus`.

## Status

- proposal only
- does **not** open `tenth_wave.manifest.json`
- does **not** replace the current `navigation.next_live_seed`
- prepared as queued future seed surfaces that can be registered later if you choose

The current public `Dionysus` rules matter here:

- `Dionysus` is seed soil and dispatch, not the final home of repo-owned meaning.
- wave order stays sovereign over intuition.
- source-authored and repo-owned surfaces come before derived graph, export, or UI growth.
- current ToS live-next gate should remain intact until you explicitly change it.

## Included seeds

1. `seed.8dionysus.aoa.derived-memory-dual-substrate.v0.md`
   - fixes vector and graph as paired downstream memory organs
   - keeps authored truth and explicit memory objects upstream

2. `seed.8dionysus.aoa.typed-provenance-lifts.v0.md`
   - turns KAG lift families into explicit export contracts
   - aims to replace ad hoc graph inflation with typed, provenance-rich lifts

3. `seed.8dionysus.aoa.diffmem-hot-memory-controller.v0.md`
   - places differentiable memory inside runtime hot-memory only
   - keeps canonical memory and ToS source truth outside the neural controller

## Suggested planting order

1. Derived Memory Dual-Substrate
2. Typed Provenance Lifts
3. DiffMem Hot-Memory Controller

That order follows the same discipline already visible across AoA and ToS:

- structure before expansion
- explicit memory before derived retrieval surfaces
- provenance before graph ambition
- runtime augmentation only after deterministic contracts exist

## Suggested repo homes

- `aoa-memo`
- `aoa-kag`
- `ATM10-Agent`
- `aoa-evals`
- `aoa-agents`
- `abyss-stack`
- `Tree-of-Sophia` for bounded export-boundary notes only, not for runtime ownership

## Registry posture

A registry append snippet is included in:

- `seed-registry.append.dialogue-memory-pack.yaml`

Use it only after maintainer choice. If you append these entries:

- keep `wave: null`
- keep `registry_status: gated_next`
- keep the existing `navigation.next_live_seed` unchanged unless you explicitly decide otherwise

## Why these seeds exist

The dialogue resolved three important tensions:

1. Vector DB and Graph DB are important, but only as derived/runtime organs.
2. `aoa-kag` should ingest typed lifts with provenance, not become a free-floating empire of edges.
3. Differentiable memory is possible, but it belongs first in runtime hot-memory as a controller, not in canonical storage.

## Quick maintainer note

If you want the cleanest next move, register the three seeds as queued surfaces but leave them dormant behind the current ToS gate. When the moment comes to plant them, use one seed at a time and make each landing leave:

- one human-readable surface
- one structural artifact
- one validation note
- explicit non-goals
