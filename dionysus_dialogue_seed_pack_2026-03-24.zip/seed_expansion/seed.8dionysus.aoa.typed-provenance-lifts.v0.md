seed_id: seed.8dionysus.aoa.typed-provenance-lifts
title: Typed Provenance Lifts
profile_anchor: 8Dionysus
projects:
  - AoA
  - ToS
kind: knowledge-architecture
status: living
priority: high
parent_seed: seed.8dionysus.aoa.derived-memory-dual-substrate
tags:
  - kag
  - provenance
  - lifts
  - metadata-spine
  - relation-view
  - provenance-view
  - counterpart-edge
  - aoa-kag
  - Tree-of-Sophia
  - ATM10-Agent

# Seed: Typed Provenance Lifts

## Назначение

Этот seed переводит `aoa-kag` из мира общих намерений в мир явных lift-contract'ов.

Нужно не просто говорить, что у нас будет metadata spine, chunk map, relation view и provenance view, а дать каждому lift-семейству inspectable export surface, который downstream runtime сможет читать без потери source linkage.

## Корневой импульс

Сейчас у проекта уже есть правильная геометрия:

- `aoa-kag` определяет семейства derived surfaces
- `aoa-memo` готовит `chunk_face` и `graph_face`
- `Tree-of-Sophia` хранит source-authored знание и lineage law
- `ATM10-Agent` уже живет в hybrid retrieval / KAG мире

Следующий правильный шаг не в том, чтобы нарастить еще один graph-сервис, а в том, чтобы перестать кормить runtime неявными lift'ами и дать ему typed, provenance-rich exports.

## Что сеять

### 1. Lift manifest as first-class artifact

Каждый KAG-export должен иметь явный manifest с полями как минимум:

- `primary_source_class`
- `source_inputs`
- `derived_kind`
- `provenance_mode`
- `normalization_scope`
- `framework_readiness`
- `source_repo_linkage`

### 2. Lift families

Зафиксировать минимум шесть lift-семейств:

- `metadata_spine_projection`
- `section_or_chunk_map`
- `relation_view`
- `provenance_view`
- `node_or_edge_projection`
- `counterpart_edge_view`

### 3. Typed relation vocabulary

Дать bounded relation vocabulary вместо расплывчатого edge flood.
Минимальный стартовый набор может включать:

- `lineage_of`
- `interprets`
- `supported_by`
- `tension_with`
- `calibrates`
- `counterpart_of`
- `decision_about`
- `episode_from`
- `claim_from`
- `mentions`
- `derived_from_chunk`

### 4. Export examples

Оставить хотя бы по одному worked example для:

- source fragment -> chunk map
- memory object -> provenance view
- ToS concept -> counterpart edge view
- decision / episode -> relation view

### 5. Runtime ingestion contract

`ATM10-Agent` и другие runtime-поверхности должны читать lift exports как bounded datasets, а не как новую самодостаточную онтологию.
KAG ingestion должен уметь отвечать на вопрос: из какого source-owned surface этот derived unit поднят.

### 6. Eval gate

Нужны явные проверки на:

- provenance fidelity
- source-link survival
- contradiction marking
- fallback honesty
- graph inflation rate
- edge type drift

## Что не сеять сюда

- token cooccurrence как новую graph canon-форму
- lift без source refs
- hidden framework lock-in
- KAG как замену памяти, proof или authored source
- переписывание ToS смысла внутри `aoa-kag`

## Предпочтительные формы посадки

- `aoa-kag/docs/LIFT_FAMILIES.md`
- `aoa-kag/docs/PROVENANCE_MODELS.md`
- `aoa-kag/schemas/lift_manifest.schema.json`
- `aoa-kag/generated/lift_surface_registry.min.json`
- `aoa-kag/examples/provenance_view.example.json`
- `aoa-kag/examples/counterpart_edge_view.example.json`
- `aoa-memo/examples/kag_bridge.graph_face.example.json`
- `Tree-of-Sophia/docs/DERIVED_EXPORT_BOUNDARY.md`
- `ATM10-Agent/configs/kag_profiles/typed_lifts.contract.yaml`
- `aoa-evals/bundles/kag-lift-fidelity/`

## Задание для Codex

1. Сделать manifests обязательными для KAG-lift surfaces.
2. Зафиксировать bounded relation vocabulary.
3. Сохранить reconstructability: graph должен пересобираться из lift exports, а не жить как скрытая магия.
4. Показать один ToS-derived и один memo-derived worked example.
5. Привязать каждый export к eval gate до runtime promotion.

## Признак удачной посадки

После посадки ясно:

- какие семейства lift'ов реально существуют
- какое поле отвечает за provenance
- как downstream runtime читает lift surfaces
- как graph можно пересобрать без потери source linkage
- где заканчивается KAG и начинается source-owned meaning
