seed_id: seed.8dionysus.aoa.diffmem-hot-memory-controller
title: DiffMem Hot-Memory Controller
profile_anchor: 8Dionysus
projects:
  - AoA
kind: architecture-seed
status: living
priority: medium
parent_seed: seed.8dionysus.aoa.restartable-inquiry-loop
tags:
  - differentiable-memory
  - dnc
  - memnets
  - hot-memory
  - runtime
  - writeback
  - ATM10-Agent
  - aoa-agents
  - aoa-memo
  - aoa-evals

# Seed: DiffMem Hot-Memory Controller

## Назначение

Этот seed вводит differentiable external memory не как новый canonical store, а как runtime hot-memory controller.

Его место не в `Tree-of-Sophia` и не в `aoa-memo` как хранилище истины.
Его место рядом с runtime-задачей, где он помогает выбирать, сжимать, удерживать и предлагать writeback для краткого горизонта действия.

## Корневой импульс

Проекту действительно может понадобиться diffmem-слой, но только после того, как уже есть:

- explicit memory canon в `aoa-memo`
- derived retrieval / graph surfaces в `aoa-kag`
- restartable inquiry discipline
- baseline-first runtime posture

Иначе вместо живой рабочей памяти получится красивый нейронный алтарь без контрактов.

## Что сеять

### 1. Runtime-only seat

DiffMem-модуль живет в runtime-среде, например в `ATM10-Agent` или `aoa-agents`, но не становится owning home для долгосрочной памяти.

### 2. Initial job description

На первом этапе ему достаточно четырех ролей:

- rerank memory slots по текущему запросу и task state
- compress short-horizon state в bounded working summary
- propose writeback candidates
- propose deep-escalation or restart triggers

### 3. Explicit operating modes

Ввести явные режимы работы:

- `observe`
- `assist`
- `dry_writeback`
- `gated_writeback`

Переход к реальному writeback разрешается только через explicit policy.

### 4. Writeback through current object canon

DiffMem не invents a new mythic object family.
Он пишет назад только через существующий explicit canon:

- `state_capsule`
- `episode`
- `decision`
- `claim` candidate
- `pattern` candidate
- `provenance_thread`

### 5. Evaluation-first promotion

Нужны отдельные eval-поверхности на:

- retrieval gain vs baseline
- drift
- hallucinated writeback
- over-retention
- contradiction handling
- restart fidelity

### 6. Kill switch and fallback

Runtime должен уметь:

- мгновенно выключить diffmem path
- вернуться к deterministic baseline
- продолжить работу без скрытой деградации данных

## Что не сеять сюда

- diffmem как primary memory database
- silent writes в ToS
- скрытое изменение policy или role law
- замещение vector / graph stores нейронными слотами
- promotion без eval gate и writeback contract

## Предпочтительные формы посадки

- `ATM10-Agent/docs/DIFFMEM_CONTROLLER.md`
- `ATM10-Agent/schemas/diffmem_turn_state.schema.json`
- `ATM10-Agent/configs/runtime_profiles/combo_b_diffmem.yaml`
- `aoa-agents/docs/HOT_MEMORY_POSTURE.md`
- `aoa-memo/docs/DIFFMEM_WRITEBACK_SEAM.md`
- `aoa-memo/examples/diffmem_writeback.example.json`
- `aoa-evals/bundles/diffmem-hot-memory/`
- `abyss-stack/docs/runtime_memory_profiles.md`

## Задание для Codex

1. Начать не с full DNC, а с assist-layer controller.
2. Сначала реализовать rerank / compress / propose-writeback, а не neural source-of-truth.
3. Вывести все writeback actions в inspectable artifacts.
4. Добавить dry-run mode как обязательную стадию.
5. Допустить `combo_b_diffmem` только как additive profile после eval-прохода.

## Признак удачной посадки

После посадки ясно:

- где живет diffmem-модуль
- что именно он умеет делать
- какие объекты он может предложить к writeback
- как он выключается
- чем он лучше baseline и в каких пределах ему вообще разрешено существовать
