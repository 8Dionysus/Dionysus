seed_id: seed.8dionysus.aoa.derived-memory-dual-substrate
title: Derived Memory Dual-Substrate
profile_anchor: 8Dionysus
projects:
  - AoA
  - ToS
kind: architecture-seed
status: living
priority: high
parent_seed: seed.8dionysus.aoa.memory-thermodynamics
tags:
  - memory
  - vector-db
  - graph-db
  - chunk-face
  - graph-face
  - aoa-memo
  - aoa-kag
  - ATM10-Agent
  - qdrant
  - neo4j

# Seed: Derived Memory Dual-Substrate

## Назначение

Этот seed фиксирует для AoA / ToS пару downstream-memory плоскостей: vector-плоскость и graph-плоскость.

Они нужны как рабочие органы recall и relation work, но не как новый суверенный источник истины.
Source-authored surfaces остаются в owning repos, explicit memory objects остаются в `aoa-memo`, а нормализация и lift-слой уходят в `aoa-kag`.

## Корневой импульс

В проекте уже возникла правильная связка:

- `aoa-memo` умеет держать explicit objects и совместимые `chunk_face` / `graph_face`
- `aoa-kag` мыслится как derived substrate, а не новая империя графа
- `ATM10-Agent` уже живет с baseline-first hybrid path и additive `combo_a`

Теперь нужно закрепить одно правило: vector и graph должны стать парными derived organs, а не заменить authored truth.

## Что сеять

### 1. Derived-memory split

Зафиксировать правило:

- authored / source truth живет в owning repos
- explicit reviewable memory object живет в `aoa-memo`
- vector index и graph substrate живут downstream

### 2. Two compatible faces

Каждый memory object должен уметь дать:

- `chunk_face` для retrieval
- `graph_face` для relation, lineage и provenance lift

### 3. Dual recall posture

Ввести два базовых retrieval-режима:

- `chunk_first` для passage / episode / capsule recall
- `graph_expand` для relation / lineage / contradiction / counterpart expansion

Роутинг между ними должен быть явным, а не спрятанным в одном generic search.

### 4. Additive runtime posture

В runtime:

- baseline file / local path остается живым
- vector + graph профиль включается как additive profile
- failure в graph/vector path должен честно деградировать, а не ломать ответ

### 5. Provenance must survive both planes

И `chunk_face`, и `graph_face` обязаны нести:

- `source_refs`
- `owner_refs`
- `provenance_thread_id` или эквивалент
- `time_window` или temporal posture
- `authority_kind` / `authority`
- `confidence`
- `freshness`
- `lift_status`

### 6. ToS boundary

`Tree-of-Sophia` не хранится в graph DB как новая первичная форма.
Graph-проекции ToS допустимы только как derived surfaces после source-first law, stable IDs, templates и manual review boundaries.

## Что не сеять сюда

- giant single brain store
- embeddings как единственную форму памяти
- graph DB как новую метафизику проекта
- silent collapse между `aoa-memo`, `aoa-kag` и `Tree-of-Sophia`
- перевод всей памяти в runtime-only слой без explicit writeback objects

## Предпочтительные формы посадки

- `aoa-memo/docs/DERIVED_MEMORY_DUAL_SUBSTRATE.md`
- `aoa-memo/examples/memory_face.chunk.example.json`
- `aoa-memo/examples/memory_face.graph.example.json`
- `aoa-kag/docs/PROJECTION_LIFT_CONTRACT.md`
- `aoa-kag/schemas/lift_surface_manifest.schema.json`
- `ATM10-Agent/docs/HYBRID_MEMORY_POSTURE.md`
- `ATM10-Agent/configs/retrieval_profiles/combo_a.contract.yaml`
- `aoa-evals/bundles/derived-memory-dual-substrate/`

## Задание для Codex

1. Не переносить source of truth в vector / graph stores.
2. Описать pair-contract между `chunk_face` и `graph_face`.
3. Зафиксировать baseline-first и additive-profile posture.
4. Оставить хотя бы один schema-backed artifact на стороне `aoa-memo` и один на стороне `aoa-kag`.
5. Сохранить честный fallback при отказе derived path.

## Признак удачной посадки

После посадки ясно:

- где живет authored truth
- где живет explicit memory
- где живут vector и graph derivatives
- как query уходит в `chunk_first` или `graph_expand`
- как runtime деградирует без фальшивой магии, если derived path недоступен
