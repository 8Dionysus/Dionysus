# AoA Growth Refinery Contract Seed Pack

This pack is the next inner wave after the Codex-plane and the implementation docket.

Its purpose is to reduce ambiguity around the single most important missing seam:
**explicit candidate lineage across checkpoint -> reviewed candidate -> seed -> owner object**.

Use this pack when:
- the Codex-plane is already installed and you want the next wave to target the real growth nerve
- the implementation docket is too high-level to land safely without concrete contract text
- you want Codex to work from proposed source files, schemas, examples, and acceptance checks instead of improvising the lineage model
- you want one pack that can be landed in slices across `Agents-of-Abyss`, `aoa-sdk`, `aoa-skills`, `Dionysus`, `aoa-stats`, `aoa-evals`, `aoa-playbooks`, and `aoa-memo`

## What this pack contains

- doctrine and crosswalk notes for the federation center
- provisional lineage carry docs and schemas for `aoa-sdk`
- reviewed candidate contract and receipt examples for `aoa-skills`
- seed identity and planting-lineage docs for `Dionysus`
- growth-funnel stats contract for `aoa-stats`
- three starter eval bundles for `aoa-evals`
- one playbook starter for `aoa-playbooks`
- one writeback seam for `aoa-memo`
- examples plus a tiny structural validator for the lineage bundle

## What this pack is not

- not a replacement for the implementation docket
- not a runtime patch pack
- not a new sovereign layer
- not a reason to push more Codex infrastructure before the refinery nerve exists

## Recommended landing order

1. `Agents-of-Abyss`
2. `aoa-sdk`
3. `aoa-skills`
4. `Dionysus`
5. `aoa-stats`
6. `aoa-evals`
7. `aoa-playbooks`
8. `aoa-memo`

Then run the local validator in this pack against the example bundle and adapt the same logic to repo-local tests.

## Fast start

1. Read `WHY_NOW.md`
2. Read `contracts/candidate_lineage_contract_v1.md`
3. Read `TARGET_MAP.md`
4. Give Codex `CODEX_EXECUTION_PROMPT.md`
5. Land the pack in PR slices using `ACCEPTANCE_MATRIX.md`
