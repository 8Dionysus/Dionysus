# Codex execution prompt

Land this pack as the next internal wave of the AoA growth refinery.

Your job is not to improvise a new architecture. Your job is to turn the proposed files in this pack into the smallest honest source-owned changes across the target repositories.

## Primary goal
Introduce an explicit, non-sovereign candidate-lineage seam across:
- checkpoint carry in `aoa-sdk`
- reviewed candidate harvest in `aoa-skills`
- seed staging in `Dionysus`
- derived growth funnel in `aoa-stats`
- proof bundles in `aoa-evals`
- recurring cycle composition in `aoa-playbooks`
- failure/recovery writeback in `aoa-memo`

## Constraints
- keep federation ownership intact
- do not turn `aoa-routing` or `aoa-kag` into owner layers
- do not mint `candidate_ref` inside `aoa-sdk`
- do not mint `seed_ref` outside `Dionysus`
- do not turn stats into proof authority
- do not turn memo into proof authority
- do not collapse the recurring session-growth cycle into one skill

## Order
1. federation doctrine files
2. `aoa-sdk` carry docs, schemas, examples
3. `aoa-skills` reviewed candidate contract and examples
4. `Dionysus` seed identity docs and examples
5. `aoa-stats` funnel docs and schema
6. `aoa-evals` starter bundles
7. `aoa-playbooks` cycle starter
8. `aoa-memo` writeback seam

## Working style
- prefer additive docs, schemas, and examples before mutating runtime code
- keep first wave reviewable and narrow
- when uncertain, choose the smaller claim and write the uncertainty down
- after each repo slice, run the strongest non-mutating checks available in that repo
- preserve existing repository style and naming posture

## Deliverable
Produce a ledger that lists:
- landed files
- files intentionally deferred
- conflicts with existing surfaces
- acceptance checks run
- unresolved risks
