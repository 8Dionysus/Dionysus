# Codex review prompt

Inspect the landed growth-refinery lineage wave and answer these questions precisely.

1. Does one real chain exist from `cluster_ref` to `object_ref` without inventing a new sovereign layer?
2. Is `candidate_ref` minted only after reviewed harvest?
3. Is `seed_ref` minted only in `Dionysus`?
4. Do the stats surfaces summarize lineage without becoming routing or proof authority?
5. Do the eval bundles test lineage and owner-fit instead of only artifact quality?
6. Does the session-growth-cycle live as a playbook, not a skill?
7. Can memory store failure and recovery patterns linked to lineage without outranking owner truth?
8. Which parts remain scaffold-like and what is the smallest next move to make them more real?

Return:
- what landed cleanly
- what drifted from the pack
- what is still missing
- the next best PR slice
