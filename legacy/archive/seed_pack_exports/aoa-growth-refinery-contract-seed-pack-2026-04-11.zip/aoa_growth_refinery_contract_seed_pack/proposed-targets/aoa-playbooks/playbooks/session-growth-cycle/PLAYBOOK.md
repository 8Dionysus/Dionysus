# session-growth-cycle

## Intent
Coordinate the recurring route that turns session residue into reviewable growth without skipping bounded review or owner boundaries.

## Route
1. capture provisional checkpoint carry
2. build reviewed closeout context
3. harvest reviewed candidates
4. choose whether diagnosis, repair, progression, or quest follow-through is needed
5. stage seeds where appropriate
6. land bounded owner objects
7. run proof where proof is needed
8. write back failure lessons and recovery patterns
9. refresh derived growth-funnel observation

## Why this is a playbook
This route coordinates multiple repositories, handoffs, and evidence postures.
It is broader than one bounded skill.

## Inputs
- reviewed session artifact
- checkpoint carry
- touched repos
- current owner hypotheses
- explicit uncertainties

## Evidence expectations
- checkpoint carry notes
- one reviewed harvest packet or explicit drop
- one seed trace when staged
- one owner landing artifact when planted
- one proof artifact when proof is required
- memory writeback when a meaningful failure or recovery occurred

## Failure modes
- provisional carry mistaken for planted truth
- donor extraction without reviewed candidate identity
- seed staging without candidate identity
- stats treated as authority
- memory treated as authority
- repair that widens scope instead of reducing ambiguity
