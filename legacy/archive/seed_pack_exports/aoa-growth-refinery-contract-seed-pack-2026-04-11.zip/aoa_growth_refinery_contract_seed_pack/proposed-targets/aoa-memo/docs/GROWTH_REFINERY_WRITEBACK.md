# Growth Refinery Writeback

The growth refinery should write back to memory only when memory improves future handling of similar cases.

## Write back failure lessons when
- the candidate was misrouted
- the candidate was dropped for a recurring reason
- a repair widened scope or violated boundaries
- the same handoff failed repeatedly

## Write back recovery patterns when
- a candidate was successfully reanchored
- a thin-evidence object became stable through a repeatable proof or review move
- a bounded repair pattern worked more than once

## Required lineage fields when available
- `cluster_ref`
- `candidate_ref`
- `seed_ref`
- `object_ref`

## Negative rule
Memory records lessons and reusable recoveries.
It does not become final lineage truth.
