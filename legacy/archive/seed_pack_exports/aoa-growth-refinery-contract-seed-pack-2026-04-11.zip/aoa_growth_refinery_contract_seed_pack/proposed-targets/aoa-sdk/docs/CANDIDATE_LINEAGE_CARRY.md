# Candidate Lineage Carry

`aoa-sdk` owns provisional lineage carry at checkpoint and reviewed-closeout preparation time.

## What `aoa-sdk` should carry

Allowed in `aoa-sdk`:
- `cluster_ref`
- `owner_hypothesis`
- `owner_shape`
- `nearest_wrong_target`
- `evidence_refs`
- `axis_pressure`
- `status_posture`
- `supersedes`
- `merged_into`
- `drop_reason`

## What `aoa-sdk` should not mint

Not allowed in `aoa-sdk`:
- reviewed `candidate_ref`
- `seed_ref`
- owner-final `object_ref`

Those belong later in the chain.

## Why

Checkpoint carry is local-first and reviewable.
It must preserve promising material without silently promoting it into a stronger identity than the evidence supports.

## Suggested closeout-context shape

At reviewed closeout, `aoa-sdk` should be able to pass a candidate map that groups:
- one `cluster_ref`
- strongest current `owner_hypothesis`
- strongest current `nearest_wrong_target`
- one small set of `evidence_refs`
- provisional `axis_pressure`
- one review note about whether the object feels early, reanchor, thin-evidence, or stable

The closeout context should remain a carry surface, not a final packet.
