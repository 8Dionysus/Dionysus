# Growth Funnel Summary

`aoa-stats` should expose a dedicated derived summary for the growth refinery.

## Proposed surface
- `generated/candidate_lineage_summary.min.json`

## Purpose
Show how real candidates move through the refinery without turning stats into routing or proof authority.

## Suggested fields
- counts by stage
- counts by owner target
- counts by owner shape
- median time to seed
- median time to plant
- misroute counts
- supersession counts
- status-posture counts
- axis-pressure aggregates that remain clearly derived

## Required stages
- `checkpointed`
- `reviewed`
- `harvested`
- `seeded`
- `planted`
- `proved`
- `promoted`
- `superseded`
- `dropped`

## Negative rules
Do not:
- emit one total growth score
- infer planted truth from provisional carry alone
- outrank owner receipts
- outrank eval verdicts
