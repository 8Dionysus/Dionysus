# aoa-candidate-lineage-integrity

## Purpose
Prove whether a candidate lineage remains internally coherent across checkpoint carry, reviewed harvest, seed staging, and owner landing.

## Core claim
Given a bounded lineage bundle, this eval can determine whether the chain:
`cluster_ref -> candidate_ref -> seed_ref -> object_ref`
is internally consistent and reviewable.

## What it checks
- no stage appears before its prerequisite
- `candidate_ref` is absent before reviewed harvest
- `seed_ref` is absent before seed staging
- final `object_ref` is absent until owner landing
- dropped and superseded paths are represented honestly
- nearest-wrong-target and owner-hypothesis fields do not disappear without explanation

## Blind spots
- does not prove the candidate belongs in a specific owner repo
- does not prove the final object is high quality
- does not replace owner receipts

## Fixtures
Start with synthetic lineage bundles and one real anonymized lineage later.
