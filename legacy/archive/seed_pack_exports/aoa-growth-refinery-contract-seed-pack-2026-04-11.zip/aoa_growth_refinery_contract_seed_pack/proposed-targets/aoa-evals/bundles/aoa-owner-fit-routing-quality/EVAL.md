# aoa-owner-fit-routing-quality

## Purpose
Judge whether a reviewed candidate is being routed to the right owner layer with bounded, reviewable reasons.

## Core claim
This eval can compare:
- chosen `owner_hypothesis`
- chosen `owner_shape`
- rejected `nearest_wrong_target`
against the candidate evidence and route doctrine.

## What it checks
- one clear owner target exists
- nearest wrong target is plausible, not perfunctory
- routing is not trying to land source meaning first in `aoa-routing` or `aoa-kag`
- explanation quality is bounded and specific

## Blind spots
- does not prove final planted object quality
- does not prove long-term adoption or usefulness
