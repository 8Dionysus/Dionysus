# Reviewable Growth Refinery

AoA is not only a federation of repositories.
It is also a machine for turning repeated work, residue, and hard-won repair into reusable, reviewable growth.

## Core idea

A session produces more than a diff.
It may also produce:
- a reusable workflow
- a repeatable technique
- a candidate proof surface
- a memory lesson
- a repair pattern
- a seed for a future owner layer

The refinery exists so that these objects are:
- noticed
- carried without premature promotion
- reviewed
- routed to the right owning layer
- proved when needed
- written back into future work

## The refinery is reviewable

Nothing important should leap straight from local signal to canonical truth.

Instead the refinery prefers:
- provisional carry
- reviewed harvest
- bounded seed staging
- owner landing
- proof where proof is needed
- memory writeback where memory is useful

## The refinery is federated

Each repository keeps its proper role.

- `aoa-sdk` carries
- `aoa-skills` harvests
- `Dionysus` stages
- owner repositories own
- `aoa-stats` observes
- `aoa-evals` proves
- `aoa-memo` remembers
- `aoa-playbooks` composes recurring cycles

## The refinery is not

- not one global score
- not one secret routing brain
- not one chat transcript archive pretending to be growth
- not one giant automation with hidden authority

## First explicit seam

The first explicit seam for this doctrine is the candidate-lineage chain:

`cluster_ref -> candidate_ref -> seed_ref -> object_ref`

This chain is deliberately narrow.
It is enough to make growth legible without creating a new sovereign layer.
