# Candidate Lineage Crosswalk

This note names the cross-repo identity seam for one growth object without introducing a new sovereign layer.

## Why this note exists

The AoA ecosystem already has:
- local checkpoint carry
- reviewed donor harvest
- seed staging and planting
- derived observability
- proof bundles
- memory writeback

What it lacked was one explicit crosswalk that makes the same growth object legible as it moves across those surfaces.

## Ownership posture

This crosswalk does not create a new owner.
It only names how one object is carried across existing owners.

- `aoa-sdk` owns provisional checkpoint carry
- `aoa-skills` owns reviewed candidate identity
- `Dionysus` owns seed identity and planting trace
- owning repositories own final object identity
- `aoa-stats` owns derived observation only
- `aoa-evals` owns bounded proof only
- `aoa-memo` owns bounded memory only

## Canonical chain

`cluster_ref -> candidate_ref -> seed_ref -> object_ref`

## Why there is no new global lineage object in v1

v1 intentionally avoids introducing a separate sovereign `lineage_ref`.
The chain itself is enough for the first wave and keeps surface area smaller.

If later waves need a convenience transport key, it must remain derivative and never outrank the chain or owner truth.

## Keep-out zones

Do not treat:
- `aoa-routing` as the first owner of lineage meaning
- `aoa-kag` as the first owner of lineage meaning
- stats as the final truth of lineage state
- memory as the final truth of lineage state

## Cross-repo carry fields

These fields should survive the chain when honestly available:

- `owner_hypothesis`
- `owner_shape`
- `nearest_wrong_target`
- `evidence_refs`
- `axis_pressure`
- `status_posture`
- `supersedes`
- `merged_into`
- `drop_reason`
