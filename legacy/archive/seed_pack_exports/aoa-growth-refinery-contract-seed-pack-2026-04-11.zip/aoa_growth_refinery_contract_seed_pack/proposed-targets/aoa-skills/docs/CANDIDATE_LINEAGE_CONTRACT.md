# Candidate Lineage Contract for aoa-skills

`aoa-skills` is the first place where a reviewed reusable candidate should receive a stronger identity than a checkpoint cluster.

## Main rule

`aoa-session-donor-harvest` may mint `candidate_ref` only after:
- the session artifact is reviewed
- the reusable unit is bounded
- one chosen owner hypothesis exists
- one nearest-wrong target was considered honestly

## Why donor-harvest is the right seam

Donor harvest already answers:
- what reusable unit emerged
- what its owner shape is
- what the owner repository should be
- what tempting target should be rejected
- which next artifact is the smallest honest move

That makes it the right seam for reviewed candidate identity.

## Required candidate fields

A kept candidate should carry:
- `candidate_ref`
- `cluster_ref` when available
- `owner_hypothesis`
- `owner_shape`
- `nearest_wrong_target`
- `status_posture`
- `evidence_refs`
- `supersedes`
- `merged_into`
- `drop_reason`

## Negative rules

Do not:
- mint `candidate_ref` for theme clouds or vague resonance
- mint `candidate_ref` for an unreviewed session
- route the first owner to `aoa-routing` or `aoa-kag`
- treat `candidate_ref` as a final planted object
