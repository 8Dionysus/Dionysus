# Candidate Seed Identity

`Dionysus` is the first place where a reviewed candidate becomes a staged seed.

## Main rule

Mint `seed_ref` only when:
- a reviewed `candidate_ref` exists
- the candidate is bounded enough to stage
- one seed wave or staging surface can honestly hold it

## Why this belongs in Dionysus

`Dionysus` already owns:
- wave manifests
- seed sources
- seed staging
- planting protocol
- planting trace

That makes it the correct home for `seed_ref`.

## Required seed-lineage carry

Each seed staging entry should preserve:
- `candidate_ref`
- `cluster_ref` when available
- `seed_ref`
- `owner_hypothesis`
- `owner_shape`
- `status_posture`
- `lifecycle_status`
- `evidence_refs`
- `supersedes`
- `merged_into`
- `drop_reason`

## Suggested lifecycle states

- `staged`
- `open-wave`
- `planting-in-progress`
- `planted`
- `superseded`
- `dropped`

## Negative rules

Do not:
- mint `seed_ref` without a reviewed candidate
- let seed staging become final owner truth
- use staging notes as stronger than opened live wave surfaces
