# Target map

## Federation center
- `Agents-of-Abyss/docs/CANDIDATE_LINEAGE_CROSSWALK.md`
- `Agents-of-Abyss/docs/REVIEWABLE_GROWTH_REFINERY.md`

## aoa-sdk
- `aoa-sdk/docs/CANDIDATE_LINEAGE_CARRY.md`
- `aoa-sdk/schemas/checkpoint_lineage_hint.schema.json`
- `aoa-sdk/examples/checkpoint_lineage_hint.example.json`
- `aoa-sdk/examples/closeout_context.lineage.example.json`

## aoa-skills
- `aoa-skills/docs/CANDIDATE_LINEAGE_CONTRACT.md`
- `aoa-skills/references/candidate-lineage-receipt-schema.yaml`
- `aoa-skills/examples/harvest_packet.lineage.example.json`
- `aoa-skills/examples/harvest_packet_receipt.lineage.example.json`

## Dionysus
- `Dionysus/docs/CANDIDATE_SEED_IDENTITY.md`
- `Dionysus/schemas/seed_lineage_entry.schema.json`
- `Dionysus/examples/seed_lineage_entry.example.json`
- `Dionysus/examples/seed_registry.lineage.snippet.yaml`

## aoa-stats
- `aoa-stats/docs/GROWTH_FUNNEL_SUMMARY.md`
- `aoa-stats/schemas/candidate_lineage_summary.schema.json`
- `aoa-stats/examples/candidate_lineage_summary.example.json`

## aoa-evals
- `aoa-evals/bundles/aoa-candidate-lineage-integrity/EVAL.md`
- `aoa-evals/bundles/aoa-owner-fit-routing-quality/EVAL.md`
- `aoa-evals/bundles/aoa-repair-boundedness/EVAL.md`

## aoa-playbooks
- `aoa-playbooks/playbooks/session-growth-cycle/PLAYBOOK.md`

## aoa-memo
- `aoa-memo/docs/GROWTH_REFINERY_WRITEBACK.md`
- `aoa-memo/examples/failure_lesson_memory.lineage.example.json`
- `aoa-memo/examples/recovery_pattern_memory.lineage.example.json`
