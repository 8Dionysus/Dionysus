# Candidate lineage contract v1

## Purpose

This contract defines the narrow identity seam for one growth object as it moves from local checkpoint carry into reviewed harvest, seed staging, and final owner landing.

It does **not** create a new owner layer.
It does **not** replace source-owned objects.
It does **not** outrank owner repositories.

## Core chain

The canonical chain is:

`cluster_ref -> candidate_ref -> seed_ref -> object_ref`

### `cluster_ref`
- minted in `aoa-sdk`
- scope: local checkpoint carry and reviewed closeout preparation
- status posture: provisional
- authority: control-plane carry only
- must never be treated as a landed object identity

### `candidate_ref`
- minted in `aoa-skills`, specifically in the reviewed donor-harvest seam
- scope: reviewed reusable candidate identity
- status posture: reviewed but not yet seeded or planted
- authority: reviewed candidate carry, not final owner truth

### `seed_ref`
- minted in `Dionysus`
- scope: seed staging, dispatch, planting trace
- status posture: bounded staged identity
- authority: seed garden and dispatch layer only

### `object_ref`
- minted or resolved in the final owning repository
- scope: source-owned landed object
- status posture: final owner truth for that object class
- authority: owning repository

## Required metadata carried across stages

Every stronger stage should preserve or explicitly update:

- `owner_hypothesis`
- `owner_shape`
- `nearest_wrong_target`
- `evidence_refs`
- `axis_pressure`
- `supersedes`
- `merged_into`
- `drop_reason`
- `status_posture`

## Minimal field dictionary

### `owner_hypothesis`
A best current statement of the expected owning repository.
Allowed examples:
- `aoa-skills`
- `aoa-playbooks`
- `aoa-evals`
- `aoa-memo`
- `aoa-agents`
- `aoa-techniques`
- `hold`

### `owner_shape`
The expected object class.
Allowed examples:
- `skill`
- `playbook`
- `eval`
- `memo`
- `agent`
- `technique`
- `hold`

### `nearest_wrong_target`
The strongest tempting target that was rejected.
This exists to preserve diagnostic value and future routing lessons.

### `axis_pressure`
A bounded multi-axis hint, not a total score.
Suggested v1 axes:
- `boundary_integrity`
- `execution_reliability`
- `change_legibility`
- `review_sharpness`
- `proof_discipline`
- `provenance_hygiene`
- `deep_readiness`

### `status_posture`
One of:
- `early`
- `reanchor`
- `thin-evidence`
- `stable`

## Lifecycle states

Suggested v1 crosswalk states:
- `checkpointed`
- `reviewed`
- `harvested`
- `seeded`
- `planted`
- `proved`
- `promoted`
- `superseded`
- `dropped`

Not every lineage must reach every state.

## Negative rules

Do not:
- mint `candidate_ref` inside `aoa-sdk`
- mint `seed_ref` outside `Dionysus`
- use stats as the authority for lineage truth
- use memo as the authority for lineage truth
- use routing as the first owning destination
- convert one chain into one global score

## Example chain

- `cluster_ref = "checkpoint/2026-04-11/cp-01"`
- `candidate_ref = "candidate/2026-04-11/cand-aoa-session-growth-cycle"`
- `seed_ref = "seed/2026-04-12/sgc-wave-001"`
- `object_ref = "playbook:session-growth-cycle"`

Each stage may exist at a different time and in a different repository.
The chain is still one object biography.
