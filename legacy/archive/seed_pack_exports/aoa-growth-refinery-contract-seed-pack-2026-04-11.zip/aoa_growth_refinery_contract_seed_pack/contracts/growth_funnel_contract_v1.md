# Growth funnel contract v1

## Purpose

Define the derived read-model for observing the growth refinery without turning observability into sovereignty.

This contract belongs conceptually in `aoa-stats`.

## Funnel stages

The v1 funnel is:

`observed -> checkpointed -> reviewed -> harvested -> seeded -> planted -> proved -> promoted -> superseded_or_dropped`

### Definitions

- `observed`: local signal exists, but no lineage carry required yet
- `checkpointed`: a checkpoint ledger has accepted the signal into provisional carry
- `reviewed`: the signal has survived reviewed closeout reading
- `harvested`: a reviewed candidate has been emitted
- `seeded`: the candidate has entered `Dionysus` staging
- `planted`: the candidate has landed in an owning repository
- `proved`: bounded proof exists that the landed object meets its claim
- `promoted`: explicit promotion or release posture exists
- `superseded_or_dropped`: chain ended, merged, or was intentionally retired

## Required summary lenses

The funnel summary should answer:

- how many lineages are currently at each stage
- how many lineages moved between stages in the current observation window
- which owner targets are drawing the most reviewed candidates
- where misroutes and drops cluster
- how long reviewed candidates take to reach seed and plant
- which status postures dominate at each stage

## Required non-score posture

The funnel must not emit one total "growth score".

Instead prefer:
- counts by stage
- counts by owner target
- time-to-stage distributions
- misroute counts
- supersession counts
- status posture counts
- axis-pressure aggregates that stay clearly derived

## Suggested v1 derived rates

- `owner_ambiguity_rate`
- `misroute_rate`
- `time_to_seed_median_days`
- `time_to_plant_median_days`
- `supersession_rate`
- `thin_evidence_rate`
- `repair_success_after_diagnosis_rate`

## Negative rules

Do not:
- use the funnel as the routing authority
- use the funnel as proof authority
- infer stronger state transitions than receipts and owner surfaces support
- treat provisional checkpoint carry as final planted truth
