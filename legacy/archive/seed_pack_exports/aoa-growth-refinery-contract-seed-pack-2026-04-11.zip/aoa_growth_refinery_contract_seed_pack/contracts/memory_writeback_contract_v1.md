# Growth refinery memory writeback contract v1

## Purpose

Define how failure lessons and recovery patterns should link back to lineage without turning memory into proof or ownership.

## Writeback targets

### Failure lesson memory
Use when:
- a candidate was misrouted
- a candidate was dropped after honest review
- a repair attempt widened scope or damaged boundedness
- a promising lineage stalled repeatedly at the same handoff

Carry:
- `cluster_ref` when available
- `candidate_ref` when available
- `seed_ref` when available
- `object_ref` when available
- `nearest_wrong_target`
- `drop_reason`
- `owner_hypothesis`
- short diagnosis notes
- what to watch next time

### Recovery pattern memory
Use when:
- a misrouted candidate was reanchored to the right owner
- a thin-evidence candidate was stabilized through better proof
- a stalled lineage moved cleanly after a bounded intervention
- a repeated confusion resolved into a reusable re-entry pattern

Carry:
- strongest available lineage refs
- the successful reanchor or repair move
- why it worked
- what preconditions mattered
- when not to reuse the pattern

## Negative rules

Do not:
- claim that memory proves correctness
- replace owner receipts with memory objects
- let memory become the only surviving source of a lineage state
