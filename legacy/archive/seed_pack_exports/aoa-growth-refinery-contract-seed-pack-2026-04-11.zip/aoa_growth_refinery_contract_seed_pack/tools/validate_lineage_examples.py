#!/usr/bin/env python3
"""Validate the structural consistency of the example lineage bundle."""
from __future__ import annotations

import json
import sys
from pathlib import Path


def load_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as fh:
        return json.load(fh)


def main() -> int:
    bundle = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1] / "examples" / "lineage_bundle_v1"
    files = {
        "checkpoint": bundle / "checkpoint_lineage_hint.json",
        "harvest": bundle / "harvest_packet_candidate.json",
        "seed": bundle / "seed_lineage_entry.json",
        "summary": bundle / "candidate_lineage_summary.json",
    }
    missing = [str(p) for p in files.values() if not p.exists()]
    if missing:
        print("missing files:", *missing, sep="\n- ")
        return 2

    checkpoint = load_json(files["checkpoint"])
    harvest = load_json(files["harvest"])
    seed = load_json(files["seed"])
    summary = load_json(files["summary"])

    errors: list[str] = []

    if "candidate_ref" in checkpoint:
        errors.append("checkpoint example must not mint candidate_ref")
    if "seed_ref" in checkpoint:
        errors.append("checkpoint example must not mint seed_ref")
    if checkpoint.get("cluster_ref") != harvest.get("cluster_ref"):
        errors.append("cluster_ref mismatch between checkpoint and harvest")
    if "candidate_ref" not in harvest:
        errors.append("harvest example must mint candidate_ref")
    if "seed_ref" in harvest:
        errors.append("harvest example must not mint seed_ref")
    if harvest.get("candidate_ref") != seed.get("candidate_ref"):
        errors.append("candidate_ref mismatch between harvest and seed")
    if "seed_ref" not in seed:
        errors.append("seed example must mint seed_ref")
    if seed.get("owner_hypothesis") != harvest.get("owner_hypothesis"):
        errors.append("owner_hypothesis mismatch between harvest and seed")
    if seed.get("object_ref") is None:
        errors.append("seed example should carry object_ref when lifecycle_status is planted")
    stage_counts = summary.get("stage_counts", {})
    for key in ("checkpointed", "reviewed", "harvested", "seeded", "planted"):
        if stage_counts.get(key, 0) < 1:
            errors.append(f"summary stage_counts.{key} must be >= 1 for the happy-path example")

    if errors:
        print("lineage example validation failed:")
        for err in errors:
            print(f"- {err}")
        return 1

    print("lineage example validation passed")
    print(f"cluster_ref: {checkpoint['cluster_ref']}")
    print(f"candidate_ref: {harvest['candidate_ref']}")
    print(f"seed_ref: {seed['seed_ref']}")
    print(f"object_ref: {seed['object_ref']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
