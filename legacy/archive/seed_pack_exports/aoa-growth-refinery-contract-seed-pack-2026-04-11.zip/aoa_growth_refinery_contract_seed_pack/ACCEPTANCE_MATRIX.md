# Acceptance matrix

Use these as merge gates, not merely as aspirations.

## PR-1 federation doctrine
Pass when:
- `CANDIDATE_LINEAGE_CROSSWALK.md` and `REVIEWABLE_GROWTH_REFINERY.md` exist
- neither file assigns new sovereign ownership to the lineage seam
- the crosswalk explicitly keeps `aoa-routing` and `aoa-kag` derivative

## PR-2 aoa-sdk carry
Pass when:
- checkpoint lineage hint schema exists
- closeout context example can carry `cluster_ref`, provisional `owner_hypothesis`, `nearest_wrong_target`, `axis_pressure`, and `evidence_refs`
- docs explicitly say that `candidate_ref` is not minted in `aoa-sdk`

## PR-3 aoa-skills reviewed candidate
Pass when:
- reviewed `candidate_ref` appears in the donor-harvest contract
- receipt schema can carry reviewed candidate identity
- examples show one accepted candidate and one rejected nearest-wrong target
- docs keep `HARVEST_PACKET` bounded and reviewable

## PR-4 Dionysus seed identity
Pass when:
- `seed_ref` is assigned only in seed staging / dispatch surfaces
- seed lifecycle states are explicit
- seed docs preserve `Dionysus` as seed garden, not final owner

## PR-5 aoa-stats funnel
Pass when:
- `candidate_lineage_summary` schema exists
- funnel stages are explicit and non-score-based
- stats remain derived and do not claim routing or proof authority

## PR-6 aoa-evals proof bundles
Pass when:
- three starter eval bundles exist
- each bundle states claim limits and blind spots
- one bundle specifically checks lineage integrity, not just output quality

## PR-7 aoa-playbooks cycle
Pass when:
- one session-growth-cycle playbook exists
- it coordinates handoffs, fallbacks, evidence, and memory writeback
- it does not collapse into one bounded skill

## PR-8 aoa-memo writeback
Pass when:
- failure and recovery examples both tie back to lineage fields
- docs say memory is support and recall, not proof
- misroutes, drops, and repairs can be written back without outranking owner truth

## Cross-repo final gate
Pass when:
- one example chain can be followed end-to-end:
  `cluster_ref -> candidate_ref -> seed_ref -> object_ref`
- dropped and superseded paths are both representable
- at least one structural validator or test proves the chain is internally consistent
