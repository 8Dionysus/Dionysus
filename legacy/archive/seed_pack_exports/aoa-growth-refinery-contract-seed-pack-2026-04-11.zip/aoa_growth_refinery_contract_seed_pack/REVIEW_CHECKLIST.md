# Review checklist

Use this after landing the pack.

- Does the federation center now name the growth refinery and candidate-lineage chain explicitly?
- Does `aoa-sdk` carry only provisional lineage hints?
- Does `aoa-skills` mint reviewed `candidate_ref` only after real harvest?
- Does `Dionysus` mint `seed_ref` only after real reviewed candidates exist?
- Does `aoa-stats` publish a growth funnel without totalizing score behavior?
- Do evals prove lineage integrity and owner fit?
- Does the playbook coordinate the whole session-growth cycle?
- Can memo write back both failure lessons and recovery patterns using lineage fields?
