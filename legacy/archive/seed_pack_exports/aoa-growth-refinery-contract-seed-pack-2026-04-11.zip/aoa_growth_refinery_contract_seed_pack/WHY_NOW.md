# Why this pack exists now

The current AoA public shape already has:
- local-first checkpoint carry in `aoa-sdk`
- reviewed post-session harvest in `aoa-skills`
- seed staging and planting in `Dionysus`
- derived observability in `aoa-stats`
- portable proof in `aoa-evals`
- recurring scenario composition in `aoa-playbooks`
- failure and recovery memory in `aoa-memo`

What is still missing is one explicit, narrow, non-sovereign lineage seam that lets one real growth object stay legible across those layers.

Without that seam:
- checkpoint notes can hold promising material but lose identity when they cross into reviewed closeout
- donor harvest can emit bounded packets without a stable reviewed candidate identity
- seed staging can hold real work without a clear contract tying it back to one candidate
- planted owner objects can be traced only by convention and prose
- stats can summarize nearby events without a proper growth funnel
- evals can judge outputs without proving the lineage chain itself
- memory can store lessons and recovery patterns without a first-class link to dropped, misrouted, or repaired candidates

This pack narrows that gap.
