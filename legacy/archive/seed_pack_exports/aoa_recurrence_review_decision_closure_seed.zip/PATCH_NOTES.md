# Patch notes

## `aoa-sdk/src/aoa_sdk/recurrence/models.py`

Adds owner-review decision, decision ledger, suppression memory, and close-report models.

## `decisions.py`

Adds queue item lookup, decision template generation, close report generation, ledger generation, and suppression-memory generation.

## `api.py`, `io.py`, `cli.py`

Adds decision template and close surfaces plus persistence helpers.

## Safety posture

- Templates are not verdicts.
- Suppression rules are narrow and visible.
- `lineage_bridge.owner_assigned_ref` is optional and must be owner-filled.
- SDK carries `cluster_ref`; it does not mint `candidate_ref`, `seed_ref`, or `object_ref`.
