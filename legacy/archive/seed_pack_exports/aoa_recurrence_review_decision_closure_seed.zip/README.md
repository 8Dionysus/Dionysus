# AOA Recurrence Review Decision Closure Seed

This delta seed adds owner-review decision closure above review queues and dossiers.

It adds:

- `aoa_sdk.recurrence.decisions`
- `OwnerReviewDecision`
- `ReviewDecisionLedger`
- `ReviewSuppressionMemory`
- `ReviewDecisionCloseReport`
- CLI group: `aoa recur review decision-template` and `aoa recur review close`
- fallback script: `scripts/review_decision_closure.py`

It preserves the core rule: beacons surface pressure; owner decisions close pressure; SDK does not mint owner canon or object refs.
