# Codex landing brief: recurrence review decision closure

Land this seed after the live observation producers seed.

1. Merge the updated recurrence models, API, IO, CLI, and new `decisions.py`.
2. Add schemas and examples.
3. Run:

```bash
python -m py_compile src/aoa_sdk/recurrence/decisions.py src/aoa_sdk/recurrence/models.py src/aoa_sdk/recurrence/api.py src/aoa_sdk/recurrence/io.py src/aoa_sdk/recurrence/cli.py
python -m pytest -q tests/test_recurrence_review_decision_closure_seed.py
```

4. Generate a decision template from a queue item:

```bash
python scripts/review_decision_closure.py --workspace-root /srv/workspace template \
  --queue .aoa/recurrence/review-queues/latest.json \
  --item-ref review-item:0001 \
  --decision defer \
  --output .aoa/recurrence/review-decisions/decision.example.json
```

5. Close with owner-authored decisions:

```bash
python scripts/review_decision_closure.py --workspace-root /srv/workspace close \
  --queue .aoa/recurrence/review-queues/latest.json \
  --decision .aoa/recurrence/review-decisions/decision.example.json
```

Do not interpret generated templates as accepted decisions until owner review edits and commits them.
