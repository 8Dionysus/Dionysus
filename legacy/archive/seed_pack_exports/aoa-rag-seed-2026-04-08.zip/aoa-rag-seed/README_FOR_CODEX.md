# aoa-rag-seed

Snapshot date: 2026-04-08

This pack is a curated downstream seed for Codex to help build a thin RAG skeleton that stays subordinate to source-owned surfaces and bounded KAG. It is not a new source of truth.

## What is inside

- `repos/Agents-of-Abyss/` gives federation law, layer roles, and ownership boundaries.
- `repos/Tree-of-Sophia/` gives the current source-owned tiny-entry seam, public compatibility authority surface, and canonical Zarathustra source node.
- `repos/aoa-kag/` gives bounded retrieval-ready and regrounding surfaces that point back to stronger refs.
- `repos/aoa-routing/` gives live entry and return maps for navigation without semantic takeover.
- `repos/aoa-memo/` gives the source-owned memo donor export and owner-boundary contracts.
- `repos/aoa-techniques/` gives the technique-side source-owned donor export used in current federation spine and projection.
- `repos/ATM10-Agent/` gives runtime reference for retrieval-first hybrid behavior and bounded degraded fallback.

## Suggested ingest posture

1. Load `constitutional_boundary` as control-plane constraints and ownership law.
2. Load `source_authority` as highest-precedence evidence.
3. Load `derived_kag` as secondary retrieval and regrounding aids.
4. Load `routing_orientation` as navigation metadata only.
5. Load `memo_bridge` as owner-boundary and writeback-adjacent contracts.
6. Load `technique_export` as supporting donor/export context.
7. Load `runtime_reference` only as implementation pattern reference.

## Hard rules for Codex

- Prefer canonical ToS node over public compatibility mirror when both match the same `node_id`.
- Prefer source-owned tiny-entry route over routing or derived entry guesses.
- Treat `aoa-routing` outputs as where-to-go-next hints, not as semantic truth.
- Treat `aoa-kag` packs as guidance-to-source, not as canon.
- Treat `aoa-memo` as owner of memory truth and writeback boundaries.
- Treat ATM10 files as runtime reference, not as ecosystem law.

## Suggested metadata fields in your index

- `repo`
- `repo_path`
- `group`
- `role`
- `priority`
- `suggested_handling`
- `sha256`

## Good first retrieval set

Start with this spine:

- `repos/Tree-of-Sophia/generated/kag_export.min.json`
- `repos/Tree-of-Sophia/examples/source_node.example.json`
- `repos/aoa-kag/generated/tos_text_chunk_map.min.json`
- `repos/aoa-kag/generated/tos_retrieval_axis_pack.min.json`
- `repos/aoa-kag/generated/federation_spine.min.json`
- `repos/aoa-routing/generated/federation_entrypoints.min.json`
- `repos/aoa-memo/generated/kag_export.min.json`
- `repos/aoa-techniques/generated/kag_export.min.json`

## When to reground

If a derived answer starts sounding stronger than the source that feeds it, step back through:

- `repos/aoa-kag/generated/return_regrounding_pack.min.json`
- `repos/Tree-of-Sophia/generated/kag_export.min.json`
- `repos/Tree-of-Sophia/examples/tos_tiny_entry_route.example.json`
- `repos/Tree-of-Sophia/tree/source/friedrich-nietzsche/thus-spoke-zarathustra/prologue-1/node.json`

## Package stats

- files: 42
- bytes: 442535

See `SEED_MANIFEST.json` for full provenance, priorities, checksums, and optional remote refs.
