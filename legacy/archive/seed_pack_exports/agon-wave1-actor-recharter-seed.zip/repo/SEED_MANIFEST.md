# Agon Wave I seed — Agonic Actor Rechartering

This seed is meant to be merged into the root of `aoa-agents` after the center-level Agon Wave 0 imposition gate has landed in `Agents-of-Abyss`.

Wave I does **not** implement Agon sessions, moves, verdicts, scars, retention, routing, runtime packets, or Tree-of-Sophia promotion. It recharters the existing `aoa-agents` role-bearing actors into explicit Agon-facing actor forms so future protocol work can read them without inventing agent ontology at the arena gate.

## What this seed adds

```text
docs/
  AGONIC_ACTOR_RECHARTERING.md
  AGENT_KIND_MODEL.md
  AGENT_SUBJECTIVITY_MODEL.md
  AGENT_OFFICE_MODEL.md
  AGENT_ARENA_ELIGIBILITY_MODEL.md
  AGENT_RESISTANCE_REVISION_POSTURE.md
  AGON_WAVE1_LANDING.md
schemas/
  agent_kind_v1.json
  agent_subjectivity_v1.json
  agent_office_overlay_v1.json
  agent_arena_eligibility_v1.json
  agent_resistance_revision_v1.json
profiles/adjuncts/
  kind/*.kind.json
  subjectivity/*.subjectivity.json
  office_overlay/*.office.json
  arena_eligibility/*.arena_eligibility.json
  resistance_revision/*.resistance_revision.json
generated/
  agent_agonic_formation_index.min.json
scripts/
  build_agent_agonic_formation_index.py
  validate_agent_agonic_formation.py
tests/
  test_agent_agonic_formation.py
examples/
  agent_agonic_formation.example.json
quests/
  AOA-AG-Q-AGON-0002-agonic-actor-recharter.md
  AOA-AG-Q-AGON-0003-formation-index-integration.md
```

## Merge posture

The seed intentionally does **not** edit:

- `schemas/agent-profile.schema.json`
- `profiles/*.profile.json`
- `generated/agent_registry.min.json`
- Codex subagent TOML projection outputs
- existing runtime seam surfaces

That is not softness. It is the first law of this landing: current profile surfaces remain the legacy role contract, while Agon-readiness becomes a required companion surface for actors that wish to survive the imposed Agon audit.

## After merge

Run from the `aoa-agents` root:

```bash
python scripts/build_agent_agonic_formation_index.py --check
python scripts/validate_agent_agonic_formation.py
python -m pytest -q tests/test_agent_agonic_formation.py
```

After those pass, Codex may choose to wire `validate_agent_agonic_formation.py` into `scripts/validate_agents.py` or `scripts/release_check.py`. This seed leaves that wiring as an owner-reviewed follow-up so the release baseline is not silently widened by a drop-in archive.

## Wave I invariant

An actor without these companion surfaces remains a legacy role actor. It may still serve the current repo, but it is not Agon-ready.

An Agon-ready actor has:

- explicit `kind`
- doctrine seed
- public self-image
- honor and shame conditions
- operational affects
- thought posture
- office overlay
- arena eligibility hints
- resistance rights
- revision obligations

This is not yet the arena. This is the forging of those who may later enter it.
