# Agon Wave XIV Seed: Retention and Rank Economy

This seed introduces the first retention and rank economy layer for Agon.

It lands after Wave XIII Mechanical Agon Trials over Duel Kernel. Wave XIV asks whether lessons survive re-entry and whether repeated retention pressure may produce rank or jurisdiction candidates.

## Landing order

1. `Agents-of-Abyss`
2. `aoa-memo`
3. `aoa-agents`
4. `aoa-evals`
5. `aoa-stats`
6. `aoa-sdk`

## What this seed allows

- define center-owned retention and rank economy law;
- prepare reviewable retention check requests and result candidates;
- separate rank standing from earned jurisdictions;
- prepare rank mutation candidates without applying them;
- prepare memo, agent, eval, stats, and SDK owner surfaces;
- expose recurrence observations over retention/rank pressure without hidden scheduling.

## What this seed forbids

- live verdict authority;
- durable scar writes;
- retention execution without owner review;
- rank or trust mutation;
- closure grants;
- live summon;
- Tree of Sophia or KAG promotion;
- hidden scheduler action;
- assistant contestant drift;
- center takeover of owner truth.

## Commands

In `Agents-of-Abyss`:

```bash
python scripts/build_agon_retention_rank_economy_registry.py --check
python scripts/validate_agon_retention_rank_economy.py
python -m pytest -q tests/test_agon_retention_rank_economy.py
```

In `aoa-memo`:

```bash
python scripts/build_agon_retention_rank_memo_bridge_registry.py --check
python scripts/validate_agon_retention_rank_memo_bridge.py
python -m pytest -q tests/test_agon_retention_rank_memo_bridge.py
```

In `aoa-agents`:

```bash
python scripts/build_agon_agent_rank_jurisdiction_registry.py --check
python scripts/validate_agon_agent_rank_jurisdiction.py
python -m pytest -q tests/test_agon_agent_rank_jurisdiction.py
```

In `aoa-evals`:

```bash
python scripts/build_agon_retention_rank_eval_alignment_registry.py --check
python scripts/validate_agon_retention_rank_eval_alignment.py
python -m pytest -q tests/test_agon_retention_rank_eval_alignment.py
```

In `aoa-stats`:

```bash
python scripts/build_agon_retention_rank_stats_observability_registry.py --check
python scripts/validate_agon_retention_rank_stats_observability.py
python -m pytest -q tests/test_agon_retention_rank_stats_observability.py
```

In `aoa-sdk`:

```bash
python scripts/build_agon_retention_rank_sdk_helpers.py --check
python scripts/validate_agon_retention_rank_sdk_helpers.py
python -m pytest -q tests/test_agon_retention_rank_sdk_helpers.py
```
