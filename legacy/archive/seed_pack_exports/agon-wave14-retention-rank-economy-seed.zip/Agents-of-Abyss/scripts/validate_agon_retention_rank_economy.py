#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REGISTRY = ROOT / "generated/agon_retention_rank_economy_registry.min.json"
REQUIRED_ENTRY_FIELDS = ['id', 'kind', 'owner', 'status', 'description', 'candidate_only', 'live_authority']
FORBIDDEN_TRUE_FIELDS = ['live_authority']
EXPECTED_LIVE_PROTOCOL = False


def main() -> int:
    if not REGISTRY.exists():
        raise SystemExit(f"missing registry: {REGISTRY}")
    data = json.loads(REGISTRY.read_text(encoding="utf-8"))
    if data.get("live_protocol") is not EXPECTED_LIVE_PROTOCOL:
        raise SystemExit("Wave XIV registries must remain non-live protocol surfaces")
    if data.get("runtime_effect") not in ['candidate_only', 'none', 'review_surface_only', 'local_dry_run_candidate_only']:
        raise SystemExit(f"unexpected runtime_effect: {data.get('runtime_effect')}")
    entries = data.get("entries", [])
    if not entries:
        raise SystemExit("registry has no entries")
    seen = set()
    for item in entries:
        missing = [field for field in REQUIRED_ENTRY_FIELDS if field not in item]
        if missing:
            raise SystemExit(f"entry {item.get('id', '<unknown>')} missing fields: {missing}")
        if item["id"] in seen:
            raise SystemExit(f"duplicate entry id: {item['id']}")
        seen.add(item["id"])
        for field in FORBIDDEN_TRUE_FIELDS:
            if item.get(field) is True:
                raise SystemExit(f"entry {item['id']} illegally sets {field}=true")
    stop_lines = set(data.get("stop_lines", []))
    for required_stop in ['no_rank_or_trust_mutation', 'no_hidden_scheduler_action', 'no_assistant_contestant_drift']:
        if required_stop not in stop_lines:
            raise SystemExit(f"missing stop-line: {required_stop}")
    print(f"ok: {REGISTRY.relative_to(ROOT)} entries={len(entries)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
