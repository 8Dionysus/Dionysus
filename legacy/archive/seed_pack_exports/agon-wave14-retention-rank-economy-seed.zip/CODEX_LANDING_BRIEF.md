# Codex Landing Brief

Land in order: `Agents-of-Abyss`, `aoa-memo`, `aoa-agents`, `aoa-evals`, `aoa-stats`, `aoa-sdk`.

Do not wire automatic rank mutation, hidden retention scheduling, durable scar writes, or trust changes. Integrate validation into release checks only after owner review.
