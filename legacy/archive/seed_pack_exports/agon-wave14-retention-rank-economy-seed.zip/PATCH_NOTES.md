# Patch Notes

- Adds Wave XIV center retention/rank economy law.
- Adds owner-side candidate surfaces for memo, agents, evals, stats, and SDK.
- Adds recurrence manifests for retention and rank pressure.
- Keeps all mutation surfaces candidate-only and review-gated.
