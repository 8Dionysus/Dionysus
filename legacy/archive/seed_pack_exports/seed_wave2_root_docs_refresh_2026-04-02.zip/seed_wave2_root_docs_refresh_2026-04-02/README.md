# Second-wave root docs refresh seed

This zip-seed is a bounded cross-repo refresh for root `README.md` and root `AGENTS.md` across the second-wave repositories:

- `Tree-of-Sophia`
- `aoa-routing`
- `aoa-memo`
- `aoa-kag`
- `aoa-playbooks`

The goal is to make the roots easier to scan, sharper about ownership, and better at routing without draining the repositories of their actual character.

## Use this package in order

1. Read `seed_wave2_root_docs_refresh.md`.
2. Read `seed_wave2_root_docs_refresh.map.yaml` if you want the machine-readable transplant map.
3. Review `notes/rewrite_spec.md` for the keep / cut / move / add contour by repository.
4. Apply the proposed files under `transplant/` with adaptation to the live repo state.
5. Use `diffs/` for quick human review.

## Codex posture

- Treat the transplant files as a target contour, not as a blind overwrite.
- Diff against live HEAD and preserve any newer landed semantics, docs, or paths that are real and still fit the boundary rules.
- Keep exact repository names, capitalization, and hyphenation.
- Keep roots route-first. Deep doctrine stays in linked docs.
- `Tree-of-Sophia/README.md` should stay meaningful and signal-rich. Tightening it must not flatten it into a sterile index.

## Package contents

- `seed_wave2_root_docs_refresh.md` - central seed note for Codex and maintainers
- `seed_wave2_root_docs_refresh.map.yaml` - machine-readable target map and guardrails
- `notes/rewrite_spec.md` - repo-by-repo rewrite contour
- `notes/followups.md` - recommended next passes outside this bounded wave
- `notes/source_urls.md` - raw public source URLs used for this seed
- `transplant/` - proposed replacement versions of root `README.md` and `AGENTS.md`
- `diffs/` - unified diffs against the public source snapshot used for this seed

## Guardrails

- Default scope is root `README.md` and root `AGENTS.md` only.
- Do not invent maturity, status, or visibility claims.
- Do not over-compress roots until they lose the repo’s actual role.
- Prefer grouped routes and grouped surface families over long root-level inventories.
- If a tiny adjacent sync is required to avoid an immediate contradiction, keep it bounded and explicit.
