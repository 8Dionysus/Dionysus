# seed_wave2_root_docs_refresh

## Intent

Refresh the root `README.md` and root `AGENTS.md` surfaces for the second-wave repositories so that:

- root `README.md` files become faster to scan and clearer about where to go next
- root `AGENTS.md` files become more consistent about ownership, workflow, and validation
- deep doctrine stays in linked docs instead of swelling at the public entry layer
- the roots stay alive to the role of each repository rather than collapsing into generic boilerplate

## Scope

This seed targets:

- `Tree-of-Sophia/README.md`
- `Tree-of-Sophia/AGENTS.md`
- `aoa-routing/README.md`
- `aoa-routing/AGENTS.md`
- `aoa-memo/README.md`
- `aoa-memo/AGENTS.md`
- `aoa-kag/README.md`
- `aoa-kag/AGENTS.md`
- `aoa-playbooks/README.md`
- `aoa-playbooks/AGENTS.md`

Default scope is limited to those root files.

If Codex sees a tiny adjacent sync that is required to avoid an immediate contradiction introduced by this seed, it may make that fix in the same bounded pass, but it should avoid drifting into a larger doctrine rewrite.

## Why this wave exists

These repositories already have strong ownership boundaries. The current drift is mostly at the root layer:

- `Tree-of-Sophia` carries a powerful public entry but the root README is now too long for first-pass human navigation.
- `aoa-routing` is precise but its root README enumerates too much of the technical surface before the reader gets a compact map.
- `aoa-memo`, `aoa-kag`, and `aoa-playbooks` all explain themselves well, but their root READMEs still spend too much space on long inventories that belong deeper in the repo.
- the root `AGENTS.md` files are solid, but they can be normalized further without erasing repository-specific doctrine.

## Codex adaptation rule

Codex already has richer live repo context than this public snapshot.

Use this seed as a target contour:

- keep live semantics that landed after the public snapshot when they are real and compatible with the boundary rules
- preserve new docs, routes, or validation entrypoints instead of deleting them just because the transplant file is shorter
- shorten by grouping and re-routing, not by amputating genuinely live capabilities
- if live HEAD has already solved part of this wave, merge toward the same shape instead of forcing the transplant text verbatim

## Repository-specific intent

### `Tree-of-Sophia`

- keep the knowledge-architecture identity vivid
- shorten the root reading path into grouped routes by need
- keep source/intake/tree/export layering explicit
- preserve the guiding axis and current bounded Zarathustra route without replaying the full wave chronology at root

### `aoa-routing`

- keep the core rule and live routing paths visible immediately
- make the root README faster to scan by grouping outputs into families
- keep the ToS tiny-entry and bounded `aoa-kag` adjunct handoff legible
- keep the AGENTS file strict about source ownership and routing thinness

### `aoa-memo`

- keep the memory-is-not-proof doctrine explicit
- compress the root reading path into grouped routes by need
- keep public recall entrypoints visible without flooding the root with every support surface
- normalize the AGENTS file around memory class, provenance, and temporal risk

### `aoa-kag`

- keep the source-first derived-substrate posture explicit
- group the pilot packs and registry surfaces into readable families
- keep the source-owned dependency and bridge law visible
- preserve the boundary that `aoa-kag` derives from source repos rather than replacing them

### `aoa-playbooks`

- keep the playbook-is-not-skill distinction explicit
- group the evidence and activation surfaces instead of enumerating the full surface inventory at root
- keep authored playbook bundles and derived composition surfaces both visible
- preserve evidence-led maturation without forcing exact live counts into the root entry layer

## Apply order

Recommended order when applying repo by repo:

1. `Tree-of-Sophia`
2. `aoa-kag`
3. `aoa-memo`
4. `aoa-playbooks`
5. `aoa-routing`

This keeps source-owned knowledge and derived substrate surfaces steady before the routing layer is refreshed against them.

## Acceptance criteria

A successful planting leaves:

- root READMEs shorter, clearer, and more route-first
- root AGENTS files more explicit about ownership, workflow, and validation
- `Tree-of-Sophia/README.md` still feeling like a living knowledge root rather than a sterile index
- generated surface families grouped instead of exhaustively re-enumerated at root
- no invented status or maturity claims
- no repo names, paths, or cross-repo roles silently changed

## Non-goals

- do not rewrite deeper docs in this wave unless a tiny same-commit sync is required
- do not move ownership out of the existing owning repositories
- do not add decorative new root files just to absorb overflow
- do not flatten repository identity in the name of uniformity
