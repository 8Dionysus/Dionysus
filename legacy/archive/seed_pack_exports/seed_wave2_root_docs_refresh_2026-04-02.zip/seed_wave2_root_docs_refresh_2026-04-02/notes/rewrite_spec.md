# Rewrite spec

This note explains what each root file is trying to preserve, reduce, move outward, or add.

| target | current words | proposed words | keep | cut / compress | move outward | add |
|---|---:|---:|---|---|---|---|
| `Tree-of-Sophia/README.md` | 2325 | 573 | knowledge identity, source/intake/tree/export layering, guiding axis, bounded Zarathustra route | 31-step linear reading path, repeated wave chronology, oversized ownership lists | full scaffold inventory and wave history stay in linked docs | grouped route-by-need, cleaner current contour |
| `Tree-of-Sophia/AGENTS.md` | 1016 | 683 | source-traceability doctrine, route-to-neighbor rule, validation entrypoints | repeated posture prose and long duplicated layer lists | deeper interpretive law stays in README and linked docs | standardized read-first and PLAN -> DIFF -> VERIFY -> REPORT framing |
| `aoa-routing/README.md` | 1608 | 711 | core rule, live paths, ToS tiny-entry handoff, build/validate commands | long generated-surface inventory and repeated boundary narration | full surface inventory stays in generated/ and docs | grouped output families, faster scan order |
| `aoa-routing/AGENTS.md` | 922 | 550 | thin-router boundary, read-first order, hard-no list | extra repetition around doctrine wording | surface specifics stay in README and scripts | tighter verification and reporting language |
| `aoa-memo/README.md` | 1213 | 517 | memory-is-not-proof doctrine, recall entrypoints, validation commands | 21-step reading path and long root-level surface inventory | support-surface detail stays in linked docs and examples | grouped doctrine/object/export families |
| `aoa-memo/AGENTS.md` | 1012 | 602 | memory/proof boundary, provenance and temporal cautions, validation | repeated posture text | fine-grained object doctrine stays in linked docs | standardized workflow and read-first order |
| `aoa-kag/README.md` | 1570 | 522 | source-first derived-substrate posture, pilot packs, build/validate paths | 23-step reading path and massive root-level pack inventory | full schema/example/manifest inventory stays in repo tree and docs | grouped surface families and clearer current contour |
| `aoa-kag/AGENTS.md` | 973 | 565 | source-first doctrine, provenance discipline, validation posture | repeated output expectations and duplicate default-editing posture | fine-grained pack detail stays in README and docs | tighter workflow and read-first order |
| `aoa-playbooks/README.md` | 1081 | 508 | playbook-is-not-skill rule, authored bundles, validation flow, bounded evidence posture | 18-step reading path and full surface enumeration | large surface inventory and live counts stay deeper | grouped evidence/activation/composition families |
| `aoa-playbooks/AGENTS.md` | 978 | 589 | scenario-composition boundary, hard-no list, validation commands | repeated default-editing posture and duplicated output expectations | surface specifics stay in README and generated docs | standardized workflow language and clearer read-first order |

## Cross-repo design rule

- root `README.md` should identify, bound, and route
- root `AGENTS.md` should govern behavior, boundaries, workflow, and validation
- linked docs should carry the deeper doctrine and long inventories
- grouped surface families are preferred over exhaustive root-level enumeration

## Special caution

`Tree-of-Sophia/README.md` is the spiritual entry point of this wave. It should become shorter and clearer, but it should not lose the sense that ToS is a living knowledge architecture rather than a thin index of links.
