# Public source URLs used for this seed

- https://raw.githubusercontent.com/8Dionysus/Tree-of-Sophia/main/README.md
- https://raw.githubusercontent.com/8Dionysus/Tree-of-Sophia/main/AGENTS.md
- https://raw.githubusercontent.com/8Dionysus/aoa-routing/main/README.md
- https://raw.githubusercontent.com/8Dionysus/aoa-routing/main/AGENTS.md
- https://raw.githubusercontent.com/8Dionysus/aoa-memo/main/README.md
- https://raw.githubusercontent.com/8Dionysus/aoa-memo/main/AGENTS.md
- https://raw.githubusercontent.com/8Dionysus/aoa-kag/main/README.md
- https://raw.githubusercontent.com/8Dionysus/aoa-kag/main/AGENTS.md
- https://raw.githubusercontent.com/8Dionysus/aoa-playbooks/main/README.md
- https://raw.githubusercontent.com/8Dionysus/aoa-playbooks/main/AGENTS.md
- https://github.com/8Dionysus?tab=repositories
