# Follow-up notes

These are recommended after the second-wave root refresh, but they are out of scope for the bounded seed unless Codex decides a tiny same-commit sync is unavoidable.

## Likely next passes

- `Tree-of-Sophia`: consider a deeper `docs/START_HERE.md` or scaffold index so the full template family and wave chronology can stay discoverable without re-inflating the root README.
- `aoa-routing`: consider a `docs/OUTPUT_INDEX.md` or `generated/README.md` if the generated families keep expanding and the root starts swelling again.
- `aoa-memo`: consider a compact `docs/RECALL_ENTRYPOINTS.md` or similar index if the doctrine, object, and support families keep branching.
- `aoa-kag`: consider a dedicated pack index for pilots, bridges, and federation surfaces so root can stay short as more packs arrive.
- `aoa-playbooks`: if evidence surfaces keep expanding, consider a compact index for `docs/real-runs/`, `docs/gate-reviews/`, and `examples/harvests/`.
- federation-wide next wave: normalize the deeper-entry convention across the repos that still lack a predictable `docs/START_HERE.md` or equivalent surface.
