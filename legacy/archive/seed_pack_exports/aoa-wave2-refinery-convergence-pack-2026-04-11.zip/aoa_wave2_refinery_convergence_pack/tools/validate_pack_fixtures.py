#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path


STAGE_ORDER = [
    "observed",
    "checkpointed",
    "reviewed",
    "harvested",
    "seeded",
    "planted",
    "proved",
    "promoted",
]


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def validate_lineage_fixture(path: Path):
    data = load(path)
    receipts = data.get("receipts", [])
    if not receipts:
        raise ValueError("no receipts found")
    for receipt in receipts:
        for entry in receipt.get("candidate_lineage_entries", []):
            stages = entry.get("stages_present", [])
            seen_positions = [STAGE_ORDER.index(s) for s in stages if s in STAGE_ORDER]
            if seen_positions != sorted(seen_positions):
                raise ValueError(f"stage order invalid for {entry.get('candidate_ref')}")
            if entry.get("seed_ref") and "seeded" not in stages:
                raise ValueError(f"seed_ref present without seeded stage for {entry.get('candidate_ref')}")
            if entry.get("object_ref") and "planted" not in stages:
                raise ValueError(f"object_ref present without planted stage for {entry.get('candidate_ref')}")
            if entry.get("dropped") and "harvested" not in stages:
                raise ValueError(f"dropped candidate missing harvested stage for {entry.get('candidate_ref')}")


def validate_memory_fixture(path: Path):
    data = load(path)
    lineage_refs = data.get("lineage_refs", {})
    if "candidate_ref" not in lineage_refs:
        raise ValueError(f"candidate_ref missing in {path.name}")
    if data.get("schema_version") not in {"failure_lesson_memory_v1", "recovery_pattern_memory_v1"}:
        raise ValueError(f"unexpected schema_version in {path.name}")


def main():
    parser = argparse.ArgumentParser(description="Validate pack-local fixture coherence.")
    parser.add_argument("--fixtures-dir", default="fixtures", help="Path to fixtures dir.")
    args = parser.parse_args()

    root = Path(args.fixtures_dir).resolve()

    validate_lineage_fixture(root / "reviewed_candidate_lineage_receipts.example.json")
    validate_memory_fixture(root / "failure_lesson_memory.lineage.example.json")
    validate_memory_fixture(root / "recovery_pattern_memory.lineage.example.json")
    print("Pack-local fixtures look coherent.")


if __name__ == "__main__":
    main()
