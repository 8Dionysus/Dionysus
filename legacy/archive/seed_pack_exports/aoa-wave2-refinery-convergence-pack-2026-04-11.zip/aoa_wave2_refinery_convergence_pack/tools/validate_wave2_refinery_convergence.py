#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Callable, List, Tuple


Check = Tuple[str, bool, str]


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def require_file(path: Path) -> Check:
    exists = path.exists()
    return (str(path), exists, "exists" if exists else "missing")


def require_text(path: Path, predicate: Callable[[str], bool], success: str, failure: str) -> Check:
    if not path.exists():
        return (str(path), False, "missing")
    text = path.read_text(encoding="utf-8")
    ok = predicate(text)
    return (str(path), ok, success if ok else failure)


def check_stats(repo: Path) -> List[Check]:
    checks: List[Check] = []
    docs = repo / "docs" / "GROWTH_FUNNEL_SUMMARY.md"
    schema = repo / "schemas" / "candidate_lineage_summary.schema.json"
    catalog = repo / "generated" / "summary_surface_catalog.min.json"

    checks.append(require_file(docs))
    checks.append(require_file(schema))
    checks.append(require_text(
        docs,
        lambda t: "observed -> checkpointed -> reviewed -> harvested -> seeded -> planted -> proved -> promoted -> superseded_or_dropped" in t,
        "explicit funnel stages present",
        "funnel stages missing or changed",
    ))
    checks.append(require_text(
        docs,
        lambda t: "Raw checkpoint notes do not enter this summary" in t,
        "reviewed-only boundary present",
        "reviewed-only boundary missing",
    ))
    if catalog.exists():
        data = load_json(catalog)
        surfaces = data.get("surfaces", [])
        ok = any(s.get("name") == "candidate_lineage_summary" for s in surfaces if isinstance(s, dict))
        checks.append((str(catalog), ok, "candidate_lineage_summary in summary catalog" if ok else "candidate_lineage_summary missing from summary catalog"))
    else:
        checks.append((str(catalog), False, "missing"))

    return checks


def check_evals(repo: Path) -> List[Check]:
    checks: List[Check] = []
    bundles = [
        "aoa-candidate-lineage-integrity",
        "aoa-owner-fit-routing-quality",
        "aoa-repair-boundedness",
    ]
    for bundle in bundles:
        eval_md = repo / "bundles" / bundle / "EVAL.md"
        checks.append(require_file(eval_md))
        checks.append(require_text(
            eval_md,
            lambda t, bundle=bundle: bundle in t,
            f"{bundle} name present",
            f"{bundle} name missing",
        ))
        checks.append(require_text(
            eval_md,
            lambda t: "This eval does not" in t or "Do not treat a positive result as" in t,
            "claim-limit language present",
            "claim-limit language missing",
        ))
    return checks


def check_playbooks(repo: Path) -> List[Check]:
    checks: List[Check] = []
    playbook = repo / "playbooks" / "session-growth-cycle" / "PLAYBOOK.md"
    automation = repo / "generated" / "playbook_automation_seeds.json"

    checks.append(require_file(playbook))
    checks.append(require_text(
        playbook,
        lambda t: "aoa-candidate-lineage-integrity" in t and "aoa-owner-fit-routing-quality" in t and "aoa-repair-boundedness" in t,
        "eval anchors present",
        "eval anchors missing",
    ))
    checks.append(require_text(
        playbook,
        lambda t: "memo_writeback_targets" in t or "memory writeback" in t.lower(),
        "memo writeback posture present",
        "memo writeback posture missing",
    ))
    if automation.exists():
        text = automation.read_text(encoding="utf-8")
        ok = ("session-growth-cycle" in text) or ("session growth cycle" in text.lower())
        checks.append((str(automation), ok, "session-growth automation seed present" if ok else "session-growth automation seed missing"))
    else:
        checks.append((str(automation), False, "missing"))

    harvest_example = repo / "examples" / "harvests" / "session-growth-cycle.harvest.example.json"
    checks.append(require_file(harvest_example))
    return checks


def check_memo(repo: Path) -> List[Check]:
    checks: List[Check] = []
    doc = repo / "docs" / "GROWTH_REFINERY_WRITEBACK.md"
    failure = repo / "examples" / "failure_lesson_memory.lineage.example.json"
    recovery = repo / "examples" / "recovery_pattern_memory.lineage.example.json"

    checks.append(require_file(doc))
    checks.append(require_text(
        doc,
        lambda t: "Use existing memo kinds instead" in t,
        "existing-memo-kind rule present",
        "existing-memo-kind rule missing",
    ))
    checks.append(require_text(
        doc,
        lambda t: "cluster_ref" in t and "candidate_ref" in t and "seed_ref" in t and "object_ref" in t,
        "lineage refs rule present",
        "lineage refs rule missing",
    ))
    checks.append(require_file(failure))
    checks.append(require_file(recovery))
    return checks


def render(checks: List[Check]) -> str:
    lines = []
    for path, ok, detail in checks:
        mark = "PASS" if ok else "FAIL"
        lines.append(f"[{mark}] {path} :: {detail}")
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate AoA wave-2 growth-refinery convergence across repos.")
    parser.add_argument("--workspace-root", required=True, help="Path to the sibling workspace root.")
    parser.add_argument("--json", action="store_true", help="Emit JSON instead of text.")
    args = parser.parse_args()

    root = Path(args.workspace_root).expanduser().resolve()

    repo_map = {
        "aoa-stats": root / "aoa-stats",
        "aoa-evals": root / "aoa-evals",
        "aoa-playbooks": root / "aoa-playbooks",
        "aoa-memo": root / "aoa-memo",
    }

    all_checks: List[Check] = []
    for name, repo in repo_map.items():
        if name == "aoa-stats":
            all_checks.extend(check_stats(repo))
        elif name == "aoa-evals":
            all_checks.extend(check_evals(repo))
        elif name == "aoa-playbooks":
            all_checks.extend(check_playbooks(repo))
        elif name == "aoa-memo":
            all_checks.extend(check_memo(repo))

    failures = [c for c in all_checks if not c[1]]

    if args.json:
        payload = {
            "workspace_root": str(root),
            "total_checks": len(all_checks),
            "failed_checks": len(failures),
            "checks": [
                {"path": path, "ok": ok, "detail": detail}
                for path, ok, detail in all_checks
            ],
        }
        print(json.dumps(payload, indent=2))
    else:
        print(render(all_checks))
        print()
        print(f"Total checks: {len(all_checks)}")
        print(f"Failed checks: {len(failures)}")

    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
