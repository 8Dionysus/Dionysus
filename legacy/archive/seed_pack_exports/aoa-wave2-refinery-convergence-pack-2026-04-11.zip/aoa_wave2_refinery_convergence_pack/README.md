# AoA Wave 2 Refinery Convergence Pack

This pack hardens the next layer after first-wave candidate lineage.

It is built for the route:

`aoa-stats -> aoa-evals -> aoa-playbooks -> aoa-memo`

The goal is not to invent a new sovereign layer. The goal is to make the already-emerging growth-refinery cycle:

- visible as a derived funnel,
- provable through bounded eval bundles,
- repeatable as a scenario-level playbook,
- memorable through bounded failure/recovery writeback.

## Why this pack exists

The live public repos already show the main bones of this wave:

- `aoa-stats` already carries `docs/GROWTH_FUNNEL_SUMMARY.md`, `schemas/candidate_lineage_summary.schema.json`, `examples/candidate_lineage_summary.example.json`, and `generated/candidate_lineage_summary.min.json`.
- `aoa-evals` already names `aoa-candidate-lineage-integrity`, `aoa-owner-fit-routing-quality`, and `aoa-repair-boundedness`.
- `aoa-playbooks` already contains `playbooks/session-growth-cycle/PLAYBOOK.md`.
- `aoa-memo` already carries `docs/GROWTH_REFINERY_WRITEBACK.md` plus lineage-rich failure and recovery examples.

What is still needed is convergence, richer evidence, operational surfacing, and cross-repo validation.

## What this pack contains

- `IMPLEMENTATION_DOCKET.md`
- `PR_SLICES.md`
- `ACCEPTANCE_MATRIX.md`
- `CODEX_EXECUTION_PROMPT.md`
- `CODEX_POST_LANDING_AUDIT.md`
- `contracts/growth_refinery_wave2_convergence_contract_v1.md`
- `patch-guides/` for each target repo
- `fixtures/` with synthetic cross-repo examples
- `tools/validate_wave2_refinery_convergence.py`
- `tools/validate_pack_fixtures.py`

## Recommended landing order

1. `aoa-stats` funnel hardening
2. `aoa-evals` proof-bundle materialization
3. `aoa-playbooks` session-growth-cycle surfacing and automation seed
4. `aoa-memo` writeback hardening
5. cross-repo validator and audit pass

## Out of scope

Do not widen this wave into:

- new routing authority
- new KAG authority
- memo as lineage truth
- stats as proof authority
- raw checkpoint-note ingestion into stats
- one total growth score
- autonomous hidden runners

## Verify after landing

Repo-local:

```bash
# aoa-stats
python scripts/build_views.py --check
python scripts/validate_repo.py
python -m pytest -q tests

# aoa-evals
python scripts/build_catalog.py --check
python -m pytest -q tests

# aoa-playbooks
python scripts/validate_playbooks.py
python -m pytest -q tests

# aoa-memo
python scripts/validate_memo.py
python scripts/validate_memory_surfaces.py
python -m pytest -q tests
```

Cross-repo:

```bash
python tools/validate_wave2_refinery_convergence.py --workspace-root /path/to/workspace
```
