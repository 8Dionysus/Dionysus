# Implementation Docket
## Wave 2: Stats, Proof, Playbook, Memo Convergence

This docket assumes first-wave candidate lineage is already landed:

- center doctrine and crosswalk
- `cluster_ref -> candidate_ref -> seed_ref -> object_ref`
- `aoa-sdk` provisional carry only
- `aoa-skills` reviewed `candidate_ref`
- `Dionysus` staged `seed_ref`

The task here is not to change the lineage order. The task is to make the downstream cycle legible, reviewable, and durable.

## Guiding rule

Extend existing surfaces first.

Do **not** create duplicate doctrine files when the live repo already has the right home. Prefer to harden the existing file, add one missing example, one missing test, or one missing generated surface, and leave the repo's owning logic where it already belongs.

---

## 1. `aoa-stats`

### Current living center of gravity
Use the existing growth-funnel family:

- `docs/GROWTH_FUNNEL_SUMMARY.md`
- `schemas/candidate_lineage_summary.schema.json`
- `examples/candidate_lineage_summary.example.json`
- `generated/candidate_lineage_summary.min.json`
- `generated/summary_surface_catalog.min.json`

### Main goals
Harden the funnel so it reads **reviewed lineage only** and becomes more useful for real follow-through.

### Concrete work
1. Keep the doctrine file canonical. Do not fork it into a second growth-funnel doc.
2. Add at least one richer example receipt feed or builder test input that includes:
   - one seeded candidate
   - one planted candidate
   - one proved candidate
   - one promoted candidate
   - one dropped or superseded candidate
3. Add tests that explicitly confirm:
   - raw checkpoint-only data does not create downstream stage counts
   - `seeded` is never inferred from reviewed harvest alone
   - `planted` is never inferred from seed staging alone
   - `time_to_stage_median_days` stays `null` when the stage is absent
   - misroute and supersession counts survive aggregation
4. Keep `candidate_lineage_summary` visible in `generated/summary_surface_catalog.min.json`.
5. Do not widen `aoa-stats` into owner, routing, or proof authority.

### Nice-to-have
Add a second synthetic example with ambiguity and recovery, not only a clean forward route.

---

## 2. `aoa-evals`

### Current living center of gravity
Use the existing growth-refinery proof family under the current bundle layout:

- `bundles/aoa-candidate-lineage-integrity/EVAL.md`
- `bundles/aoa-owner-fit-routing-quality/EVAL.md`
- `bundles/aoa-repair-boundedness/EVAL.md`

### Main goals
Turn the current bundle names from draft-only text into a more materially runnable proof family.

### Concrete work
1. Keep the existing bundle names and bounded claims stable.
2. For each bundle, add the missing supporting surfaces if absent:
   - `fixtures/<bundle-family>/README.md`
   - at least one synthetic fixture or case family
   - `reports/<bundle>.example-report.json`
   - one short proof-flow markdown note
   - a runner, scorer, or test seam that matches the repo's existing eval infrastructure
3. Add tests that confirm:
   - the bundle does not claim stronger meaning than its own bounded claim
   - lineage integrity does not prove owner fit
   - owner-fit routing does not prove final object quality
   - repair boundedness does not retroactively prove the initial route
4. Keep bundle status as `draft` unless there is at least one real reviewed case and supporting report surface.

### Nice-to-have
Add one comparison note that explains how this proof family differs from:
- `aoa-bounded-change-quality`
- `aoa-antifragility-posture`
- `aoa-stress-recovery-window`

---

## 3. `aoa-playbooks`

### Current living center of gravity
Use the existing playbook:

- `playbooks/session-growth-cycle/PLAYBOOK.md`

### Main goals
Make the cycle easier to discover, easier to harvest, and ready for bounded future automation without letting the playbook become a hidden runner.

### Concrete work
1. Surface `session-growth-cycle` more clearly in repo entry surfaces if it is not already easy to find:
   - `README.md`
   - docs map or registry route if appropriate
2. Add at least one bounded harvest or review artifact example if absent, for example:
   - `examples/harvests/session-growth-cycle.harvest.example.json`
   - or a gate review note under `docs/gate-reviews/`
3. Add one automation seed entry in `generated/playbook_automation_seeds.json` for a **manual or review-gated** session-growth follow-through route.
4. Keep the playbook explicit about:
   - eval anchors
   - memo writeback targets
   - return anchors
   - stop conditions
   - owner boundaries
5. Do not turn the playbook into a silent autonomous runner.

### Nice-to-have
Add one short real-run or gate-review note showing where the cycle should stop rather than continue.

---

## 4. `aoa-memo`

### Current living center of gravity
Use the existing growth-refinery writeback family:

- `docs/GROWTH_REFINERY_WRITEBACK.md`
- `examples/failure_lesson_memory.lineage.example.json`
- `examples/recovery_pattern_memory.lineage.example.json`

### Main goals
Make memory writeback reusable and honest without turning memory into lineage, proof, or owner authority.

### Concrete work
1. Keep `docs/GROWTH_REFINERY_WRITEBACK.md` canonical.
2. Extend or add examples so both main directions are covered clearly:
   - one failure lesson from misroute or drop
   - one recovery pattern from reanchor or bounded repair
3. Add tests or schema validations that confirm:
   - memory does not mint `candidate_ref`, `seed_ref`, or `object_ref`
   - only existing memo kinds are used
   - strongest available lineage refs can be preserved without requiring the full chain
   - lineage context remains explanatory, not authoritative
4. Keep `aoa-memo` subordinate to owner receipts, seed truth, and proof truth.

### Nice-to-have
Add one recall-oriented note showing when growth-refinery memory should *not* be recalled.

---

## 5. Cross-repo convergence

### Main goals
Install one simple cross-repo validator so this wave can be checked as a body, not only as isolated repos.

### Concrete work
1. Add a validator script to a sensible shared home:
   - workspace root tools
   - `8Dionysus` shared-root scripts
   - or the center repo if that is the chosen governance home
2. Validator should check:
   - stats funnel surfaces exist and stay reviewed-only in posture
   - all three eval bundles exist
   - `session-growth-cycle` exists and carries eval anchors
   - playbook automation seeds include one session-growth route
   - memo writeback doc and lineage-rich examples exist
3. Validator should return non-zero when a required seam is missing.
4. Validator should produce a human-readable summary, not only machine output.

---

## Hard stop rules

Do not treat this wave as successful if:

- `aoa-stats` starts inferring downstream stages from weaker evidence
- `aoa-evals` starts collapsing three bounded bundles into one vague meta-proof
- `aoa-playbooks` becomes a stealth runtime authority
- `aoa-memo` becomes the canonical home of lineage or owner state
- the new surfaces widen routing or KAG into first-authoring homes
