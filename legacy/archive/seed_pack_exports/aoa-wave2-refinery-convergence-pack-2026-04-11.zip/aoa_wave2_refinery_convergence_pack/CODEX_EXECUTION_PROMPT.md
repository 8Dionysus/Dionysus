# Codex Execution Prompt
## Wave 2: Stats, Proof, Playbook, Memo Convergence

You are landing the next AoA growth-refinery wave after first-wave candidate lineage.

Read first:

1. `README.md`
2. `IMPLEMENTATION_DOCKET.md`
3. `PR_SLICES.md`
4. `ACCEPTANCE_MATRIX.md`
5. `contracts/growth_refinery_wave2_convergence_contract_v1.md`

Then inspect the live repos before mutating anything.

## Primary target repos

- `aoa-stats`
- `aoa-evals`
- `aoa-playbooks`
- `aoa-memo`

## Core instruction

Do not create parallel doctrine files where the live repo already has the right home.

Prefer:
- extending the existing file,
- adding one missing example,
- adding one missing generated surface,
- adding one missing proof or test seam,
- and improving discoverability.

Avoid redundant doctrine sprawl.

## Required sequence

### PR-1
Harden `aoa-stats` growth-funnel surfaces.

Goals:
- reviewed-only funnel posture stays explicit
- richer stage evidence exists
- no downstream stage is inferred from weaker evidence
- `candidate_lineage_summary` remains visible in the summary catalog

### PR-2
Materialize the growth-refinery proof family in `aoa-evals`.

Goals:
- each of the three existing bundles gains missing fixture/report/proof-flow support
- bounded claim limits stay explicit
- bundle status remains honest

### PR-3
Harden `aoa-playbooks` around `session-growth-cycle`.

Goals:
- easier repo entry
- at least one harvest or gate-review example
- one review-gated automation seed
- no hidden-runner drift

### PR-4
Harden `aoa-memo` growth-refinery writeback.

Goals:
- failure and recovery examples both remain lineage-rich
- no new memo kind is introduced
- strongest available lineage refs are preserved honestly
- recall remains bounded and non-authoritative

### PR-5
Install or update a cross-repo validator.

Goals:
- one command checks all four repos together
- failures are loud
- output is readable

## Negative rules

Do not:
- invent a global growth score
- ingest raw checkpoint notes into stats
- let eval bundles collapse into vague meta-proof
- let playbooks become silent runners
- let memo become lineage truth
- let routing or KAG absorb first-authoring meaning

## Finish condition

Stop only when:
- repo-local tests and validators pass where applicable
- the cross-repo validator passes
- acceptance criteria are satisfied without widening authority
