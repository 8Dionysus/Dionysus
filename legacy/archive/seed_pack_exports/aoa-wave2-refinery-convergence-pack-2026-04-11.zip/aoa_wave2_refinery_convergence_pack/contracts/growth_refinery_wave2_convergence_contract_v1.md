# Growth Refinery Wave 2 Convergence Contract v1

## Purpose

This contract governs the second downstream wave of the reviewable growth refinery after first-wave candidate lineage is already in place.

It binds together four already-distinct homes:

- `aoa-stats` for derived funnel visibility
- `aoa-evals` for bounded proof
- `aoa-playbooks` for recurring cycle method
- `aoa-memo` for bounded failure/recovery recall

## Precondition

The first-wave lineage order is already explicit and governed:

`cluster_ref -> candidate_ref -> seed_ref -> object_ref`

Wave 2 must not reorder or blur that chain.

## Canonical downstream order

1. owner-local reviewed artifacts exist
2. derived funnel may summarize reviewed movement
3. eval bundles may make bounded claims about lineage, owner-fit, or repair
4. playbook may coordinate recurring follow-through
5. memo may retain bounded failure or recovery value
6. all derived or recall surfaces remain subordinate to owner truth

## `aoa-stats`

`aoa-stats` may:

- summarize reviewed lineage movement
- count stage, owner-target, ambiguity, misroute, supersession, and axis-pressure signals
- expose machine-first read models

`aoa-stats` may not:

- read raw checkpoint notes directly into the funnel
- mint `candidate_ref`, `seed_ref`, or `object_ref`
- infer `seeded`, `planted`, `proved`, or `promoted` from weaker evidence
- outrank owner receipts or eval verdicts

## `aoa-evals`

The growth-refinery proof family stays split into three bounded bundles:

- `aoa-candidate-lineage-integrity`
- `aoa-owner-fit-routing-quality`
- `aoa-repair-boundedness`

They may:

- prove one bounded claim each
- expose fixtures, runners, reports, scorers, and proof flows

They may not:

- collapse into one total growth verdict
- replace owner truth
- grant routing sovereignty to derivative repos
- turn repair success into retroactive proof of initial correctness

## `aoa-playbooks`

`session-growth-cycle` is the recurring scenario-level method for this route.

It may:

- coordinate reviewed harvest, diagnosis, repair, progression, staging, landing, proof, writeback, and derived refresh
- name required skills, agents, anchors, and stop conditions
- surface one review-gated automation seed

It may not:

- become a hidden runtime runner
- replace owner-local authorship
- replace proof with orchestration language
- replace memo with scenario narrative

## `aoa-memo`

Growth-refinery writeback must reuse existing memo kinds:

- `failure_lesson_memory_v1`
- `recovery_pattern_memory_v1`

It may:

- preserve strongest available lineage refs
- preserve bounded lineage context that helps future recall
- retain bounded failure or recovery value

It may not:

- mint new lineage identity
- replace owner, seed, or proof truth
- become the canonical ledger of growth-refinery state

## Cross-layer negative rules

Do not:

- invent one total growth score
- infer downstream stages from upstream traces
- promote derivative repos into first-authoring homes
- route first-authoring meaning into `aoa-routing` or `aoa-kag`
- treat memory recall as proof
- treat playbook composition as execution authority
- treat stats as promotion authority

## Minimal proving run

A minimally successful wave-2 proving run should leave:

- one richer reviewed lineage example or test input in `aoa-stats`
- one fixture/report surface per growth-refinery eval bundle
- one discoverable and harvestable `session-growth-cycle` route in `aoa-playbooks`
- one failure and one recovery lineage-rich writeback example in `aoa-memo`
- one cross-repo validator command

## Exit signal

Wave 2 is ready for the next wave when a low-context reader can answer:

- how far did the candidate move?
- what proof family reads it honestly?
- what recurring route coordinates it?
- what lesson or recovery pattern should survive?

without any downstream layer pretending to be the new sovereign center.
