# Codex Post-Landing Audit
After landing wave 2, audit the result in this order.

## 1. `aoa-stats`
Confirm:
- `candidate_lineage_summary` is still present in the summary catalog
- reviewed-only posture is explicit
- richer stage evidence exists
- no weaker-evidence inference was introduced

## 2. `aoa-evals`
Confirm:
- all three growth-refinery bundles still exist
- each has support surfaces beyond only `EVAL.md`
- claim boundaries are still split and explicit
- no total-growth proof language appeared

## 3. `aoa-playbooks`
Confirm:
- `session-growth-cycle` is easy to find
- one harvest or gate-review surface exists
- one review-gated automation seed exists
- the playbook did not become a hidden runner

## 4. `aoa-memo`
Confirm:
- only existing memo kinds are used
- lineage-rich failure and recovery examples both exist
- lineage refs remain supportive rather than authoritative

## 5. Cross-repo
Run the validator and summarize:
- passes
- warnings
- missing seams
- possible drift risks

If any layer widened beyond its owning role, stop and recommend a bounded rollback or rewrite.
