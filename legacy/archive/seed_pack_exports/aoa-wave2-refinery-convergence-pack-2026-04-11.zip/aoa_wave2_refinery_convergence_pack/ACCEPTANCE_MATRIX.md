# Acceptance Matrix

## `aoa-stats`

Required:
- `docs/GROWTH_FUNNEL_SUMMARY.md` remains the doctrine home
- `schemas/candidate_lineage_summary.schema.json` remains the contract home
- `generated/summary_surface_catalog.min.json` includes `candidate_lineage_summary`
- reviewed-only posture remains explicit
- no raw checkpoint intake into the funnel
- seeded/planted/proved/promoted are never inferred from weaker stages
- at least one richer lineage example or test input exists

Strong:
- ambiguity, misroute, supersession, and recovery all appear in examples or tests

## `aoa-evals`

Required:
- three bundles exist under the live bundle layout:
  - `aoa-candidate-lineage-integrity`
  - `aoa-owner-fit-routing-quality`
  - `aoa-repair-boundedness`
- each bundle has at least one supporting fixture or case surface
- each bundle has at least one example report or proof-flow artifact
- claim-limit language remains explicit
- bundle status remains honest

Strong:
- at least one synthetic failure case exists for each bundle

## `aoa-playbooks`

Required:
- `playbooks/session-growth-cycle/PLAYBOOK.md` remains canonical
- playbook includes eval anchors for the three growth-refinery bundles
- playbook includes memo writeback targets
- playbook includes return anchors or explicit stop posture
- one harvest or gate-review example exists
- `generated/playbook_automation_seeds.json` contains one review-gated session-growth seed

Strong:
- repo entry surfaces point clearly to `session-growth-cycle`

## `aoa-memo`

Required:
- `docs/GROWTH_REFINERY_WRITEBACK.md` remains canonical
- existing memo kinds only:
  - `failure_lesson_memory_v1`
  - `recovery_pattern_memory_v1`
- lineage-rich failure example exists
- lineage-rich recovery example exists
- strongest available lineage refs can be partial
- memo does not mint lineage identity

Strong:
- one recall guard or non-recall note exists

## Cross-repo

Required:
- one validator command checks all four repos together
- validator fails non-zero on missing required seams
- validator output is readable by humans

Strong:
- validator also emits JSON for later automation or dashboards
