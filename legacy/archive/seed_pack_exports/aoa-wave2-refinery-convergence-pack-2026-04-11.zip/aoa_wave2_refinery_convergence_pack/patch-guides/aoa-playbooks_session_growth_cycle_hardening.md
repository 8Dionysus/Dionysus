# Patch Guide: `aoa-playbooks`

Use the existing playbook home:

- `playbooks/session-growth-cycle/PLAYBOOK.md`

## Suggested minimal diff

1. Surface the playbook in one easier-to-find entry surface:
   - `README.md`
   - docs map
   - or registry-adjacent route note
2. Add one bounded harvest or gate-review example.
3. Add one review-gated automation seed entry in `generated/playbook_automation_seeds.json`.

## Keep explicit

- eval anchors
- memo writeback targets
- return anchors
- stop posture
- owner boundaries

## Avoid

- hidden-runner drift
- turning automation seed into autonomous authority
- moving owner truth into playbook prose
