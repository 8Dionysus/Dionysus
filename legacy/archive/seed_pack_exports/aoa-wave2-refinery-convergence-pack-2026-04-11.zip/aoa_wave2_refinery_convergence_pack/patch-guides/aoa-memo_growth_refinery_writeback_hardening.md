# Patch Guide: `aoa-memo`

Use the existing writeback doctrine home:

- `docs/GROWTH_REFINERY_WRITEBACK.md`

## Preferred surfaces

- `examples/failure_lesson_memory.lineage.example.json`
- `examples/recovery_pattern_memory.lineage.example.json`
- repo validation or tests for lineage-support posture

## Suggested minimal diff

1. Ensure both failure and recovery examples remain strong and lineage-rich.
2. Add validation or tests for:
   - no minting of lineage refs
   - strongest available chain can be partial
   - lineage context is explanatory only
3. Optionally add one short note on when growth-refinery memory should not be recalled.

## Avoid

- new growth-refinery-only memory family
- memo as lineage ledger
- memo as proof authority
