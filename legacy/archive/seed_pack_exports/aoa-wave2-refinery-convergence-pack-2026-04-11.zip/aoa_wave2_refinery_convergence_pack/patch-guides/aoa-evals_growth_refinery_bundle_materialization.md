# Patch Guide: `aoa-evals`

Use the current bundle layout under `bundles/`.

## Bundle homes

- `bundles/aoa-candidate-lineage-integrity/EVAL.md`
- `bundles/aoa-owner-fit-routing-quality/EVAL.md`
- `bundles/aoa-repair-boundedness/EVAL.md`

## Suggested minimal diff

For each bundle, add if missing:
- one fixture family
- one example report
- one short proof-flow note
- one runner/scorer/test seam compatible with the existing repo pattern

## Keep explicit

- lineage integrity does not prove owner fit
- owner fit does not prove final quality
- repair boundedness does not prove the initial route was correct

## Avoid

- one umbrella meta-proof bundle
- silent status inflation from `draft`
- proof language that outranks owner receipts
