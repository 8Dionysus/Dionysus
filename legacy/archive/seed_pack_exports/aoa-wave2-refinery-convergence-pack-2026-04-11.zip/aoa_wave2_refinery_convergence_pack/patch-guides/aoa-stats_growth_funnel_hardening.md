# Patch Guide: `aoa-stats`

Use the existing growth-funnel family. Do not fork it.

## Preferred file targets

- `docs/GROWTH_FUNNEL_SUMMARY.md`
- `schemas/candidate_lineage_summary.schema.json`
- `examples/candidate_lineage_summary.example.json`
- `examples/` richer reviewed-lineage fixture or receipt input
- `generated/summary_surface_catalog.min.json`
- repo tests around the builder

## Suggested minimal diff

1. Keep doctrine unchanged in spirit, but make sure the negative rules remain explicit.
2. Add one richer lineage input with more than zero `seeded`, `planted`, `proved`, or `promoted`.
3. Add tests for:
   - no raw checkpoint overread
   - no seed-from-harvest inference
   - no planted-from-seed inference
   - preserved misroute and supersession counts
4. Keep `candidate_lineage_summary` in the runtime capsule.

## Avoid

- new doctrine sprawl
- owner-meaning language
- proof-verdict language
- one total score
