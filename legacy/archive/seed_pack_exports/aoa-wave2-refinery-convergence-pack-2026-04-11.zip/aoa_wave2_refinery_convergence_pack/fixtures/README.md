# Fixtures

These fixtures are synthetic and pack-local.

They are not meant to replace repo-owned examples. They exist to help Codex:

- see the intended shape of a richer lineage input,
- see what a session-growth-cycle harvest example could look like,
- see what lineage-rich failure and recovery writeback examples should preserve.

Use them as bounded guides. Prefer live repo-owned schemas and examples when landing changes.
