# PR Slices

## PR-1
### `aoa-stats`: growth funnel hardening

Land:
- richer reviewed-lineage example input
- extra builder/tests around stage evidence and no-overread
- keep `candidate_lineage_summary` entry stable in the summary catalog

Exit when:
- no raw checkpoint-only input can produce fake downstream stages
- seeded/planted/proved/promoted remain evidence-bound
- misroute/supersession aggregates survive

## PR-2
### `aoa-evals`: growth-refinery proof family materialization

Land:
- supporting fixture/report/proof-flow surfaces for
  - `aoa-candidate-lineage-integrity`
  - `aoa-owner-fit-routing-quality`
  - `aoa-repair-boundedness`
- tests around claim limits

Exit when:
- each bundle has at least one synthetic case family and one example report
- claim boundaries stay explicit
- status remains honest

## PR-3
### `aoa-playbooks`: session-growth-cycle surfacing

Land:
- README or docs-map surfacing for `session-growth-cycle`
- one harvest or gate-review example
- one review-gated automation seed entry

Exit when:
- a low-context reader can find the playbook quickly
- the playbook is easier to harvest and revisit
- automation remains advisory/review-gated

## PR-4
### `aoa-memo`: growth-refinery writeback hardening

Land:
- improved lineage-rich failure/recovery examples or tests
- guardrail validation that memory stays non-authoritative
- optional recall note if needed

Exit when:
- failure and recovery patterns are both represented clearly
- strongest-available lineage refs are preserved honestly
- no new growth-refinery-only memory kind appears

## PR-5
### Cross-repo convergence validator

Land:
- one script that checks all four repos together
- one short audit note or generated report format

Exit when:
- a single command can say whether wave 2 is structurally present
- missing seams fail loudly
