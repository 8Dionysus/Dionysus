# aoa_workspace_mcp_contract_v1

## Purpose

`aoa_workspace_mcp` is the project-level, read-only, route-first MCP seam for the AoA sibling workspace.

It exists to help Codex orient in the federation before it commits to a repo-local surface.

## Allowed responsibilities

- detect the AoA workspace root
- report which key sibling repos are present
- expose a small repo-role map
- expose a small surface crosswalk
- preview the AoA skill index
- preview the AoA agent profile set
- preview the current runtime-entry capsules for the workspace

## Explicit non-goals

This server must not:

- become a generic file browser
- edit files
- claim owner truth for any repo
- replace `aoa-stats` as a derived observability surface
- replace `Dionysus` as a seed-garden surface
- replace repo-local `AGENTS.md` guidance
- decide workflow authority, proof authority, or quest authority

## Tool set

### `workspace_health()`

Return a narrow workspace health bundle:

- workspace root
- marker presence
- expected repo presence
- launcher visibility
- key entry-capsule visibility

### `workspace_repo_map()`

Return the small repo-role map for the AoA federation.

### `workspace_surface_crosswalk()`

Return the surface-selection bundle that helps Codex choose among:

- `AGENTS.md`
- skills
- subagents
- project-level MCP
- repo-local MCP
- repo-local source files

### `workspace_runtime_entrypoints()`

Return the detected runtime-entry capsules in the workspace.

### `workspace_skill_index(mode="preview", limit=80)`

Return a preview of `aoa-skills/SKILL_INDEX.md`.

### `workspace_agent_profiles()`

Return the compact discovered profile set from `aoa-agents/profiles/*.profile.json`.

## Resource posture

Resources are snapshots, not sovereign truth.

## Precedence rule

When there is tension:

1. repo-local source surfaces outrank workspace summaries
2. repo-local MCP surfaces outrank workspace route hints inside their domain
3. workspace route hints outrank guesswork
4. nothing here outranks explicit human instruction

## Recommended use

Use this server first when you need to decide where to go.

Do not use it as the final answer surface when a repo-local canonical source exists.
