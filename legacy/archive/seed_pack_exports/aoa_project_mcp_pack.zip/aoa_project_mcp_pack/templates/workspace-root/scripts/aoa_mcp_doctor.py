#!/usr/bin/env python3
from __future__ import annotations

import sys
from pathlib import Path
import tomllib


def find_workspace_root(start: Path) -> Path | None:
    for candidate in [start, *start.parents]:
        if (candidate / "AOA_WORKSPACE_ROOT").exists():
            return candidate
    return None


def main() -> int:
    root = find_workspace_root(Path.cwd())
    if root is None:
        print("ERROR: AOA_WORKSPACE_ROOT not found.")
        return 1

    print(f"Workspace root: {root}")
    config_path = root / ".codex" / "config.toml"
    if not config_path.exists():
        print("ERROR: missing .codex/config.toml")
        return 1

    data = tomllib.loads(config_path.read_text(encoding="utf-8"))
    servers = data.get("mcp_servers", {})
    if not servers:
        print("ERROR: no [mcp_servers.*] entries found")
        return 1

    print("Configured MCP servers:")
    for name, cfg in servers.items():
        cwd = cfg.get("cwd", ".")
        command = cfg.get("command")
        args = cfg.get("args", [])
        resolved_cwd = (config_path.parent / cwd).resolve()
        print(f"  - {name}: command={command!r} cwd={resolved_cwd}")
        if not resolved_cwd.exists():
            print("    ! cwd missing")
            continue
        if args:
            launcher = resolved_cwd / args[0]
            print(f"    launcher={launcher} exists={launcher.exists()}")

    for rel in [
        "Agents-of-Abyss/ECOSYSTEM_MAP.md",
        "aoa-skills/SKILL_INDEX.md",
        "aoa-agents/profiles",
        "aoa-stats/generated/summary_surface_catalog.min.json",
        "Dionysus/generated/seed_route_map.min.json",
    ]:
        path = root / rel
        print(f"  entrypoint {rel}: exists={path.exists()}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
