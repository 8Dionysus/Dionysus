# AoA workspace guidance

This directory is the AoA sibling workspace, not a monorepo.

## First posture

- Treat this root as a federation entrypoint.
- Use the workspace MCP server only to orient and choose stronger surfaces.
- Treat repo-local source files and repo-local guidance as stronger than workspace summaries.

## Surface priorities

- Use workspace `AGENTS.md` for federation posture.
- Use repo-local `AGENTS.md` for bounded repo work.
- Use skills for repeatable workflows.
- Use repo-local MCP servers for bounded read access to derived or staging context.
- Use repo-local source files when semantics or edits matter.

## Boundaries

- `aoa-stats` is derived-only.
- `Dionysus` is seed-garden and staging context, not final owner truth.
- Do not let project-level route hints outrank repo-local meaning.

## Working style

- Name the target repo before editing.
- Name the stronger surface you are relying on.
- Prefer the smallest coherent landing slice.
