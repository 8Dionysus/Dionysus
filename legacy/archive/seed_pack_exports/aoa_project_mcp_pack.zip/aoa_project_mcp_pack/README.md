# AoA project MCP pack v0

This pack shifts the next step from repo-islands to a project spine.

It gives the AoA sibling-workspace a narrow, read-only, route-first MCP surface, plus the workspace-root
Codex scaffolding needed to load it consistently.

## Why this before more repo-local polishing

For a multi-repo workspace, the first useful move is to give Codex one stable project entrypoint:
a workspace marker, one workspace-level `AGENTS.md`, one project-scoped `.codex/config.toml`,
and one narrow MCP server that teaches Codex how to orient before it dives into any single repo.

That keeps the workspace readable without turning a new layer into hidden semantic authority.

## What is inside

- `workspace-overlay/src/aoa_workspace_mcp/`: read-only workspace MCP package
- `workspace-overlay/scripts/aoa_workspace_mcp_server.py`: workspace-root bootstrap launcher
- `workspace-overlay/tests/test_aoa_workspace_mcp_state.py`: helper-layer tests
- `workspace-overlay/requirements-mcp.txt`: minimal MCP dependency line
- `contracts/aoa_workspace_mcp_contract_v1.md`: boundary contract
- `templates/workspace-root/AOA_WORKSPACE_ROOT`: marker file for workspace anchoring
- `templates/workspace-root/AGENTS.md`: workspace-root guidance
- `templates/workspace-root/.codex/config.toml`: project-scoped Codex config
- `templates/workspace-root/scripts/aoa-codex`: launcher that enters Codex through the workspace root
- `templates/workspace-root/scripts/aoa_mcp_doctor.py`: local config and path checker
- `prompts/aoa_workspace_mcp_usage_recipes.md`: first prompt recipes
- `ROLL_OUT.md`: merge order and verification path

## Intended posture

This server is deliberately narrow.

It exposes only six tools:

- `workspace_health`
- `workspace_repo_map`
- `workspace_surface_crosswalk`
- `workspace_runtime_entrypoints`
- `workspace_skill_index`
- `workspace_agent_profiles`

The point is to orient Codex in the AoA federation and point it at the right surfaces.
It must not become a generic file browser, a proof authority, or a hidden routing empire.

## Quick local test after merge

From the AoA workspace root:

```bash
pip install -r requirements-mcp.txt
python -m pytest -q tests/test_aoa_workspace_mcp_state.py
python scripts/aoa_workspace_mcp_server.py
```

## Suggested rollout order

1. Copy the `workspace-overlay/` files into the AoA workspace root.
2. Copy the `templates/workspace-root/` files into the same root.
3. Merge the repo-local MCP packs into `aoa-stats` and `Dionysus`.
4. Trust the workspace in Codex.
5. Launch Codex from the workspace root, ideally through `scripts/aoa-codex`.
6. Verify with `/mcp`, then try `workspace_health` and `workspace_surface_crosswalk` first.

## What I would do immediately after this lands

1. Keep the workspace server read-only.
2. Use it as the first orientation layer.
3. Let repo-local MCP servers stay the stronger context providers for their own bounded domains.
4. Only later consider a project-level orchestration skill that depends on this MCP surface.
