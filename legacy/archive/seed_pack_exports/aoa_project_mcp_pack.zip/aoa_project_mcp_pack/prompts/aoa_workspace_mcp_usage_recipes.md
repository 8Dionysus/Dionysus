# AoA workspace MCP usage recipes

## Orient in the workspace

Use `workspace_health`, then `workspace_repo_map`, then `workspace_surface_crosswalk`.

Name the exact surface you should open next and why that surface is stronger than the alternatives for the task.

## Choose the right Codex surface

Use `workspace_surface_crosswalk`.

Given the current task, decide whether the next move should go through:

- workspace `AGENTS.md`
- repo-local `AGENTS.md`
- skills
- project-level MCP
- repo-local MCP
- repo-local source files
- subagents

Call out one primary choice and one fallback.

## Check the skill and agent frontiers

Use `workspace_skill_index` and `workspace_agent_profiles`.

Name the nearest reusable workflow and the nearest role posture that fit the task.
Say explicitly where repo-local truth would still be needed before making edits.
