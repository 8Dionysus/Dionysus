from __future__ import annotations

import json
from pathlib import Path

from aoa_workspace_mcp.repo_state import AoAWorkspaceState


def make_workspace(tmp_path: Path) -> Path:
    root = tmp_path / "workspace"
    root.mkdir()
    (root / "AOA_WORKSPACE_ROOT").write_text("", encoding="utf-8")

    agents = root / "Agents-of-Abyss"
    agents.mkdir()
    (agents / "ECOSYSTEM_MAP.md").write_text("# Ecosystem map\nline two\n", encoding="utf-8")

    skills = root / "aoa-skills"
    skills.mkdir()
    (skills / "SKILL_INDEX.md").write_text("# Skill index\n- foo\n- bar\n", encoding="utf-8")

    aoa_agents = root / "aoa-agents" / "profiles"
    aoa_agents.mkdir(parents=True)
    (aoa_agents / "architect.profile.json").write_text(
        json.dumps({
            "name": "architect",
            "description": "System architect",
            "model": "gpt-5.4",
            "role": "architect",
        }),
        encoding="utf-8",
    )

    stats = root / "aoa-stats" / "generated"
    stats.mkdir(parents=True)
    (stats / "summary_surface_catalog.min.json").write_text("{}", encoding="utf-8")
    (root / "aoa-stats" / "scripts").mkdir(exist_ok=True)
    (root / "aoa-stats" / "scripts" / "aoa_stats_mcp_server.py").write_text("print('ok')\n", encoding="utf-8")

    dion = root / "Dionysus" / "generated"
    dion.mkdir(parents=True)
    (dion / "seed_route_map.min.json").write_text("{}", encoding="utf-8")
    (root / "Dionysus" / "scripts").mkdir(exist_ok=True)
    (root / "Dionysus" / "scripts" / "dionysus_mcp_server.py").write_text("print('ok')\n", encoding="utf-8")

    return root


def test_discover_workspace_marker_from_nested_dir(tmp_path: Path) -> None:
    root = make_workspace(tmp_path)
    nested = root / "aoa-skills" / "inner"
    nested.mkdir()
    state = AoAWorkspaceState.discover(start=nested)
    assert state.workspace_root == root
    assert state.marker_found is True


def test_build_health_detects_repos_and_launchers(tmp_path: Path) -> None:
    root = make_workspace(tmp_path)
    state = AoAWorkspaceState.discover(start=root)
    health = state.build_health()
    assert health["repos"]["aoa-stats"]["present"] is True
    assert health["repos"]["aoa-stats"]["launcher"]["exists"] is True
    assert health["repos"]["Dionysus"]["entrypoints"][0]["exists"] is True


def test_runtime_entrypoints_detect_capsules(tmp_path: Path) -> None:
    root = make_workspace(tmp_path)
    state = AoAWorkspaceState.discover(start=root)
    payload = state.build_runtime_entrypoints()
    names = {entry["name"]: entry["exists"] for entry in payload["entrypoints"]}
    assert names["ecosystem_map"] is True
    assert names["skill_index"] is True
    assert names["stats_catalog"] is True
    assert names["seed_route_map"] is True


def test_load_agent_profiles_reads_profile_json(tmp_path: Path) -> None:
    root = make_workspace(tmp_path)
    state = AoAWorkspaceState.discover(start=root)
    profiles = state.load_agent_profiles()
    assert profiles["profile_count"] == 1
    assert profiles["profiles"][0]["name"] == "architect"


def test_load_skill_index_preview_returns_content(tmp_path: Path) -> None:
    root = make_workspace(tmp_path)
    state = AoAWorkspaceState.discover(start=root)
    payload = state.load_skill_index()
    assert payload["exists"] is True
    assert "Skill index" in payload["content"]
