from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

MARKER_FILE = "AOA_WORKSPACE_ROOT"

KNOWN_REPOS: dict[str, dict[str, Any]] = {
    "Agents-of-Abyss": {
        "role": "federation-center",
        "surface": "federation rules, ecosystem map, method spine",
        "entry_candidates": [
            "ECOSYSTEM_MAP.md",
            "docs/FEDERATION_RULES.md",
            "docs/METHOD_SPINE.md",
        ],
    },
    "aoa-skills": {
        "role": "workflow-canon",
        "surface": "skills, Codex-facing export, session-growth kernel",
        "entry_candidates": [
            "SKILL_INDEX.md",
            ".agents/skills",
            "skills",
        ],
    },
    "aoa-agents": {
        "role": "role-canon",
        "surface": "agent profiles, role posture, orchestration seams",
        "entry_candidates": [
            "profiles",
            "README.md",
        ],
    },
    "aoa-stats": {
        "role": "derived-observability",
        "surface": "generated summaries and derived observability",
        "entry_candidates": [
            "generated/summary_surface_catalog.min.json",
            "config/live_receipt_sources.json",
        ],
        "launcher": "scripts/aoa_stats_mcp_server.py",
    },
    "Dionysus": {
        "role": "seed-garden",
        "surface": "seed staging, route maps, planting lineage",
        "entry_candidates": [
            "generated/seed_route_map.min.json",
            "seed-registry.yaml",
            "README.md",
        ],
        "launcher": "scripts/dionysus_mcp_server.py",
    },
}

SURFACE_CROSSWALK: list[dict[str, Any]] = [
    {
        "need": "repo law, conventions, always-on posture",
        "primary_surface": "AGENTS.md",
        "fallback": "repo source files",
        "notes": "use workspace-root guidance for federation posture, then repo-local guidance for bounded work",
    },
    {
        "need": "repeatable bounded workflow",
        "primary_surface": "skills",
        "fallback": "playbooks or repo-local source",
        "notes": "skills carry reusable workflow instructions; source truth still lives in owner repos",
    },
    {
        "need": "role specialization or multi-agent delegation",
        "primary_surface": "subagents",
        "fallback": "skills",
        "notes": "agent posture is not the same thing as a workflow canon",
    },
    {
        "need": "project orientation across repos",
        "primary_surface": "project-level MCP",
        "fallback": "workspace AGENTS.md",
        "notes": "use the workspace MCP to choose where to go next, not to replace repo-local truth",
    },
    {
        "need": "derived metrics, summary views, receipts overview",
        "primary_surface": "repo-local MCP: aoa-stats",
        "fallback": "repo source files",
        "notes": "aoa-stats is derived-only, so verify owner repos when semantics matter",
    },
    {
        "need": "seed staging, route map, planting follow-through",
        "primary_surface": "repo-local MCP: Dionysus",
        "fallback": "repo source files",
        "notes": "staging notes and route maps do not outrank planted owner objects",
    },
]


@dataclass(slots=True)
class AoAWorkspaceState:
    workspace_root: Path
    marker_found: bool

    @classmethod
    def discover(cls, start: Path | None = None) -> "AoAWorkspaceState":
        start_path = (start or Path.cwd()).resolve()

        current = start_path
        for candidate in [current, *current.parents]:
            if (candidate / MARKER_FILE).exists():
                return cls(workspace_root=candidate, marker_found=True)

        return cls(workspace_root=start_path, marker_found=False)

    def _repo_path(self, repo_name: str) -> Path:
        return self.workspace_root / repo_name

    def build_health(self) -> dict[str, Any]:
        repos: dict[str, Any] = {}
        for repo_name, meta in KNOWN_REPOS.items():
            repo_root = self._repo_path(repo_name)
            present = repo_root.exists()
            entrypoints = []
            for rel in meta.get("entry_candidates", []):
                entrypoints.append(
                    {
                        "path": rel,
                        "exists": (repo_root / rel).exists(),
                    }
                )
            launcher_rel = meta.get("launcher")
            launcher_exists = (repo_root / launcher_rel).exists() if launcher_rel and present else False

            repos[repo_name] = {
                "present": present,
                "role": meta["role"],
                "surface": meta["surface"],
                "entrypoints": entrypoints,
                "launcher": {
                    "path": launcher_rel,
                    "exists": launcher_exists,
                } if launcher_rel else None,
            }

        return {
            "workspace_root": str(self.workspace_root),
            "marker_found": self.marker_found,
            "repos": repos,
        }

    def build_repo_map(self) -> dict[str, Any]:
        repo_rows: list[dict[str, Any]] = []
        for repo_name, meta in KNOWN_REPOS.items():
            repo_root = self._repo_path(repo_name)
            repo_rows.append(
                {
                    "repo": repo_name,
                    "present": repo_root.exists(),
                    "role": meta["role"],
                    "surface": meta["surface"],
                    "preferred_entrypoints": [
                        rel for rel in meta.get("entry_candidates", [])
                        if (repo_root / rel).exists()
                    ],
                }
            )

        ecosystem_preview = self._text_preview(
            self._repo_path("Agents-of-Abyss") / "ECOSYSTEM_MAP.md",
            limit=40,
        )

        return {
            "workspace_root": str(self.workspace_root),
            "repos": repo_rows,
            "ecosystem_map_preview": ecosystem_preview,
        }

    def build_surface_crosswalk(self) -> dict[str, Any]:
        return {
            "workspace_root": str(self.workspace_root),
            "crosswalk": SURFACE_CROSSWALK,
        }

    def build_runtime_entrypoints(self) -> dict[str, Any]:
        entries = [
            {
                "name": "ecosystem_map",
                "repo": "Agents-of-Abyss",
                "path": "ECOSYSTEM_MAP.md",
            },
            {
                "name": "skill_index",
                "repo": "aoa-skills",
                "path": "SKILL_INDEX.md",
            },
            {
                "name": "agent_profiles",
                "repo": "aoa-agents",
                "path": "profiles",
            },
            {
                "name": "stats_catalog",
                "repo": "aoa-stats",
                "path": "generated/summary_surface_catalog.min.json",
            },
            {
                "name": "seed_route_map",
                "repo": "Dionysus",
                "path": "generated/seed_route_map.min.json",
            },
        ]

        resolved = []
        for entry in entries:
            abs_path = self._repo_path(entry["repo"]) / entry["path"]
            resolved.append(
                {
                    **entry,
                    "exists": abs_path.exists(),
                    "abs_path": str(abs_path),
                }
            )

        return {
            "workspace_root": str(self.workspace_root),
            "entrypoints": resolved,
        }

    def load_skill_index(self, mode: str = "preview", limit: int = 80) -> dict[str, Any]:
        path = self._repo_path("aoa-skills") / "SKILL_INDEX.md"
        return self._text_payload(path=path, mode=mode, limit=limit, label="skill_index")

    def load_agent_profiles(self) -> dict[str, Any]:
        profiles_dir = self._repo_path("aoa-agents") / "profiles"
        profiles: list[dict[str, Any]] = []
        if profiles_dir.exists():
            for path in sorted(profiles_dir.glob("*.profile.json")):
                try:
                    data = json.loads(path.read_text(encoding="utf-8"))
                except json.JSONDecodeError:
                    data = {}

                profiles.append(
                    {
                        "file": path.name,
                        "name": data.get("name"),
                        "description": data.get("description"),
                        "model": data.get("model"),
                        "role": data.get("role"),
                    }
                )

        return {
            "workspace_root": str(self.workspace_root),
            "profile_count": len(profiles),
            "profiles": profiles,
        }

    def _text_payload(self, path: Path, mode: str, limit: int, label: str) -> dict[str, Any]:
        if not path.exists():
            return {
                "label": label,
                "path": str(path),
                "exists": False,
                "mode": mode,
                "content": None,
            }

        text = path.read_text(encoding="utf-8")
        if mode == "full":
            content = text
        else:
            content = "\n".join(text.splitlines()[:limit])

        return {
            "label": label,
            "path": str(path),
            "exists": True,
            "mode": mode,
            "content": content,
        }

    def _text_preview(self, path: Path, limit: int = 40) -> dict[str, Any]:
        return self._text_payload(path=path, mode="preview", limit=limit, label="preview")
