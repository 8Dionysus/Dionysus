from __future__ import annotations

import json
import logging
from typing import Any

from aoa_workspace_mcp.repo_state import AoAWorkspaceState

LOGGER = logging.getLogger(__name__)


def build_server() -> Any:
    try:
        from mcp.server.fastmcp import FastMCP
    except ImportError as exc:
        raise SystemExit(
            "Missing dependency 'mcp'. Install with: pip install -r requirements-mcp.txt"
        ) from exc

    state = AoAWorkspaceState.discover()
    mcp = FastMCP("aoa-workspace", json_response=True)

    @mcp.tool()
    def workspace_health() -> dict[str, Any]:
        """Return the narrow AoA workspace health bundle."""
        return state.build_health()

    @mcp.tool()
    def workspace_repo_map() -> dict[str, Any]:
        """Return the small AoA repo-role map."""
        return state.build_repo_map()

    @mcp.tool()
    def workspace_surface_crosswalk() -> dict[str, Any]:
        """Return the small surface-selection crosswalk for the AoA workspace."""
        return state.build_surface_crosswalk()

    @mcp.tool()
    def workspace_runtime_entrypoints() -> dict[str, Any]:
        """Return the current detected runtime-entry capsules in the AoA workspace."""
        return state.build_runtime_entrypoints()

    @mcp.tool()
    def workspace_skill_index(mode: str = "preview", limit: int = 80) -> dict[str, Any]:
        """Return a preview of aoa-skills/SKILL_INDEX.md."""
        return state.load_skill_index(mode=mode, limit=limit)

    @mcp.tool()
    def workspace_agent_profiles() -> dict[str, Any]:
        """Return the compact discovered aoa-agents profile set."""
        return state.load_agent_profiles()

    @mcp.resource("aoa-workspace://health")
    def health_resource() -> str:
        return json.dumps(state.build_health(), ensure_ascii=False, indent=2)

    @mcp.resource("aoa-workspace://repo-map")
    def repo_map_resource() -> str:
        return json.dumps(state.build_repo_map(), ensure_ascii=False, indent=2)

    @mcp.resource("aoa-workspace://surface-crosswalk")
    def crosswalk_resource() -> str:
        return json.dumps(state.build_surface_crosswalk(), ensure_ascii=False, indent=2)

    @mcp.resource("aoa-workspace://runtime-entrypoints")
    def entrypoints_resource() -> str:
        return json.dumps(state.build_runtime_entrypoints(), ensure_ascii=False, indent=2)

    @mcp.resource("aoa-workspace://skill-index")
    def skill_index_resource() -> str:
        return json.dumps(state.load_skill_index(mode="preview", limit=80), ensure_ascii=False, indent=2)

    @mcp.resource("aoa-workspace://agent-profiles")
    def agent_profiles_resource() -> str:
        return json.dumps(state.load_agent_profiles(), ensure_ascii=False, indent=2)

    @mcp.prompt()
    def orient_in_aoa_workspace() -> str:
        """Prompt recipe for first orientation in the AoA workspace."""
        return (
            "Use workspace_health, then workspace_repo_map, then workspace_surface_crosswalk. "
            "Name the strongest next surface for the task, one fallback surface, and the boundary you must not cross."
        )

    @mcp.prompt()
    def choose_codex_surface(task: str) -> str:
        """Prompt recipe for choosing the right Codex surface."""
        return (
            f"Task: {task}\n"
            "Use workspace_surface_crosswalk first. Then say whether the next move belongs in AGENTS.md, "
            "skills, subagents, project-level MCP, repo-local MCP, or repo-local source files. "
            "Name one primary choice and one fallback."
        )

    LOGGER.info("AoA workspace MCP server ready at workspace root: %s", state.workspace_root)
    return mcp


def main() -> None:
    logging.basicConfig(level=logging.INFO)
    server = build_server()
    server.run(transport="stdio")


if __name__ == "__main__":
    main()
