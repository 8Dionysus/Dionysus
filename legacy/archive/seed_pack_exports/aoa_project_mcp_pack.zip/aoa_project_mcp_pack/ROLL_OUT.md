# Roll out the AoA project MCP pack

## 1. Merge the workspace overlay

Copy these files into the AoA workspace root:

- `src/aoa_workspace_mcp/`
- `scripts/aoa_workspace_mcp_server.py`
- `tests/test_aoa_workspace_mcp_state.py`
- `requirements-mcp.txt`

A practical target layout is:

```text
<AoA-workspace>/
  AOA_WORKSPACE_ROOT
  AGENTS.md
  .codex/
    config.toml
  scripts/
    aoa-codex
    aoa_mcp_doctor.py
    aoa_workspace_mcp_server.py
  src/
    aoa_workspace_mcp/
  tests/
    test_aoa_workspace_mcp_state.py
  Agents-of-Abyss/
  aoa-skills/
  aoa-agents/
  aoa-stats/
  Dionysus/
```

## 2. Merge the workspace-root templates

Copy the marker, `AGENTS.md`, `.codex/config.toml`, and the helper scripts from `templates/workspace-root/`.

Do not flatten the marker into repo roots. It belongs only at the AoA workspace root.

## 3. Install the MCP dependency and run the helper tests

From the workspace root:

```bash
pip install -r requirements-mcp.txt
python -m pytest -q tests/test_aoa_workspace_mcp_state.py
python scripts/aoa_mcp_doctor.py
```

## 4. Trust the workspace and launch Codex through the root

Preferred path:

```bash
scripts/aoa-codex
```

This enters Codex through the workspace root and passes a one-off `project_root_markers` override so the
workspace marker becomes the project anchor for that run.

## 5. Verify MCP visibility

Inside Codex:

- use `/mcp` to inspect active servers
- start with `workspace_health`
- then call `workspace_surface_crosswalk`

## 6. Add repo-local MCP servers after the workspace spine is stable

The project-scoped `.codex/config.toml` template already includes commented blocks for `aoa-stats` and
`Dionysus`. Enable them only after their repo-local packs are merged.
