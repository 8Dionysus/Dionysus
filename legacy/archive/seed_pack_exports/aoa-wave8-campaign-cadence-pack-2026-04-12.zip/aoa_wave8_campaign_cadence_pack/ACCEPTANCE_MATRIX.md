# Acceptance Matrix

| Area | Accept when... |
|---|---|
| Doctrine | `8Dionysus` clearly defines campaign batching, drift review cadence, and bounded rollback follow-through for the shared-root Codex plane. |
| Identity | One `campaign_ref` is reused consistently across campaign, drift, rollback, stats, and memo examples. |
| Drift | `review_ref` windows make cadence explicit without creating a scheduler empire. |
| Rollback | `rollback_ref` windows remain contingent and reviewable; they do not imply automatic rollback execution. |
| Stats | `aoa-stats` exposes campaign/drift summaries as derived read models only. |
| Playbook | `rollout-drift-review-campaign` is clearly bigger than one rollout action and smaller than generic program management. |
| Memo | Drift lessons and rollback patterns stay memory objects, not proof or workflow authority. |
| SDK | `aoa-sdk` carries refs only and does not decide campaign outcomes. |
| Validation | Pack validator passes and repo-local validation paths are still intelligible. |
