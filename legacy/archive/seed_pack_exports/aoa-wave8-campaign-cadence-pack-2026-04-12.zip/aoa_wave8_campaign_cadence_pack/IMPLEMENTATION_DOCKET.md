# Wave 8 Implementation Docket

## Goal

Make trusted rollout work legible as a bounded campaign with explicit review rhythm,
drift windows, and rollback posture.

This wave should **not** create a new sovereign runtime or scheduling authority.
It should add reviewable campaign structure around the already-landed Codex plane.

---

## 1. `8Dionysus`

### Add doctrine
Create:

- `docs/TRUSTED_ROLLOUT_CAMPAIGNS.md`

Intent:
- define campaign batching for shared-root Codex-plane upkeep
- define drift review cadence as a review window, not a daemon
- define bounded rollback windows as explicit contingency posture
- keep campaign truth weaker than owner truth in neighboring repos

### Add schemas
Create:

- `schemas/rollout_campaign_window_v1.json`
- `schemas/drift_review_window_v1.json`
- `schemas/rollback_followthrough_window_v1.json`

### Add examples
Create:

- `examples/rollout_campaign_window.example.json`
- `examples/drift_review_window.example.json`
- `examples/rollback_followthrough_window.example.json`

### Rules
- stable `campaign_ref`
- stable `review_ref`
- stable `rollback_ref`
- lineage refs may cite `candidate_ref`, `seed_ref`, and `object_ref`
- campaign windows may cite rollout receipts but do not replace them
- rollback windows may cite rollback anchors but do not execute rollback automatically

---

## 2. `aoa-stats`

### Add docs
Create:

- `docs/ROLLOUT_CAMPAIGN_SUMMARY.md`
- `docs/DRIFT_REVIEW_SUMMARY.md`

### Add schemas
Create:

- `schemas/rollout_campaign_summary_v1.json`
- `schemas/drift_review_summary_v1.json`

### Add examples / generated starters
Create:

- `examples/rollout_campaign_summary.example.json`
- `examples/drift_review_summary.example.json`

### Rules
- summaries are derived-only
- summaries read reviewed campaign/drift artifacts only
- summaries never decide whether rollback is honest
- summaries keep batch and cadence legible without becoming scheduler authority

---

## 3. `aoa-playbooks`

### Add playbook
Create:

- `playbooks/rollout-drift-review-campaign/PLAYBOOK.md`

Intent:
- coordinate campaign batching
- coordinate cadence reviews
- coordinate bounded rollback follow-through
- return to last valid campaign or rollback anchor when drift wins

### Required artifacts
- `rollout_campaign_window`
- `drift_review_window`
- `rollback_followthrough_window`
- `campaign_summary_refresh_record`
- `drift_review_summary_refresh_record`

### Required posture
- experimental
- strict evaluation
- bounded memory
- review-required fallback

---

## 4. `aoa-memo`

### Add docs
Create:

- `docs/DRIFT_REVIEW_LESSON_MEMORY.md`
- `docs/ROLLBACK_FOLLOWTHROUGH_PATTERN.md`

### Add examples
Create:

- `examples/drift_review_lesson_memory.example.json`
- `examples/rollback_followthrough_pattern.example.json`

### Rules
- preserve campaign-scoped lessons without claiming proof
- preserve rollback patterns only after reviewed follow-through
- cite strongest available rollout / drift / rollback anchors

---

## 5. `aoa-sdk`

### Add boundary note
Create:

- `docs/codex_rollout_campaign_refs.md`

Intent:
- sdk may carry `campaign_ref`, `review_ref`, and `rollback_ref`
- sdk does not own campaign outcome or rollout truth
- sdk may help attach refs to reports, not decide campaign branching

---

## Acceptance bar

The wave is done when:
- one stable `campaign_ref` survives across campaign / drift / rollback / memo / stats examples
- derived stats surfaces summarize campaign and drift without turning into authority
- playbook route is clearly larger than one rollout action but smaller than generic program management
- memo examples preserve lesson/pattern posture without claiming proof
- sdk boundary note stays typed-carry only
