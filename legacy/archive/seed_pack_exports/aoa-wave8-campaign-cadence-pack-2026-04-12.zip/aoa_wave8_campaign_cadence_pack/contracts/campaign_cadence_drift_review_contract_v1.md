# campaign_cadence_drift_review_contract_v1

## Purpose

This contract introduces one bounded layer above trusted rollout operations:
campaign cadence.

It is for repeated, reviewable maintenance of the shared-root Codex plane and its
neighboring rollout surfaces.

## Core objects

### 1. `rollout_campaign_window`
A bounded campaign window for grouped rollout or regeneration work.

Required identity:
- `campaign_ref`

Carries:
- rollout scope
- lineage refs when relevant
- batch posture
- cadence policy
- review due time
- current state

It does **not**:
- claim rollout success by itself
- replace rollout receipts
- execute changes automatically

### 2. `drift_review_window`
A bounded review window over campaign drift.

Required identity:
- `review_ref`
- `campaign_ref`

Carries:
- named drift signals
- evidence refs
- review decision
- escalation or reanchor posture
- optional rollback anchor

It does **not**:
- become a scheduler
- become proof
- mutate rollout state by itself

### 3. `rollback_followthrough_window`
A bounded contingency window for rollback follow-through.

Required identity:
- `rollback_ref`
- `campaign_ref`

Carries:
- rollback anchor
- bounded scope
- trigger conditions
- post-rollback review requirement

It does **not**:
- authorize rollback by itself
- replace change protocol or approval surfaces
- erase rollout history

## Cross-repo ownership

- `8Dionysus` owns campaign doctrine and shared-root Codex-plane examples
- `aoa-stats` owns derived campaign and drift read models
- `aoa-playbooks` owns recurring campaign composition
- `aoa-memo` owns drift lessons and rollback patterns
- `aoa-sdk` may carry refs but does not own campaign truth

## Naming law

Stable names:
- `campaign_ref`
- `review_ref`
- `rollback_ref`

Optional lineage refs:
- `cluster_ref`
- `candidate_ref`
- `seed_ref`
- `object_ref`

## Minimal flow

`rollout_campaign_window -> drift_review_window -> rollback_followthrough_window? -> stats refresh -> memo writeback`

Rollback remains optional and contingent.

## Stop lines

Stop and return to review when:
- campaign scope widens beyond a bounded Codex-plane or owner-followthrough wave
- drift signals are being narrated without evidence
- rollback is invoked as convenience instead of contingency
- stats are asked to decide outcomes
- memo is asked to certify proof
- sdk starts acting like rollout authority
