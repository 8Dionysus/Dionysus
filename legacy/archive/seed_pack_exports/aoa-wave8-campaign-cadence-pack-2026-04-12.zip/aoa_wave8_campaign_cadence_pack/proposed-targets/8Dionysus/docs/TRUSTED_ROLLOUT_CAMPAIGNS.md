# Trusted Rollout Campaigns

This note defines bounded campaign batching for the shared-root Codex plane.

A campaign is:
- reviewable
- bounded in scope
- cadence-aware
- able to carry drift windows and rollback windows

A campaign is not:
- a scheduler empire
- proof authority
- a replacement for rollout receipts
- a reason to mutate by inertia

Core objects:
- `rollout_campaign_window`
- `drift_review_window`
- `rollback_followthrough_window`

Core rule:
campaign batching exists to keep repeated rollout upkeep legible.
It should never hide which owner surfaces still decide meaning.
