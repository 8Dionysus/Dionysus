# Codex Rollout Campaign Refs

`aoa-sdk` may carry:
- `campaign_ref`
- `review_ref`
- `rollback_ref`

It may attach them to reports or closeout carry.

It may not:
- decide campaign outcome
- decide rollback
- replace rollout receipts
