# Drift Review Lesson Memory

Preserve one bounded lesson from a reviewed drift window.

This memory kind is for:
- repeated deployment drift
- review cadence mistakes
- campaign batching lessons

It is not proof and it does not authorize rollout choices.
