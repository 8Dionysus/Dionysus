# Rollback Followthrough Pattern

Preserve one bounded recovery pattern after reviewed rollback follow-through.

Use it for:
- rollback scope discipline
- good anchor choice
- recovery sequencing

Do not use it as workflow authority or proof.
