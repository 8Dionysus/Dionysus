---
id: AOA-P-0027
name: rollout-drift-review-campaign
status: experimental
summary: Coordinates trusted rollout campaigns across bounded batches, drift review windows, and rollback follow-through without turning campaign cadence into scheduler sovereignty.
scenario: rollout_drift_review_campaign
trigger: repeated_trusted_rollout_ops_needing_campaign_rhythm
participating_agents:
  - architect
  - coder
  - reviewer
  - evaluator
  - memory-keeper
required_skills:
  - aoa-source-of-truth-check
  - aoa-approval-gate-check
  - aoa-dry-run-first
  - aoa-change-protocol
  - aoa-contract-test
expected_artifacts:
  - rollout_campaign_window
  - drift_review_window
  - rollback_followthrough_window
  - campaign_summary_refresh_record
  - drift_review_summary_refresh_record
fallback_mode: review_required
---
# rollout-drift-review-campaign

Use this playbook when trusted rollout operations are no longer isolated and now need a bounded campaign rhythm.

The playbook keeps explicit:
- batch scope
- cadence review timing
- drift signals
- rollback contingency
- summary refresh
- memoizable lesson or recovery pattern

Return posture:
- previous campaign anchor
- review gate
- rollback gate
- safe stop
