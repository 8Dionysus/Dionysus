# Rollout Campaign Summary

`aoa-stats` may summarize trusted rollout campaigns only as derived read models.

It may count:
- open batches
- pending review windows
- rollback-ready windows
- lineage-stage counts

It may not:
- decide whether a campaign is honest
- decide whether rollback should execute
- replace rollout receipts
