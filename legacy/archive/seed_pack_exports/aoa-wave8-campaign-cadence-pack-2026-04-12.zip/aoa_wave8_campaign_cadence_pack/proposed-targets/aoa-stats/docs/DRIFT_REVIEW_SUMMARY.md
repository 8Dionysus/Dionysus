# Drift Review Summary

This summary keeps cadence review legible without becoming a scheduler or proof layer.

It tracks:
- how many drift windows were reviewed
- which signals appeared
- which decisions were taken
