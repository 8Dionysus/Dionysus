
#!/usr/bin/env python3
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path


BASE = Path(__file__).resolve().parents[1]


def load_json(rel: str) -> dict:
    return json.loads((BASE / rel).read_text(encoding="utf-8"))


def parse_ts(value: str) -> datetime:
    if value.endswith("Z"):
        value = value[:-1] + "+00:00"
    return datetime.fromisoformat(value)


def main() -> int:
    campaign = load_json("examples/rollout_campaign_window.example.json")
    drift = load_json("examples/drift_review_window.example.json")
    rollback = load_json("examples/rollback_followthrough_window.example.json")
    campaign_summary = load_json("examples/rollout_campaign_summary.example.json")
    drift_summary = load_json("examples/drift_review_summary.example.json")
    drift_lesson = load_json("examples/drift_review_lesson_memory.example.json")
    rollback_pattern = load_json("examples/rollback_followthrough_pattern.example.json")

    errors: list[str] = []

    campaign_ref = campaign.get("campaign_ref")
    for name, doc in [
        ("drift", drift),
        ("rollback", rollback),
        ("campaign_summary", campaign_summary),
        ("drift_summary", drift_summary),
        ("drift_lesson", drift_lesson),
        ("rollback_pattern", rollback_pattern),
    ]:
        if doc.get("campaign_ref") != campaign_ref:
            errors.append(f"{name}: campaign_ref drift")

    if parse_ts(campaign["next_review_due_at"]) <= parse_ts(campaign["window_opened_at"]):
        errors.append("campaign: next_review_due_at must be after window_opened_at")

    if not any(campaign.get("lineage_refs", {}).values()):
        errors.append("campaign: at least one lineage ref family should be non-empty")

    if len(set(rollback["bounded_scope"]["paths"])) != len(rollback["bounded_scope"]["paths"]):
        errors.append("rollback: bounded_scope.paths contains duplicates")

    if drift["decision"] == "prepare_bounded_rollback" and rollback["status"] not in {"ready_if_needed", "armed"}:
        errors.append("rollback: incompatible status for prepare_bounded_rollback decision")

    expected_candidate_count = len(campaign.get("lineage_refs", {}).get("candidate_refs", []))
    if campaign_summary["stage_counts"].get("candidate_refs") != expected_candidate_count:
        errors.append("campaign_summary: candidate_refs count mismatch")

    if drift_summary["review_windows_total"] < 1:
        errors.append("drift_summary: review_windows_total must be >= 1")

    if drift_summary["signals_seen"].get("path_drift") != int(bool(drift["signals"].get("path_drift"))):
        errors.append("drift_summary: path_drift count mismatch")

    if drift_lesson["strongest_available_anchor"] != drift["review_ref"]:
        errors.append("drift_lesson: strongest_available_anchor should match review_ref")

    if rollback_pattern["strongest_available_anchor"] != rollback["rollback_ref"]:
        errors.append("rollback_pattern: strongest_available_anchor should match rollback_ref")

    if errors:
        raise SystemExit("Validation failed:\n- " + "\n- ".join(errors))

    print("wave8 campaign cadence pack: validation passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
