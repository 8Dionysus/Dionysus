# PR Slices

## PR-1: `8Dionysus` campaign doctrine + schemas
- add trusted rollout campaign doctrine
- add campaign / drift / rollback schemas
- add starter examples
- verify JSON validity

## PR-2: `aoa-stats` derived campaign/drift summaries
- add docs
- add schemas
- add examples
- ensure summaries remain derived-only

## PR-3: `aoa-playbooks` recurring campaign playbook
- add `rollout-drift-review-campaign`
- wire expected artifacts and anchors
- keep route experimental and review-required

## PR-4: `aoa-memo` drift and rollback memory seams
- add lesson/pattern docs
- add examples
- cite strongest available anchors

## PR-5: `aoa-sdk` typed-carry boundary
- add campaign-ref carry note
- keep sdk out of rollout authority

## PR-6: convergence + validation
- run repo-local validators
- run `python tools/validate_wave8_campaign_cadence.py`
- inspect drift between docs, examples, and route names
