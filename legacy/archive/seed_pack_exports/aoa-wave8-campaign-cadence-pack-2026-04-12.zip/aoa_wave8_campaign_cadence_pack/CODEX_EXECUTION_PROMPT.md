# Codex Execution Prompt: Wave 8 Campaign Cadence

You are landing Wave 8 of the AoA growth / Codex-plane program.

Goal:
Turn trusted rollout operations into bounded campaigns with explicit review rhythm,
drift windows, and rollback follow-through.

Follow this order exactly:
1. `8Dionysus`
2. `aoa-stats`
3. `aoa-playbooks`
4. `aoa-memo`
5. `aoa-sdk`

Rules:
- keep source ownership where it already belongs
- do not invent runtime daemons or scheduler authority
- do not let stats become authority
- do not let memo become proof
- do not let sdk become rollout owner
- prefer smallest honest surfaces
- keep names stable:
  - `campaign_ref`
  - `review_ref`
  - `rollback_ref`

Required deliverables:
- campaign doctrine and schemas in `8Dionysus`
- derived campaign/drift docs and schemas in `aoa-stats`
- `rollout-drift-review-campaign` playbook in `aoa-playbooks`
- memo lesson/pattern docs and examples in `aoa-memo`
- typed-carry boundary note in `aoa-sdk`

Before finalizing:
- run each repo's narrow validator path
- run `python tools/validate_wave8_campaign_cadence.py`
- report what landed, what drifted, and what still needs review
