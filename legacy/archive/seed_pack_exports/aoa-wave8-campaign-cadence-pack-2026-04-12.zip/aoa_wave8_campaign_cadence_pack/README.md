# aoa_wave8_campaign_cadence_pack

Wave 8 turns trusted rollout operations into a repeatable rhythm:
- campaign batching
- drift review cadence
- bounded rollback follow-through
- derived campaign summaries
- memoized rollout lessons and rollback patterns

This wave assumes Wave 7 has already landed or is landing.

## What this wave is for

Earlier waves made the Codex plane portable, deployable, and reviewable.
This wave adds **tempo** so the plane can be maintained through bounded campaigns
instead of isolated heroic fixes.

The new route is:

`rollout_campaign_window -> drift_review_window -> bounded_rollback_window -> summary refresh -> memo lesson/pattern`

## Repo targets

- `8Dionysus`
  - source-owned campaign doctrine for the shared-root Codex plane
  - campaign / drift / rollback schemas and examples
- `aoa-stats`
  - derived rollout campaign and drift review summaries
- `aoa-playbooks`
  - recurring `rollout-drift-review-campaign` playbook
- `aoa-memo`
  - drift review lesson and rollback follow-through pattern writeback
- `aoa-sdk`
  - typed carry note only, no rollout authority

## Recommended landing order

1. `8Dionysus`
2. `aoa-stats`
3. `aoa-playbooks`
4. `aoa-memo`
5. `aoa-sdk`

## Validation

Run the pack validator before sending Codex to land it:

```bash
python tools/validate_wave8_campaign_cadence.py
```

Then use the Codex prompt in `CODEX_EXECUTION_PROMPT.md`.

## Contents

- `IMPLEMENTATION_DOCKET.md`
- `PR_SLICES.md`
- `CODEX_EXECUTION_PROMPT.md`
- `ACCEPTANCE_MATRIX.md`
- `contracts/campaign_cadence_drift_review_contract_v1.md`
- `tools/validate_wave8_campaign_cadence.py`
- `proposed-targets/` starter surfaces
