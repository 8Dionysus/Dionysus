# Prediction Rivalry Campaign

Purpose: Repeated model-of-other prediction contests between actors or schools.

Runtime posture: candidate-only. This campaign coordinates reviewed trial episodes and owner handoffs.

Stop-lines: no live verdict, no durable scar, no rank mutation, no ToS/KAG promotion, no assistant contestant drift.
