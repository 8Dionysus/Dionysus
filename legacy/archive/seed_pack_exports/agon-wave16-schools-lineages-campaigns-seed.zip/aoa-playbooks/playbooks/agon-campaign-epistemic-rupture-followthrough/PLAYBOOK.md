# Epistemic Rupture Followthrough Campaign

Purpose: Followthrough on rupture candidates through delta, retention, and lineage episode candidates.

Runtime posture: candidate-only. This campaign coordinates reviewed trial episodes and owner handoffs.

Stop-lines: no live verdict, no durable scar, no rank mutation, no ToS/KAG promotion, no assistant contestant drift.
