# Bifurcation Survival Campaign

Purpose: Repeated branch tests after honest split rather than forced agreement.

Runtime posture: candidate-only. This campaign coordinates reviewed trial episodes and owner handoffs.

Stop-lines: no live verdict, no durable scar, no rank mutation, no ToS/KAG promotion, no assistant contestant drift.
