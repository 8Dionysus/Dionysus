# Agon Wave XVI Seed

Wave XVI is the first historical layer of Agon.

Earlier waves gave actors, assistants, gates, trials, packet grammar, laws, verdict/delta/scar bridges, a duel kernel, mechanical trials, retention/rank economy, and epistemic conflict. This wave prevents those events from remaining isolated sparks.

It prepares reviewed candidate forms for repeated conflict across time.
