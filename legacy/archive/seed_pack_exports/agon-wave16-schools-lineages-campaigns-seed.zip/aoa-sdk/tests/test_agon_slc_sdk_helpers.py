from __future__ import annotations
import json, pathlib, subprocess, sys
ROOT = pathlib.Path(__file__).resolve().parents[1]

def test_wave16_registry_shape():
    reg = json.loads((ROOT / 'generated/agon_slc_sdk_helpers.min.json').read_text(encoding='utf-8'))
    assert reg['wave'] == 'XVI'
    assert reg['count'] == 7
    assert len(reg['sdk_helpers']) == 7
    for item in reg['sdk_helpers']:
        assert item['live_protocol'] is False
        assert 'no_school_as_authority' in item.get('stop_lines', [])
        assert 'lineage_canonization' in item.get('forbidden_effects', [])

def test_builder_check_and_validator():
    assert subprocess.run([sys.executable, str(ROOT / 'scripts/build_agon_slc_sdk_helpers.py'), '--check'], cwd=ROOT).returncode == 0
    assert subprocess.run([sys.executable, str(ROOT / 'scripts/validate_agon_slc_sdk_helpers.py')], cwd=ROOT).returncode == 0
