#!/usr/bin/env python3
from __future__ import annotations
import json, pathlib, sys
ROOT = pathlib.Path(__file__).resolve().parents[1]
SRC = ROOT / 'config/agon_slc.seed.json'
OUT = ROOT / 'generated/agon_slc_registry.min.json'
ITEM_KEY = 'slc_components'
EXPECTED_COUNT = 10
ID_FIELDS = ['component_id', 'posture_id', 'playbook_id', 'alignment_id', 'intake_id', 'summary_id', 'helper_id']
REQUIRED_FORBIDDEN = ['live_verdict_authority', 'durable_scar_write', 'retention_execution', 'rank_mutation', 'trust_mutation', 'tree_of_sophia_promotion', 'kag_promotion', 'hidden_scheduler_action', 'assistant_contestant_drift', 'auto_doctrine_rewrite', 'school_authority', 'lineage_canonization', 'live_campaign_arena']
ALLOWED_RUNTIME = ('none', 'candidate_only', 'local_dry_run_candidate_only', 'local_rehearsal_candidate_only')
EXTRA_CHECKS = []

def fail(msg):
    print(msg, file=sys.stderr)
    return 1

def key_of(item):
    for field in ID_FIELDS:
        if item.get(field):
            return item[field]
    return item.get('id')

def validate_item(item):
    key = key_of(item)
    if not key:
        return 'missing item key'
    if item.get('wave') not in (None, 'XVI'):
        return f'unexpected wave for {key}: {item.get("wave")}'
    if item.get('live_protocol') is not False:
        return f'live_protocol must be false for {key}'
    if item.get('runtime_effect') not in ALLOWED_RUNTIME:
        return f'invalid runtime_effect for {key}: {item.get("runtime_effect")}'
    forbidden = set(item.get('forbidden_effects', []))
    for required in REQUIRED_FORBIDDEN:
        if required not in forbidden:
            return f'missing forbidden effect {required} for {key}'
    if item.get('assistant_contestant_allowed') is True:
        return f'assistant_contestant_allowed must not be true for {key}'
    if item.get('canonical_status') in ('canon','canonical','tree_of_sophia_canon'):
        return f'canonical status forbidden in Wave XVI for {key}'
    if item.get('authority_posture') in ('sovereign','authority','governing'):
        return f'authority posture leak for {key}'
    return None

def main():
    if not SRC.exists():
        return fail(f'missing source {SRC}')
    data = json.loads(SRC.read_text(encoding='utf-8'))
    items = data.get(ITEM_KEY, [])
    if len(items) != EXPECTED_COUNT:
        return fail(f'expected {EXPECTED_COUNT} items in {ITEM_KEY}, got {len(items)}')
    seen = set()
    for item in items:
        key = key_of(item)
        if key in seen:
            return fail(f'duplicate key {key}')
        seen.add(key)
        err = validate_item(item)
        if err:
            return fail(err)
    if OUT.exists():
        reg = json.loads(OUT.read_text(encoding='utf-8'))
        if reg.get('count') != len(items):
            return fail('generated count does not match source')
        if reg.get('wave') != 'XVI':
            return fail('generated wave must be XVI')
    print(json.dumps({'ok': True, 'item_key': ITEM_KEY, 'count': len(items)}, sort_keys=True))
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
