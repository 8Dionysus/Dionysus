# Validation Summary

- `Agents-of-Abyss` `build_agon_slc_registry.py`: green
- `Agents-of-Abyss` `validate_agon_slc_registry.py`: green
- `aoa-agents` `build_agon_agent_school_campaign_posture_registry.py`: green
- `aoa-agents` `validate_agon_agent_school_campaign_posture_registry.py`: green
- `aoa-playbooks` `build_agon_campaign_playbook_registry.py`: green
- `aoa-playbooks` `validate_agon_campaign_playbook_registry.py`: green
- `aoa-evals` `build_agon_slc_eval_alignment_registry.py`: green
- `aoa-evals` `validate_agon_slc_eval_alignment_registry.py`: green
- `aoa-memo` `build_agon_slc_memo_bridge_registry.py`: green
- `aoa-memo` `validate_agon_slc_memo_bridge_registry.py`: green
- `aoa-stats` `build_agon_slc_stats_observability_registry.py`: green
- `aoa-stats` `validate_agon_slc_stats_observability_registry.py`: green
- `aoa-sdk` `build_agon_slc_sdk_helpers.py`: green
- `aoa-sdk` `validate_agon_slc_sdk_helpers.py`: green
