# SEED MANIFEST — Agon Wave XVI: Schools / Lineages / Campaigns

This seed plants Wave XVI across seven repositories.

It does not open a live arena. It gives repeated epistemic conflict a historical candidate form: schools, lineages, campaigns, rivalries, branch survival, and doctrine evolution pressure.

Landing order:

1. `Agents-of-Abyss`
2. `aoa-agents`
3. `aoa-playbooks`
4. `aoa-evals`
5. `aoa-memo`
6. `aoa-stats`
7. `aoa-sdk`

Core invariant:

`school_candidate != authority`
`lineage_candidate != canon`
`campaign_candidate != live arena`
`doctrine_evolution_candidate != doctrine rewrite`
`branch_survival_candidate != Tree of Sophia branch`

Commands are repo-local. Run the build `--check`, validator, and tests in each landed repository.
