# Patch Notes

Adds candidate-only registries and owner surfaces for schools, lineages, campaigns, rivalries, branch survival, and doctrine evolution pressure.

No repo receives live verdict authority, scar writing, rank mutation, KAG promotion, or Tree of Sophia promotion.
