# Codex Landing Brief

Treat this as a multi-repo seed. Do not merge all directories into one repository.

Do not patch existing release checks automatically unless the owner asks. After landing, each repo may wire these validators into its release contour as an explicit commit.

Preserve all stop-lines. This wave is pre-KAG and pre-ToS.
