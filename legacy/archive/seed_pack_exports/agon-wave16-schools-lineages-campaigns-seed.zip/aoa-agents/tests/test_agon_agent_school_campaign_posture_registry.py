from __future__ import annotations
import json, pathlib, subprocess, sys
ROOT = pathlib.Path(__file__).resolve().parents[1]

def test_wave16_registry_shape():
    reg = json.loads((ROOT / 'generated/agon_agent_school_campaign_posture_registry.min.json').read_text(encoding='utf-8'))
    assert reg['wave'] == 'XVI'
    assert reg['count'] == 10
    assert len(reg['agent_school_campaign_postures']) == 10
    for item in reg['agent_school_campaign_postures']:
        assert item['live_protocol'] is False
        assert 'no_school_as_authority' in item.get('stop_lines', [])
        assert 'lineage_canonization' in item.get('forbidden_effects', [])

def test_builder_check_and_validator():
    assert subprocess.run([sys.executable, str(ROOT / 'scripts/build_agon_agent_school_campaign_posture_registry.py'), '--check'], cwd=ROOT).returncode == 0
    assert subprocess.run([sys.executable, str(ROOT / 'scripts/validate_agon_agent_school_campaign_posture_registry.py')], cwd=ROOT).returncode == 0
