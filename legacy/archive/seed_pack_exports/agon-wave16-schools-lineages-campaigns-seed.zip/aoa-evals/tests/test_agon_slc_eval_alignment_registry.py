from __future__ import annotations
import json, pathlib, subprocess, sys
ROOT = pathlib.Path(__file__).resolve().parents[1]

def test_wave16_registry_shape():
    reg = json.loads((ROOT / 'generated/agon_slc_eval_alignment_registry.min.json').read_text(encoding='utf-8'))
    assert reg['wave'] == 'XVI'
    assert reg['count'] == 8
    assert len(reg['eval_alignments']) == 8
    for item in reg['eval_alignments']:
        assert item['live_protocol'] is False
        assert 'no_school_as_authority' in item.get('stop_lines', [])
        assert 'lineage_canonization' in item.get('forbidden_effects', [])

def test_builder_check_and_validator():
    assert subprocess.run([sys.executable, str(ROOT / 'scripts/build_agon_slc_eval_alignment_registry.py'), '--check'], cwd=ROOT).returncode == 0
    assert subprocess.run([sys.executable, str(ROOT / 'scripts/validate_agon_slc_eval_alignment_registry.py')], cwd=ROOT).returncode == 0
