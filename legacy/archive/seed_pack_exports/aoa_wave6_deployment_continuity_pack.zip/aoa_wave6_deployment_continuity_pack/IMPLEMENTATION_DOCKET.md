# Wave 6 — Deployment continuity and rollout discipline

## Goal

Make the AoA Codex plane **deployable, inspectable, and reversible** as a governed live surface.

The previous wave made it possible to render project-level `.codex/config.toml` and
`.codex/hooks.json` from source-owned regeneration inputs. That solved portability.
This wave solves continuity:

- can we tell whether the live workspace is trusted and active?
- can we tell what got rendered and where?
- can we tell whether rollout was only rendered, actually applied, or later drifted?
- can we stop and roll back without losing the trail?

## Scope

### `8Dionysus`
Own the shared-root deployment doctrine and deploy-local report shapes.

Add:
- `docs/CODEX_PLANE_ROLLOUT.md`
- `schemas/codex_plane_trust_state_v1.json`
- `schemas/codex_plane_regeneration_report_v1.json`
- `schemas/codex_plane_rollout_receipt_v1.json`
- matching `examples/*.example.json`

Expected render/runtime locations under the live workspace root:
- `/.codex/generated/rollout/codex_plane_trust_state.current.json`
- `/.codex/generated/rollout/codex_plane_regeneration_report.latest.json`
- `/.codex/generated/rollout/codex_plane_rollout_receipt.latest.json`

Renderer / rollout behavior to land:
- renderer emits a regeneration report in both dry-run and execute modes
- rollout entrypoint captures trust-state before apply
- execute mode writes a rollout receipt after doctor / verify
- stable MCP server names remain unchanged:
  - `aoa_workspace`
  - `aoa_stats`
  - `dionysus`

### `aoa-sdk`
Own the typed status read for the live Codex plane.

Add:
- `docs/CODEX_PLANE_DEPLOY_STATUS.md`
- `schemas/codex_plane_deploy_status_snapshot_v1.json`
- `examples/codex_plane_deploy_status_snapshot.example.json`

Status snapshot builder / reader should:
- read the deploy-local rollout artifacts under `/.codex/generated/rollout/`
- expose a bounded live summary without turning `aoa-sdk` into rollout authority
- surface `trust_posture`, `rollout_state`, `hooks_active`, `project_config_active`,
  `active_mcp_servers`, `drift_detected`, and `next_action`

### `aoa-stats`
Own the derived deployment summary.

Add:
- `docs/CODEX_PLANE_DEPLOYMENT_SUMMARIES.md`
- `schemas/codex_plane_deployment_summary_v1.json`
- `examples/codex_plane_deployment_summary.example.json`

Summary posture:
- derived only
- based on rollout receipts / status snapshots
- no mutation authority
- no hidden trust override

### `aoa-playbooks`
Own the recurring rollout method.

Add:
- `docs/CODEX_PLANE_ROLLOUT_CYCLE.md`
- `examples/codex_plane_rollout_lane.example.json`

The lane should express:
- render
- trust-check
- dry-run validation
- execute apply
- doctor verify
- rollback decision
- stats refresh

## Contract edges

### Trust-state
The trust-state object answers:
- did the expected project root marker resolve?
- is project config active at the current root?
- are hooks enabled and discoverable?
- are named MCP servers present with the stable names we depend on?
- what is the current trust posture?

Allowed `trust_posture` values:
- `unknown`
- `root_mismatch`
- `config_inactive`
- `trusted_ready`
- `rollout_active`
- `rollback_recommended`

### Regeneration report
A regeneration report answers:
- what files were rendered?
- from what source profiles / templates?
- in what mode (`dry_run`, `check`, `execute`)?
- were stable MCP server names preserved?
- were warnings raised?

### Rollout receipt
A rollout receipt answers:
- what trust-state and regeneration report was this rollout based on?
- was it applied or only simulated?
- did doctor / verify pass?
- is rollback recommended?
- should stats refresh follow?

### Deploy-status snapshot
The status snapshot is `aoa-sdk`'s bounded read model over live rollout artifacts.

### Deployment summary
The stats summary is a derived view over multiple rollout receipts and status snapshots.

## PR slices

### PR-1 — `8Dionysus`
Land doctrine, three schemas, and three examples.

### PR-2 — `aoa-sdk`
Land deploy-status docs, schema, example, and builder/reader patch.

### PR-3 — `aoa-stats`
Land deployment summary doctrine, schema, example, and builder patch.

### PR-4 — `aoa-playbooks`
Land rollout-cycle doctrine and lane example.

## Stop lines

- Do not widen `.codex/` ownership beyond the shared-root subset already declared.
- Do not treat a successful render as a successful rollout.
- Do not let `aoa-stats` or `aoa-sdk` overrule live trust-state evidence.
- Do not rename MCP servers that earlier waves already wired into skills and validators.
- Do not let rollout artifacts become source truth inside `8Dionysus`; keep them deploy-local.

## Acceptance shape

A healthy landing makes it possible to point to:
- one trust-state contract and example
- one regeneration report contract and example
- one rollout receipt contract and example
- one typed deploy-status snapshot in `aoa-sdk`
- one derived deployment summary in `aoa-stats`
- one recurring rollout-cycle note in `aoa-playbooks`
- one validator pass that checks cross-repo coherence
