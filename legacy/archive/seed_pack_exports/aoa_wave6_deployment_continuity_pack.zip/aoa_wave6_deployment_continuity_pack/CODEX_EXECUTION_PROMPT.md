# Codex execution prompt — Wave 6

Implement the **deployment continuity and rollout discipline** wave for the AoA Codex plane.

Use this order and do not jump ahead:

1. `8Dionysus`
2. `aoa-sdk`
3. `aoa-stats`
4. `aoa-playbooks`

## Mission

The portability/regeneration wave made path-bound Codex-plane surfaces re-renderable.
This wave must make the **live rollout** legible and governable.

Land all of the following, staying narrow and source-owned:

- trust-state contract for the live workspace root
- regeneration report contract for render output
- rollout receipt contract for apply / verify / rollback posture
- typed deploy-status snapshot in `aoa-sdk`
- derived deployment summary in `aoa-stats`
- one recurring rollout-cycle method in `aoa-playbooks`

## Hard rules

- Keep `8Dionysus` as the source-owned home for the selected shared-root install subset only.
- Keep deploy-local generated rollout artifacts under `/.codex/generated/rollout/`.
- Do not rename the MCP server names `aoa_workspace`, `aoa_stats`, `dionysus`.
- Do not let `aoa-sdk` or `aoa-stats` become mutation authority for rollout.
- Do not treat dry-run render as a successful rollout.
- Keep rollback posture explicit.

## Artifacts to land

### `8Dionysus`
- `docs/CODEX_PLANE_ROLLOUT.md`
- `schemas/codex_plane_trust_state_v1.json`
- `schemas/codex_plane_regeneration_report_v1.json`
- `schemas/codex_plane_rollout_receipt_v1.json`
- matching examples

### `aoa-sdk`
- `docs/CODEX_PLANE_DEPLOY_STATUS.md`
- `schemas/codex_plane_deploy_status_snapshot_v1.json`
- example + bounded reader/builder patch

### `aoa-stats`
- `docs/CODEX_PLANE_DEPLOYMENT_SUMMARIES.md`
- `schemas/codex_plane_deployment_summary_v1.json`
- example + builder patch

### `aoa-playbooks`
- `docs/CODEX_PLANE_ROLLOUT_CYCLE.md`
- `examples/codex_plane_rollout_lane.example.json`

## Verification

Before opening the final PR or final grouped review:
- run each repo's local check/validator/build loop
- run the wave-6 cross-repo validator from this pack
- include a short note on any path-resolution or trust-state decisions
- call out any uncertainty explicitly rather than papering it over
