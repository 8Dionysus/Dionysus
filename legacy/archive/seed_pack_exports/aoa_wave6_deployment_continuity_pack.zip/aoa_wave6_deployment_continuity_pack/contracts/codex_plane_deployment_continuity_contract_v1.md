# Codex plane deployment continuity contract v1

## Purpose

Make the live AoA Codex plane deployable with provenance, trust, drift visibility, and rollback posture.

This contract sits **after** regeneration and **before** any later wider automation.

## Ownership

- `8Dionysus` owns shared-root deployment doctrine, trust-state, regeneration-report, and rollout-receipt contracts for the selected shared-root subset.
- `aoa-sdk` owns bounded typed reads over live rollout artifacts.
- `aoa-stats` owns derived deployment summaries.
- `aoa-playbooks` owns recurring rollout method.

## Live artifact family

Preferred deploy-local live output paths under the workspace root:

- `/.codex/generated/rollout/codex_plane_trust_state.current.json`
- `/.codex/generated/rollout/codex_plane_regeneration_report.latest.json`
- `/.codex/generated/rollout/codex_plane_rollout_receipt.latest.json`

These are deploy-local runtime artifacts. They are not copied back into source control as truth.

## Object family

### 1. `codex_plane_trust_state_v1`
Required fields:
- `schema_version`
- `trust_state_id`
- `workspace_root`
- `detected_project_root`
- `project_root_markers_expected`
- `project_root_marker_match`
- `project_config_active`
- `active_config_layers`
- `hooks_enabled`
- `hook_layers_detected`
- `mcp_server_names_expected`
- `mcp_server_names_detected`
- `stable_names_ok`
- `trust_posture`
- `warnings`
- `captured_at`

Allowed `trust_posture` values:
- `unknown`
- `root_mismatch`
- `config_inactive`
- `trusted_ready`
- `rollout_active`
- `rollback_recommended`

### 2. `codex_plane_regeneration_report_v1`
Required fields:
- `schema_version`
- `regeneration_report_id`
- `source_profile_ref`
- `target_workspace_root`
- `render_posture`
- `rendered_files`
- `stable_names`
- `warnings`
- `generated_at`

Allowed `render_posture` values:
- `dry_run`
- `check`
- `execute`

Each `rendered_file` contains:
- `relative_path`
- `source_path`
- `mode`
- `changed`
- `sha256`

### 3. `codex_plane_rollout_receipt_v1`
Required fields:
- `schema_version`
- `rollout_receipt_id`
- `trust_state_id`
- `regeneration_report_id`
- `apply_mode`
- `deployment_state`
- `doctor_result`
- `rollback_plan_ref`
- `stats_refresh_required`
- `verified_at`

Allowed `apply_mode` values:
- `dry_run`
- `execute`

Allowed `deployment_state` values:
- `render_only`
- `dry_run_ready`
- `applied`
- `verified`
- `drifted`
- `rollback_recommended`

Allowed `doctor_result` values:
- `pass`
- `warn`
- `fail`

### 4. `codex_plane_deploy_status_snapshot_v1`
This is `aoa-sdk`'s typed live read.

Required fields:
- `schema_version`
- `workspace_root`
- `trust_posture`
- `latest_trust_state_ref`
- `latest_rollout_receipt_ref`
- `project_config_active`
- `hooks_active`
- `active_mcp_servers`
- `rollout_state`
- `drift_detected`
- `next_action`
- `observed_at`

Allowed `next_action` values:
- `none`
- `run_doctor`
- `rerender`
- `rerollout`
- `rollback`

### 5. `codex_plane_deployment_summary_v1`
This is `aoa-stats`' derived read model.

Required fields:
- `schema_version`
- `summary_generated_at`
- `workspaces_total`
- `latest_rollout_state`
- `trust_posture_counts`
- `drift_count`
- `rollback_recommended_count`
- `stable_mcp_name_set`
- `latest_receipt_ref`

### 6. `codex_plane_rollout_lane`
Playbook-owned recurring lane that carries:
- render
- trust-check
- dry-run validation
- execute apply
- doctor verify
- rollback decision
- stats refresh

## Precedence

When deployment signals disagree, prefer:
1. live trust-state captured at the workspace root
2. rollout receipt doctor / verify outcome
3. `aoa-sdk` typed status snapshot
4. `aoa-stats` derived deployment summary

Do not let derived layers overrule live trust evidence.

## Guardrails

- stable MCP server names stay fixed
- no hidden trust override
- no hidden auto-apply from a render-only run
- no source-control writeback of deploy-local rollout artifacts
- rollback posture must remain explicit

## Minimum success condition

A healthy landing lets an operator answer, with one linked artifact family:
- where Codex thinks the project root is
- whether project config and hooks are active
- what `.codex/` surfaces were rendered
- whether rollout was only simulated, applied, verified, drifted, or rollback-recommended
- what action should happen next
