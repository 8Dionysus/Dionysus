#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

STABLE_NAMES = ["aoa_workspace", "aoa_stats", "dionysus"]

def load_json(path: Path):
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)

def fail(msg: str) -> None:
    print(f"FAIL: {msg}", file=sys.stderr)
    raise SystemExit(1)

def expect(cond: bool, msg: str) -> None:
    if not cond:
        fail(msg)

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=None, help="Pack root; defaults to parent of this script.")
    args = parser.parse_args()

    root = Path(args.root) if args.root else Path(__file__).resolve().parents[1]
    trust = load_json(root / "proposed-targets/8Dionysus/examples/codex_plane_trust_state.example.json")
    regen = load_json(root / "proposed-targets/8Dionysus/examples/codex_plane_regeneration_report.example.json")
    receipt = load_json(root / "proposed-targets/8Dionysus/examples/codex_plane_rollout_receipt.example.json")
    status = load_json(root / "proposed-targets/aoa-sdk/examples/codex_plane_deploy_status_snapshot.example.json")
    summary = load_json(root / "proposed-targets/aoa-stats/examples/codex_plane_deployment_summary.example.json")
    lane = load_json(root / "proposed-targets/aoa-playbooks/examples/codex_plane_rollout_lane.example.json")

    # Trust state basics
    expect("AOA_WORKSPACE_ROOT" in trust["project_root_markers_expected"], "trust-state must expect AOA_WORKSPACE_ROOT marker")
    expect(sorted(trust["mcp_server_names_expected"]) == sorted(STABLE_NAMES), "trust-state expected MCP names must match stable set")
    expect(sorted(trust["mcp_server_names_detected"]) == sorted(STABLE_NAMES), "trust-state detected MCP names must match stable set")
    expect(trust["stable_names_ok"] is True, "trust-state stable_names_ok must be true in happy-path example")

    # Regen report coherence
    expect(regen["target_workspace_root"] == trust["workspace_root"], "regen target root must equal trust workspace root")
    expect(all(name in regen["stable_names"] and regen["stable_names"][name] is True for name in STABLE_NAMES), "regen stable_names must keep all stable names true")
    rendered_paths = {item["relative_path"] for item in regen["rendered_files"]}
    expect(".codex/config.toml" in rendered_paths, "regen report must include .codex/config.toml")
    expect(".codex/hooks.json" in rendered_paths, "regen report must include .codex/hooks.json")

    # Rollout receipt coherence
    expect(receipt["trust_state_id"] == trust["trust_state_id"], "rollout receipt must point to trust-state id")
    expect(receipt["regeneration_report_id"] == regen["regeneration_report_id"], "rollout receipt must point to regeneration report id")
    expect(receipt["deployment_state"] == "verified", "happy-path receipt should be verified")
    expect(receipt["doctor_result"] == "pass", "happy-path doctor_result should be pass")

    # SDK status coherence
    expect(status["workspace_root"] == trust["workspace_root"], "status snapshot root must match trust root")
    expect(status["latest_trust_state_ref"] == trust["trust_state_id"], "status snapshot must point to trust-state id")
    expect(status["latest_rollout_receipt_ref"] == receipt["rollout_receipt_id"], "status snapshot must point to rollout receipt id")
    expect(sorted(status["active_mcp_servers"]) == sorted(STABLE_NAMES), "status snapshot active servers must match stable set")
    expect(status["rollout_state"] == receipt["deployment_state"], "status rollout_state must match receipt deployment_state")

    # Stats summary coherence
    expect(summary["latest_receipt_ref"] == receipt["rollout_receipt_id"], "stats summary must point to latest receipt id")
    expect(summary["latest_rollout_state"] == receipt["deployment_state"], "stats latest rollout state must match receipt")
    expect(sorted(summary["stable_mcp_name_set"]) == sorted(STABLE_NAMES), "stats stable name set must match stable set")

    # Playbook lane coherence
    phase_names = [phase["name"] for phase in lane["phases"]]
    required_phases = ["render", "trust-check", "dry-run-validate", "execute-apply", "doctor-verify", "rollback-decision", "stats-refresh"]
    expect(phase_names == required_phases, "playbook phases must match rollout cycle order")
    expect(trust["trust_state_id"] in lane["evidence_refs"], "playbook evidence refs must include trust-state id")
    expect(regen["regeneration_report_id"] in lane["evidence_refs"], "playbook evidence refs must include regeneration report id")
    expect(receipt["rollout_receipt_id"] in lane["evidence_refs"], "playbook evidence refs must include rollout receipt id")

    print("OK: wave-6 deployment continuity examples are coherent.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
