# aoa_wave6_deployment_continuity_pack

Wave 6 hardens the **live deployment life** of the AoA Codex plane.

The previous wave made the Codex plane portable by moving path-bound config and hooks into
source-owned regeneration inputs. This wave covers what happens after render:

- trust-state capture for the live workspace
- regeneration reports that describe what was rendered and where
- rollout receipts for apply / doctor / verify passes
- typed deploy-status snapshots in `aoa-sdk`
- derived deployment summaries in `aoa-stats`
- one recurring rollout lane in `aoa-playbooks`

## Why now

The public workspace install note already says the shared-root `.codex/` tree is source-owned
for the **current live deployment** and must be regenerated or adapted when the workspace root
changes. The checked-in project config still uses named MCP servers and path-bound working
directories, so the next risk is not missing bridges but silent rollout drift.

This pack keeps ownership narrow:

- `8Dionysus` owns shared-root Codex plane source copies, deployment doctrine, render/rollout
  contracts, and deploy-local report shapes.
- `aoa-sdk` owns typed reads and live workspace status snapshots.
- `aoa-stats` owns derived deployment summaries.
- `aoa-playbooks` owns the recurring rollout method and stop conditions.

## Main files

- `IMPLEMENTATION_DOCKET.md`
- `PR_SLICES.md`
- `CODEX_EXECUTION_PROMPT.md`
- `ACCEPTANCE_MATRIX.md`
- `contracts/codex_plane_deployment_continuity_contract_v1.md`
- `tools/validate_wave6_deployment_continuity.py`

## Proposed target highlights

- `8Dionysus/docs/CODEX_PLANE_ROLLOUT.md`
- `8Dionysus/schemas/codex_plane_trust_state_v1.json`
- `8Dionysus/schemas/codex_plane_regeneration_report_v1.json`
- `8Dionysus/schemas/codex_plane_rollout_receipt_v1.json`
- `aoa-sdk/schemas/codex_plane_deploy_status_snapshot_v1.json`
- `aoa-stats/schemas/codex_plane_deployment_summary_v1.json`
- `aoa-playbooks/docs/CODEX_PLANE_ROLLOUT_CYCLE.md`

## Landing order

1. `8Dionysus`
2. `aoa-sdk`
3. `aoa-stats`
4. `aoa-playbooks`

Do not start by widening MCP or subagent scope. This wave is about deployment continuity,
trust, and rollback posture for the Codex plane that already exists.
