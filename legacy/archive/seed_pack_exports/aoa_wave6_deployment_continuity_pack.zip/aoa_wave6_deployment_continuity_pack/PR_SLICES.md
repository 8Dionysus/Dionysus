# PR slices — Wave 6

## PR-1 — `8Dionysus`
Land:
- `docs/CODEX_PLANE_ROLLOUT.md`
- `schemas/codex_plane_trust_state_v1.json`
- `schemas/codex_plane_regeneration_report_v1.json`
- `schemas/codex_plane_rollout_receipt_v1.json`
- `examples/codex_plane_trust_state.example.json`
- `examples/codex_plane_regeneration_report.example.json`
- `examples/codex_plane_rollout_receipt.example.json`

Verification:
- `python scripts/validate_workspace_projection.py --check`
- schema/example validation if available
- repo tests

## PR-2 — `aoa-sdk`
Land:
- `docs/CODEX_PLANE_DEPLOY_STATUS.md`
- `schemas/codex_plane_deploy_status_snapshot_v1.json`
- `examples/codex_plane_deploy_status_snapshot.example.json`
- builder / typed reader patch

Verification:
- workspace-layout / control-plane checks
- builder `--check`
- repo tests

## PR-3 — `aoa-stats`
Land:
- `docs/CODEX_PLANE_DEPLOYMENT_SUMMARIES.md`
- `schemas/codex_plane_deployment_summary_v1.json`
- `examples/codex_plane_deployment_summary.example.json`
- summary builder patch

Verification:
- summary build `--check`
- validator
- repo tests

## PR-4 — `aoa-playbooks`
Land:
- `docs/CODEX_PLANE_ROLLOUT_CYCLE.md`
- `examples/codex_plane_rollout_lane.example.json`

Verification:
- playbook builders / validators
- repo tests

## Final cross-repo pass
Run:
- wave-6 cross-repo validator
- workspace doctor / rollout smoke once live
