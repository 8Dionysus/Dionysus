# CODEX_PLANE_ROLLOUT

## Purpose

This note defines the source-owned rollout discipline for the selected shared-root Codex plane
that `8Dionysus` projects into the live workspace root.

The scope stays narrow:
- project-level `.codex/config.toml`
- project-level `.codex/hooks.json`
- workspace-level agent/plugin/script install surfaces that belong to the selected shared-root subset

This note does not widen `8Dionysus` ownership beyond that subset.

## Live phases

1. render
2. trust-check
3. dry-run validation
4. execute apply
5. doctor verify
6. rollback decision
7. stats refresh

## Deploy-local artifacts

Preferred live outputs under the workspace root:
- `/.codex/generated/rollout/codex_plane_trust_state.current.json`
- `/.codex/generated/rollout/codex_plane_regeneration_report.latest.json`
- `/.codex/generated/rollout/codex_plane_rollout_receipt.latest.json`

## Trust-check

A healthy trust-check confirms:
- the workspace root resolves through `AOA_WORKSPACE_ROOT` or another expected project root marker
- project config is active at the current root
- hooks are enabled and discoverable from active config layers
- named MCP servers use the stable names:
  - `aoa_workspace`
  - `aoa_stats`
  - `dionysus`

## Rollback posture

Rollback is recommended when:
- the detected project root is wrong
- project config is inactive after apply
- hooks cannot be discovered after apply
- required MCP server names drift
- doctor returns `fail`

A rollback recommendation should produce a fresh rollout receipt rather than silently mutating history.
