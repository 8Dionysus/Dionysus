# CODEX_PLANE_DEPLOYMENT_SUMMARIES

`aoa-stats` owns the derived view over Codex-plane deployment continuity.

This summary is derived from rollout receipts and typed status snapshots.
It does not authorize rollout, trust, or rollback.

## Minimum fields

- latest rollout state
- trust posture counts
- drift count
- rollback recommendation count
- stable MCP name set
- latest receipt reference

## Source precedence

Prefer:
1. rollout receipts
2. typed deploy-status snapshots
3. other derived counters only as secondary shaping signals
