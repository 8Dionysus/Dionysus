# CODEX_PLANE_DEPLOY_STATUS

`aoa-sdk` owns the typed live read over deploy-local Codex-plane rollout artifacts.

It does not own rollout authority.

## Inputs

Read from the live workspace root:
- `/.codex/generated/rollout/codex_plane_trust_state.current.json`
- `/.codex/generated/rollout/codex_plane_regeneration_report.latest.json`
- `/.codex/generated/rollout/codex_plane_rollout_receipt.latest.json`

## Output

Expose one bounded status snapshot with:
- `trust_posture`
- `rollout_state`
- `project_config_active`
- `hooks_active`
- `active_mcp_servers`
- `drift_detected`
- `next_action`

The snapshot is for control-plane orientation and review. It is not a permission surface.
