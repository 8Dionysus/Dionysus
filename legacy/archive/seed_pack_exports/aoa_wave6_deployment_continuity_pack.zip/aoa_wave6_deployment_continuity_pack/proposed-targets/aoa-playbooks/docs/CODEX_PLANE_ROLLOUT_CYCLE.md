# CODEX_PLANE_ROLLOUT_CYCLE

This playbook owns the recurring rollout method for the live AoA Codex plane.

## Phases

1. render
2. trust-check
3. dry-run validate
4. execute apply
5. doctor verify
6. rollback decision
7. stats refresh

## Stop conditions

Stop before apply when:
- trust posture is `root_mismatch`
- trust posture is `config_inactive`
- stable MCP names drift
- dry-run validation fails

Stop after apply and recommend rollback when:
- doctor returns `fail`
- hooks are not active
- project config is not active
- drift is detected immediately after rollout

## Required artifacts

- trust-state
- regeneration report
- rollout receipt
- deploy-status snapshot
- deployment summary
