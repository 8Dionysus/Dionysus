# Acceptance matrix — Wave 6

| Area | What must exist | Acceptance |
|---|---|---|
| `8Dionysus` doctrine | `docs/CODEX_PLANE_ROLLOUT.md` | explains trust-state, regeneration reports, rollout receipts, rollback posture, and deploy-local output locations |
| `8Dionysus` trust-state | schema + example | example uses `AOA_WORKSPACE_ROOT`, preserves stable MCP names, and resolves to one allowed `trust_posture` |
| `8Dionysus` regeneration report | schema + example | example lists rendered `.codex/` files, render mode, stable MCP names, warnings |
| `8Dionysus` rollout receipt | schema + example | example references trust-state and regeneration report IDs and records doctor / verify result |
| `aoa-sdk` status snapshot | docs + schema + example | snapshot reflects live rollout state without becoming rollout authority |
| `aoa-stats` deployment summary | docs + schema + example | derived summary reports latest rollout state, trust counts, drift count, rollback recommendations |
| `aoa-playbooks` rollout cycle | docs + example | method includes render, trust-check, dry-run, execute, doctor, rollback decision, stats refresh |
| Cross-repo coherence | validator pass | IDs, server names, states, and artifact flow line up across examples |

## Required stable names

The following server names must remain unchanged in this wave:

- `aoa_workspace`
- `aoa_stats`
- `dionysus`

## Required deploy-local artifact paths

These paths are the preferred live output locations:

- `/.codex/generated/rollout/codex_plane_trust_state.current.json`
- `/.codex/generated/rollout/codex_plane_regeneration_report.latest.json`
- `/.codex/generated/rollout/codex_plane_rollout_receipt.latest.json`
