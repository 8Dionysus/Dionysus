# Patch notes

- Adds graph closure with cycle detection and depth limit.
- Adds graph snapshots and delta reports.
- Adds planner batch fields: `batch_order`, `graph_depth`, `edge_strength`, `propagation_batches`, `graph_closure_ref`.
- Adds `aoa recur graph snapshot`, `aoa recur graph closure`, and `aoa recur graph diff`.
- Adds read-only snapshot script.
