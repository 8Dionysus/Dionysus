# AOA Recurrence Graph Closure & Snapshot Seed

Second hardening seed after manifest compatibility. It turns the recurrence graph from direct walking into typed closure with depth, lineage, cycles, snapshots, deltas, and planner batches.

Primary landing target: `aoa-sdk`.

Run after planting:

```bash
python scripts/build_recurrence_graph_snapshot.py --workspace-root /srv/workspace --json
python -m pytest -q tests/test_recurrence_graph_closure_snapshot_seed.py
```

Read `aoa-sdk/docs/RECURRENCE_GRAPH_CLOSURE_AND_SNAPSHOT.md` for the law and stop-lines.
