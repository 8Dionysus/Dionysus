# Codex landing brief: graph closure seed

Plant this after the hardening/compatibility seed. Preserve the existing `expand_component_graph` public seam, but replace its internals with typed closure.

## Landing order

1. Merge `aoa-sdk/src/aoa_sdk/recurrence/models.py` additions.
2. Replace `graph.py` and `planner.py`.
3. Merge `api.py`, `io.py`, and `cli.py` graph command additions.
4. Add schemas, examples, docs, script, and tests.
5. Run the graph test, then run existing recurrence tests.

## Stop-lines

Do not turn graph snapshots into routing authority. Do not run plan commands during snapshot/closure. Do not promote techniques, skills, evals, or playbooks from graph shape alone.
