# Patch notes

Adds a new draft eval bundle:

```text
bundles/aoa-recurrence-control-plane-integrity/
```

This is a proof surface, not a scheduler, not a planner, and not a promotion engine.
