# AoA Recurrence Eval Suite Seed

Delta-seed for the first bounded proof surface that evaluates the recurrence control-plane itself.

Primary owner repo: `aoa-evals`.
Support note for `aoa-sdk` is included, but this seed does not add SDK execution logic.

The bundle checks whether recurrence artifacts preserve their authority boundaries:
registry hardening, graph closure, observation-only hooks, beacon/review separation,
downstream thinness, Agon stop-lines, and anti-overclaim wording.
