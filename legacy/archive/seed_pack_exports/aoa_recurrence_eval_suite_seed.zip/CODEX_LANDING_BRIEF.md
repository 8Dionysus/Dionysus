# Codex landing brief

Land into `aoa-evals` first.

```bash
python -m py_compile scorers/recurrence_control_plane_integrity.py scripts/run_recurrence_control_plane_integrity_eval.py
python scripts/run_recurrence_control_plane_integrity_eval.py   --case fixtures/recurrence-control-plane-integrity-v1/cases/RCPI-001.registry-mixed-manifests.json   --check-expected --json
python -m unittest -q tests/test_recurrence_control_plane_integrity_eval_seed.py
```

Then wire the bundle into catalog/index generation using current repo conventions. The seed provides insert notes, not generated-catalog rewrites.
