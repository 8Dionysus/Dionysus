---
name: aoa-recurrence-control-plane-integrity
category: meta-control-plane
status: draft
summary: Checks whether recurrence control-plane artifacts preserve typed propagation, observation-only hooks, owner review boundaries, thin downstream projections, and Agon stop-lines.
object_under_evaluation: recurrence control-plane run artifacts
claim_type: bounded
baseline_mode: none
report_format: summary
technique_dependencies:
  - recurrence-control-plane discipline
skill_dependencies: []
---

# aoa-recurrence-control-plane-integrity

## Intent

Use this eval when a recurrence wave or recurrence-enabled Codex session has produced manifests, change signals, graph closure reports, hook reports, observations, beacons, review decisions, downstream projections, or Agon-adjacent diagnostics, and you need to check whether those artifacts stayed inside the recurrence boundary.

This eval is not a global score for the project. It is a bounded integrity read for the recurrence control-plane itself.

## Bounded claim

This eval can support a claim like:

> On this bounded recurrence run, the control-plane loaded or quarantined mixed manifest shapes safely, built typed and reviewable propagation evidence, kept hooks observation-only, kept beacons subordinate to owner review, projected only thin downstream hints, and preserved Agon stop-lines.

It does **not** support claims such as:

- recurrence is complete across the whole federation;
- all downstream repos are fully connected;
- a technique or skill should be promoted;
- a beacon is a verdict;
- routing, stats, or KAG now own source truth;
- Agon runtime/session/scar/rank machinery is live;
- future recursor agents may spawn automatically.

## Evidence inputs

A careful run may include any subset of these artifacts, but the report must state which axes were actually supported:

- `manifest_scan_report`
- `graph_closure_report` or graph snapshot/delta report
- `propagation_plan`
- `hook_run_report`
- `observation_packet`
- `beacon_packet`
- `review_queue`
- `owner_review_decision` or decision close report
- downstream projection bundle for routing/stats/KAG
- Agon adapter/guard diagnostics

## Verdict logic

Suggested verdicts:

- `supports bounded claim`
- `mixed support`
- `does not support bounded claim`
- `insufficient evidence`

Rubric axes:

1. registry robustness
2. propagation closure
3. hook no-mutation
4. beacon boundary
5. review decision closure
6. downstream thinness
7. Agon stop-lines
8. anti-overclaim report posture

Missing axes are `not_observed`, not passes.

## Neighbor evals

Pair with `aoa-candidate-lineage-integrity` when SDK hints may become owner objects, with `aoa-eval-integrity-check` when proof wording inflates, and with `aoa-return-anchor-integrity` when the question is honest return/re-entry rather than recurrence control-plane integrity.
