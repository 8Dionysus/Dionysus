# Follow-up notes

These are recommended after the first-wave root refresh, but they are out of scope for the bounded seed unless Codex decides a tiny same-commit sync is unavoidable.

## Likely next passes

- `Agents-of-Abyss`: if you want `aoa-sdk` to become visible beyond the root README, align `CHARTER.md`, `ECOSYSTEM_MAP.md`, and any generated registry surfaces in one bounded center pass.
- `Dionysus`: search for lingering phrases that still describe `aoa-sdk` as deferred future separation.
- `8Dionysus`: if the profile grows again, move any expanded personal stack or working-method detail into `docs/` instead of the profile root.
- `abyss-stack`: consider a future `docs/START_HERE.md` or `docs/INDEX.md` so the root can stay short even as operational documentation expands.
- federation-wide second wave: normalize the deeper-entry convention across repos so roots point into a predictable `docs/START_HERE.md` or equivalent surface.
