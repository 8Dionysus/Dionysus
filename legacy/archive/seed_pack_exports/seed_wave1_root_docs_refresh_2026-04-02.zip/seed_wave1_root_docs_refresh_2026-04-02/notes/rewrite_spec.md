# Rewrite spec

This note explains what each root file is trying to preserve, reduce, move outward, or add.

| target | current words | proposed words | keep | cut / compress | move outward | add |
|---|---:|---:|---|---|---|---|
| `8Dionysus/README.md` | 650 | 511 | public face, two long-horizon anchors, core ecosystem map, GitHub stats | dedicated "What this profile is for" section, separate working-style section, oversized stack detail | deep doctrine stays in linked repos and `GLOSSARY.md` | `aoa-sdk` route, tighter intro, compressed stack |
| `8Dionysus/AGENTS.md` | 425 | 322 | profile-orientation role, GLOSSARY alignment, low-hype tone | extra repetition around sync rules | deeper repo doctrine stays out of profile repo | first-screen scan guardrail, explicit workflow |
| `Agents-of-Abyss/README.md` | 2035 | 647 | constitutional role, quick route table, linked wave notes | 17-step linear reading path, repeated wave exposition at root | detailed doctrine remains in linked docs | grouped route-by-need, compact current contour, `aoa-sdk` as related consumer surface |
| `Agents-of-Abyss/AGENTS.md` | 711 | 377 | ecosystem-boundary discipline, nested AGENTS precedence, validator entrypoint | repeated stylistic phrasing | layer-owned meaning stays in owning repos | clearer read-first order, hard-no list, bounded `aoa-sdk` note |
| `Dionysus/README.md` | 1642 | 690 | seed-garden role, source-of-truth order, planting workflow, validation | giant current-state inventory, oversized repo map | detailed inventory stays in repo tree, registry, manifests, and docs | compact live-surfaces section, explicit live-home note for `aoa-sdk` |
| `Dionysus/AGENTS.md` | 461 | 362 | nearest-file precedence, source-of-truth order, validation entrypoint | stale repo-specific deferred-separation phrasing | future-wave specifics stay in manifests, seeds, and registry | already-landed-repo rule, explicit hard-no list |
| `abyss-stack/README.md` | 1408 | 602 | Fedora-first / Windows-usable posture, path rule, route table, current runtime posture | 36-step linear reading path, oversized runtime inventory at root | deep operational detail stays in linked docs | grouped route-by-need, tighter ownership framing |
| `abyss-stack/AGENTS.md` | 374 | 439 | safety posture, hard-no list, host-facts rule | minimal read-first context | detailed validation commands stay repo-local where they already live | explicit read-first list, clearer verify section |

## Cross-repo design rule

- root `README.md` should identify, bound, and route
- root `AGENTS.md` should govern behavior, boundaries, workflow, and validation
- linked docs should carry the deep doctrine
- public map surfaces should stay accurate to the current public repo topology

## Special caution

`8Dionysus/README.md` is the public face. The rewrite keeps its rhythm deliberately closer to the current structure than the other three repos. It is tightened, not reinvented.
