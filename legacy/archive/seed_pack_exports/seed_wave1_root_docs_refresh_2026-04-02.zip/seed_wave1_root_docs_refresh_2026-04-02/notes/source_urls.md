# Source URLs used for this seed

Snapshot source date: 2026-04-02

## 8Dionysus
- https://raw.githubusercontent.com/8Dionysus/8Dionysus/main/README.md
- https://raw.githubusercontent.com/8Dionysus/8Dionysus/main/AGENTS.md
- https://raw.githubusercontent.com/8Dionysus/8Dionysus/main/GLOSSARY.md

## Agents-of-Abyss
- https://raw.githubusercontent.com/8Dionysus/Agents-of-Abyss/main/README.md
- https://raw.githubusercontent.com/8Dionysus/Agents-of-Abyss/main/AGENTS.md
- https://raw.githubusercontent.com/8Dionysus/Agents-of-Abyss/main/CHARTER.md
- https://raw.githubusercontent.com/8Dionysus/Agents-of-Abyss/main/ECOSYSTEM_MAP.md
- https://raw.githubusercontent.com/8Dionysus/Agents-of-Abyss/main/ROADMAP.md

## Dionysus
- https://raw.githubusercontent.com/8Dionysus/Dionysus/main/README.md
- https://raw.githubusercontent.com/8Dionysus/Dionysus/main/AGENTS.md

## abyss-stack
- https://raw.githubusercontent.com/8Dionysus/abyss-stack/main/README.md
- https://raw.githubusercontent.com/8Dionysus/abyss-stack/main/AGENTS.md
- https://raw.githubusercontent.com/8Dionysus/abyss-stack/main/ROADMAP.md

## Related public surfaces checked for routing
- https://raw.githubusercontent.com/8Dionysus/aoa-sdk/main/README.md
- https://raw.githubusercontent.com/8Dionysus/ATM10-Agent/main/README.md
- https://raw.githubusercontent.com/8Dionysus/Tree-of-Sophia/main/README.md
- https://raw.githubusercontent.com/8Dionysus/aoa-routing/main/README.md
