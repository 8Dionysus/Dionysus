# seed_wave1_root_docs_refresh

## Intent

Refresh the root `README.md` and root `AGENTS.md` surfaces for the first-wave repositories so that:

- root `README.md` files become easier to scan and better at routing
- root `AGENTS.md` files become clearer about boundaries, workflow, and validation
- the public face of the ecosystem stays compact without flattening meaning
- stale routing and stale separation language get corrected where the public layer already drifted

## Scope

This seed targets:

- `8Dionysus/README.md`
- `8Dionysus/AGENTS.md`
- `Agents-of-Abyss/README.md`
- `Agents-of-Abyss/AGENTS.md`
- `Dionysus/README.md`
- `Dionysus/AGENTS.md`
- `abyss-stack/README.md`
- `abyss-stack/AGENTS.md`

Default scope is limited to those root files.

If Codex sees a tiny adjacent sync that is required to avoid an immediate contradiction introduced by this seed, it may make that fix in the same bounded pass, but it should avoid drifting into a larger doctrine rewrite.

## Why this wave exists

The public roots are strong in meaning but several of them grew too large for their actual role.

- `8Dionysus` should stay a public foyer, not become a second constitutional center.
- `Agents-of-Abyss` should stay the center, but the root README should route faster and duplicate less of the linked doctrine.
- `Dionysus` should stay a seed garden, not a giant inventory page, and it should stop describing already-separated work as future separation.
- `abyss-stack` should keep its operational clarity without making the root README carry the full reading archive.

## Repository-specific intent

### `8Dionysus`

- preserve the current face and first-screen rhythm
- keep GitHub-profile friendliness and the stats block
- make the root more concise without flattening the two long-horizon anchors
- add `aoa-sdk` to the public route map without promoting it above its actual role

### `Agents-of-Abyss`

- keep the constitutional role explicit
- compress the root reading path into a grouped route-by-need shape
- keep the quick route table
- keep wave notes visible by link, not by reproducing their full spine at root
- mention `aoa-sdk` only as a related public consumer surface, not as a constitutional layer

### `Dionysus`

- keep the source-of-truth order and Codex planting discipline explicit
- reduce root-level inventory overload
- keep validation and planting usage visible
- remove stale phrasing that still treats `aoa-sdk` as deferred future separation

### `abyss-stack`

- keep the runtime path rule and ecosystem relationship explicit
- compress the root reading path into a grouped route-by-need shape
- keep the quick route table
- preserve the Fedora-first / Windows-usable posture without turning the root into a full ops index

## Apply order

Recommended order when applying repo by repo:

1. `Agents-of-Abyss`
2. `abyss-stack`
3. `Dionysus`
4. `8Dionysus`

This keeps owning and routing surfaces steady before the profile-level public entry page is refreshed against them.

## Acceptance criteria

A successful planting leaves:

- root READMEs shorter, clearer, and more route-first
- root AGENTS more explicit about ownership boundaries and working protocol
- `8Dionysus/README.md` still feeling like the public face rather than a flattened index
- no invented status or maturity claims
- no repo names, paths, or cross-repo roles silently changed
- `aoa-sdk` routed where appropriate without being promoted into a role it does not own

## Non-goals

- do not rewrite deeper docs in this wave unless a tiny same-commit sync is required
- do not move ownership out of the existing owning repositories
- do not add decorative new root files just to hold overflow
- do not over-normalize voice at the cost of repo identity
