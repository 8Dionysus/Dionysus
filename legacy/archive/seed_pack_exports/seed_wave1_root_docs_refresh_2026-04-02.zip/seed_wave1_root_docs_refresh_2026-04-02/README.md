# First-wave root docs refresh seed

This zip-seed is a bounded cross-repo refresh for root `README.md` and root `AGENTS.md` across the first-wave repositories:

- `8Dionysus`
- `Agents-of-Abyss`
- `Dionysus`
- `abyss-stack`

The goal is to make the roots more route-first, reduce overload in the public entry surfaces, tighten ownership boundaries, and remove stale or lagging routing where it is already visible from the public layer.

## Use this package in order

1. Read `seed_wave1_root_docs_refresh.md`.
2. Read `seed_wave1_root_docs_refresh.map.yaml` if you want the machine-readable transplant map.
3. Review `notes/rewrite_spec.md` for the keep / cut / move / add logic by repository.
4. Apply the proposed files under `transplant/` with adaptation to the live repo state.
5. Use `diffs/` for quick human review.

## Package contents

- `seed_wave1_root_docs_refresh.md` - central seed note for Codex and maintainers
- `seed_wave1_root_docs_refresh.map.yaml` - machine-readable target map and guardrails
- `notes/rewrite_spec.md` - repo-by-repo rewrite contour
- `notes/followups.md` - out-of-scope but recommended next passes
- `notes/source_urls.md` - raw public source URLs used for this seed
- `transplant/` - proposed replacement versions of root `README.md` and `AGENTS.md`
- `diffs/` - unified diffs against the public source snapshot used for this seed

## Guardrails

- Treat `8Dionysus/README.md` as the public face of the ecosystem. Preserve first-screen scan rhythm, public readability, and the GitHub profile feel.
- Keep roots route-first. Deep doctrine stays in linked docs.
- Keep exact repository names, capitalization, and hyphenation.
- Do not invent maturity, status, or visibility claims.
- Default scope is root `README.md` and root `AGENTS.md` only. If a tiny adjacent sync is required to avoid an immediate contradiction, keep that follow-up bounded and explicit.
