# Agon Wave IV Seed: Move Owner Binding

## Wave

Wave IV: Move Owner Binding.

## Purpose

Wave III gave Agon a lawful move vocabulary. Wave IV binds each lawful move to the owners that must later carry practice, bounded execution, proof, routing, scenario choreography, memory intake, derived observability, or actor-form constraints.

This seed does **not** create arena sessions, runtime packets, verdicts, scars, retention, or Tree-of-Sophia promotion.

## Shape

This is a multi-repo seed.

```text
Agents-of-Abyss/   primary center landing
aoa-techniques/    companion owner candidate landing
aoa-skills/        companion owner candidate landing
```

The center landing should be applied first. The companion landings may be applied after the center registry is reviewed.

## Primary landing: Agents-of-Abyss

Adds:

```text
docs/AGON_MOVE_OWNER_BINDING.md
docs/AGON_MOVE_BINDING_MATRIX_MODEL.md
docs/AGON_OWNER_REPO_REQUESTS.md
docs/AGON_PRE_PROTOCOL_STOP_LINES.md
docs/AGON_WAVE4_LANDING.md
schemas/agon-move-owner-binding.schema.json
schemas/agon-move-owner-binding-registry.schema.json
config/agon_move_owner_bindings.seed.json
generated/agon_move_owner_binding_registry.min.json
scripts/build_agon_move_owner_binding_registry.py
scripts/validate_agon_move_owner_bindings.py
tests/test_agon_move_owner_bindings.py
examples/agon_move_owner_binding.example.json
quests/AOA-Q-AGON-0013-move-owner-binding.md
quests/AOA-Q-AGON-0014-technique-skill-owner-candidates.md
quests/AOA-Q-AGON-0015-eval-memo-routing-prebinding.md
```

Verify from `Agents-of-Abyss`:

```bash
python scripts/build_agon_move_owner_binding_registry.py --check
python scripts/validate_agon_move_owner_bindings.py
python -m pytest -q tests/test_agon_move_owner_bindings.py
```

## Companion landing: aoa-techniques

Adds requested-only practice candidates:

```text
docs/AGON_MOVE_TECHNIQUE_BRIDGE.md
docs/AGON_WAVE4_TECHNIQUE_LANDING.md
schemas/agon-technique-binding-candidate.schema.json
config/agon_technique_binding_candidates.seed.json
generated/agon_technique_binding_candidates.min.json
scripts/build_agon_technique_binding_candidates.py
scripts/validate_agon_technique_binding_candidates.py
tests/test_agon_technique_binding_candidates.py
examples/agon_technique_binding_candidate.example.json
quests/AOT-Q-AGON-0001-technique-binding-candidates.md
```

Verify from `aoa-techniques`:

```bash
python scripts/build_agon_technique_binding_candidates.py --check
python scripts/validate_agon_technique_binding_candidates.py
python -m pytest -q tests/test_agon_technique_binding_candidates.py
```

## Companion landing: aoa-skills

Adds requested-only bounded workflow candidates:

```text
docs/AGON_MOVE_SKILL_BRIDGE.md
docs/AGON_WAVE4_SKILL_LANDING.md
schemas/agon-skill-binding-candidate.schema.json
config/agon_skill_binding_candidates.seed.json
generated/agon_skill_binding_candidates.min.json
scripts/build_agon_skill_binding_candidates.py
scripts/validate_agon_skill_binding_candidates.py
tests/test_agon_skill_binding_candidates.py
examples/agon_skill_binding_candidate.example.json
quests/AOS-Q-AGON-0001-skill-binding-candidates.md
```

Verify from `aoa-skills`:

```bash
python scripts/build_agon_skill_binding_candidates.py --check
python scripts/validate_agon_skill_binding_candidates.py
python -m pytest -q tests/test_agon_skill_binding_candidates.py
```

## What this seed binds

The center registry covers all 18 Wave III lawful moves:

```text
assert_position
challenge_claim
request_evidence
offer_evidence_reference
probe_trace
deny_trace_closure
mark_contradiction
localize_contradiction
deny_closure
request_closure_review
request_summon_intent
request_witness
revise_position
stand_fast
concede
defer_with_cost
flag_scope_breach
escalate_to_agon_gate
```

## Invariants

- `Agents-of-Abyss` remains the center law owner.
- `aoa-techniques` receives practice candidates, not move law.
- `aoa-skills` receives workflow candidates, not proof truth or arena authority.
- All non-center owner refs remain `requested_not_landed`.
- Assistant boundaries stay explicit.
- No live protocol behavior is introduced.

## Next wave unlocked

Wave V: Agon Gate Routing.
