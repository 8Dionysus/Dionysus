# Codex Landing Brief

Land this as a disciplined overlay, not as a sovereign rewrite.

## Required behavior

- preserve source-owned repository boundaries
- keep recurrence read-only and reviewed
- keep `aoa-routing` thin and navigation-only
- keep `aoa-kag` regrounding-only where downstream owner truth is stronger
- keep `aoa-agents` projection explicit and subordinate to source profiles and wiring
- keep beacon output advisory until an owning repo explicitly reviews it
- keep hook output subordinate to `observe -> beacon -> ledger`, not parallel authority
- keep technique hooks publication-time and evidence-time, not runtime activation hooks

## Concrete landing moves

1. Replace or merge `aoa-sdk/src/aoa_sdk/recurrence/` with the seeded version
2. Register `RecurrenceAPI` on `AoASDK` if it is not wired yet
3. Register the `aoa recur ...` CLI group if it is not wired yet
4. Add the owner manifests and hook binding sets to the owning repos
5. Keep repo-local command names where the live workspace has drifted, but preserve the recurrence contract
6. Treat the new hook layer as an observation overlay beside the planner and beacon layers, not as a replacement for them

## Non-goals in this wave

- no automatic edits across repos
- no background reconciliation
- no auto-promotion from hint to canonical status
- no live scheduler lanes
- no automatic subagent spawning
- no conversion of routing, stats, or KAG into source truth

## Expected honesty

Some hook bindings will begin life with only one real artifact surface and one or two missing-path warnings. That is fine.

Those warnings are part of the value. The hook pack is also a connectivity probe.

The important thing is to keep the packet shapes stable now so later receipts, real-run artifacts, and witness-style subagents can contribute evidence without reinventing the control plane.
