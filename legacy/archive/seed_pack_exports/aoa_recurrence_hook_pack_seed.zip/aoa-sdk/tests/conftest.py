from __future__ import annotations

import sys
import types
from dataclasses import dataclass
from pathlib import Path

src_path = Path(__file__).resolve().parents[1] / "src"
if str(src_path) not in sys.path:
    sys.path.insert(0, str(src_path))

def _install_workspace_stub() -> None:
    if "aoa_sdk.workspace.discovery" in sys.modules:
        return

    workspace_pkg = types.ModuleType("aoa_sdk.workspace")
    discovery_mod = types.ModuleType("aoa_sdk.workspace.discovery")

    @dataclass
    class Workspace:
        root: Path
        federation_root: Path
        federation_root_source: str
        manifest_path: Path | None
        repo_roots: dict[str, Path]
        repo_origins: dict[str, str]

        @classmethod
        def discover(cls, root: str | Path) -> "Workspace":
            root_path = Path(root).expanduser().resolve()
            repo_roots = {}
            for child in root_path.iterdir():
                if child.is_dir():
                    repo_roots[child.name] = child
            return cls(
                root=root_path,
                federation_root=root_path,
                federation_root_source="test",
                manifest_path=None,
                repo_roots=repo_roots,
                repo_origins={name: "test" for name in repo_roots},
            )

    workspace_pkg.discovery = discovery_mod
    discovery_mod.Workspace = Workspace
    sys.modules.setdefault("aoa_sdk.workspace", workspace_pkg)
    sys.modules.setdefault("aoa_sdk.workspace.discovery", discovery_mod)


_install_workspace_stub()
