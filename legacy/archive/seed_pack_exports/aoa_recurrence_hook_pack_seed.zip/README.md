# AoA Recurrence Hook Pack Seed

This seed carries the first programmable recurrence wave forward, preserves the beacon layer, and adds the third contour: hook-bound observation producers.

It is meant to stay useful even if Codex lands only one archive. This pack therefore includes:

- the first-wave recurrence control plane under `aoa-sdk/src/aoa_sdk/recurrence/`
- the beacon layer and candidate ledger surfaces
- the same small integration patches for `aoa-sdk/src/aoa_sdk/api.py` and `aoa-sdk/src/aoa_sdk/cli/main.py`
- owner manifests for the first two seeded components
- owner manifests for the beacon-sensitive layers: techniques, skills, evals, and playbooks
- hook binding sets for techniques, skills, evals, and playbooks
- hook schemas, examples, docs, and tests

## What this wave adds

The first wave answers: "what must update now?"

The beacon wave adds a softer question: "what is trying to be born?"

This hook wave adds a third question:

- which current artifact families can feed the beacon layer programmatically
- where growth pressure is visible in receipts, trigger suites, harvests, and runtime evidence
- how to do that without turning recurrence into a hidden scheduler

## What it does not do

- it does not auto-promote anything
- it does not auto-edit owner repos
- it does not auto-activate skills
- it does not auto-create playbooks or eval bundles
- it does not create a hidden scheduler
- it does not make runtime evidence behave like portable proof authority by magic

## Intended landing order

1. Land `aoa-sdk/src/aoa_sdk/recurrence/`
2. Land `aoa-sdk/docs/`, `schemas/`, `examples/`, and `tests/`
3. Apply the tiny integration patches to `aoa-sdk/src/aoa_sdk/api.py` and `aoa-sdk/src/aoa_sdk/cli/main.py` if recurrence is not wired yet
4. Place the owner manifests and hook binding sets into the owning repos
5. Let Codex adapt command names or file paths where the live repo has drifted
6. Run the repo-local tests and validators after landing

## Core split

Keep three adjacent contours:

- `planner` and `doctor` own obligation recurrence
- `observe`, `beacon`, `ledger`, and `usage-gaps` own emergence recurrence
- `hooks` own thin observation production from current artifact families

The first contour says what is owed.
The second contour says what is trying to be born.
The third contour says where the system can start hearing its own quieter signals.
