# AOA Recurrence Hardening & Compatibility Seed

This seed is the first closure pass after the recurrence, beacon, hook, review, and rollout seeds. It hardens the recurrence registry so mixed `manifests/recurrence/**/*.json` files cannot break the control plane.

Core move: `load_registry()` becomes tolerant. It loads only `recurrence_component` manifests, recognises known foreign recurrence-adjacent shapes, quarantines malformed/unknown files as diagnostics, and lets `doctor` report the gaps instead of crashing.

## Landing order

1. Copy the `aoa-sdk/src/aoa_sdk/recurrence/` overlay into `aoa-sdk`.
2. Copy `aoa-sdk/scripts/validate_recurrence_manifests.py`.
3. Copy docs, schemas, examples, and tests.
4. Run:

```bash
python scripts/validate_recurrence_manifests.py --workspace-root /srv/workspace --json
python -m pytest -q tests/test_recurrence_hardening_compat_seed.py
```

## What this seed does not do

It does not create live Agon runtime behaviour. It does not promote techniques, alter skill boundaries, mutate eval verdicts, update KAG truth, or spawn agents. It only makes recurrence manifest loading survivable, inspectable, and reviewable.
