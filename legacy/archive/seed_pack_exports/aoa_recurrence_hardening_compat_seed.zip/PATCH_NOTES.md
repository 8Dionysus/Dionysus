# Patch Notes

## Added

- `aoa_sdk.recurrence.compat`
- `ManifestDiagnostic`, `ManifestScanReport`, `manifest_kind` discriminator support
- tolerant recursive scan of `manifests/recurrence/**/*.json`
- registry quarantine diagnostics
- manifest diagnostics in `ConnectivityGapReport`
- manifest validation script
- schema and examples for manifest scan reports and Agon adapter stubs

## Changed

- `RecurrenceComponent` accepts `manifest_kind: recurrence_component` and schema version `aoa_recurrence_component_v3`.
- `HookBindingSet` accepts `manifest_kind: hook_binding_set`.
- `ConnectivityGap.severity` now accepts `critical` in addition to `low|medium|high`.
- `ConnectivityGap.gap_kind` now includes manifest hardening gaps.
- `RecurrenceRegistry` records `foreign_manifests` and `diagnostics`.
- `doctor` can include manifest diagnostics as gaps.

## CLI seam

The seed includes a full `cli.py` overlay based on the wiring-rollout wave. If current `cli.py` has drifted, preserve local commands and carry over these two additions:

```bash
aoa recur manifest-scan --root /srv/workspace --json
aoa recur handoff <plan.json>
```

`handoff` is only an alias for `return-handoff`; it must not alter semantics.
