# Codex Landing Brief: Recurrence Hardening & Compatibility

Goal: land a tolerant manifest compatibility layer before expanding graph closure or live observation producers.

## Why

`manifests/recurrence` now contains several recurrence-adjacent shapes: component contracts, hook binding sets, rollout/review surfaces, and early Agon-shaped observation manifests. The component registry must not assume every JSON file is a `RecurrenceComponent`.

## Expected integration

- `compat.py` classifies each JSON file by explicit `manifest_kind`, by `schema_version`, or by shape heuristics.
- `registry.py` scans `manifests/recurrence/**/*.json`, loads only recurrence components, and keeps foreign/quarantined manifests as diagnostics.
- `doctor.py` surfaces invalid/unknown/adapter-required manifests as connectivity gaps.
- `scripts/validate_recurrence_manifests.py` gives CI and Codex a small smoke gate.
- `cli.py` gains `aoa recur manifest-scan` and an alias `aoa recur handoff` for `aoa recur return-handoff`.

## Guardrails

- Known hook manifests are not component gaps. They are foreign-but-known.
- Agon-shaped manifests are adapter-required, observation-only diagnostics. Do not create arena sessions, verdicts, scars, ranks, or agent spawns.
- Invalid JSON and invalid component shapes must never abort registry loading.
- Owner mismatch is low severity and loaded with discovered repo ownership, preserving current behaviour while making the rewrite visible.

## Smoke commands

```bash
python scripts/validate_recurrence_manifests.py --workspace-root /srv/workspace --json
python -m pytest -q tests/test_recurrence_hardening_compat_seed.py
```
