# Second-wave contour

## Essence

Wave one teaches the system to notice.
Wave two teaches the ecosystem to speak back more clearly.

That means better hints, better inspect surfaces, better closeout packets, and better derived visibility.
It does **not** mean a new central brain.

## Four workstreams

### A. Runtime truth bridge (`aoa-skills`)

Goal:
carry more of the useful runtime signal outward without pretending every useful discipline was an activated skill.

Good candidates:
- richer receipt fields for adjacent-layer relevance
- stable references from runtime receipts into closeout handoff notes
- optional explicit triage helper only after repeated proven need

### B. Shortlist precision (`aoa-routing`)

Goal:
give `aoa-sdk` better advisory hints about likely owner layers when multiple interpretations are plausible.

Good candidates:
- additive shortlist outputs
- confidence metadata
- owner-layer ambiguity signaling

Bad candidate:
- router becoming the semantic judge of what a playbook, eval, memo, or technique is

### C. Family entry contracts (owner repos)

Goal:
let non-skill layers expose compact inspect surfaces so first-wave candidates can be handled more cleanly.

Examples of the shape, not literal file names:
- a small typed entry for "what kind of eval surface is this?"
- a stable inspect hint for memo/provenance use
- a family entry ref for playbook-shaped recurring scenarios
- a role-posture inspect contract for agent-layer questions
- a portable-practice hint for technique promotion

These should stay lightweight.
The point is to increase precision, not to require each repo to build a giant runtime API.

### D. Observability (`aoa-stats`)

Goal:
make patterns visible across windows once real usage exists.

Useful summaries:
- activated vs manual-equivalent rates
- candidate-now vs candidate-later distribution
- owner-layer ambiguity frequency
- closeout-handoff volume by family
- repetition signals that correlate with promotion discussions

Stats should describe the weather, not steer the ship.

## Sequence

1. Land wave one.
2. Collect real reports.
3. Tighten `aoa-skills` receipts and `aoa-routing` shortlist hints.
4. Add family entry contracts only where repeated use justifies them.
5. Add stats summaries after the above creates enough signal worth observing.

## Second-wave anti-goals

- giant detector-skill
- router-owned meaning
- stats-owned promotion logic
- mandatory big-bang changes across all owner repos
- silent broadening of activation authority
