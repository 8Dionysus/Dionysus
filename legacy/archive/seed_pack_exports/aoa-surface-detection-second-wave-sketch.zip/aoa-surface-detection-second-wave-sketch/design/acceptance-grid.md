# Acceptance grid

A second-wave landing is healthy when these are true.

## Precision

- owner-layer shortlist quality improves in real sessions
- fewer ambiguous candidate clusters need manual interpretation
- Codex can inspect non-skill candidates more directly

## Honesty

- `manual-equivalent` never drifts into `activated`
- non-skill surfaces remain non-activating
- runtime truth still comes from executable skill paths when activation is claimed

## Closeout quality

- closeout packets contain stronger, family-aware references
- repeated candidates are easier to harvest or defer intentionally
- promotion-shaped notes stay reviewed, not live-mutating

## Observability

- derived summaries help humans see patterns across windows
- stats do not become control-plane authority

## Scope control

- second-wave value appears before every owner repo lands new surfaces
- no repo has to surrender canonical meaning to the SDK or router
