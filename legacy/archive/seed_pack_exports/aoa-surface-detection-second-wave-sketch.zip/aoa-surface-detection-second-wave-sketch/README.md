# AoA Surface Detection Second Wave Sketch

Date: 2026-04-07

This package is a **compact second-wave sketch** that follows the first-wave AoA surface-detection seam.

It assumes wave one has already landed in `aoa-sdk` with:

- a standing detection reflex in `AGENTS.md`
- an additive multi-surface detection report
- honest truth labels (`activated`, `manual-equivalent`, `candidate-now`, `candidate-later`)
- closeout-only promotion handoff

## What second wave is for

Second wave should **improve signal quality and cross-repo ergonomics** without breaking the wave-one posture:

- `aoa-sdk` remains the control-plane seam
- owner repos keep canonical meaning
- only executable skills can auto-activate
- non-skill surfaces stay inspect / hint / closeout objects
- stats remain derived views

## Second-wave contour

1. `aoa-skills`
   - expose richer runtime receipts and adjacent-layer hints
   - optionally add an explicit triage helper for human/Codex review
   - tighten the bridge from skill runtime truth to closeout handoff notes

2. `aoa-routing`
   - provide additive owner-layer shortlist hints for non-skill surfaces
   - improve routing-assisted precision without becoming semantic authority

3. `aoa-stats`
   - emit derived summaries across windows
   - track activation honesty and promotion-shape volume
   - never decide promotion on its own

4. owner repos (`aoa-playbooks`, `aoa-evals`, `aoa-memo`, `aoa-agents`, `aoa-techniques`)
   - add compact family entry surfaces and typed inspect hints
   - make first-wave detection more precise
   - avoid forcing a big-bang canon rewrite

## What should trigger wave two

Wave two becomes worth landing when one or more are true:

- first-wave reports recur in real sessions
- the same owner-layer ambiguity appears multiple times
- Codex keeps finding useful non-skill candidates but lacks stable inspect surfaces
- closeout handoffs show repeatable promotion shapes
- manual-equivalent versus activated needs better observability

## Inside this package

- `TO_CODEX.md` — direct brief for a repo-aware Codex pass
- `patch_map.cross_repo.yaml` — likely edit targets by repository
- `design/second-wave-contour.md` — architecture and sequencing
- `design/acceptance-grid.md` — what to prove before calling it done

## Posture

Second wave should feel like a **tightening spiral**, not a second foundation pour.
