# To Codex

Treat this package as a **cross-repo second-wave sketch**, not a rigid patch.

Read the live repos first and adapt naming, file locations, and command surfaces to what already exists.

## Read first

1. first-wave landing in `aoa-sdk`
2. `aoa-sdk` docs for surface detection and closeout handoff
3. `aoa-skills` runtime / receipts / generated indexes / `QUESTBOOK.md`
4. `aoa-routing` docs around flat routing and owner-layer selection
5. `aoa-stats` docs on derived views and non-authority posture
6. relevant family READMEs in:
   - `aoa-playbooks`
   - `aoa-evals`
   - `aoa-memo`
   - `aoa-agents`
   - `aoa-techniques`

## Primary goal

Harden cross-repo support around the first-wave detection seam without moving canonical meaning away from source repos.

## Required invariants

- Do not turn `.agents/skills/` into a second canon for non-skill meaning.
- Do not make `aoa-routing` the source of semantic truth.
- Do not let `aoa-stats` decide promotion.
- Do not auto-activate non-skill surfaces.
- Do not erase the distinction between `activated` and `manual-equivalent`.
- Do not require all owner repos to land new public objects before second-wave value appears.

## Best second-wave outcome

The best outcome is that Codex can move through live work with:

- better owner-layer shortlist precision
- clearer inspect surfaces for non-skill candidates
- stronger closeout packets
- derived observability across windows

while wave-one honesty stays intact.
