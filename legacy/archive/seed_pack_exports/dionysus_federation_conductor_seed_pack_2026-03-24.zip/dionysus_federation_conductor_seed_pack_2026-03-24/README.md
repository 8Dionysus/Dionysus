# Dionysus seed prep — federation conductor import pack
Date: 2026-03-24

This package is prepared for `8Dionysus/Dionysus` as a **staged `seed_expansion/` addition**, not as a new wave.

Why staged, not waved:
- `Dionysus` defines itself as the seed garden and dispatch layer, not the final owning home of repo meaning.
- the current registry already keeps a separate `next_live_seed` for ToS wider world-thought expansion.
- `seed_expansion/seed.aoa.agents-runtime-pack.v0.md` already records bounded runtime-follow-on slices (`R1` through `R5`) that landed post-wave.
- this pack extends that runtime line with the **control-plane / conductor body** imported from the Symphony discussion, without reopening the ninth wave and without replacing the current ToS gate.

Recommended placement inside `Dionysus`:
- `seed_expansion/seed.aoa.federation-conductor-pack.v0.md`
- `seed_expansion/notes/symphony-import-boundaries.md`
- optionally merge `seed_expansion/notes/suggested-seed-registry-append.yaml` into `seed-registry.yaml` as `wave: null` + `registry_status: gated_next` entries
- keep `navigation.next_live_seed` unchanged unless you explicitly want to reprioritize this pack

Files in this package:
- `seed_expansion/seed.aoa.federation-conductor-pack.v0.md`
- `seed_expansion/notes/symphony-import-boundaries.md`
- `seed_expansion/notes/suggested-seed-registry-append.yaml`

Pack intent:
- harvest the **transplantable orchestration invariants** from the Symphony / AoA dialogue
- keep source-owned meaning in the existing AoA repos
- add only the bounded seeds that belong in Dionysus before planting outward
