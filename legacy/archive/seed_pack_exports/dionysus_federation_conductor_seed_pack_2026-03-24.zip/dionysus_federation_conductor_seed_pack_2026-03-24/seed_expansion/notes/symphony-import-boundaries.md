# Symphony import boundaries for Dionysus
Date: 2026-03-24

## Why this note exists

The dialogue around Symphony produced useful orchestration patterns, but those patterns only stay fertile in AoA if they are translated into the current federation boundaries.

This note is a guardrail note for maintainers before planting the pack outward.

## Import these invariants

### 1. One authoritative runtime state
Import:
- reconcile-before-dispatch
- bounded concurrency
- retry / backoff
- stop when ineligible
- terminal cleanup

Translate into:
- `abyss-stack` conductor state and run ledger

Do **not** translate into:
- semantic ownership
- new repo center
- workflow doctrine in runtime code

### 2. Deterministic workspaces
Import:
- per-run workspace
- replay identity
- cleanup policy
- stable workspace keys

Translate into:
- work-unit identity + workspace key + lease-aware placement

Do **not** translate into:
- issue-tracker lock-in
- “one chat = one truth” runtime posture

### 3. Spec-first workflow posture
Import:
- orchestration should consume small inspectable contracts
- workflow law should be versioned

Translate into:
- `run_activation` assembled from:
  - `aoa-routing`
  - `aoa-playbooks`
  - `aoa-agents`
  - `aoa-memo`
  - `aoa-evals`

Do **not** translate into:
- one imperial `WORKFLOW.md`
- prompt sovereignty above source-owned repos

### 4. Worker pool discipline
Import:
- host caps
- lease discipline
- continuation locality

Translate into:
- local / Podman / remote worker classes under `abyss-stack`

Do **not** translate into:
- SSH or any one transport becoming architecture canon

### 5. Tool injection by session
Import:
- session-scoped tool grants

Translate into:
- capability capsules derived from role + playbook stage + memo/eval posture

Do **not** translate into:
- ambient tool access
- invisible privilege escalation

## Do not import these as AoA canon

- Linear as the ontology of work
- one repo-local workflow file as the soul of the system
- dashboard truth
- general-purpose workflow-engine ambitions
- runtime authoring ToS directly
- conductor as new sovereign meaning layer

## AoA-native translation formula

Use this translation, not the upstream repo shape:

`work source -> route_hint -> playbook activation -> agent profile / tier -> run_activation -> deterministic workspace -> runtime artifacts -> memo writeback seam -> eval verdict -> release / retry`

## Best owner map

- `abyss-stack`: conductor, work units, worker leases, operator surfaces, runtime assembly
- `aoa-routing`: route hints and entrypoints
- `aoa-playbooks`: activation meaning and scenario contracts
- `aoa-agents`: roles, tiers, allowed tool families, artifact contracts
- `aoa-memo`: writeback / recall boundaries
- `aoa-evals`: trace-to-verdict and proof posture
- `Tree-of-Sophia`: source-owned authored meaning only

## Final guardrail

Import the **discipline** of the orchestrator.

Do not import the orchestrator as a new religion.
