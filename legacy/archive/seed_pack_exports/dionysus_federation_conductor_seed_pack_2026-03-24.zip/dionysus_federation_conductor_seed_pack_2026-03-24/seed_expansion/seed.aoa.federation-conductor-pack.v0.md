seed_id: seed.aoa.federation-conductor-pack.v0
title: AoA Federation Conductor Pack
profile_anchor: 8Dionysus
projects:
  - AoA
kind: seed-pack
status: gated_next
priority: high
parent_seed: seed.aoa.agents-runtime-pack.v0
tags:
  - conductor
  - orchestration
  - control-plane
  - run-activation
  - workspace
  - worker-leases
  - capability-capsule
  - abyss-stack
  - artifact-first-operator-plane

# Seed Pack: AoA Federation Conductor Pack

## Purpose

This pack harvests the **transplantable orchestration patterns** from the dialogue around Symphony, agent civilizations, and the AoA federation.

It does **not**:
- reopen the ninth wave;
- replace the current `next_live_seed`;
- turn `Dionysus` into a runtime monolith;
- turn one vendor's repo shape into AoA canon;
- move meaning out of `aoa-routing`, `aoa-playbooks`, `aoa-agents`, `aoa-memo`, or `aoa-evals`.

This pack exists because the current AoA public layers already have:
- role and tier seams;
- playbook activation surfaces;
- memo writeback seams;
- trace-to-eval bridge surfaces.

What still needs a cleaner seed from this dialogue is the **runtime body that conducts them without stealing their meaning**.

## Provenance

- dialogue path:
  - Symphony as spec-first orchestrator
  - orchestration for civilizations of agents
  - grounding into the current `8Dionysus` repo federation
  - import posture: what to steal, what not to steal
- reference posture:
  - import **invariants**, not repo theater
  - import **lifecycle discipline**, not foreign sovereignty
  - keep AoA source-owned repos authoritative

## Preserved Vocabulary

- conductor
- lifecycle-smart, semantically dumb
- authoritative runtime state
- run_activation
- route_hint
- playbook activation
- agent profile
- tier binding
- work unit
- deterministic workspace
- worker lease
- continuation locality
- capability capsule
- session-scoped grants
- runtime artifacts
- memo writeback seam
- eval verdict
- release / retry / reconcile

## Compression

If this entire dialogue is squeezed into one AoA-native formula, it becomes:

`work source -> routing hint -> playbook activation -> agent profile / tier -> deterministic workspace -> runtime artifacts -> memo writeback seam -> eval verdict -> release / retry`

The conductor should be:
- **very smart** about lifecycle;
- **very dumb** about authored meaning.

## Anti-Goals

Do **not** import as canon:
- Linear-native worldview;
- monolithic `WORKFLOW.md` as sovereign prompt law;
- conductor as a new semantic source of truth;
- dashboard-first truth;
- general-purpose workflow engine ambitions;
- silent AoA ↔ ToS collapse;
- direct ToS authorship from runtime movement.

## AOA-SEED-C1 Federation Conductor

### Purpose

Put one explicit **federation conductor** into the runtime body so that AoA has:
- one authoritative run-state owner;
- bounded dispatch and reconciliation;
- explicit retry / backoff / stop rules;
- lifecycle authority that does not pretend to own meaning.

This is the runtime translation of the strongest orchestration lesson from the dialogue:
the conductor should coordinate the orchestra, not swallow the score.

### Repo Homes

- `abyss-stack`

### First Artifact Hint

- conductor contract note
- `run_ledger` schema
- one service-module or unit stub
- one operator-facing state readout example

### Preserved Vocabulary

- authoritative runtime state
- reconcile-before-dispatch
- bounded concurrency
- retry with backoff
- stop when ineligible
- terminal cleanup
- lifecycle-smart, semantically dumb

### Explicit Non-Goals

- move routing meaning into `abyss-stack`
- move playbook meaning into `abyss-stack`
- move role law into `abyss-stack`
- build a hidden agent-brain repo
- make the conductor a prompt archive
- turn n8n or any single runtime tool into doctrine

### What Stays In Neighboring Repos

- `aoa-routing` keeps navigation and route hints
- `aoa-playbooks` keeps scenario meaning and activation meaning
- `aoa-agents` keeps role, tier, and runtime artifact contracts
- `aoa-memo` keeps memory object meaning and writeback doctrine
- `aoa-evals` keeps verdict logic and bounded proof
- `Tree-of-Sophia` keeps source-authored knowledge meaning

### Public Contract

The conductor must only own lifecycle fields such as:

```yaml
run_id: string
work_unit_id: string
run_state: queued | leased | activating | running | verifying | paused | succeeded | failed | cancelled
activation_ref: string
workspace_ref: string
assigned_host: string | null
attempt: integer
next_retry_at: iso8601 | null
last_artifact_ref: string | null
stop_reason: string | null
created_at: iso8601
updated_at: iso8601
```

### First Planting Slice

Leave:
- one `docs/FEDERATION_CONDUCTOR.md` note in `abyss-stack`;
- one `schemas/run_ledger.schema.json`;
- one tiny example ledger row or fixture;
- one explicit note that the conductor is **not** semantic authority.

## AOA-SEED-C2 Derived Run Activation Pack

### Purpose

Replace the temptation of a monolithic orchestration prompt with a **derived run activation pack** assembled from source-owned surfaces.

AoA already has the right ownership split:
- routing owns the smallest-next hop;
- playbooks own scenario composition;
- agents own role and tier contracts;
- memo owns writeback and recall posture;
- evals own proof posture.

The conductor should consume a compact activation pack built from those surfaces, not invent an imperial `WORKFLOW.md`.

### Repo Homes

- `abyss-stack`
- `aoa-playbooks`
- `aoa-routing`
- `aoa-agents`
- `aoa-memo`
- `aoa-evals`

### First Artifact Hint

- one contract note for `run_activation`
- one schema-backed example pack
- one mapping note from source-owned inputs to runtime assembly

### Preserved Vocabulary

- run_activation
- route_hint
- playbook activation
- agent profile
- tier binding
- memory posture
- eval anchor
- source-owned meaning
- derived runtime assembly

### Explicit Non-Goals

- new authored meaning in the activation pack
- prompt monoliths pretending to be control plane
- duplication of playbook prose inside runtime assembly
- hidden override layer that quietly rewrites upstream contracts

### What Stays In Neighboring Repos

- `aoa-routing` publishes route hints and entrypoints
- `aoa-playbooks` publishes activation surfaces and scenario contracts
- `aoa-agents` publishes role, tier, and artifact contracts
- `aoa-memo` publishes writeback / recall seams and posture fields
- `aoa-evals` publishes eval hooks and verdict anchors

### Public Contract

```yaml
run_activation_id: string
work_unit_ref: string
route_hint_ref: string
playbook_activation_ref: string
agent_profile_refs: []
tier_binding_refs: []
memory_posture_refs: []
eval_anchor_refs: []
capability_policy_ref: string | null
non_goals: []
notes: string | null
```

### First Planting Slice

Leave:
- one `docs/RUN_ACTIVATION_PACK.md` note in `abyss-stack`;
- one `examples/run_activation.example.json`;
- one explicit dependency map showing which fields are source-owned upstream and which are assembled runtime-side.

## AOA-SEED-C3 Deterministic Work Units and Worker Leases

### Purpose

Make runtime execution AoA-native by introducing:
- **GitHub-native ingress** instead of tracker lock-in;
- deterministic work-unit identity;
- per-run workspaces;
- host-aware worker leasing;
- continuation locality.

The smallest orchestration unit in AoA should not be “whatever the current chat happens to be”.
It should be a named work unit that can be resumed, retried, moved, or cancelled without folklore.

### Repo Homes

- `abyss-stack`

### First Artifact Hint

- work-unit contract note
- workspace-key policy
- worker-lease schema
- one example of a GitHub-native ingress envelope

### Preserved Vocabulary

- work unit
- GitHub-native ingress
- deterministic workspace
- worker lease
- host caps
- continuation locality
- bounded concurrency
- retry budget

### Explicit Non-Goals

- Linear-shaped ontology as AoA canon
- hidden ephemeral folders with no replay identity
- worker allocation by mood
- unbounded parallelism
- network hop inflation when local workers are enough

### Public Contract

```yaml
work_unit_id: string
kind: github_issue | github_pr_comment | manual_task | replay
source_ref: string
workspace_key: string
preferred_host_class: local | podman | remote | any
lease_id: string | null
max_attempts: integer
retry_budget: integer
continuation_locality: same_host_preferred | any_host
cleanup_policy: preserve_on_fail | cleanup_on_success | preserve_all
```

```yaml
worker_lease:
  lease_id: string
  host_id: string
  capacity_class: small | medium | large
  current_runs: integer
  max_runs: integer
  acquired_at: iso8601
  expires_at: iso8601 | null
```

### First Planting Slice

Leave:
- one `docs/WORK_UNIT_MODEL.md` note in `abyss-stack`;
- one `schemas/work_unit.schema.json`;
- one `schemas/worker_lease.schema.json`;
- one example ingress envelope for GitHub issues or PR comments.

## AOA-SEED-C4 Capability Capsules and Session-Scoped Grants

### Purpose

Turn tool access into a visible runtime contract instead of ambient magic.

The conductor should inject a **capability capsule** per run stage from the intersection of:
- agent role contract;
- playbook stage;
- memory posture;
- eval posture;
- current work-unit risk.

This lets AoA import the good part of tool-session injection from the dialogue while keeping authority distributed.

### Repo Homes

- `abyss-stack`
- `aoa-agents`
- `aoa-playbooks`
- `aoa-memo`
- `aoa-evals`

### First Artifact Hint

- capability-capsule contract note
- one schema for stage-scoped grants
- one example capsule for `route`, `do`, and `verify`

### Preserved Vocabulary

- capability capsule
- session-scoped grants
- allowed tools
- stage-scoped rights
- memory write gate
- eval hook gate
- human override

### Explicit Non-Goals

- all tools always on
- hidden privilege escalation
- memo writeback from any stage by default
- eval verdict mutation from runtime code
- direct policy mutation without review

### What Stays In Neighboring Repos

- `aoa-agents` names allowed tool families and actor posture
- `aoa-playbooks` names stage order and scenario-level constraints
- `aoa-memo` names writeback and recall contract boundaries
- `aoa-evals` names proof hook and verdict boundaries
- `abyss-stack` assembles and enforces the runtime capsule

### Public Contract

```yaml
capability_capsule_id: string
run_id: string
stage: route | plan | do | verify | distill | deep_synthesis
allowed_tool_families: []
memory_read_modes: []
memory_write_modes: []
eval_hook_modes: []
human_override_required: boolean
expires_at: iso8601 | null
derived_from:
  agent_profile_refs: []
  playbook_refs: []
  memo_refs: []
  eval_refs: []
```

### First Planting Slice

Leave:
- one `docs/CAPABILITY_CAPSULES.md` note;
- one `schemas/capability_capsule.schema.json`;
- one `examples/capability_capsule.route.example.json`;
- one `examples/capability_capsule.verify.example.json`.

## Support Note: What This Pack Deliberately Does Not Import

Keep these as **import boundaries**, not deferred TODOs:

1. Do not make the conductor the author of playbook meaning.
2. Do not let runtime dashboards become the source of truth.
3. Do not let `aoa-kag` or any derived substrate replace source-owned meaning.
4. Do not let a future worker pool quietly become the new architecture center.
5. Do not let remote-worker support define the ontology of the system.
6. Do not let direct ToS writing emerge from runtime convenience.

## Suggested Planting Order

1. `AOA-SEED-C1` into `abyss-stack`
2. `AOA-SEED-C3` into `abyss-stack`
3. `AOA-SEED-C2` as the runtime assembly seam across `abyss-stack` + existing upstream surfaces
4. `AOA-SEED-C4` once the conductor and activation pack are visible

## Success Sign

This pack is planted well when:
- the runtime body gains orchestration discipline;
- no repo loses its meaning-owning boundary;
- a run can be resumed or retried without folklore;
- tool rights are visible and stage-scoped;
- the conductor feels like a conductor, not a coup.
