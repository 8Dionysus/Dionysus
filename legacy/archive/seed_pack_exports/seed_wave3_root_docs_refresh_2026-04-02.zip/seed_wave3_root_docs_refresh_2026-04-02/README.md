# Third-wave root docs refresh seed

This zip-seed is a bounded cross-repo refresh for root `README.md` and root `AGENTS.md` across the third-wave repositories:

- `aoa-techniques`
- `aoa-skills`
- `aoa-evals`
- `aoa-agents`
- `ATM10-Agent`
- `aoa-sdk`

The goal is to make the remaining roots faster to scan, tighten ownership boundaries, reduce root-level overload, and normalize the public topologies without flattening each repo into generic boilerplate.

## Use this package in order

1. Read `seed_wave3_root_docs_refresh.md`.
2. Read `seed_wave3_root_docs_refresh.map.yaml` if you want the machine-readable transplant map.
3. Review `notes/rewrite_spec.md` for the keep / cut / move / add logic by repository.
4. Apply the proposed files under `transplant/` with adaptation to the live repo state.
5. Use `diffs/` for quick human review.

## Package contents

- `seed_wave3_root_docs_refresh.md` - central seed note for Codex and maintainers
- `seed_wave3_root_docs_refresh.map.yaml` - machine-readable target map and guardrails
- `notes/rewrite_spec.md` - repo-by-repo rewrite contour
- `notes/followups.md` - out-of-scope but recommended next passes
- `notes/source_urls.md` - raw public source URLs used for this seed
- `transplant/` - proposed replacement versions of root `README.md` and `AGENTS.md`
- `diffs/` - unified diffs against the public source snapshot used for this seed

## Guardrails

- Treat this package as a target contour, not a blind overwrite. Preserve newer live semantics, docs, and validation paths that landed after the public snapshot.
- Keep roots route-first. Long inventories, wave history, and generated-surface detail stay in linked docs or generated surfaces.
- Keep exact repository names, capitalization, and hyphenation.
- Do not invent maturity, status, or visibility claims.
- Default scope is root `README.md` and root `AGENTS.md` only. If a tiny adjacent sync is required to avoid an immediate contradiction, keep it bounded and explicit.
