# Source URLs used for this seed

These are the public source snapshots used to build the diffs and transplants.

## Repository list snapshot

- https://github.com/8Dionysus?tab=repositories

## Root files

- https://raw.githubusercontent.com/8Dionysus/aoa-techniques/main/README.md
- https://raw.githubusercontent.com/8Dionysus/aoa-techniques/main/AGENTS.md
- https://raw.githubusercontent.com/8Dionysus/aoa-skills/main/README.md
- https://raw.githubusercontent.com/8Dionysus/aoa-skills/main/AGENTS.md
- https://raw.githubusercontent.com/8Dionysus/aoa-evals/main/README.md
- https://raw.githubusercontent.com/8Dionysus/aoa-evals/main/AGENTS.md
- https://raw.githubusercontent.com/8Dionysus/aoa-agents/main/README.md
- https://raw.githubusercontent.com/8Dionysus/aoa-agents/main/AGENTS.md
- https://raw.githubusercontent.com/8Dionysus/ATM10-Agent/main/README.md
- https://raw.githubusercontent.com/8Dionysus/ATM10-Agent/main/AGENTS.md
- https://raw.githubusercontent.com/8Dionysus/aoa-sdk/main/README.md
- https://raw.githubusercontent.com/8Dionysus/aoa-sdk/main/AGENTS.md
