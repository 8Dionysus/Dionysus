# Follow-up notes

These are recommended after the third-wave root refresh, but they are out of scope for the bounded seed unless Codex decides a tiny same-commit sync is unavoidable.

## Likely next passes

- `aoa-techniques`: if root pressure returns, consider a compact `docs/ROUTE_INDEX.md` or similar index for donor, selection, capsule, and source-lift families.
- `aoa-skills`: consider a dedicated docs index for portable export, trust/config, deterministic-resource, and tiny-router families so root can stay short even as those layers grow.
- `aoa-evals`: consider a compact proof-surface index for comparison, progression, and trace families if the docs tree keeps expanding.
- `aoa-agents`: consider a small start-here index inside `docs/` for profiles, tiers, cohorts, runtime seam, and recurrence surfaces if the public registry families keep branching.
- `ATM10-Agent`: keep `README.md`, `MANIFEST.md`, `ROADMAP.md`, `docs/RUNBOOK.md`, and `docs/SOURCE_OF_TRUTH.md` synchronized whenever document roles drift.
- `aoa-sdk`: as the SDK grows, consider a deeper `docs/START_HERE.md` or equivalent surface for topology, compatibility, and typed API families so root can stay lean.

## Federation-wide next pass

- normalize the deeper-entry convention across all remaining repos that still rely on long root reading paths instead of one predictable repo-owned start surface
- review cross-repo references again after all three waves land, especially where `aoa-sdk` should be named as a consumer surface but not promoted into an ownership role
