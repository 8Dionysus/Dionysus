# Rewrite spec

This note explains what each root file is trying to preserve, reduce, move outward, or add.

| target | current words | proposed words | keep | cut / compress | move outward | add |
|---|---:|---:|---|---|---|---|
| `aoa-techniques/README.md` | 755 | 337 | public-canon identity, start-here path, layer map, one end-to-end example | long deeper-route inventory and root-level surface enumeration | full source-lift, review, and donor details stay in docs and generated surfaces | grouped route families and cleaner local validation |
| `aoa-techniques/AGENTS.md` | 779 | 498 | reusable-extraction doctrine, boundedness, public hygiene | repeated neighboring-layer phrasing | fine-grained promotion and intake posture stays in linked docs | standardized read-first, workflow, and validation framing |
| `aoa-skills/README.md` | 2184 | 490 | operational-companion identity, layer position, runtime path, starter skill | 27-step reading order and giant generated-surface inventory | long wave history and exact generated-file detail stay in docs and generated surfaces | grouped runtime, evaluation, export, trust, and tiny-router families |
| `aoa-skills/AGENTS.md` | 1276 | 608 | bounded execution doctrine, technique-vs-skill rule, export caution | exhaustive generated-surface list and repeated public-hygiene prose | full command matrix stays in README and nested docs | clearer primary-object families and tighter verify rules |
| `aoa-evals/README.md` | 1835 | 453 | proof-layer identity, anti-overclaim posture, starter bundle, validation entry | long quick-route inventory and root-level proof-infra enumeration | deeper comparison, progression, and trace details stay in docs and generated surfaces | grouped route families and cleaner bounded-proof statement |
| `aoa-evals/AGENTS.md` | 833 | 561 | bounded-claim doctrine, verdict discipline, read-first order | repeated output-expectation wording | fine-grained interpretation guidance stays in bundle docs | stronger verify checklist and claim-shape framing |
| `aoa-agents/README.md` | 706 | 348 | role-layer identity, agent-is-not-skill rule, validation path | long linear reading path and root-level schema inventory | full contract families stay in docs, schemas, and generated surfaces | grouped profile, tier, seam, and progression routes |
| `aoa-agents/AGENTS.md` | 902 | 547 | role-boundary doctrine, agent-not-skill rule, source-family caution | repeated neighboring-layer phrasing | detailed contract inventories stay in README and source tree | tighter read-first, primary-object grouping, and verify block |
| `ATM10-Agent/README.md` | 209 | 221 | badges, compact public face, current highlights | none beyond small wording trims | deeper operating detail stays in manifest, roadmap, and runbook | explicit document-topology note |
| `ATM10-Agent/AGENTS.md` | 579 | 583 | Windows-first safety posture, dry-run rule, document-role discipline | minor repetition | deeper runbook and archived-track detail stays in linked docs | exact repo naming, explicit non-ownership note, nested-AGENTS rule |
| `aoa-sdk/README.md` | 428 | 392 | control-plane identity, current slice, workspace exception, compatibility path | seed-inventory heaviness | deeper blueprint and ecosystem-impact detail stays in docs | clearer start-here and ownership framing |
| `aoa-sdk/AGENTS.md` | 167 | 481 | workspace topology exception and manifest alignment | under-specified behavior guidance | fine-grained package-level behavior stays in code and tests | real owns/does-not-own, workflow, hard-no, and validation sections |

## Cross-repo design rule

- root `README.md` should identify, bound, and route
- root `AGENTS.md` should govern behavior, boundaries, workflow, and validation
- linked docs should carry deeper doctrine, inventories, and wave history
- grouped surface families are preferred over exhaustive root-level enumeration

## Special cautions

- `aoa-techniques` should still feel like the public canon, not a sterile index.
- `aoa-skills` should still signal real operational depth even after the root inventory is compressed.
- `ATM10-Agent` should stay compact. This is a tune-up, not a rebuild.
- `aoa-sdk` is new enough that the AGENTS expansion matters more than README shrinkage.
