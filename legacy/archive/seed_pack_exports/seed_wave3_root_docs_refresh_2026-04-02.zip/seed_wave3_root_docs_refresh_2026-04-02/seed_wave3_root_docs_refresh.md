# seed_wave3_root_docs_refresh

## Intent

Refresh the root `README.md` and root `AGENTS.md` surfaces for the third-wave repositories so that:

- root `README.md` files become easier to scan and better at routing
- root `AGENTS.md` files become clearer about boundaries, workflow, and validation
- deep doctrine stays in linked docs instead of swelling the public entry layer
- the remaining repos line up with the route-first shape established in waves one and two

## Scope

This seed targets:

- `aoa-techniques/README.md`
- `aoa-techniques/AGENTS.md`
- `aoa-skills/README.md`
- `aoa-skills/AGENTS.md`
- `aoa-evals/README.md`
- `aoa-evals/AGENTS.md`
- `aoa-agents/README.md`
- `aoa-agents/AGENTS.md`
- `ATM10-Agent/README.md`
- `ATM10-Agent/AGENTS.md`
- `aoa-sdk/README.md`
- `aoa-sdk/AGENTS.md`

Default scope is limited to those root files.

If Codex sees a tiny adjacent sync that is required to avoid an immediate contradiction introduced by this seed, it may make that fix in the same bounded pass, but it should avoid drifting into a larger doctrine rewrite.

## Why this wave exists

These are the remaining public roots after the first two waves, and they split into three different correction types:

- `aoa-techniques`, `aoa-skills`, and `aoa-evals` carry strong meaning but still over-enumerate deep reading paths and generated-surface inventories at root.
- `aoa-agents` has strong content but still carries a long linear route and a root-level validation inventory that can be grouped more cleanly.
- `ATM10-Agent` is already compact, so this wave only tightens topology language and fixes the root `AGENTS.md` naming drift.
- `aoa-sdk` is the newest public repo. Its root README is already clear, but its root `AGENTS.md` is still too thin for the federation role it now plays.

## Codex adaptation rule

Codex already has richer live repo context than this public snapshot.

Use this seed as a target contour:

- keep live semantics that landed after the public snapshot when they are real and compatible with repository boundaries
- preserve new docs, routes, or validation entrypoints instead of deleting them just because the transplant file is shorter
- shorten by grouping and re-routing, not by amputating genuinely live capabilities
- if live HEAD already solved part of this wave, merge toward the same shape instead of forcing the transplant text verbatim

## Repository-specific intent

### `aoa-techniques`

- keep the public-canon identity vivid
- shorten the root README without losing the technique-to-skill boundary
- group donor, selection, capsule, and source-lift families instead of enumerating every surface at root
- keep the AGENTS file strict about reusable extraction and boundedness

### `aoa-skills`

- keep the operational-companion identity relative to `aoa-techniques`
- shorten the long root start path into grouped routes by need
- preserve portable export, runtime seam, trust/config, deterministic-resource, and tiny-router families without listing every generated file at root
- keep AGENTS strict about canonical skill authoring versus generated export surfaces

### `aoa-evals`

- keep the proof-layer identity and anti-overclaim posture explicit
- group comparison, artifact/process, shared proof infra, and progression families instead of replaying the whole inventory at root
- keep the README honest about bounded proof and explicit limits
- keep AGENTS centered on claim boundaries and verdict discipline

### `aoa-agents`

- keep the role-layer identity explicit
- compress the root start path and validation inventory into grouped route families
- preserve the distinction between profiles, tiers, cohorts, runtime seam, progression, and consumer surfaces
- keep AGENTS strict that agents are not skills and not playbooks

### `ATM10-Agent`

- keep the README short and operator-facing
- preserve badges, current highlights, and human entry rhythm
- add a compact document-topology note so root, manifest, roadmap, and runbook roles stay legible
- fix the AGENTS file so the repo name matches the actual repository casing

### `aoa-sdk`

- keep the control-plane role explicit
- keep the README route-first around boundaries, topology, compatibility, and current slice
- expand the AGENTS file into a real workspace, boundary, and validation contract
- preserve the `abyss-stack` source-checkout exception as a first-class rule

## Apply order

Recommended order when applying repo by repo:

1. `aoa-techniques`
2. `aoa-skills`
3. `aoa-evals`
4. `aoa-agents`
5. `aoa-sdk`
6. `ATM10-Agent`

This keeps canon and layer-owned meaning steady before the newest consumer surfaces and project-facing companion repo are refreshed against them.

## Acceptance criteria

A successful planting leaves:

- root READMEs shorter, clearer, and more route-first
- root AGENTS files more explicit about ownership, workflow, and validation
- `aoa-techniques`, `aoa-skills`, and `aoa-evals` no longer using root as a giant reading-path archive
- `aoa-agents` clearer about source families without losing its role-layer specificity
- `ATM10-Agent` still compact and human-facing
- `aoa-sdk` now carrying a real agent/workspace contract at root
- no invented status or maturity claims
- no repo names, paths, or cross-repo roles silently changed

## Non-goals

- do not rewrite deeper docs in this wave unless a tiny same-commit sync is required
- do not move ownership out of the existing owning repositories
- do not add decorative new root files just to absorb overflow
- do not flatten repository identity in the name of uniformity
