# aoa-evals

Public library of portable evaluation bundles for agents and agent-shaped workflows.

`aoa-evals` is the proof layer in the AoA public surface. Where `aoa-techniques` stores reusable practice and `aoa-skills` stores bounded execution bundles, `aoa-evals` stores **evaluation bundles** that make claims about quality, boundaries, regressions, artifact output, and repeated-window movement reproducible, reviewable, and portable.

An eval here is not a random benchmark and not a pile of project-local tests. It is a bounded proof surface with clear claim limits, explicit scoring or verdict logic, defined fixtures or cases, known blind spots, and portable execution guidance.

## Start here

Use the shortest route by need:

- docs map: `docs/README.md`
- architecture: `docs/ARCHITECTURE.md`
- proof posture and limits: `docs/EVAL_PHILOSOPHY.md`
- current eval surface: `EVAL_INDEX.md`
- first starter bundle: `bundles/aoa-bounded-change-quality/EVAL.md`
- authoring template: `templates/EVAL.template.md`

## Route by need

- regression, peer comparison, and repeated-window reading: `docs/COMPARISON_SPINE_GUIDE.md`, `docs/REPEATED_WINDOW_DISCIPLINE_GUIDE.md`, and `generated/comparison_spine.json`
- artifact-side versus process-side reading: `docs/ARTIFACT_PROCESS_SEPARATION_GUIDE.md`
- runtime-artifact to verdict bridge: `docs/TRACE_EVAL_BRIDGE.md` and `docs/RUNTIME_BENCH_PROMOTION_GUIDE.md`
- shared proof infra and portable report surfaces: `docs/SHARED_PROOF_INFRA_GUIDE.md`, `fixtures/`, `runners/`, `scorers/`, `reports/`, and `schemas/`
- adjunct progression, self-agent, and recurrence seams: `docs/PROGRESSION_EVIDENCE_MODEL.md`, `docs/SELF_AGENT_CHECKPOINT_EVAL_POSTURE.md`, and `docs/RECURRENCE_PROOF_PROGRAM.md`
- selection surfaces: `EVAL_SELECTION.md`

## What belongs here

Good candidates:

- portable eval bundles for agent behavior
- bounded workflow evaluations
- boundary and authority adherence evals
- artifact-quality evals
- regression and comparison evals
- longitudinal movement evals
- scorers, rubrics, and verdict schemas
- shared fixture and runner contracts
- schema-backed report examples

Bad candidates:

- random tests with no portable evaluation contract
- raw project-local QA that was not generalized
- secret-bearing fixtures or logs
- massive uncurated run dumps
- techniques that belong in `aoa-techniques`
- skills that belong in `aoa-skills`
- undocumented scoring logic
- metrics with no interpretation boundary
- claims stronger than the evidence actually supports

## Core distinction

- `aoa-techniques` owns practice meaning
- `aoa-skills` owns bounded workflow meaning
- `aoa-evals` owns bounded proof meaning

In short:

`practice canon -> workflow canon -> proof canon`

The current public runtime path remains:

`pick -> inspect -> expand -> object use`

## What this repository does not try to do

`aoa-evals` does not provide a final or total measure of intelligence.
It does not reduce agent quality to one number.
It does not treat any single eval as the whole truth.

This repository prefers explicit limits over false objectivity.

## Local validation

Install local dependencies:

```bash
python -m pip install -r requirements-dev.txt
```

Run the full repository check:

```bash
python scripts/validate_repo.py
```

Refresh or parity-check the derived reader catalogs when needed:

```bash
python scripts/build_catalog.py
python scripts/build_catalog.py --check
```

If local sibling repositories are not checked out beside this repo, some dependency-target existence checks stay in the looser local path. Use the documented environment variables when you need the stricter federated path.

## Go elsewhere when...

- you need reusable practice meaning: `aoa-techniques`
- you need the bounded workflows under evaluation: `aoa-skills`
- you need routing and dispatch: `aoa-routing`
- you need role posture or handoff context: `aoa-agents`
- you need scenario-level composition: `aoa-playbooks`

## License

Apache-2.0
