# aoa-techniques

Public library of reusable techniques for coding agents and humans.

`aoa-techniques` is the public practice canon of AoA. It is not a snippet dump and not an “awesome list”. A technique here is a minimal reproducible unit of engineering practice: a workflow, validation pattern, safety protocol, documentation layout, evaluation loop, or transfer method that can travel cleanly across projects.

## Start here

Use the shortest route by need:

- repo-owned entrypoint: `docs/START_HERE.md`
- current technique map: `TECHNIQUE_INDEX.md`
- deeper docs map: `docs/README.md`
- one full bundle end to end: `techniques/agent-workflows/plan-diff-apply-verify-report/TECHNIQUE.md`
- authoring template: `templates/TECHNIQUE.template.md`
- contribution path: `CONTRIBUTING.md`

## Route by need

- layer position and neighboring repos: `docs/ECOSYSTEM_CONTEXT.md`
- donor intake, refinement, and promotion: `docs/DONOR_REFINERY_RUBRIC.md`, `docs/EXTERNAL_IMPORT_RUNBOOK.md`, `docs/CROSS_LAYER_TECHNIQUE_CANDIDATES.md`, `docs/PROMOTION_READINESS_MATRIX.md`, `docs/PROMOTION_WAVE_A_RUNBOOK.md`, and `docs/EXTERNAL_EVIDENCE_LEDGER.md`
- selection and chooser surfaces: `docs/TECHNIQUE_SELECTION_GUIDE.md`, `docs/TECHNIQUE_SELECTION.md`, and `docs/SELECTION_PATTERNS.md`
- runtime cards and capsules: `docs/TECHNIQUE_CAPSULES.md`, `generated/technique_capsules.json`, `generated/technique_capsules.min.json`, and `docs/TECHNIQUE_CAPSULE_GUIDE.md`
- source-lift, KAG, and repo-doc surfaces: `docs/KAG_EXPORT.md`, `generated/kag_export.json`, `generated/kag_export.min.json`, `docs/KAG_SOURCE_LIFT_GUIDE.md`, `docs/TECHNIQUE_SECTIONS.md`, `docs/REPO_DOC_SURFACES.md`, and `generated/repo_doc_surface_manifest.json`
- one end-to-end repo walk: `WALKTHROUGH.md`
- bounded release prep: `docs/RELEASING.md`

## What belongs here

Good candidates:

- agent workflows
- validation patterns
- documentation structures
- evaluation and monitoring loops
- safety and sanitization patterns
- infra operation techniques
- cross-repo promotion and reuse patterns

Bad candidates:

- random snippets
- private project hacks without adaptation notes
- secret-bearing configs
- raw logs
- project-only dumps
- undocumented scripts
- objects that belong as skills, evals, routing logic, role contracts, or playbooks

## Relationship to neighboring repositories

- `aoa-techniques` owns practice meaning
- `aoa-skills` owns bounded execution meaning
- `aoa-evals` owns bounded proof meaning
- `aoa-routing` owns navigation and dispatch hints
- `aoa-agents` owns role and persona contracts
- `aoa-playbooks` owns scenario composition

If a reusable contract can be extracted cleanly from a neighboring layer, the technique still belongs here once it becomes public-safe, bounded, and portable.

## Repository layout

- `techniques/` for published technique bundles
- `templates/` for technique authoring and promotion scaffolds
- `generated/` for derived catalogs, capsules, and source-lift surfaces
- `docs/` for doctrine, intake, release, and selection surfaces
- `scripts/` and `tests/` for validation and generation helpers

## Local validation

Install local dependencies:

```bash
python -m pip install -r requirements-dev.txt
```

Run the bounded repo check:

```bash
python scripts/release_check.py
```

Add targeted tests when scripts, schemas, or generated surfaces change.

## License

Apache-2.0
