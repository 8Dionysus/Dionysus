# Repo grounding

Read these first before editing. This seed is intentionally built against the current public contour.

## aoa-kag

Open in roughly this order:

1. `README.md`
2. `AGENTS.md`
3. `docs/KAG_MODEL.md`
4. `docs/FEDERATION_KAG_READINESS.md`
5. `docs/FEDERATION_SPINE.md`
6. `docs/SOURCE_OWNED_EXPORT_DEPENDENCIES.md`
7. `docs/REASONING_HANDOFF.md`
8. `manifests/federation_spine.json`
9. `manifests/source_owned_export_dependencies.json`
10. `scripts/kag_generation.py`
11. `scripts/validate_kag.py`

## aoa-routing

Open in roughly this order:

1. `README.md`
2. `AGENTS.md`
3. `docs/FEDERATION_ENTRY_ABI.md`
4. `generated/federation_entrypoints.min.json`
5. `scripts/build_router.py`
6. `scripts/validate_router.py`

## aoa-memo

Open in roughly this order:

1. `README.md`
2. `AGENTS.md`
3. `docs/KAG_SOURCE_EXPORT.md`
4. `generated/kag_export.min.json`

## aoa-sdk

Open in roughly this order:

1. `README.md`
2. `AGENTS.md`
3. `docs/boundaries.md`
4. `docs/workspace-layout.md`
5. the current KAG-facing typed facade and tests

## Optional adjacent proof pass

If the landing adds new durable generated surfaces or behavior contracts that would benefit from portable proof, inspect `aoa-evals/README.md` and keep any proof addition tightly bounded. Proof is optional for this wave, but boundary tests are not.
