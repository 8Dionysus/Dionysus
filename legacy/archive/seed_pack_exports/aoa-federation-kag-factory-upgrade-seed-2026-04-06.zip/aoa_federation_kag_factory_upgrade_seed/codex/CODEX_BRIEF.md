# Codex brief

You already know the workspace. Treat this as a bounded architecture upgrade, not as a doctrine rewrite.

## Core move

Convert the current federation KAG ingress from a **two-donor pilot with code-level hard assumptions** into a **manifest-driven donor system with explicit activation gates**.

The important nuance:

- a donor may be **published**
- a donor may be **visible inside a KAG registry**
- a donor may be **visible inside the live federation spine**
- a donor may be **visible inside routing**
- those are not the same event

This lets the system grow toward “KAG for any direction” without pretending every donor is already live or equally exposed.

## What to preserve

Preserve the current public law of the layer:

- source repos remain authoritative
- `aoa-kag` remains derived
- `aoa-routing` remains orientation, not authority
- `aoa-memo` remains memory, not proof
- `aoa-sdk` remains control-plane, not source-owner

Preserve existing live behavior unless an activation flag says otherwise.

## The actual bottleneck to remove

The system already has:
- a public `federation_kag_export` contract
- a live `federation_spine`
- a live two-repo routing seam
- a published memo donor export

But the current landing is still structurally narrower than the doctrine:
- federation donor handling is still specialized around the current pilot
- cross-repo supporting source inputs are not yet first-class at the validator / generator seam
- donor publication and donor exposure are not cleanly separated

## Preferred landing shape

### Mandatory

1. Generalize export validation so a source-owned export may keep:
   - exactly one `primary` source input
   - that primary input must belong to `owner_repo`
   - zero or more `supporting` inputs from the same repo or other repos

2. Introduce a manifest-driven donor registry in `aoa-kag` so donor visibility can be staged explicitly:
   - `registry_visible`
   - `spine_visible`
   - `routing_visible`

3. Refactor federation spine generation so it iterates declared donors rather than hardcoded repo names.

4. Keep the current live spine stable:
   - `aoa-techniques` stays live
   - `Tree-of-Sophia` stays live
   - `aoa-memo` may remain registry-only in this landing

5. Add or update tests so the new generic ingress path is proven without widening current user-facing exposure.

### Recommended

6. Add a generated `federation_export_registry(.min).json` surface in `aoa-kag`.
7. Let `aoa-routing` consume donor activation metadata if present, but keep current live `kag_view` cards unchanged unless visibility is explicitly turned on.
8. Add a typed `aoa-sdk` read path for the donor registry if the current facade layout makes that easy.

## Strong non-goals

Do not use this wave to:
- activate `AOA-K-0008`
- widen routing kinds
- turn KAG into graph sovereignty
- turn memo into graph truth
- replace current source-owned ToS entry posture
- add framework-specific storage or graph-engine commitments

## Naming freedom

Suggested manifest / output names are included in `proposed/`, but keep nearby canon if there is already a better internal naming pattern. The important thing is the behavior and boundary law, not the exact filename spelling.

## Delivery preference

Prefer one clean additive wave over a sprawling multi-repo cascade. If tradeoffs appear, prioritize:

1. `aoa-kag` ingress generalization
2. boundary tests and docs
3. routing compatibility
4. SDK convenience surface
