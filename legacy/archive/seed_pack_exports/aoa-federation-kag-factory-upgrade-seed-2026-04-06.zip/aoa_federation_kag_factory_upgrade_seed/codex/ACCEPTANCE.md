# Acceptance

This wave is done when the system becomes generic at the ingress layer without becoming wider in authority or live exposure than intended.

## Behavioral acceptance

### Mandatory

1. `aoa-kag` accepts a source-owned export with:
   - one `primary` source input owned by `owner_repo`
   - one or more cross-repo `supporting` inputs

2. the donor system is manifest-driven rather than repo-name hardcoded.

3. a downstream consumer can inspect one generated registry surface and see donor activation state.

4. the current live spine stays bounded by default:
   - `aoa-techniques` present
   - `Tree-of-Sophia` present
   - `aoa-memo` absent unless explicitly activated for the spine

5. current routing stays bounded by default:
   - no new active entry kind
   - no automatic memo `kag_view`
   - no authority moved into routing

### Optional but desirable

6. `aoa-sdk` exposes a typed donor-registry read helper.

## Suggested verification order

### aoa-kag

```bash
python scripts/generate_kag.py
python scripts/validate_kag.py
python scripts/validate_nested_agents.py
python -m unittest discover -s tests -p 'test_*.py'
```

### aoa-routing

```bash
python scripts/build_router.py
python scripts/validate_router.py
python -m pytest -q tests
```

### aoa-sdk

```bash
python -m pytest -q
python -m ruff check .
aoa workspace inspect /srv/aoa-sdk
aoa compatibility check /srv/aoa-sdk
```

## High-value assertions

- Current `federation_spine.min.json` remains semantically stable for live donors.
- New donor registry output includes `aoa-memo` with visibility gates set to hidden/off by default outside the registry.
- Supporting source inputs from other repos no longer fail validation just because they are supporting.
- Broken owner-primary posture still fails loudly.
- No new routing starter appears.
- No new active routing kind appears.
- `AOA-K-0008` remains unactivated.
