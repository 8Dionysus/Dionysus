# Risk notes

## Boundary risks

### 1. Registry drift becomes fake authority
The new donor registry must remain a guide to source-owned exports, not a replacement source.

### 2. Routing starts acting like canon
`aoa-routing` may consume donor activation metadata, but it must not point authority at router-owned generated surfaces.

### 3. Memo donor becomes silently “true”
`aoa-memo` export visibility must not inflate memory into proof or graph truth. Registry visibility is not truth promotion.

### 4. Two-donor pilot becomes wider by accident
Generic donor iteration must not automatically widen the live spine or routing exposure.

### 5. Counterpart wave gets accidentally activated
This landing is not permission to expose `AOA-K-0008`.

## Guardrail preferences

- keep live exposure behind explicit flags
- keep `tiny` as the default package tier
- prefer additive outputs over rewiring existing IDs
- preserve current ToS adjunct behavior unless a generic rule is clearly cleaner and still bounded
