# aoa-routing ABI delta

Routing changes are optional for this wave, but if touched, keep them extremely bounded.

## Desired behavior

- `aoa-routing` may consume donor activation metadata from `aoa-kag`.
- `aoa-routing` must not become authority for those donors.
- hidden donors must not automatically gain live `kag_view` cards.
- active entry kinds must remain unchanged.

## Minimal routing landing

1. Read the new donor registry if that simplifies federation-entry generation.
2. Keep current live `kag_view` cards:
   - `aoa-techniques`
   - `Tree-of-Sophia`
3. Do not emit `aoa-memo` unless `routing_visible` is explicitly true.
4. Do not add a new starter.
5. Do not add a new entry kind.

## Anti-confusion rule

A donor registry is still a derived readiness surface.
The first authority surface must remain in the owning repo.
