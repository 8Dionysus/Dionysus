# aoa-sdk control-plane delta

This repo is optional for the wave. Only land a change if there is already a clean KAG-facing typed facade.

## Good landing

Add a small typed read helper over the donor registry, for example in the spirit of:

- `sdk.kag.export_registry()`
- `sdk.kag.list_federation_exports()`
- `sdk.kag.export_visibility(owner_repo=...)`

The exact method names should follow existing SDK canon.

## Keep

- control-plane posture
- explicit workspace discovery
- no hidden heuristics
- no routing reimplementation
- no source ownership drift

## Avoid

- scraping routing output when the donor registry is the direct source
- adding service behavior
- duplicating KAG doctrine inside the SDK
