# aoa-kag implementation notes

These notes intentionally point at the current likely bottlenecks.

## Current code-level constraints to unwind

1. `load_federation_export_payload(...)` currently behaves like a narrow pilot validator.
   The desired change is:
   - exactly one primary source input
   - that primary input must belong to `owner_repo`
   - supporting inputs may belong to other repos

2. `build_federation_spine_payload(...)` is currently organized around named pilot inputs.
   The desired change is:
   - donor iteration via manifest
   - one donor registry / activation source of truth
   - spine emission filtered by `spine_visible`

3. donor publication and donor live exposure are still conceptually entangled.
   The desired change is:
   - registry-visible donor
   - spine-visible donor
   - routing-visible donor
   as separate booleans or equivalent explicit states

## Suggested minimal architecture

### Keep
- `source_owned_export_dependencies.json` as donor invariant contract
- `federation_spine.json` as live spine contract
- `AOA-K-0009` as current live spine surface id

### Add
- one donor activation / export registry manifest
- one generated donor registry output

This keeps the current shapes intelligible:
- dependency invariants stay invariants
- live spine stays live spine
- donor activation becomes explicit rather than inferred

## Suggested generator sequence

1. load dependency invariants
2. load donor activation registry
3. validate donor exports generically
4. emit full donor registry
5. emit live spine from donors where `spine_visible == true`
6. leave routing exposure to `aoa-routing`

## Suggested donor states for the first landing

- `aoa-techniques`
  - registry_visible: true
  - spine_visible: true
  - routing_visible: true

- `Tree-of-Sophia`
  - registry_visible: true
  - spine_visible: true
  - routing_visible: true

- `aoa-memo`
  - registry_visible: true
  - spine_visible: false
  - routing_visible: false

## Preferred restraint

Do not attempt to genericize everything at once.
It is enough to genericize the donor ingress and visibility gating while preserving the current live contour.
