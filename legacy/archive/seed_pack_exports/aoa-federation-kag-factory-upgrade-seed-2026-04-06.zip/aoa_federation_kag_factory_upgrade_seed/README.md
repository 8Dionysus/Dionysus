# AoA Federation KAG Factory Upgrade Seed

This packet is a bounded upgrade seed for Codex to land the next federation-KAG wave in the AoA workspace.

The seed assumes Codex already knows the workspace topology, local AGENTS rules, and the current generated-surface style. It should therefore act as a precise delta packet, not as a full repo explainer.

## Intent

Land a minimal but durable upgrade that turns the current bounded two-donor federation spine into a **manifest-driven federation ingress system** while preserving the current source-first boundary law:

- source repos keep authored meaning
- `aoa-kag` keeps derived substrate structure
- `aoa-routing` stays an orientation layer
- `aoa-memo` remains memory, not proof
- `aoa-sdk` stays on the control plane

## Desired landing

1. `aoa-kag` can validate and index **N source-owned `kag_export.min.json` donors** by manifest rather than by repo-specific hardcoding.
2. federation export validation accepts **one owner-primary source input plus cross-repo supporting source inputs**.
3. donor **publication**, **KAG visibility**, and **routing visibility** become separate gates.
4. the current live user-facing behavior remains stable unless a donor is explicitly activated.
5. the live spine may remain two-donor for now, but the substrate should no longer be structurally trapped in that shape.

## Start order

1. `codex/REPO_GROUNDING.md`
2. `codex/CODEX_BRIEF.md`
3. `codex/WORK_ITEMS.yaml`
4. `codex/ACCEPTANCE.md`
5. `proposed/`

## Package layout

- `codex/` — execution brief, work items, risks, and touchpoints
- `machine/` — machine-readable upgrade manifest and test matrix
- `proposed/` — suggested manifest/output shapes and repo-specific delta notes

## Working posture

Prefer the smallest additive wave that gets the system out of the current two-donor bottleneck without widening authority claims.

Preserve current IDs and downstream expectations where possible, especially:
- `AOA-K-0009` as the current live federation spine surface
- the current live `kag_view` cards in `aoa-routing`
- existing source-owned export semantics for `aoa-techniques` and `Tree-of-Sophia`

Do **not** use this wave to smuggle in a graph engine, counterpart activation, routing sovereignty, or memo truth inflation.
