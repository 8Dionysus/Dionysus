Seed bundle for `aoa-agents` Act I / Wave II / assistant formation.

Open `repo/SEED_MANIFEST.md` first.

This seed lands the service-facing assistant variants as additive companion surfaces
without rewriting the current core profile wire shape or widening the public role
catalog too early.
