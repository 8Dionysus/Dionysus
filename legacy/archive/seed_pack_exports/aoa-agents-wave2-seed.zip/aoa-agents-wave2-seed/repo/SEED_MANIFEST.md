# aoa-agents Wave II seed

This seed is for **Act I / Wave II / assistant formation** at the point where the
project needs a true service-bearing civil layer beside the agonic one.

This is **not** the same thing as the current repo-internal `ROADMAP.md` Wave 2.
The live repo's current cycle still names Wave 2 as scenario-backed reference
routes. This seed is the project-level second wave for the wider AoA program.

The seed is intentionally **additive**.

## Keep unchanged

Do not treat this seed as permission to rewrite the current core profile surface.

Keep these intact unless a stronger migration is explicitly chosen later:

- `profiles/*.profile.json`
- `schemas/agent-profile.schema.json`
- `generated/agent_registry.min.json`
- the current five seed roles
- the current runtime seam minimal landing
- the current checkpoint-stack discipline
- the current stress-posture and progression adjunct families
- any battle-facing adjuncts already landed from Wave I

## Land now

This seed adds four assistant companion families, each attached to an explicit
assistant variant id rather than embedded into the core profile shape:

- `assistant_service_contract_v1`
- `assistant_service_identity_v1`
- `assistant_service_governance_v1`
- `assistant_service_certification_v1`

It also adds:

- source adjunct files for five assistant variants anchored to the current seed roles
- one compact generated assistant index
- one standalone validator
- one standalone builder
- one test file
- three quest stubs for the landing

## Intent

The goal is not to widen the public role catalog yet.

The goal is to make assistants explicit as predictable, transparent, service-bound
actors whose growth is externally governed.

This means:

- pair assistants to existing seed roles as anchored variants
- keep assistant growth exogenous and release-governed
- land mandate, scope, transparency, escalation, and receipt discipline
- land service identity as uniform rather than heroic persona
- land certification and regression law rather than arena authority
- keep assistants unable to drift silently into hidden warrior behavior

## Variant law

A service variant is not a hidden rewrite of a live public role profile.

For this wave:

- `architect.assistant` is an assistant variant anchored to `architect`
- `coder.assistant` is an assistant variant anchored to `coder`
- `reviewer.assistant` is an assistant variant anchored to `reviewer`
- `evaluator.assistant` is an assistant variant anchored to `evaluator`
- `memory-keeper.assistant` is an assistant variant anchored to `memory-keeper`

These are **paired variants**, not a new public base-role family.

If the live repo later decides to make any assistant variant a first-class public
profile, that should be an explicit reissue step rather than a silent widening of
the current registry.

## First cast

This seed maps the current five public seed roles into service offices like this:

- `architect.assistant` -> `concierge`
- `coder.assistant` -> `notary`
- `reviewer.assistant` -> `monitor`
- `evaluator.assistant` -> `steward`
- `memory-keeper.assistant` -> `librarian`

These are assistant variants, not replacements for the current seed roles.

## Wave-II invariants

This seed preserves the following invariants:

- no changes to the published core profile wire shape
- no new live public role family
- no arena authority inside assistant surfaces
- no hidden summon
- no self-authored persistent policy rewrite
- no direct `Tree of Sophia` write path
- no silent scope expansion
- no service variant that pretends to be a warrior
- every assistant path leaves a structured receipt

## Suggested apply order

1. Land the docs and schemas.
2. Land the source adjunct files under `profiles/adjuncts/`.
3. Land the builder, validator, and tests.
4. Generate or refresh `generated/agent_wave2_assistant_index.min.json`.
5. Decide whether to wire these helpers into broader release checks.
6. Keep assistant variants derived and explicit until you deliberately widen the live public registry.

## Compatibility note

If Wave I from the project-level plan is already landed, mirror these assistant
variants into the generic kind split there with:

- `kind = assistant`
- `evolution_mode = exogenous_reactive`
- `revision_governance = operator_release_only`
- `history_mode = revision_log`

Do **not** alter the already-defined agonic seed actors in order to do that.

## Codex note

If the live repo already contains semantically equivalent service surfaces, merge
by meaning rather than duplicating by filename.

If the live repo has a stronger local convention than `profiles/adjuncts/`,
relocate the source adjuncts but preserve:

- the assistant-variant anchoring law
- the separation from the core profile surface
- the keep/do-not-widen rules of this seed
- the prohibition on silent conversion between service and agonic forms
