# ASSISTANT VARIANT MODEL

## Core claim

The assistant-bearing second wave should not widen the live public role catalog too
early.

Instead it should form **paired assistant variants** anchored to the current seed roles.

## Why anchored variants

The current repo already guards against premature role-family sprawl.

That matters here because service actors need explicit form, but the live public
registry does not yet need a second explosion of base-role ids.

Anchored variants let the repo say:

- this service actor descends from an existing role house
- this service actor is not identical to the agonic embodiment
- this service actor may later be reissued as a public profile, but not silently

## Variant identity

A variant is identified by:

- `assistant_id`
- `role_ref`
- `variant_key = assistant`

Recommended ids in this wave are:

- `architect.assistant`
- `coder.assistant`
- `reviewer.assistant`
- `evaluator.assistant`
- `memory-keeper.assistant`

## Anti-goals

Avoid treating a service variant as:

- a hidden rewrite of the public base role
- a mixed-form actor that can silently switch from service to combat
- a runtime implementation detail
- a disguised catalog expansion with no explicit reissue step

## Future promotion law

If a later cycle decides that a service variant deserves first-class public profile
status, do that as an explicit profile-issuance change with registry review.

Do not smuggle that transition through adjunct files alone.
