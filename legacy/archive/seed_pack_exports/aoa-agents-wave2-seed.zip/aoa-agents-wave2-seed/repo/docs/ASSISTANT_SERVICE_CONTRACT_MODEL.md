# ASSISTANT SERVICE CONTRACT MODEL

## Purpose

A service contract defines what an assistant is for and what it is not allowed to
become.

## What a useful contract must answer

A useful assistant service contract should answer:

- what office this service variant occupies
- what mandate it serves
- what actions are in scope
- what remains out of scope
- what actions are outright prohibited
- when escalation is mandatory
- what receipt must be left behind
- how memory behaves under this service posture

## Design rules

Service contracts in this wave should stay legible and bounded:

- prefer low or bounded output variance
- require receipts
- require explicit escalation posture
- keep memory writeback reviewed
- prohibit direct canon writing
- prohibit hidden summon
- prohibit persistent self-rewrite

## Relation to other layers

The service contract lives in `aoa-agents` because it describes the actor and its
boundary.

It does not replace:

- routing
- playbooks
- eval law
- memo meaning
- runtime implementation
