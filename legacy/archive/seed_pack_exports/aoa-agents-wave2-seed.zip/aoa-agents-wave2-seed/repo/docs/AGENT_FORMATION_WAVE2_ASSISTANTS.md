# AGENT FORMATION WAVE 2: ASSISTANTS

## Purpose

This note marks the landing discipline for the first explicit assistant-bearing
deepening of `aoa-agents`.

The repo already has clear role contracts and the project now also has the first
battle-facing deepening in view.

This wave gives the system the opposite pole:

predictable, transparent, service-bound actors whose growth is governed from
outside rather than produced by internal struggle.

## What already exists and stays

The following are already strong and should stay stable in this wave:

- compact source-authored profiles
- derived compact registry publication
- progression overlays
- stress posture overlays
- runtime seam minimality
- checkpoint-stack discipline
- the current five seed roles

## What this wave adds

This wave adds four assistant companion families:

- service contract
- service identity
- service governance
- service certification

Together these four families let the repo say:

- what an assistant is allowed to do
- how it must present itself in service
- who is allowed to change it
- how it proves that it remains predictable and bounded

## Why this is a turning-point wave

The project can no longer act as if every agent should be formed in the same fire.

Some actors must fight.

Some actors must hold shape.

The discipline of this wave is:

- keep the core profile surface stable
- add assistant depth through anchored variants
- resist new public role-family sprawl
- defer service runtime machinery

## What is deliberately deferred

This wave does **not** land:

- assistant runtime orchestration logic
- service routing gates
- service packet transport law
- service auto-upgrade logic
- new public base role families
- direct canon or `Tree of Sophia` writes
- arena authority for assistants

Those belong to later waves.

## Exit signals

Wave II is ready when all of the following are true:

- the five assistant variants each have a service contract adjunct
- the five assistant variants each have a service identity adjunct
- the five assistant variants each have a service governance adjunct
- the five assistant variants each have a service certification adjunct
- every assistant variant is at least `service_ready`
- at least one assistant variant is `certified_service`
- no assistant variant allows persistent self-revision
- no assistant variant omits receipts
- the core profile wire shape remains unchanged

## Relation to later waves

A later Agon protocol wave should be able to rely on assistants as stewards,
notaries, monitors, librarians, and concierges without treating them as hidden
combatants.

That is the entire aim of this landing.
