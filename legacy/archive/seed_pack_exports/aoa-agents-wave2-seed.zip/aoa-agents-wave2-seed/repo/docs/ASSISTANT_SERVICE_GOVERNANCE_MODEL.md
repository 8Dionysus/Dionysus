# ASSISTANT SERVICE GOVERNANCE MODEL

## Purpose

An assistant grows by external revision, certification, and reissue.

That law needs to be explicit.

## What governance must answer

A useful governance adjunct should answer:

- what kind this actor is expected to be
- what evolution mode it is expected to follow
- who may upgrade it
- whether certification is required
- whether rollback is allowed
- whether persistent self-revision is forbidden
- how release gates work
- how incidents and regressions are handled
- which self-changes are forbidden

## Core rule

For this wave assistants are expected to be:

- `assistant`
- `exogenous_reactive`

That means they may adapt execution in-session, but they do not silently rewrite
their persistent doctrine, scope, or authority.

## Anti-goals

Avoid treating governance as:

- a back door for runtime autonomy
- a way to smuggle new authority into service actors
- a myth that assistants are static and therefore need no revision law
