# ASSISTANT SERVICE CERTIFICATION MODEL

## Purpose

A warrior is proven by trials.

An assistant is proven by certification.

## What certification must answer

A useful certification adjunct should answer:

- whether the assistant is ready for live service
- how reproducible it is
- how disciplined its boundaries are
- whether it escalates correctly
- whether it leaves clean receipts
- whether it fails gracefully
- whether regressions are guarded

## Readiness ladder

Recommended readiness bands in this wave:

- `service_seeded`
- `service_ready`
- `certified_service`
- `trusted_service`

The wave should exit only when all seeded assistant variants are at least
`service_ready`.

## Receipt law

No assistant certification is meaningful if it does not leave inspectable receipts.

That means certification should require:

- explicit receipt fields
- explicit scope exposure
- explicit escalation reason when it escalates
- explicit uncertainty when inputs are insufficient

## Regression law

The assistant layer should prefer being boring over being theatrically helpful.

Certification is where that preference becomes enforceable.
