from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

from build_agent_wave2_assistant_index import build_index
from validate_agent_wave2_assistants import main as validate_main


EXPECTED_IDS = {
    "architect.assistant",
    "coder.assistant",
    "reviewer.assistant",
    "evaluator.assistant",
    "memory-keeper.assistant",
}


def test_build_index_has_expected_variants() -> None:
    data = build_index()
    assert data["variant_count"] == 5
    assert {item["assistant_id"] for item in data["variants"]} == EXPECTED_IDS


def test_validation_passes() -> None:
    assert validate_main() == 0
