from __future__ import annotations

import json
from pathlib import Path

from jsonschema import Draft202012Validator

from build_agent_wave2_assistant_index import build_index


ROOT = Path(__file__).resolve().parents[1]

SCHEMA_FILES = {
    "service_contract": ROOT / "schemas" / "assistant_service_contract_v1.json",
    "service_identity": ROOT / "schemas" / "assistant_service_identity_v1.json",
    "service_governance": ROOT / "schemas" / "assistant_service_governance_v1.json",
    "service_certification": ROOT / "schemas" / "assistant_service_certification_v1.json",
}

SOURCE_DIRS = {
    "service_contract": ROOT / "profiles" / "adjuncts" / "service_contract",
    "service_identity": ROOT / "profiles" / "adjuncts" / "service_identity",
    "service_governance": ROOT / "profiles" / "adjuncts" / "service_governance",
    "service_certification": ROOT / "profiles" / "adjuncts" / "service_certification",
}

EXAMPLE_FILES = {
    "service_contract": ROOT / "examples" / "assistant_service_contract.example.json",
    "service_identity": ROOT / "examples" / "assistant_service_identity.example.json",
    "service_governance": ROOT / "examples" / "assistant_service_governance.example.json",
    "service_certification": ROOT / "examples" / "assistant_service_certification.example.json",
}

GENERATED_INDEX = ROOT / "generated" / "agent_wave2_assistant_index.min.json"
KNOWN_BASE_ROLES = {"architect", "coder", "reviewer", "evaluator", "memory-keeper"}
REQUIRED_CONTRACT_PROHIBITIONS = {"persistent_self_rewrite", "hidden_summon", "direct_tree_write"}
REQUIRED_GOVERNANCE_PROHIBITIONS = {
    "mandate_expansion",
    "persistent_policy_rewrite",
    "authority_self_promotion",
    "memory_schema_mutation",
}


def _load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def _validator_for(path: Path) -> Draft202012Validator:
    return Draft202012Validator(_load_json(path))


def _validate_file(validator: Draft202012Validator, path: Path, errors: list[str]) -> dict | None:
    data = _load_json(path)
    found = sorted(validator.iter_errors(data), key=lambda err: list(err.path))
    for err in found:
        loc = ".".join(str(part) for part in err.path) or "<root>"
        errors.append(f"{path}: {loc}: {err.message}")
    return data if not found else None


def _family_items(family: str, validator: Draft202012Validator, errors: list[str]) -> dict[str, dict]:
    items: dict[str, dict] = {}
    directory = SOURCE_DIRS[family]
    for path in sorted(directory.glob("*.json")):
        data = _validate_file(validator, path, errors)
        if data is not None:
            items[data["assistant_id"]] = data
    return items


def _check_examples(validators: dict[str, Draft202012Validator], errors: list[str]) -> None:
    for family, path in EXAMPLE_FILES.items():
        _validate_file(validators[family], path, errors)


def _check_family_alignment(
    contract_items: dict[str, dict],
    identity_items: dict[str, dict],
    governance_items: dict[str, dict],
    certification_items: dict[str, dict],
    errors: list[str],
) -> None:
    family_sets = {
        "service_contract": set(contract_items),
        "service_identity": set(identity_items),
        "service_governance": set(governance_items),
        "service_certification": set(certification_items),
    }
    first = next(iter(family_sets.values()), set())
    for family_name, ids in family_sets.items():
        if ids != first:
            errors.append(f"family mismatch for {family_name}: {sorted(ids)} vs {sorted(first)}")

    for assistant_id in sorted(first):
        contract = contract_items[assistant_id]
        identity = identity_items[assistant_id]
        governance = governance_items[assistant_id]
        certification = certification_items[assistant_id]

        role_ref = contract["role_ref"]
        if role_ref not in KNOWN_BASE_ROLES:
            errors.append(f"{assistant_id}: unknown role_ref {role_ref!r}")
        expected_prefix = f"{role_ref}.assistant"
        if assistant_id != expected_prefix:
            errors.append(f"{assistant_id}: assistant_id must match role_ref-derived id {expected_prefix!r}")

        if identity["role_ref"] != role_ref:
            errors.append(f"{assistant_id}: identity role_ref mismatch")
        if governance["role_ref"] != role_ref:
            errors.append(f"{assistant_id}: governance role_ref mismatch")
        if certification["role_ref"] != role_ref:
            errors.append(f"{assistant_id}: certification role_ref mismatch")

        if identity["service_office"] != contract["service_office"]:
            errors.append(f"{assistant_id}: service_office mismatch between contract and identity")

        if contract["variant_key"] != "assistant":
            errors.append(f"{assistant_id}: contract variant_key must be assistant")
        if identity["variant_key"] != "assistant":
            errors.append(f"{assistant_id}: identity variant_key must be assistant")
        if governance["variant_key"] != "assistant":
            errors.append(f"{assistant_id}: governance variant_key must be assistant")
        if certification["variant_key"] != "assistant":
            errors.append(f"{assistant_id}: certification variant_key must be assistant")


def _check_contract_semantics(contract_items: dict[str, dict], errors: list[str]) -> None:
    for assistant_id, item in contract_items.items():
        prohibited = set(item["prohibited"])
        if not REQUIRED_CONTRACT_PROHIBITIONS.issubset(prohibited):
            errors.append(
                f"{assistant_id}: contract prohibited set must include {sorted(REQUIRED_CONTRACT_PROHIBITIONS)}"
            )
        transparency = item["transparency"]
        if not transparency["receipt_required"]:
            errors.append(f"{assistant_id}: assistants must require receipts")
        if not transparency["trace_required"]:
            errors.append(f"{assistant_id}: assistants must require traceable output")
        if item["scope"]["output_variance"] not in {"low", "bounded"}:
            errors.append(f"{assistant_id}: assistants must keep output variance low or bounded")
        if item["memory_policy"]["writeback_requires_review"] is not True:
            errors.append(f"{assistant_id}: assistants must keep persistent writeback reviewed")


def _check_identity_semantics(identity_items: dict[str, dict], errors: list[str]) -> None:
    for assistant_id, item in identity_items.items():
        affects = item["affect_regulators"]
        if affects["self_expansion_drive"] != "low":
            errors.append(f"{assistant_id}: assistant self_expansion_drive must stay low")
        posture = item["communication_posture"]
        if posture["predictability_priority"] not in {"high", "strict"}:
            errors.append(f"{assistant_id}: predictability priority must remain high or strict")


def _check_governance_semantics(governance_items: dict[str, dict], errors: list[str]) -> None:
    for assistant_id, item in governance_items.items():
        if item["expected_kind"] != "assistant":
            errors.append(f"{assistant_id}: expected_kind must be assistant")
        if item["expected_evolution_mode"] != "exogenous_reactive":
            errors.append(f"{assistant_id}: expected_evolution_mode must be exogenous_reactive")
        if item["persistent_self_revision"] is not False:
            errors.append(f"{assistant_id}: assistants must not permit persistent self revision in Wave II")
        if item["certification_required"] is not True:
            errors.append(f"{assistant_id}: assistants require certification")
        if item["release_governance"]["requires_operator_review"] is not True:
            errors.append(f"{assistant_id}: release must remain operator-reviewed")
        if item["incident_posture"]["self_patch_allowed"] is not False:
            errors.append(f"{assistant_id}: assistants must not self-patch persistently")
        prohibited = set(item["prohibited_self_changes"])
        if not REQUIRED_GOVERNANCE_PROHIBITIONS.issubset(prohibited):
            errors.append(
                f"{assistant_id}: governance prohibited_self_changes must include {sorted(REQUIRED_GOVERNANCE_PROHIBITIONS)}"
            )


def _grade_value(value: str) -> int:
    order = {"provisional": 0, "passed": 1, "strong": 2}
    return order[value]


def _check_certification_semantics(cert_items: dict[str, dict], errors: list[str]) -> None:
    seen_certified = False
    for assistant_id, item in cert_items.items():
        readiness = item["readiness_state"]
        if readiness == "service_seeded":
            errors.append(f"{assistant_id}: Wave II exit requires all assistants to be at least service_ready")
        if readiness in {"certified_service", "trusted_service"}:
            seen_certified = True

        receipt = item["receipt_requirements"]
        if not receipt["must_expose_scope"]:
            errors.append(f"{assistant_id}: receipts must expose scope")
        if not receipt["must_expose_escalation_reason"]:
            errors.append(f"{assistant_id}: receipts must expose escalation reason")
        if not receipt["must_expose_uncertainty"]:
            errors.append(f"{assistant_id}: receipts must expose uncertainty")
        if item["handoff_requirements"]["packet_style"] != "service_receipt":
            errors.append(f"{assistant_id}: packet_style must be service_receipt")

        axes = item["certification_axes"]
        if _grade_value(axes["reproducibility"]) < 1:
            errors.append(f"{assistant_id}: reproducibility must be at least passed")
        if _grade_value(axes["graceful_failure"]) < 1:
            errors.append(f"{assistant_id}: graceful_failure must be at least passed")

    if not seen_certified:
        errors.append("Wave II requires at least one certified_service or trusted_service assistant variant")


def _check_generated_index(errors: list[str]) -> None:
    expected = build_index(ROOT)
    if not GENERATED_INDEX.exists():
        errors.append(f"missing generated index: {GENERATED_INDEX}")
        return
    current = json.loads(GENERATED_INDEX.read_text(encoding="utf-8"))
    if current != expected:
        errors.append(f"generated assistant index is stale: {GENERATED_INDEX}")


def main() -> int:
    errors: list[str] = []
    validators = {name: _validator_for(path) for name, path in SCHEMA_FILES.items()}

    contract_items = _family_items("service_contract", validators["service_contract"], errors)
    identity_items = _family_items("service_identity", validators["service_identity"], errors)
    governance_items = _family_items("service_governance", validators["service_governance"], errors)
    certification_items = _family_items("service_certification", validators["service_certification"], errors)

    _check_examples(validators, errors)
    _check_family_alignment(contract_items, identity_items, governance_items, certification_items, errors)
    _check_contract_semantics(contract_items, errors)
    _check_identity_semantics(identity_items, errors)
    _check_governance_semantics(governance_items, errors)
    _check_certification_semantics(certification_items, errors)
    _check_generated_index(errors)

    if errors:
        print("Wave-II assistant validation failed:")
        for err in errors:
            print(f" - {err}")
        return 1

    print("Wave-II assistant validation passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
