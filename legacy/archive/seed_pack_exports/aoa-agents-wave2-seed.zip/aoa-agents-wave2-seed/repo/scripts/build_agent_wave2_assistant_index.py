from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]

SOURCE_DIRS = {
    "service_contract": ROOT / "profiles" / "adjuncts" / "service_contract",
    "service_identity": ROOT / "profiles" / "adjuncts" / "service_identity",
    "service_governance": ROOT / "profiles" / "adjuncts" / "service_governance",
    "service_certification": ROOT / "profiles" / "adjuncts" / "service_certification",
}

OUTPUT = ROOT / "generated" / "agent_wave2_assistant_index.min.json"


def _load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def build_index(root: Path = ROOT) -> dict:
    source_dirs = {
        family: root / "profiles" / "adjuncts" / family
        for family in SOURCE_DIRS
    }
    families: dict[str, dict[str, dict]] = {}
    for family, directory in source_dirs.items():
        items: dict[str, dict] = {}
        for path in sorted(directory.glob("*.json")):
            data = _load_json(path)
            items[data["assistant_id"]] = data
        families[family] = items

    if not families:
        variants: list[dict] = []
    else:
        assistant_ids = sorted(set.intersection(*(set(items) for items in families.values())))
        variants = []
        for assistant_id in assistant_ids:
            contract = families["service_contract"][assistant_id]
            identity = families["service_identity"][assistant_id]
            governance = families["service_governance"][assistant_id]
            certification = families["service_certification"][assistant_id]
            variants.append(
                {
                    "assistant_id": assistant_id,
                    "role_ref": contract["role_ref"],
                    "variant_key": contract["variant_key"],
                    "service_office": contract["service_office"],
                    "mandate": contract["mandate"],
                    "service_promise": identity["service_promise"],
                    "readiness_state": certification["readiness_state"],
                    "expected_kind": governance["expected_kind"],
                    "expected_evolution_mode": governance["expected_evolution_mode"],
                    "upgrade_authority": governance["upgrade_authority"],
                    "public_safe": all(
                        item.get("public_safe", False)
                        for item in (contract, identity, governance, certification)
                    ),
                }
            )

    return {
        "schema_version": "agent_wave2_assistant_index_v1",
        "variant_count": len(variants),
        "variants": variants,
    }


def main() -> int:
    data = build_index(ROOT)
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(
        json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":")),
        encoding="utf-8",
    )
    print(f"Wrote {OUTPUT}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
