# self_agency_continuity_contract_v1

## Purpose

This contract defines the first bounded, cross-repo seam for self-agency continuity in AoA.

It exists to operationalize the long arc toward self-agency without collapsing:
- provenance
- reviewability
- return posture
- owner boundaries
- human judgment

The contract is intentionally smaller than "autonomy".
It is about continuity, bounded revision, and explicit reanchor.

## Core chain

`continuity_ref -> revision_window_ref -> reanchor_ref -> anchor_artifact_ref`

### continuity_ref
A reviewed continuity thread that persists across more than one bounded window and keeps the
route inspectable across time.

### revision_window_ref
A bounded window where reflective revision may happen.
It is narrower than "the whole session history".

### reanchor_ref
An explicit return/reanchor event used when the route loses boundedness, anchor clarity,
owner fit, or verification posture.

### anchor_artifact_ref
The actual prior valid artifact used as the return target.
It must point to an inspectable artifact, not vague remembered context.

## Ownership map

- `Agents-of-Abyss` owns doctrine and ecosystem-level meaning
- `aoa-agents` owns role-facing continuity, recurrence, and checkpoint posture
- `aoa-sdk` may carry continuity hints only
- `aoa-playbooks` owns scenario-level continuity and self-reanchor method
- `aoa-memo` owns relaunch anchors and writeback using the existing canon
- `aoa-stats` owns derived continuity read-models
- `aoa-evals` owns bounded proof about continuity quality

## Minimal fields

### Agent-side continuity window
- `continuity_ref`
- `revision_window_ref`
- `reanchor_ref`
- `anchor_artifact_ref`
- `continuity_status`
- `agent_id`
- `role`
- `memory_scope`
- `approval_mode`
- `rollback_marker`
- `max_iterations`

### SDK-side continuity hint carry
- `continuity_ref_hint`
- `revision_window_ref_hint`
- `anchor_artifact_ref`
- `reanchor_need`
- `continuity_status_hint`

### Playbook route artifacts
- `continuity_window`
- `reflective_revision_decision`
- `reanchor_decision`
- `anchor_trace`
- `continuity_writeback_record`
- `continuity_summary_refresh_record`

### Memo-side allowed writeback kinds
Use existing canon only:
- `anchor`
- `decision`
- `audit_event`
- `episode`
- `state_capsule`
- `provenance_thread`

### Stats-side summary fields
- `continuity_ref`
- `current_status`
- `open_revision_windows`
- `successful_reanchors`
- `failed_reanchors`
- `last_anchor_artifact_ref`
- `drift_flags`
- `bounded_revision_count`

### Eval bundle anchors
- `aoa-continuity-anchor-integrity`
- `aoa-reflective-revision-boundedness`
- `aoa-self-reanchor-correctness`

## Hard rules

1. No self-agency claim is valid if it lacks a named anchor artifact.
2. Reflective revision must occur within a named revision window.
3. Reanchor must point to a prior valid artifact rather than a vague conversational memory.
4. `aoa-sdk` cannot mint reviewed continuity truth.
5. `aoa-memo` cannot invent a new continuity object family for this wave.
6. `aoa-stats` summarizes continuity; it does not define or authorize it.
7. `aoa-evals` prove bounded questions; they do not assign a total self-agency score.

## Example chain

```json
{
  "continuity_ref": "CONT-20260412-0001",
  "revision_window_ref": "REV-20260412-0001",
  "reanchor_ref": "REA-20260412-0001",
  "anchor_artifact_ref": "reviewed_closeout_context:AOA-CTX-0001"
}
```

## Anti-patterns

Do not:
- use chat continuity as the anchor
- widen the revision window until something feels coherent
- let memory writeback replace owner truth
- let playbooks become hidden retry runners
- let stats become a continuity sovereign
- narrate self-agency where only bounded continuity exists
