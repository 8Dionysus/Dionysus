# IMPLEMENTATION_DOCKET — Wave 9: self-agency continuity

This wave should land **after** the current campaign-cadence layer.
Its purpose is to make the long arc toward self-agency operational without turning it into
permissionless runtime autonomy.

The core contract is:

`continuity_ref -> revision_window_ref -> reanchor_ref -> anchor_artifact_ref`

## Repo 1 — Agents-of-Abyss

### Goal
Name self-agency continuity as an ecosystem doctrine, not as a runtime claim.

### Add
- `docs/SELF_AGENCY_CONTINUITY.md`

### Doctrine points
- self-agency remains a long-horizon discipline, not a myth of free self-modification
- continuity must preserve provenance, legibility, and human judgment
- reflective revision must occur inside bounded revision windows
- when continuity drifts, the route returns through explicit reanchor rather than
  widening context by convenience
- owner layers keep their existing authority split

### Optional cross-links
- `docs/METHOD_SPINE.md`
- `docs/FEDERATION_RULES.md`

## Repo 2 — aoa-agents

### Goal
Give the agent layer a public continuity lane rooted in return, checkpoint posture,
and explicit artifact anchors.

### Add
- `docs/SELF_AGENCY_CONTINUITY_LANE.md`
- `examples/self_agency_continuity_window.example.json`
- optional schema: `schemas/self-agency-continuity-window.schema.json`

### Required semantics
The lane must name:
- `continuity_ref`
- `revision_window_ref`
- `reanchor_ref`
- `anchor_artifact_ref`
- `continuity_status`
- `agent_id`
- `role`
- `memory_scope`
- `approval_mode`
- `rollback_marker`
- `max_iterations`

### Boundary rules
- continuity is not a runtime retry loop
- continuity is not granted by memo alone
- return must point to a public anchor artifact, not vague chat continuity

## Repo 3 — aoa-sdk

### Goal
Allow the control plane to carry continuity hints without owning self-agency meaning.

### Extend
- `docs/session-growth-checkpoints.md`
- add example: `examples/closeout_continuity_window.example.json`
- optional schema or typed example for `closeout_continuity_window`

### Allowed carry
- `continuity_ref_hint`
- `revision_window_ref_hint`
- `anchor_artifact_ref`
- `reanchor_need`
- `continuity_status_hint`

### Explicit prohibition
`aoa-sdk` must not mint reviewed continuity truth, self-agent authority, or memo truth.

## Repo 4 — aoa-playbooks

### Goal
Create one playbook-owned scenario for self-agency continuity and bounded self-reanchor.

### Add
- `playbooks/self-agency-continuity-cycle/PLAYBOOK.md`

### Intent
Use this playbook when the route is no longer only one owner landing or one growth cycle
step, but a recurring continuity lane spanning:
- reviewed anchors
- bounded revision windows
- explicit reanchor decisions
- memo-side relaunch aids
- derived continuity refresh
- proof that continuity stayed bounded

### Expected artifacts
- `continuity_window`
- `reflective_revision_decision`
- `reanchor_decision`
- `anchor_trace`
- `continuity_writeback_record`
- `continuity_summary_refresh_record`

## Repo 5 — aoa-memo

### Goal
Support continuity and reanchor through the existing canon.

### Add
- `docs/SELF_AGENCY_CONTINUITY_WRITEBACK.md`
- `examples/self_agency_continuity_writeback.example.json`

### Hard rule
Do **not** add a new `self_agency_memory` or `return_memory` object family.

### Use only existing memo-side kinds
- `anchor`
- `decision`
- `audit_event`
- `episode`
- `state_capsule`
- `provenance_thread`

## Repo 6 — aoa-stats

### Goal
Make continuity visible as a derived read-model.

### Add
- `docs/CONTINUITY_WINDOW_SUMMARY.md`
- `schemas/continuity-window-summary.schema.json`
- `examples/continuity_window_summary.example.json`
- `generated/continuity_window_summary.min.json`

### Suggested fields
- `continuity_ref`
- `current_status`
- `open_revision_windows`
- `successful_reanchors`
- `failed_reanchors`
- `last_anchor_artifact_ref`
- `drift_flags`
- `bounded_revision_count`

## Repo 7 — aoa-evals

### Goal
Prove continuity honestly.

### Add bundles
- `bundles/aoa-continuity-anchor-integrity/EVAL.md`
- `bundles/aoa-reflective-revision-boundedness/EVAL.md`
- `bundles/aoa-self-reanchor-correctness/EVAL.md`

### Bundle intent
1. `aoa-continuity-anchor-integrity`
   - verifies that continuity windows keep an inspectable anchor chain
2. `aoa-reflective-revision-boundedness`
   - verifies that reflective revision stayed inside the named revision window
3. `aoa-self-reanchor-correctness`
   - verifies that return moved to the last valid anchor rather than widening scope

## Suggested repo order

1. center doctrine
2. agent continuity lane
3. control-plane continuity carry
4. playbook route
5. memo writeback
6. stats summary
7. eval proof

## Global stop-lines

Stop the wave if any proposal would:
- create free-floating "autonomy" semantics with no checkpoint or return posture
- create a new memo object family for continuity
- make stats or playbooks the authority layer for self-agency
- turn `aoa-sdk` into a self-agent owner
- let reanchor target chat continuity instead of a named artifact
