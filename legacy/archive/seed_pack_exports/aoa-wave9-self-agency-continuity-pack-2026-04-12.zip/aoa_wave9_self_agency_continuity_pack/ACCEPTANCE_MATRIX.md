# ACCEPTANCE_MATRIX — Wave 9

| Area | Must exist | Must not happen | Acceptance check |
|---|---|---|---|
| Center doctrine | one doctrine note naming self-agency continuity as bounded, provenance-preserving growth | mythology of free self-modification | doctrine cross-links agent/playbook/memo/stats/evals |
| Agent lane | continuity window semantics, explicit return, explicit anchor artifact | vague "continue from context" language | example or schema names `continuity_ref`, `revision_window_ref`, `reanchor_ref`, `anchor_artifact_ref` |
| SDK carry | hint-only continuity carry | reviewed continuity truth minted in sdk | docs/example say `*_hint` and keep authority outside sdk |
| Playbook | one recurring self-agency continuity cycle | hidden runner or implicit retries | playbook has clear trigger, decision points, fallback, return posture |
| Memo | continuity writeback via existing kinds | new memory-object family | doc/example uses `anchor`, `decision`, `audit_event`, `episode`, `state_capsule`, or `provenance_thread` only |
| Stats | derived continuity summary | stats as continuity authority | schema/example/generated summary read from owner artifacts |
| Evals | three draft proof bundles | totalized "autonomy score" | bundle names and intents stay bounded and claim-limited |

## Exit criteria

The wave is done when:
- continuity has a named doctrine and route
- reanchor is public-artifact based
- reflective revision is bounded by a revision window
- memo can support re-entry without becoming the router
- stats can summarize continuity without becoming the judge
- proof bundles can falsify bad continuity stories

## Failure signs

Treat these as red flags:
- a new object family appears in `aoa-memo`
- `aoa-sdk` starts naming reviewed continuity truth
- playbooks start acting like runtime schedulers
- stats define what continuity means instead of summarizing it
- evals try to assign one total self-agency score
