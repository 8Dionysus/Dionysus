#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path
import sys

ALLOWED_MEMO_KINDS = {
    "anchor",
    "decision",
    "audit_event",
    "episode",
    "state_capsule",
    "provenance_thread",
}

EXPECTED_EVALS = {
    "aoa-continuity-anchor-integrity",
    "aoa-reflective-revision-boundedness",
    "aoa-self-reanchor-correctness",
}


def load(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as fh:
        return json.load(fh)


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    ex = root / "examples"

    agents = load(ex / "aoa_agents.self_agency_continuity_window.example.json")
    sdk = load(ex / "aoa_sdk.closeout_continuity_window.example.json")
    playbook = load(ex / "aoa_playbooks.self_agency_continuity_packet.example.json")
    memo = load(ex / "aoa_memo.self_agency_continuity_writeback.example.json")
    stats = load(ex / "aoa_stats.continuity_window_summary.example.json")
    evals = load(ex / "aoa_evals.self_agency_eval_registry.example.json")

    continuity_ref = agents["continuity_ref"]
    revision_window_ref = agents["revision_window_ref"]
    reanchor_ref = agents["reanchor_ref"]
    anchor_artifact_ref = agents["anchor_artifact_ref"]

    assert sdk["continuity_ref_hint"] == continuity_ref, "sdk continuity hint drift"
    assert sdk["revision_window_ref_hint"] == revision_window_ref, "sdk revision hint drift"
    assert sdk["anchor_artifact_ref"] == anchor_artifact_ref, "sdk anchor drift"
    assert sdk["reanchor_need"] is True, "sdk must indicate reanchor need in the fixture"

    assert playbook["continuity_ref"] == continuity_ref, "playbook continuity drift"
    assert playbook["revision_window_ref"] == revision_window_ref, "playbook revision drift"
    assert playbook["reanchor_ref"] == reanchor_ref, "playbook reanchor drift"
    assert playbook["anchor_artifact_ref"] == anchor_artifact_ref, "playbook anchor drift"

    assert memo["kind"] in ALLOWED_MEMO_KINDS, "memo fixture introduced forbidden kind"
    assert memo["continuity_ref"] == continuity_ref, "memo continuity drift"
    assert memo["revision_window_ref"] == revision_window_ref, "memo revision drift"
    assert memo["reanchor_ref"] == reanchor_ref, "memo reanchor drift"
    assert memo["anchor_artifact_ref"] == anchor_artifact_ref, "memo anchor drift"

    assert stats["continuity_ref"] == continuity_ref, "stats continuity drift"
    assert stats["last_anchor_artifact_ref"] == anchor_artifact_ref, "stats anchor drift"
    assert isinstance(stats["drift_flags"], list), "stats drift flags must be a list"

    actual_evals = set(evals["required_eval_bundles"])
    assert actual_evals == EXPECTED_EVALS, "eval registry drift"

    print("wave9 self-agency continuity fixtures: OK")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except AssertionError as exc:
        print(f"validation failed: {exc}", file=sys.stderr)
        raise SystemExit(1)
