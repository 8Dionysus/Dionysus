# PR_SLICES — Wave 9

## PR-1 — center doctrine + agent lane
Repos:
- `Agents-of-Abyss`
- `aoa-agents`

Land:
- `docs/SELF_AGENCY_CONTINUITY.md`
- `docs/SELF_AGENCY_CONTINUITY_LANE.md`
- continuity window example/schema if desired

Acceptance:
- doctrine names the long arc without granting runtime autonomy
- return/reanchor requires a named anchor artifact
- no ownership drift into memory, routing, or runtime

## PR-2 — control-plane carry + playbook route
Repos:
- `aoa-sdk`
- `aoa-playbooks`

Land:
- continuity hint carry in checkpoint/closeout surfaces
- `playbooks/self-agency-continuity-cycle/PLAYBOOK.md`

Acceptance:
- sdk only carries hints
- playbook owns scenario composition
- continuity route has clear fallback/return posture

## PR-3 — memo writeback + stats summary
Repos:
- `aoa-memo`
- `aoa-stats`

Land:
- continuity writeback doc/example using existing memo kinds
- continuity summary schema/example/generated surface

Acceptance:
- no new memo taxonomy
- stats remain derived-only
- continuity summary cites anchor semantics rather than inventing them

## PR-4 — proof bundles
Repo:
- `aoa-evals`

Land:
- three draft eval bundles

Acceptance:
- each bundle has explicit claim limits
- each bundle points to public anchor artifacts and bounded revision windows
- proof remains narrower than the doctrine

## Optional PR-5 — public route-map wording
Repo:
- `8Dionysus`

Only if useful:
- one short note linking the long arc in `README.md` or docs to the newly landed
  center/agent/playbook continuity surfaces

Acceptance:
- public wording stays route-map level
- no authority transfer away from owner repos
