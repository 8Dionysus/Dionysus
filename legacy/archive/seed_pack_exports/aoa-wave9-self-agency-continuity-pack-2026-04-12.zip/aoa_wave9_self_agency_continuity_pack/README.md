# aoa_wave9_self_agency_continuity_pack

Wave 9 turns the current growth-refinery and campaign cadence work toward the longer AoA arc:
bounded, reviewable agency growing toward self-agency without dissolving provenance,
anchors, or human judgment.

This pack is for **continuity**, not for mythic autonomy.

## What this wave lands

- a federation doctrine note for self-agency continuity
- an agent-layer continuity lane rooted in explicit return and checkpoint posture
- a playbook-owned self-agency continuity cycle
- memo-side continuity writeback that uses existing memory kinds rather than inventing a
  new taxonomy
- a derived continuity window summary
- three proof bundles for continuity integrity, reflective revision boundedness, and
  self-reanchor correctness
- a minimal control-plane carry note in `aoa-sdk` for continuity hints only

## Why this wave now

Earlier waves already established reviewed growth follow-through, owner landing,
campaign cadence, portability, deployment continuity, and trusted rollout operations.
The next honest step is to let the system hold duration across those moves:

- continuity across reviewed windows
- reflective revision without silent scope drift
- explicit reanchor and return to a last valid artifact
- bounded memory support for relaunch
- proof that continuity was preserved rather than narrated

## Contents

- `IMPLEMENTATION_DOCKET.md` — repo-by-repo execution plan
- `PR_SLICES.md` — suggested PR sequencing
- `CODEX_EXECUTION_PROMPT.md` — ready prompt for Codex
- `ACCEPTANCE_MATRIX.md` — done criteria and stop-lines
- `contracts/self_agency_continuity_contract_v1.md` — core cross-repo contract
- `proposed-targets/` — proposed doctrine/playbook/writeback/summary notes
- `examples/` — synthetic cross-repo fixtures
- `tools/validate_wave9_self_agency_continuity.py` — structural validator for the pack

## Landing order

1. `Agents-of-Abyss`
2. `aoa-agents`
3. `aoa-sdk`
4. `aoa-playbooks`
5. `aoa-memo`
6. `aoa-stats`
7. `aoa-evals`

## Non-goals

- no hidden runtime autonomy
- no new memo object family for "self-agency"
- no stats authority over owner truth
- no routing authority transfer
- no vague continuity based only on chat residue

## Minimal verification after landing

Run the owning-repo checks only after each slice lands:

- `Agents-of-Abyss`: local docs/contract verification if the repo already has one
- `aoa-agents`: `python scripts/validate_agents.py && python -m pytest -q tests`
- `aoa-sdk`: `python scripts/build_workspace_control_plane.py --check && python scripts/validate_workspace_control_plane.py && python -m pytest -q`
- `aoa-playbooks`: `python scripts/generate_playbook_activation_surfaces.py --check && python scripts/validate_playbooks.py && python -m pytest -q tests`
- `aoa-memo`: `python scripts/validate_memo.py && python scripts/validate_memory_surfaces.py && python -m pytest -q tests`
- `aoa-stats`: `python scripts/build_views.py --check && python scripts/validate_repo.py && python -m pytest -q tests`
- `aoa-evals`: `python scripts/build_catalog.py --check && python scripts/validate_repo.py && python -m pytest -q tests`
