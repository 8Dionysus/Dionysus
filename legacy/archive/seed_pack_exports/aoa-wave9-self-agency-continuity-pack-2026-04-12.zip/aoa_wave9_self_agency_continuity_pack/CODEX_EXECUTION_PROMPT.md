You are landing Wave 9 of the AoA refinement program: bounded self-agency continuity.

Read first:
1. this pack's `IMPLEMENTATION_DOCKET.md`
2. this pack's `PR_SLICES.md`
3. `contracts/self_agency_continuity_contract_v1.md`
4. current owner-repo docs before mutating anything:
   - `8Dionysus/README.md`
   - workspace-root `AGENTS.md`
   - `aoa-agents/docs/SELF_AGENT_CHECKPOINT_STACK.md`
   - `aoa-agents/docs/RECURRENCE_DISCIPLINE.md`
   - `aoa-playbooks/playbooks/session-growth-cycle/PLAYBOOK.md`
   - `aoa-memo/docs/RECURRENCE_MEMORY_SUPPORT_SURFACES.md`
   - `aoa-stats/README.md`
   - `aoa-evals/README.md`

Execution rules:
- preserve source-of-truth boundaries
- do not invent a new memory object family
- do not let `aoa-sdk` become the owner of self-agency meaning
- do not narrate "autonomy" where only bounded continuity is justified
- make return/reanchor artifact-anchored and reviewable
- prefer the smallest honest diff in each repo
- land PR slices in order; do not skip upstream doctrine or agent contract
- run the owning repo validators after each slice
- report any unresolved ID collision or file-naming conflict instead of guessing silently

What to land:
- center doctrine note
- agent continuity lane
- sdk continuity hint carry
- self-agency continuity playbook
- memo continuity writeback seam
- stats continuity window summary
- three eval bundles

Deliverables at the end:
- changed files by repo
- validation commands run and results
- any TODOs that remained intentionally deferred
- explicit note confirming:
  - no new memo taxonomy
  - no hidden runtime autonomy
  - reanchor uses named anchor artifacts
