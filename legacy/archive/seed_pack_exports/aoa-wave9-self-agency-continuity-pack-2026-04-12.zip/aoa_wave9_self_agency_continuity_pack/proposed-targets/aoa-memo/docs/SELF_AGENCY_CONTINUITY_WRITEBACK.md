# SELF_AGENCY_CONTINUITY_WRITEBACK

## Purpose

This note defines how `aoa-memo` supports self-agency continuity without becoming
the policy owner, the router, or the runtime body.

## Rule

Do not add a new memory object family for continuity.

Use the existing canon:

- `anchor`
- `decision`
- `audit_event`
- `episode`
- `state_capsule`
- `provenance_thread`

## Recommended landing

- stable continuity reference point -> `anchor`
- explicit reanchor or reflective revision choice -> `decision`
- bounded review or failure note -> `audit_event`
- meaningful continuity episode -> `episode`
- exported bounded working state for relaunch -> `state_capsule`
- cross-window continuity chain -> `provenance_thread`

## Boundary

Memo can help a route return.
Memo cannot decide whether return is legitimate.
Memo cannot define the active revision window.
Memo cannot replace owner truth or proof truth.
