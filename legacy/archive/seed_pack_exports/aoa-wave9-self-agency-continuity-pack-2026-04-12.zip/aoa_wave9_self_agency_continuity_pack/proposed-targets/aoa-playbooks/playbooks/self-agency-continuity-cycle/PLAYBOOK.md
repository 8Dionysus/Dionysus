---
id: AOA-P-TBD
name: self-agency-continuity-cycle
status: experimental
summary: Coordinates bounded self-agency continuity across reviewed anchors, revision windows, reanchor decisions, memo-side relaunch aids, derived continuity refresh, and bounded proof without turning continuity into hidden runtime autonomy.
---

# self-agency-continuity-cycle

## Intent

Use this playbook when the route has outgrown a single landing or single growth-cycle step
and now needs to preserve continuity across more than one bounded window.

This playbook is about:
- holding a continuity thread
- revising methods inside a bounded revision window
- returning through an explicit reanchor if drift appears
- using memo-side relaunch aids without making memory sovereign
- refreshing derived continuity summaries without letting them outrun owner truth

## Trigger boundary

Use this playbook when:
- a reviewed anchor already exists
- continuity matters across more than one bounded window
- reflective revision is required, but only inside a named revision window
- the route may need explicit reanchor rather than unbounded forward motion

Do not use this playbook when:
- there is no reviewed anchor yet
- the route is only one owner follow-through move
- the route is only one runtime retry
- continuity would be narrated from vague chat residue

## Participating agents

- `architect`
- `coder`
- `reviewer`
- `evaluator`
- `memory-keeper`

## Expected artifacts

- `continuity_window`
- `reflective_revision_decision`
- `reanchor_decision`
- `anchor_trace`
- `continuity_writeback_record`
- `continuity_summary_refresh_record`

## Fallback and return posture

Pause or return when:
- the anchor artifact is missing
- the current revision window is no longer bounded
- memory is being asked to replace owner truth
- derived summaries are being treated as authority
- the route starts behaving like hidden autonomy

Return to the last valid `anchor_artifact_ref`.
If no valid anchor remains, stop and defer.

## Eval anchors

- `aoa-continuity-anchor-integrity`
- `aoa-reflective-revision-boundedness`
- `aoa-self-reanchor-correctness`
