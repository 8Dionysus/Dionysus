# SELF_AGENCY_CONTINUITY

## Intent

AoA's longer arc points toward self-agency: continuity, memory, reflective revision,
durable orientation, and growth that preserves provenance, legibility, and human judgment.

This note keeps that arc operational and bounded.

Self-agency continuity is **not** free-form self-modification.
It is the ability of a governed route to persist across time without losing:
- inspectable anchors
- source-of-truth boundaries
- rollback posture
- reviewability
- answerability to human judgment

## Core discipline

A continuity route stays smaller than autonomy mythology.

It must name:
- the continuity thread being preserved
- the bounded revision window currently active
- the explicit reanchor event when drift occurs
- the anchor artifact that remains valid enough for return

The practical chain is:

`continuity_ref -> revision_window_ref -> reanchor_ref -> anchor_artifact_ref`

## Boundary split

- `aoa-agents` owns role-facing checkpoint, recurrence, and return posture
- `aoa-playbooks` owns scenario-level continuity choreography
- `aoa-memo` owns bounded relaunch anchors and writeback through existing memory kinds
- `aoa-stats` owns derived continuity summaries
- `aoa-evals` owns proof about continuity quality
- `aoa-sdk` may carry continuity hints only

## Stop-lines

Self-agency continuity fails when:
- continuity has no public anchor artifact
- revision widens beyond the named bounded window
- reanchor targets vague chat continuity
- memory replaces owner truth
- stats or playbooks claim authority they do not own
- runtime behavior is narrated as healthy continuity without reviewed anchors

## One-line rule

Self-agency continuity means bounded duration with explicit anchors and reviewable return,
not permissionless autonomy.
