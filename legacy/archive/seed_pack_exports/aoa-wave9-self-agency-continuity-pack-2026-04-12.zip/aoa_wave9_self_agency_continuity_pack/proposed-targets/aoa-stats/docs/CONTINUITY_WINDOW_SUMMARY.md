# CONTINUITY_WINDOW_SUMMARY

## Purpose

A derived summary surface that makes self-agency continuity visible without turning
`aoa-stats` into the authority for continuity meaning.

## Summary posture

This surface is downstream of:
- agent-layer continuity windows
- playbook continuity artifacts
- memo-side writeback anchors
- bounded proof results

## Minimal fields

- `continuity_ref`
- `current_status`
- `open_revision_windows`
- `successful_reanchors`
- `failed_reanchors`
- `last_anchor_artifact_ref`
- `drift_flags`
- `bounded_revision_count`

## One-line rule

The summary describes continuity movement.
It does not authorize continuity claims.
