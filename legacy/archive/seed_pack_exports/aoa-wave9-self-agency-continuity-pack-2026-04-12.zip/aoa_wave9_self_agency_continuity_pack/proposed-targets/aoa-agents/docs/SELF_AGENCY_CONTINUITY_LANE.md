# SELF_AGENCY_CONTINUITY_LANE

## Purpose

This note hardens the agent-layer landing for self-agency continuity.

The agent layer does not own runtime retries or memory truth.
It owns the role-facing contract for explicit continuity, bounded revision, and return.

## Core rule

A continuity route is valid only when the acting role can still name:
- the active continuity thread
- the current revision window
- the last valid anchor artifact
- the reanchor path to that artifact if drift appears

If those cannot be named, the route should return rather than improvise.

## Minimal continuity window

A public continuity window should be able to state:
- `continuity_ref`
- `revision_window_ref`
- `reanchor_ref`
- `anchor_artifact_ref`
- `continuity_status`
- `agent_id`
- `role`
- `memory_scope`
- `approval_mode`
- `rollback_marker`
- `max_iterations`

## Return discipline

Return is legitimate when:
- the current actor can no longer state the active bounded route
- source-of-truth fit has drifted
- verification posture was lost
- the revision window widened without a new bounded plan
- repeated contradiction makes forward motion theatrical

Return must target a prior valid public artifact.
It must not target vague chat continuity.

## Cohort posture

A portable continuity route should usually keep:
- `architect` for route and anchor naming
- `coder` for bounded mutation only after approval
- `reviewer` for boundedness and health
- `memory-keeper` for provenance-thread legibility

No new role family is required.
