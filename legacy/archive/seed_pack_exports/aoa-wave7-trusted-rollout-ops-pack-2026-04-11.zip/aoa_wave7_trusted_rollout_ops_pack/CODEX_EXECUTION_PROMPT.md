You are integrating **AoA Wave 7: Trusted Rollout Operations**.

Read first:
1. `README.md`
2. `IMPLEMENTATION_DOCKET.md`
3. `PR_SLICES.md`
4. `ACCEPTANCE_MATRIX.md`
5. `contracts/trusted_rollout_operations_contract_v1.md`

Then execute in order:

## Objectives
Implement a source-owned, reviewable rollout operations layer for the shared-root Codex plane.

### Required outputs
- `8Dionysus` doctrine + rollout history surfaces
- `aoa-stats` derived rollout summaries
- `aoa-playbooks` recurring trusted rollout operations playbook
- `aoa-memo` lesson + recovery writeback seams
- optional light-touch `aoa-sdk` boundary note
- passing cross-repo validation

## Guardrails
- Do not create a new sovereign orchestration layer.
- Do not move rollout truth into stats.
- Do not let memo become proof.
- Do not let playbooks become routing authority.
- Do not let `aoa-sdk` claim rollout success authority.
- Prefer append-only or superseding records over destructive replacement.
- Keep lifecycle vocabulary stable with the contract.

## Working order
1. land `8Dionysus`
2. land `aoa-stats`
3. land `aoa-playbooks`
4. land `aoa-memo`
5. add optional `aoa-sdk` note
6. validate each repo
7. run `tools/validate_wave7_trusted_rollout_ops.py`

## Validation expectations
- repo-local builders/validators/tests where available
- no broken docs references
- generated examples remain structurally consistent

## Final report
Return:
- what landed repo by repo
- which files changed
- which validators ran
- unresolved drift / naming issues if any
