# Implementation Docket: Wave 7 Trusted Rollout Operations

## Purpose

Turn Codex-plane deployment continuity into a **reviewable rollout operations cycle** with:
- deploy-local history
- regeneration campaign records
- drift windows
- rollback windows
- derived rollout summaries
- recovery lessons

This is not a scheduler empire. It is a source-owned operational seam.

---

## Repo 1: `8Dionysus`

### Add doctrine / operational note
Proposed file:
- `docs/CODEX_TRUSTED_ROLLOUT_OPERATIONS.md`

Must define:
- rollout operations are source-owned by `8Dionysus` for the shared-root Codex plane
- project trust is a prerequisite for project-scoped `.codex/config.toml`
- rollout work must remain bounded and reviewable
- rollback is allowed only through explicit bounded windows
- deploy-local history does not override owner repo meaning

### Add generated rollout surfaces
Proposed directory:
- `generated/codex/rollout/`

Starter surfaces:
- `deploy_history.jsonl`
- `regeneration_campaigns.min.json`
- `rollback_windows.min.json`
- `rollout_latest.min.json`

### Add example records
Use the example shapes in `proposed-targets/8Dionysus/generated/codex/rollout/`.

### Add rollout doctor note to workspace install docs
Patch:
- `docs/WORKSPACE_INSTALL.md`
Mention:
- after regeneration/render, open rollout window
- record smoke + trust + drift outcomes
- if drift exceeds boundary, create rollback window

---

## Repo 2: `aoa-stats`

### Add derived read models
Proposed files:
- `generated/codex_rollout_operations_summary.min.json`
- `generated/codex_rollout_drift_summary.min.json`

The summary layer should derive from `8Dionysus/generated/codex/rollout/*`.
Do not move authority into stats.

### Add source registry entry
Update source registry / builder logic so `8Dionysus` rollout surfaces become recognized inputs.

### Acceptance
- stats can point to latest rollout campaign
- stats can show current drift window status
- stats can distinguish `stabilized`, `rollback_open`, `rolled_back`, `abandoned`

---

## Repo 3: `aoa-playbooks`

### Add recurring operational playbook
Proposed playbook:
- `playbooks/trusted-rollout-operations/PLAYBOOK.md`

Core route:
1. regeneration/render
2. doctor
3. smoke
4. trust confirmation
5. bounded activation
6. drift observation
7. repair attempt if bounded
8. rollback window if needed
9. receipt publication
10. stats refresh
11. memo writeback

The playbook owns:
- decision points
- stop-lines
- rollback entry conditions
- evidence expectations
- required artifacts

### Add adjunct automation seed if useful
Keep it seed-level, not scheduler authority.

---

## Repo 4: `aoa-memo`

### Add bounded memory seams
Proposed writeback objects:
- `deploy_drift_lesson`
- `rollout_recovery_pattern`

Each should carry:
- `rollout_campaign_ref`
- strongest available lineage refs
- trigger / symptom / attempted repair / outcome
- rollback relation if any
- confidence / evidence refs

Memo remains memory, not proof.

---

## Repo 5: `aoa-sdk` (light touch)

### Add boundary note only
Do **not** move rollout sovereignty into `aoa-sdk`.
A light note can state:
- typed deploy-operation packets may be consumed
- rollout decisions remain reviewed closeout / owner operations
- sdk may surface status, not declare success

---

## Cross-repo contracts to keep stable

### Stable ids
- `rollout_campaign_ref`
- `deploy_receipt_ref`
- `rollback_window_ref`
- `drift_window_ref`

### Shared lifecycle vocabulary
- `prepared`
- `activated`
- `monitoring`
- `stabilized`
- `rollback_open`
- `rolled_back`
- `abandoned`

### Shared artifact classes
- rollout history record
- regeneration campaign record
- rollback window record
- stats summary
- memo lesson / recovery pattern
- playbook decision artifact

---

## Order of landing

1. `8Dionysus` doctrine + generated rollout surfaces
2. `aoa-stats` derived rollout summaries
3. `aoa-playbooks` trusted rollout operations playbook
4. `aoa-memo` rollout lesson + recovery pattern writeback
5. optional `aoa-sdk` boundary note
6. cross-repo validation

---

## Non-goals

- no new sovereign orchestration layer
- no raw hidden automation empire
- no replacement of project trust model
- no stats sovereignty
- no routing expansion into authority
