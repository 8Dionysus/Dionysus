# PR Slices: Wave 7 Trusted Rollout Operations

## PR-1: `8Dionysus` rollout operations source layer
Scope:
- `docs/CODEX_TRUSTED_ROLLOUT_OPERATIONS.md`
- `generated/codex/rollout/*`
- `docs/WORKSPACE_INSTALL.md` patch

Acceptance:
- rollout surfaces exist
- latest rollout can be read from a compact summary
- rollback window shape is explicit
- no authority leakage into generated summaries

## PR-2: `aoa-stats` derived rollout summaries
Scope:
- rollout operations summary
- rollout drift summary
- source registry / build hooks

Acceptance:
- stats derive from `8Dionysus` rollout surfaces
- latest rollout, drift, and rollback posture are visible
- no source-of-truth inversion

## PR-3: `aoa-playbooks` trusted rollout operations
Scope:
- new playbook
- decision artifacts
- stop-lines / rollback conditions

Acceptance:
- playbook route is explicit
- expected artifacts named
- rollback is bounded and evidence-backed

## PR-4: `aoa-memo` rollout lessons
Scope:
- `deploy_drift_lesson`
- `rollout_recovery_pattern`
- writeback seam note

Acceptance:
- memory objects reference rollout campaign and strongest lineage refs
- lesson / recovery split is clear
- memo does not declare proof

## PR-5: validation / polish
Scope:
- run repo validators
- run cross-repo validator from this pack
- refresh docs if naming drift appeared

Acceptance:
- green validators
- ids stable across examples
- no lifecycle term drift
