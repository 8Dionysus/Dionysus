# Patch Guide: `aoa-playbooks`

Add:
- `trusted-rollout-operations`

This playbook should bind together:
- regeneration
- doctor
- smoke
- activation
- drift observation
- rollback if needed
- stats refresh
- memo writeback

Keep this playbook:
- recurring
- operational
- bounded
- explicit about stop-lines
