# Patch Guide: `aoa-memo`

Add memory seams for:
- deploy drift lessons
- rollout recovery patterns

Memory objects should preserve:
- campaign refs
- drift / rollback refs
- trigger and symptom
- attempted repair
- outcome
- evidence refs

Do not:
- claim proof
- overwrite source rollout history
