# Patch Guide: `8Dionysus`

Add:
- `docs/CODEX_TRUSTED_ROLLOUT_OPERATIONS.md`
- `generated/codex/rollout/`
- update `docs/WORKSPACE_INSTALL.md`

Keep naming aligned with:
- wave 5 regeneration contract
- wave 6 deployment continuity contract
- this wave 7 rollout operations contract

Do not:
- move rollout truth into `.codex/` itself
- silently overwrite history without superseding note
