# Patch Guide: `aoa-stats`

Add two derived summaries:
- `codex_rollout_operations_summary`
- `codex_rollout_drift_summary`

Builder posture:
- read from `8Dionysus/generated/codex/rollout/*`
- derive compact status windows
- avoid becoming source authority

Useful dimensions:
- counts by rollout state
- active drift / rollback status
- latest stable campaign
