#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]

def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))

def read_jsonl(path: Path):
    lines = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        lines.append(json.loads(line))
    return lines

def fail(msg: str) -> None:
    print(f"[FAIL] {msg}")
    raise SystemExit(1)

def main() -> None:
    deploy_history = read_jsonl(
        ROOT / "proposed-targets/8Dionysus/generated/codex/rollout/deploy_history.example.jsonl"
    )
    regen = read_json(
        ROOT / "proposed-targets/8Dionysus/generated/codex/rollout/regeneration_campaigns.min.example.json"
    )
    rollback = read_json(
        ROOT / "proposed-targets/8Dionysus/generated/codex/rollout/rollback_windows.min.example.json"
    )
    latest = read_json(
        ROOT / "proposed-targets/8Dionysus/generated/codex/rollout/rollout_latest.min.example.json"
    )
    stats_ops = read_json(
        ROOT / "proposed-targets/aoa-stats/generated/codex_rollout_operations_summary.min.example.json"
    )
    stats_drift = read_json(
        ROOT / "proposed-targets/aoa-stats/generated/codex_rollout_drift_summary.min.example.json"
    )
    lesson = read_json(
        ROOT / "proposed-targets/aoa-memo/generated/deploy_drift_lesson.example.json"
    )
    recovery = read_json(
        ROOT / "proposed-targets/aoa-memo/generated/rollout_recovery_pattern.example.json"
    )

    campaigns_from_history = {row["rollout_campaign_ref"] for row in deploy_history}
    campaigns_from_regen = {row["rollout_campaign_ref"] for row in regen["campaigns"]}
    if campaigns_from_history != campaigns_from_regen:
        fail("deploy history and regeneration campaign refs differ")

    latest_ref = latest["latest_rollout_campaign_ref"]
    if latest_ref not in campaigns_from_history:
        fail("latest rollout ref not found in deploy history")

    if stats_ops["latest_rollout_campaign_ref"] != latest_ref:
        fail("stats operations latest rollout ref does not match latest summary")

    if stats_drift["latest_rollout_campaign_ref"] != latest_ref:
        fail("stats drift latest rollout ref does not match latest summary")

    rollback_refs = {row["rollback_window_ref"] for row in rollback["rollback_windows"]}
    if recovery.get("rollback_window_ref") not in rollback_refs:
        fail("memo recovery pattern rollback ref not found in rollback windows")

    history_by_campaign = {row["rollout_campaign_ref"]: row for row in deploy_history}
    history_latest = history_by_campaign[latest_ref]

    if lesson["rollout_campaign_ref"] != latest_ref:
        fail("memo lesson rollout ref does not match latest rollout")
    if recovery["rollout_campaign_ref"] != latest_ref:
        fail("memo recovery rollout ref does not match latest rollout")

    expected_drift_ref = history_latest["drift_window_refs"][0]
    if lesson["drift_window_ref"] != expected_drift_ref:
        fail("memo lesson drift ref does not match deploy history")
    if stats_drift["drift_window_ref"] != expected_drift_ref:
        fail("stats drift ref does not match deploy history")

    if history_latest["state"] not in {"stabilized", "rolled_back", "abandoned", "monitoring"}:
        fail("unexpected latest rollout lifecycle state")

    print("[OK] Wave 7 trusted rollout operations examples are structurally consistent.")
    print(f"[OK] latest_rollout_campaign_ref = {latest_ref}")
    print(f"[OK] drift_window_ref = {expected_drift_ref}")
    if history_latest["rollback_window_refs"]:
        print(f"[OK] rollback_window_ref = {history_latest['rollback_window_refs'][0]}")

if __name__ == "__main__":
    main()
