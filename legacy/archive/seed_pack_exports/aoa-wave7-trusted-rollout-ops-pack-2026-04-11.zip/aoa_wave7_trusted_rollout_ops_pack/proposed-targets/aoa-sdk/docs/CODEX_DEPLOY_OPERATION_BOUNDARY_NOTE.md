# Codex Deploy Operation Boundary Note

`aoa-sdk` may surface typed references related to Codex-plane rollout operations.

It does not own:
- rollout success authority
- trust decisions
- rollback decisions
- deployment history truth

Acceptable seam:
- consume `rollout_campaign_ref`
- consume `deploy_receipt_ref`
- surface deploy status snapshots
- pass through doctor / smoke / drift packet references

Unacceptable seam:
- declaring a rollout stabilized by sdk-local state alone
