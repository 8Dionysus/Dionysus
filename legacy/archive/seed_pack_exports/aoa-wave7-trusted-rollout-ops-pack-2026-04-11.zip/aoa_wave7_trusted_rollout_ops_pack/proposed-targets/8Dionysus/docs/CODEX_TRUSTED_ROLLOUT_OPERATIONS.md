# Codex Trusted Rollout Operations

`8Dionysus` owns the shared-root operational history for the live Codex plane.

This note exists to keep rollout work:
- reviewable
- bounded
- source-owned
- reversible

## What this note governs

After regeneration or deployment continuity work on the project-level Codex plane:
- open a bounded rollout campaign
- record deploy receipts
- observe a bounded drift window
- either stabilize or open a rollback window
- publish source artifacts in `generated/codex/rollout/`
- allow derived layers to summarize, not replace, these source artifacts

## Why this stays here

The shared-root Codex plane is installed from `8Dionysus`.
That makes `8Dionysus` the correct home for rollout history and bounded operational law.

## Non-goals

- not a scheduler
- not a hidden automation governor
- not a replacement for approval / sandbox / trust controls
- not a new source of truth for owner-layer meaning outside the shared-root Codex plane

## Required rollout artifacts

- rollout history records
- regeneration campaign summaries
- rollback window records
- latest rollout summary

## Rollout posture

A rollout campaign must move through explicit states:
`prepared -> activated -> monitoring -> stabilized`
or
`prepared -> activated -> monitoring -> rollback_open -> rolled_back`

## Drift posture

Drift is not noise to bury.
Drift must be named, bounded, and either resolved or rolled back.

## Recovery posture

Successful repair patterns should be memoized.
Failed or insufficient repairs should become lessons.
