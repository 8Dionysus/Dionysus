# trusted-rollout-operations

## Purpose

Run a bounded, reviewable rollout campaign for the shared-root Codex plane.

## Route

1. regenerate / render target Codex plane
2. run doctor
3. run smoke checks
4. confirm trust + boundary posture
5. activate bounded rollout
6. open drift window
7. attempt bounded repair only if safe
8. open rollback window if drift turns material
9. publish rollout receipts
10. refresh stats
11. write memo lesson / recovery pattern

## Required artifacts

- `rollout_decision`
- `doctor_report_ref`
- `smoke_report_ref`
- `deploy_receipt_ref`
- `drift_window_ref`
- `rollback_window_ref` when needed
- `stats_refresh_ref`
- `memo_writeback_ref`

## Stop-lines

Stop and require review when:
- project is not trusted
- smoke or doctor reports fail on boundary-critical surfaces
- drift becomes material on startup / MCP / shared-root loading path
- rollback window outcome remains ambiguous

## Outcome classes

- `stabilized`
- `rolled_back`
- `abandoned`
