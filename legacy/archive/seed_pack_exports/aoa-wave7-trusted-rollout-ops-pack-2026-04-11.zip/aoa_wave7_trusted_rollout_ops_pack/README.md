# AoA Wave 7: Trusted Rollout Operations Pack

This wave extends portability/regeneration and deployment continuity into a **live rollout discipline** for the Codex-plane.

## Why this wave exists

The project-level Codex plane is already alive. After:
- workspace/shared-root installation
- MCP / plugin / subagent wiring
- portability + regeneration
- deployment continuity receipts

the next missing layer is **operational continuity under drift**:
- deploy-local history
- regeneration campaigns
- drift windows
- bounded rollback follow-through
- derived rollout summaries
- memoized recovery lessons

This pack is intentionally narrow. It does **not** create a new authority layer.
It makes rollout operations:
- reviewable
- source-owned
- receipt-first
- bounded
- reversible
- visible to stats and memo
- orchestrated by playbook rather than hidden automation

## What is inside

- `IMPLEMENTATION_DOCKET.md`
- `PR_SLICES.md`
- `CODEX_EXECUTION_PROMPT.md`
- `ACCEPTANCE_MATRIX.md`
- `contracts/trusted_rollout_operations_contract_v1.md`
- `proposed-targets/...` starter docs, examples, and patch guides
- `tools/validate_wave7_trusted_rollout_ops.py`

## Repo targets in this wave

Primary:
- `8Dionysus`
- `aoa-stats`
- `aoa-playbooks`
- `aoa-memo`

Light touch:
- `aoa-sdk` boundary note for typed deploy-operation packet references

## Operational thesis

Wave 6 made the Codex plane portable and continuable.

Wave 7 makes it **operable as a governed cycle**:
1. render / regenerate project-scoped Codex plane
2. run trust + doctor + smoke
3. open bounded rollout window
4. capture drift / failure / repair
5. either stabilize or rollback
6. publish rollout receipts
7. derive stats summaries
8. write memo lessons / recovery patterns

## Expected outcome

After this wave lands, the project should be able to answer:
- What rollout campaign changed the Codex plane most recently?
- Was it trusted and reviewed?
- What drift or failure windows appeared afterward?
- Which rollback window, if any, was opened?
- What recovery pattern succeeded?
- Which derived summaries reflect the result?

## Validate the pack locally

```bash
python tools/validate_wave7_trusted_rollout_ops.py
```
