# Acceptance Matrix: Wave 7 Trusted Rollout Operations

## A. `8Dionysus`
- [ ] `docs/CODEX_TRUSTED_ROLLOUT_OPERATIONS.md` exists
- [ ] `generated/codex/rollout/deploy_history.jsonl` shape documented
- [ ] `generated/codex/rollout/regeneration_campaigns.min.json` exists or is buildable
- [ ] `generated/codex/rollout/rollback_windows.min.json` exists or is buildable
- [ ] `generated/codex/rollout/rollout_latest.min.json` exists or is buildable
- [ ] lifecycle vocabulary matches contract

## B. `aoa-stats`
- [ ] rollout operations summary exists
- [ ] rollout drift summary exists
- [ ] summaries cite `8Dionysus` rollout surfaces as upstream input
- [ ] no truth inversion into stats

## C. `aoa-playbooks`
- [ ] `trusted-rollout-operations` playbook exists
- [ ] playbook defines bounded activation and rollback entry
- [ ] playbook names required artifacts
- [ ] playbook stop-lines are explicit

## D. `aoa-memo`
- [ ] `deploy_drift_lesson` seam exists
- [ ] `rollout_recovery_pattern` seam exists
- [ ] strongest available refs carried
- [ ] memo remains non-proof, non-sovereign

## E. Cross-repo integrity
- [ ] `rollout_campaign_ref` stable across examples
- [ ] `rollback_window_ref` linked to same campaign where intended
- [ ] `drift_window_ref` linked to stats and memo examples
- [ ] validator passes

## F. Behavioral posture
- [ ] rollout remains reviewable and bounded
- [ ] rollback is explicit rather than hidden cleanup
- [ ] drift becomes visible instead of implicit
- [ ] recovery is memoized instead of forgotten
