# Trusted Rollout Operations Contract v1

## Purpose

Define the minimum stable vocabulary and artifacts for **reviewable rollout operations**
for the shared-root Codex plane.

This contract binds together:
- source-owned rollout history in `8Dionysus`
- derived rollout read models in `aoa-stats`
- recurring operational route in `aoa-playbooks`
- lesson / recovery memory in `aoa-memo`

It does not create a new sovereign layer.

---

## Stable references

### `rollout_campaign_ref`
Canonical id for one bounded rollout campaign.

Pattern:
`ROLL-YYYYMMDD-<slug>-NN`

Example:
`ROLL-20260412-codex-plane-regen-01`

### `deploy_receipt_ref`
Append-only receipt id for one activation step inside a campaign.

Pattern:
`DEPLOY-YYYYMMDD-<slug>-NN`

### `drift_window_ref`
Id for a bounded observation window after activation.

Pattern:
`DRIFT-YYYYMMDD-<slug>-NN`

### `rollback_window_ref`
Id for an explicit bounded rollback window.

Pattern:
`RBK-YYYYMMDD-<slug>-NN`

---

## Lifecycle vocabulary

Allowed rollout states:
- `prepared`
- `activated`
- `monitoring`
- `stabilized`
- `rollback_open`
- `rolled_back`
- `abandoned`

Allowed drift states:
- `quiet`
- `watch`
- `material`
- `repairing`
- `resolved`
- `rolled_back`

---

## Source-owned artifacts

### `8Dionysus` rollout history record
Required fields:
- `rollout_campaign_ref`
- `state`
- `activated_at`
- `actor`
- `scope`
- `deploy_receipt_refs`
- `drift_window_refs`
- `rollback_window_refs`
- `summary`

### regeneration campaign summary
Required fields:
- `rollout_campaign_ref`
- `render_profile`
- `workspace_root`
- `trusted_project`
- `doctor_result`
- `smoke_result`
- `state`

### rollback window record
Required fields:
- `rollback_window_ref`
- `rollout_campaign_ref`
- `opened_at`
- `trigger`
- `decision`
- `closed_at`
- `outcome`

---

## Derived artifacts

### `aoa-stats` rollout operations summary
Required fields:
- `latest_rollout_campaign_ref`
- `latest_state`
- `active_drift_window_ref`
- `active_rollback_window_ref`
- `counts_by_state`
- `source_refs`

### `aoa-stats` rollout drift summary
Required fields:
- `latest_rollout_campaign_ref`
- `drift_window_ref`
- `drift_state`
- `repair_attempted`
- `rollback_required`
- `source_refs`

---

## Playbook artifacts

The `trusted-rollout-operations` playbook should emit or expect:
- `rollout_decision`
- `doctor_report_ref`
- `smoke_report_ref`
- `deploy_receipt_ref`
- `drift_window_ref`
- `rollback_window_ref` when needed
- `stats_refresh_ref`
- `memo_writeback_ref`

---

## Memo artifacts

### `deploy_drift_lesson`
Required fields:
- `rollout_campaign_ref`
- `drift_window_ref`
- `symptom`
- `boundary_hit`
- `repair_attempt`
- `outcome`
- `evidence_refs`

### `rollout_recovery_pattern`
Required fields:
- `rollout_campaign_ref`
- `rollback_window_ref` or `drift_window_ref`
- `pattern_name`
- `trigger`
- `steps`
- `outcome`
- `confidence`
- `evidence_refs`

---

## Boundary law

- `8Dionysus` owns rollout source artifacts for the shared-root Codex plane.
- `aoa-stats` may summarize but not override source artifacts.
- `aoa-playbooks` may define method but not claim source-of-truth on outcomes.
- `aoa-memo` may preserve lessons and recovery patterns but not prove correctness.
- `aoa-sdk` may surface typed packet references but does not own rollout decisions.

---

## Correction law

Use append-only or superseding updates.
Do not silently mutate history records.

Optional correction fields:
- `supersedes`
- `superseded_by`
- `correction_note`

---

## Minimal success condition

A rollout campaign can be reconstructed across:
1. rollout source history
2. derived stats
3. playbook route
4. memo writeback

using stable refs and without ambiguity about whether the campaign stabilized or rolled back.
