seed_id: seed.future.agent-systems-prep-pack.v0
title: Future Agent Systems Seed Prep Pack
profile_anchor: 8Dionysus
projects:
  - AoA
  - ToS
kind: prep-pack-note
status: pending_archive
priority: medium
parent_seed: null
tags:
  - seeds
  - memory
  - agents
  - evals
  - skills
  - documentation
  - mcp
  - a2a
  - governance

# Seed Note: Future Agent Systems Seed Prep Pack

## Purpose

Prepare a **non-queued future seed pack** for the AoA / ToS ecosystem so strong future seeds can live in `Dionysus` without pretending to be the next wave, without changing the current `next_live_seed`, and without forcing premature `seed_index` registration.

## Why this belongs in Dionysus

`Dionysus` is the seed garden and dispatch layer.

This prep pack belongs here because:
- the candidate seeds span multiple owning repositories
- the right current posture is **staging**, not immediate planting
- the current `navigation.next_live_seed` should stay untouched
- the current registry contract does not provide a neutral parked status for many `wave: null` candidates in `seed_index`
- the ecosystem already uses future prep notes and maps for later bounded work instead of pretending everything is a wave

## Why these are packed instead of registered now

The current contract for `seed_index` entries is too narrow for a waiting garden:
- if `wave` is `null`, the entry must be `gated_next` or `landed_post_wave`
- these seeds are neither the single next seed nor already planted post-wave surfaces

So the clean form is:
1. keep them in a prep pack
2. keep the current `next_live_seed` intact
3. append only the prep note to `origin_notes` if discoverability is desired
4. delay `seed_index` promotion until a later bounded manifest or explicit planting decision

## Bundle contents to preserve

The source artifact is `future_agent_systems_seed_pack.zip`.

It carries:
- `README.md`
- `matrix/future_agent_systems_applicability.yaml`
- `notes/selection_rationale.md`
- `notes/origin_notes_patch.snippet.yaml`
- `seed_cards/AOA-SEED-R6-memory-namespace-and-compression-discipline.md`
- `seed_cards/AOA-SEED-R7-eval-ladder-and-judge-discipline.md`
- `seed_cards/AOA-SEED-R8-skills-as-contracted-execution-capsules.md`
- `seed_cards/AOA-SEED-R9-ai-native-documentation-surface.md`
- `seed_cards/AOA-SEED-R10-tool-approval-and-remote-boundary-policy.md`
- `seed_cards/AOA-SEED-R11-online-trace-sentinel.md`
- `seed_cards/AOA-SEED-R12-skill-proof-regression-dataset-spine.md`
- `seed_cards/AOA-SEED-R13-mcp-resource-and-prompt-surface.md`
- `seed_cards/AOA-SEED-R14-outward-a2a-boundary-and-agent-card.md`
- `seed_cards/AOA-SEED-R15-prompt-profile-version-spine.md`

## Ownership posture

Read later plantings under existing repo-home boundaries:
- `aoa-memo` owns memory contracts and recall/writeback doctrine
- `aoa-evals` owns proof and evaluation canon
- `aoa-skills` owns bounded execution canon
- `aoa-playbooks` owns scenario composition
- `aoa-agents` owns role/tier runtime seam and orchestration posture
- `aoa-routing` owns navigation and dispatch
- `Agents-of-Abyss` owns ecosystem center and constitutional routing
- `Tree-of-Sophia` owns authored conceptual source meaning
- `abyss-stack` owns runtime substrate and exposure posture

This prep pack stages future seeds for those owners.  
It does **not** transfer their meaning into `Dionysus`.

## What this pack is for

- preserve high-fit future seeds without fixing their order
- keep future plantings legible by readiness and repo-home fit
- provide bounded planting hints and non-goals for each seed
- keep official/primary source basis attached to the seeds
- avoid cross-repo authorship drift while still letting the garden hold future work

## What this pack is not for

- no new wave manifest yet
- no change to `navigation.next_live_seed`
- no new `seed_index` entries yet
- no direct downstream planting yet
- no second registry hidden inside a note
- no claim that all seeds should be planted

## Seed list

### Direct fit now
- AOA-SEED-R6 Memory Namespace and Compression Discipline
- AOA-SEED-R7 Eval Ladder and Judge Discipline
- AOA-SEED-R8 Skills as Contracted Execution Capsules
- AOA-SEED-R9 AI-Native Documentation Surface
- AOA-SEED-R10 Tool Approval and Remote Boundary Policy

### Strong fit after one adjacent baseline or bounded neighbor move
- AOA-SEED-R11 Online Trace Sentinel
- AOA-SEED-R12 Skill/Proof Regression Dataset Spine
- AOA-SEED-R13 MCP Resource and Prompt Surface
- AOA-SEED-R14 Outward A2A Boundary and Agent Card

### Reserve
- AOA-SEED-R15 Prompt/Profile Version Spine

## Selection rule for later plantings

When a future planting begins:
1. choose the smallest bounded seed that strengthens an already-owned boundary
2. prefer one primary repo-home and, at most, one adjacent bridge repo
3. avoid opening two seeds that would redefine the same seam in one pass without a manifest
4. keep AoA meaning, ToS meaning, runtime meaning, workflow meaning, and proof meaning from collapsing into each other
5. leave one human-readable explanation and one structural artifact in the owner repo

## Final rule

Use this prep pack to let strong seeds wait **without pretending to be ordered**.  
Do not let a waiting garden become a shadow queue, a shadow registry, or a second source of truth.
