# Dionysus future seed pack drop-in

Prepared on: 2026-03-26

## What to copy into `Dionysus`

Drop these files into the repository root:

- `seed_future_agent_systems_prep_pack.md`
- `seed_future_agent_systems_prep_pack.map.yaml`
- `future_agent_systems_seed_pack.zip`

Optional:
- append `seed_future_agent_systems_prep_pack.md` to `navigation.origin_notes`
- keep the current `navigation.next_live_seed` untouched:
  - `seed_expansion/seed.tos.wider-world-thought-expansion.v0.md#tos-expansion-wider-world-thought-expansion`

## Why this shape

This drop-in follows the current Dionysus pattern of using **prep notes + maps** for future cross-repo work without pretending the work is already a wave or a live `seed_index` entry.

## Included bundle

The bundled archive `future_agent_systems_seed_pack.zip` contains:
- one README
- one applicability matrix
- one selection-rationale note
- one origin-notes snippet
- ten seed cards

