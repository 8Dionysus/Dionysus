# Future Agent Systems Seed Pack

Prepared on: 2026-03-26

This bundle stages **10 carefully selected future seeds** for the AoA / ToS ecosystem. It is meant to live in `Dionysus` as a **future prep pack**, not as a new wave and not as a replacement for the current `next_live_seed`.

## Why this is a pack instead of registry entries

The current `Dionysus` contract is friendly to:
- archived wave seeds
- one current `gated_next`
- landed post-wave seeds
- origin-note style prep surfaces

It is **not** friendly to a neutral pile of `seed_index` entries with `wave: null` that are merely waiting around, because the registry contract only permits `gated_next` or `landed_post_wave` for `wave: null` entries. So the cleanest way to stage these seeds is:
1. keep them in a prep pack note
2. keep the current `next_live_seed` untouched
3. delay `seed_index` promotion until a later bounded manifest or planting decision

## What is in this bundle

- `seed_cards/` — one card per seed
- `matrix/future_agent_systems_applicability.yaml` — machine-readable applicability matrix
- `notes/selection_rationale.md` — why these seeds were chosen and why others were excluded
- `notes/origin_notes_patch.snippet.yaml` — optional snippet for appending the prep pack note/map to `origin_notes`

## Readiness posture

These seeds are **not queued**. They are grouped by readiness, not order.

### Direct fit now
- AOA-SEED-R6 Memory Namespace and Compression Discipline
- AOA-SEED-R7 Eval Ladder and Judge Discipline
- AOA-SEED-R8 Skills as Contracted Execution Capsules
- AOA-SEED-R9 AI-Native Documentation Surface
- AOA-SEED-R10 Tool Approval and Remote Boundary Policy

### Strong fit after one adjacent bounded planting or baseline
- AOA-SEED-R11 Online Trace Sentinel
- AOA-SEED-R12 Skill/Proof Regression Dataset Spine
- AOA-SEED-R13 MCP Resource and Prompt Surface
- AOA-SEED-R14 Outward A2A Boundary and Agent Card

### Reserve seed
- AOA-SEED-R15 Prompt/Profile Version Spine

## Selection rule when a later planting opens

Choose the **smallest bounded slice** that:
- strengthens an already-owned repo boundary
- does not change the current `next_live_seed`
- does not require two neighboring layers to be redefined at once
- can leave one human-readable explanation and one structural artifact in the owner repo
- keeps AoA meaning, ToS meaning, runtime meaning, and proof meaning from collapsing into each other

## Seed list

1. **AOA-SEED-R6 Memory Namespace and Compression Discipline**  
   Memory namespaces, memory kinds, governed compaction, and bounded writeback.

2. **AOA-SEED-R7 Eval Ladder and Judge Discipline**  
   A structured evaluator authority ladder: deterministic checks, trace grading, LLM judges, pairwise review, human review.

3. **AOA-SEED-R8 Skills as Contracted Execution Capsules**  
   Skills as bounded execution capsules with explicit inputs, outputs, failure modes, and eval hooks.

4. **AOA-SEED-R9 AI-Native Documentation Surface**  
   Thin AI-readable documentation surfaces: `llms.txt`, AI doc maps, curated resource entrypoints.

5. **AOA-SEED-R10 Tool Approval and Remote Boundary Policy**  
   Unified approval posture and remote-boundary policy for local tools, remote MCP tools, and sensitive actions.

6. **AOA-SEED-R11 Online Trace Sentinel**  
   Production trace sentinel logic for anomaly, regression, and wrong-boundary detection.

7. **AOA-SEED-R12 Skill/Proof Regression Dataset Spine**  
   Regression corpus binding skills, playbooks, proof bundles, and traces.

8. **AOA-SEED-R13 MCP Resource and Prompt Surface**  
   MCP resource/prompt exposure for high-signal AoA / ToS surfaces.

9. **AOA-SEED-R14 Outward A2A Boundary and Agent Card**  
   Outward A2A boundary policy and Agent Card examples.

10. **AOA-SEED-R15 Prompt/Profile Version Spine**  
    Prompt/profile versioning with rollback, baselines, and linked eval discipline.

## Working rule

Do not let this pack become a disguised second registry, a shadow wave, or a new source of truth.  
Its job is only to preserve strong future seeds until a later bounded planting chooses one.

