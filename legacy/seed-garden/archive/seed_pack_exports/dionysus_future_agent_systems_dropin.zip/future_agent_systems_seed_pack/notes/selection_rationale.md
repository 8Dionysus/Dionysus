# Selection rationale for the Future Agent Systems Seed Pack

Prepared on: 2026-03-26

## Why these 10 seeds were kept

These seeds were kept because they extend **existing repo boundaries** instead of inventing a second architecture next to them.

They cluster around five live concerns in the AoA / ToS ecosystem:

1. **Memory discipline**
   - AOA-SEED-R6 Memory Namespace and Compression Discipline

2. **Proof / eval discipline**
   - AOA-SEED-R7 Eval Ladder and Judge Discipline
   - AOA-SEED-R11 Online Trace Sentinel
   - AOA-SEED-R12 Skill/Proof Regression Dataset Spine

3. **Execution / skills discipline**
   - AOA-SEED-R8 Skills as Contracted Execution Capsules

4. **AI-facing documentation and protocol surfaces**
   - AOA-SEED-R9 AI-Native Documentation Surface
   - AOA-SEED-R13 MCP Resource and Prompt Surface
   - AOA-SEED-R14 Outward A2A Boundary and Agent Card

5. **Safety and runtime governance**
   - AOA-SEED-R10 Tool Approval and Remote Boundary Policy
   - AOA-SEED-R15 Prompt/Profile Version Spine

## Why they fit Dionysus

These seeds are **cross-repo stageable** but **not yet registry-stable**.

That means they are ideal for `Dionysus` as:
- a waiting garden
- a dispatch layer
- a bounded prep surface
- a place to hold future-seed notes without forcing the registry to pretend they are already wave-bound

## Why they were not added to `seed_index` yet

The current registry contract only gives a `wave: null` seed two legal public states:
- `gated_next`
- `landed_post_wave`

That is too rigid for a pack of future candidates. These seeds are neither:
- the single live next seed
- nor already planted post-wave material

So the correct shape is **prep pack + map + optional origin note append**, not `seed_index` promotion.

## Important exclusions

The following kinds of seeds were **intentionally excluded** from this pack:

- broad “GraphRAG overhaul” seeds with no bounded owner repo
- UI-only or app-shell seeds that would outrun current contracts
- vendor-specific orchestration seeds that would hard-code one framework as doctrine
- generic “make everything a server” seeds
- broad model hierarchy or infra seeds that duplicate already owned `abyss-stack` / `aoa-agents` surfaces
- wide “tool marketplace” seeds that would weaken approval posture

## Readiness notes

### Highest immediate fit
- AOA-SEED-R6 Memory Namespace and Compression Discipline
- AOA-SEED-R7 Eval Ladder and Judge Discipline
- AOA-SEED-R8 Skills as Contracted Execution Capsules
- AOA-SEED-R9 AI-Native Documentation Surface
- AOA-SEED-R10 Tool Approval and Remote Boundary Policy

These extend already visible seams and can be planted in one owner repo plus, at most, one adjacent bridge repo.

### Good but better after one baseline or neighbor move
- AOA-SEED-R11 Online Trace Sentinel
- AOA-SEED-R12 Skill/Proof Regression Dataset Spine
- AOA-SEED-R13 MCP Resource and Prompt Surface
- AOA-SEED-R14 Outward A2A Boundary and Agent Card

These are strong, but they benefit from:
- a live trace baseline
- a starter dataset spine
- a chosen MCP surface
- or one explicitly outward-facing agent

### Reserve
- AOA-SEED-R15 Prompt/Profile Version Spine

This one is useful, but it becomes much stronger once at least one prompt-bearing runtime surface is already being measured against a real baseline.

## Source basis

The pack was shaped primarily from current official or primary documentation:
- OpenAI Remote MCP / connectors: https://platform.openai.com/docs/guides/tools-remote-mcp
- OpenAI Agent Evals: https://platform.openai.com/docs/guides/agent-evals
- OpenAI Prompting / prompt versioning: https://platform.openai.com/docs/guides/prompting
- OpenAI Docs MCP: https://platform.openai.com/docs/docs-mcp
- LangGraph Memory Overview: https://docs.langchain.com/oss/javascript/langgraph/memory
- LangChain Long-term Memory: https://docs.langchain.com/oss/python/langchain/long-term-memory
- LangSmith Evaluation Concepts: https://docs.langchain.com/langsmith/evaluation-concepts
- MCP Resources: https://modelcontextprotocol.io/docs/concepts/resources
- MCP Tools: https://modelcontextprotocol.io/docs/concepts/tools
- MCP Prompts: https://modelcontextprotocol.io/specification/2025-06-18/server/prompts
- A2A Specification: https://a2aproject.github.io/A2A/latest/specification/
- Google ADK A2A Intro: https://google.github.io/adk-docs/a2a/intro/
- llms.txt proposal/spec: https://llmstxt.org/
- Anthropic MCP connector: https://docs.anthropic.com/en/docs/agents-and-tools/mcp-connector

## Final rule

This pack should **wait without pretending to be ordered**.  
When a later planting begins, choose the smallest seed that improves a real boundary and does not force three other boundaries to move with it.
