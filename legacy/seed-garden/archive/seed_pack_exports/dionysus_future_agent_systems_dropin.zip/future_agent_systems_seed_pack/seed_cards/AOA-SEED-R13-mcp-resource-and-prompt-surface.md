seed_id: seed.future.agent-systems.r13.v0
label: AOA-SEED-R13 MCP Resource and Prompt Surface
projects:
  - AoA
  - ToS
kind: protocol-seed
pack_status: staged_candidate
repo_homes:
  - Agents-of-Abyss
  - aoa-skills
  - aoa-playbooks
  - Tree-of-Sophia
summary: Expose the most reusable AoA and ToS surfaces as MCP resources and prompts so clients can discover, select, and invoke them without flattening everything into tools.

# AOA-SEED-R13 MCP Resource and Prompt Surface

## Fit
Expose the most reusable AoA and ToS surfaces as MCP resources and prompts so clients can discover, select, and invoke them without flattening everything into tools.

## Why this fits AoA / ToS
- Your architecture already thinks in surfaces and ownership. MCP resources and prompts give those surfaces a standard protocol shape.
- The current MCP specification distinguishes server features into resources, prompts, and tools, which maps surprisingly well onto your docs / skill / runtime boundaries.
- Resources are application-controlled and prompts are user-controlled, which is useful for keeping doctrinal and workflow surfaces from becoming model-autonomous tools too early.

## First artifact hint
A resource/prompt manifest naming which docs, capsules, and scenario prompts deserve protocol exposure first.

## Bounded planting options
- Agents-of-Abyss: expose a small MCP resource set for ecosystem maps, ownership tables, and high-signal canonical docs.
- aoa-skills / aoa-playbooks: expose a few user-triggered prompt surfaces for tightly bounded workflows.
- Tree-of-Sophia: expose read-only resources for authored trunks and lineage guides only.

## Boundaries to preserve
- Do not map every doc or file into MCP on day one.
- Do not expose ToS authored meaning as tool-controlled behavior.
- Do not let prompts stand in for approval-aware tools.

## Non-goals
- No full MCP platform rewrite.
- No blind export of internal-only materials.
- No assumption that every MCP client will surface resources/prompts the same way.

## Source basis
- MCP specification overview: https://modelcontextprotocol.io/specification/2025-06-18
- Resources (MCP): https://modelcontextprotocol.io/docs/concepts/resources
- Prompts (MCP): https://modelcontextprotocol.io/specification/2025-06-18/server/prompts
