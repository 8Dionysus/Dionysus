seed_id: seed.future.agent-systems.r12.v0
label: AOA-SEED-R12 Skill/Proof Regression Dataset Spine
projects:
  - AoA
kind: dataset-seed
pack_status: staged_candidate
repo_homes:
  - aoa-evals
  - aoa-skills
  - aoa-playbooks
  - aoa-agents
summary: Build a reusable regression dataset spine that binds skills, playbooks, proof bundles, and traces into one auditable evaluation corpus.

# AOA-SEED-R12 Skill/Proof Regression Dataset Spine

## Fit
Build a reusable regression dataset spine that binds skills, playbooks, proof bundles, and traces into one auditable evaluation corpus.

## Why this fits AoA / ToS
- Your ecosystem already separates workflow meaning and proof meaning. A shared regression spine lets that seam be exercised repeatedly instead of only discussed.
- OpenAI's eval stack now emphasizes datasets as the reproducible substrate for evaluation and prompt iteration.
- LangSmith documents datasets, versions, splits, experiments, and exporting runs into datasets, which is an unusually good match for an AoA regression corpus.

## First artifact hint
A dataset manifest plus a schema for examples linking input, expected artifacts, reference outputs, and known failure tags.

## Bounded planting options
- aoa-evals: add dataset_schema.skill_proof_regression.json and a tiny hand-built starter dataset.
- aoa-skills: tag a few high-signal skills with canonical regression example IDs.
- aoa-playbooks: add expected_artifact test anchors so dataset cases can follow scenario slices without embedding whole playbooks.

## Boundaries to preserve
- Do not mistake dataset coverage for semantic completeness.
- Do not let regression examples rewrite canon by accumulation.
- Do not force every skill to be evaluated through the same example geometry.

## Non-goals
- No synthetic-only benchmark garden.
- No giant dataset before a starter corpus proves useful.
- No collapse of production traces and curated gold cases into one undifferentiated pool.

## Source basis
- Agent evals (OpenAI): https://platform.openai.com/docs/guides/agent-evals
- Evaluation concepts (LangSmith): https://docs.langchain.com/langsmith/evaluation-concepts
