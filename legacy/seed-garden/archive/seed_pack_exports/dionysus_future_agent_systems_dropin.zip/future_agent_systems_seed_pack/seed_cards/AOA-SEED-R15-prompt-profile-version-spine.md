seed_id: seed.future.agent-systems.r15.v0
label: AOA-SEED-R15 Prompt/Profile Version Spine
projects:
  - AoA
kind: prompt-governance-seed
pack_status: staged_candidate
repo_homes:
  - aoa-agents
  - aoa-playbooks
  - aoa-skills
  - aoa-evals
summary: Create a versioned prompt and profile spine so prompt-bearing surfaces can be pinned, compared, rolled back, and evaluated without relying on hidden mutable prompt text.

# AOA-SEED-R15 Prompt/Profile Version Spine

## Fit
Create a versioned prompt and profile spine so prompt-bearing surfaces can be pinned, compared, rolled back, and evaluated without relying on hidden mutable prompt text.

## Why this fits AoA / ToS
- Your ecosystem already values explicit artifacts. Prompt-bearing runtime surfaces should follow the same rule instead of living as drifting text blobs.
- OpenAI's current prompting guidance now treats prompts as long-lived objects with versioning, variables, rollback, and prompt-linked eval practice.
- This seed is especially useful for aoa-agents profiles and prompt-backed skill capsules, but only if versions stay attached to measurable baselines.

## First artifact hint
A prompt/profile registry note with version IDs, variables, baseline links, rollback posture, and eval references.

## Bounded planting options
- aoa-agents: add PROMPT_PROFILE_VERSIONING.md and one versioned prompt-bearing profile example.
- aoa-playbooks: mark which playbook prompts are frozen, which are experimental, and which require linked eval baselines.
- aoa-evals: add a small convention for evaluating prompt versions against the same dataset slices.

## Boundaries to preserve
- Do not hide active prompt changes behind stable profile names.
- Do not let prompt versions outrank owning repo doctrine.
- Do not version prompts without a linked baseline or rollback rule.

## Non-goals
- No giant prompt CMS.
- No forced migration of every static doc into prompt objects.
- No prompt version churn with no evaluation discipline.

## Source basis
- Prompting (OpenAI): https://platform.openai.com/docs/guides/prompting
