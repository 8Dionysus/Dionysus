seed_id: seed.future.agent-systems.r8.v0
label: AOA-SEED-R8 Skills as Contracted Execution Capsules
projects:
  - AoA
kind: workflow-seed
pack_status: staged_candidate
repo_homes:
  - aoa-skills
  - aoa-playbooks
  - aoa-agents
  - aoa-evals
summary: Turn skills into reusable execution capsules with explicit I/O, preconditions, side-effects, overlays, failure modes, and eval hooks so they can be executed, audited, and composed without bloating playbooks.

# AOA-SEED-R8 Skills as Contracted Execution Capsules

## Fit
Turn skills into reusable execution capsules with explicit I/O, preconditions, side-effects, overlays, failure modes, and eval hooks so they can be executed, audited, and composed without bloating playbooks.

## Why this fits AoA / ToS
- Your skill layer is already a canonical execution layer. The next useful step is to make each skill callable and testable as a bounded capsule, not just readable as a doctrine surface.
- MCP prompts formalize reusable prompt templates as user-invoked surfaces, while MCP tools formalize callable operations with input schemas and optional structured output schemas.
- OpenAI prompting now supports long-lived prompt objects with versioning and templating, which strengthens the case for bounded prompt-backed execution capsules rather than free-floating prompt text.

## First artifact hint
A skill capsule contract: inputs, outputs, preconditions, overlays, failure modes, witness surface, and eval hook IDs.

## Bounded planting options
- aoa-skills: add SKILL_CAPSULE_CONTRACT.md and one exemplar capsule file for a high-signal existing skill.
- aoa-playbooks: reference capsule IDs instead of repeating operational detail that belongs to the skill.
- aoa-evals: attach capsule-aware regression checks so a skill can fail because its contract drifted even if the surrounding playbook still 'sounds right'.

## Boundaries to preserve
- Do not let skills absorb scenario composition owned by playbooks.
- Do not let skills redefine role/tier meaning owned by aoa-agents.
- Do not let derived overlays become stronger than the authored skill capsule.

## Non-goals
- No monolithic skills runtime.
- No hidden prompt bundles with no contract surface.
- No collapse of skill meaning into eval meaning.

## Source basis
- Prompts (MCP): https://modelcontextprotocol.io/specification/2025-06-18/server/prompts
- Tools (MCP): https://modelcontextprotocol.io/docs/concepts/tools
- Prompting (OpenAI): https://platform.openai.com/docs/guides/prompting
