seed_id: seed.future.agent-systems.r6.v0
label: AOA-SEED-R6 Memory Namespace and Compression Discipline
projects:
  - AoA
kind: architecture-seed
pack_status: staged_candidate
repo_homes:
  - aoa-memo
  - aoa-agents
  - abyss-stack
  - aoa-kag (derived only)
summary: Split memory into named scopes and memory kinds, then add governed compaction so runtime state, long-term memory, and derived retrieval memory stop bleeding into each other.

# AOA-SEED-R6 Memory Namespace and Compression Discipline

## Fit
Split memory into named scopes and memory kinds, then add governed compaction so runtime state, long-term memory, and derived retrieval memory stop bleeding into each other.

## Why this fits AoA / ToS
- Your current ecosystem already treats memory as a bounded surface instead of hidden context, so the next useful move is not 'more memory' but sharper memory boundaries.
- LangGraph now explicitly distinguishes short-term thread state from long-term memory, and frames long-term memory around semantic, episodic, and procedural types stored in namespaces.
- LangChain's long-term memory guidance now makes namespace + key organization a first-class pattern, while Deep Agents documents hybrid routing where some paths persist and others stay transient.

## First artifact hint
A memory namespace contract plus a compaction policy: semantic / episodic / procedural / transient, each with write rules, retrieval rules, and public-safe export rules.

## Bounded planting options
- aoa-memo: add MEMORY_NAMESPACE_POLICY.md and a compact JSON/YAML contract for memory kinds, write triggers, retention classes, and export posture.
- aoa-agents: add memory_intent fields to role/tier artifacts so runs can declare whether they are writing semantic facts, episodic traces, or procedural deltas.
- abyss-stack: add a storage profile note showing which backends may hold which memory classes and which classes must never be co-located by default.

## Boundaries to preserve
- Do not let KAG become the source of truth for authored memory.
- Do not let run-local state silently harden into durable memory without explicit writeback posture.
- Do not let compaction rewrite authored meaning; compaction can only compress or index derived memory surfaces.

## Non-goals
- No generic 'one vector store for everything' design.
- No silent promotion of traces into durable memory.
- No collapse of memo doctrine into retrieval substrate.

## Source basis
- Memory overview (LangGraph): https://docs.langchain.com/oss/javascript/langgraph/memory
- Long-term memory (LangChain): https://docs.langchain.com/oss/python/langchain/long-term-memory
- Long-term memory with hybrid persistent/transient filesystem (Deep Agents): https://docs.langchain.com/oss/python/deepagents/long-term-memory
