seed_id: seed.future.agent-systems.r11.v0
label: AOA-SEED-R11 Online Trace Sentinel
projects:
  - AoA
kind: observability-seed
pack_status: staged_candidate
repo_homes:
  - aoa-evals
  - aoa-memo
  - aoa-agents
  - abyss-stack
summary: Introduce a production-facing trace sentinel layer that samples runs, grades trajectories, labels failure modes, and raises bounded escalation signals without pretending to be final truth.

# AOA-SEED-R11 Online Trace Sentinel

## Fit
Introduce a production-facing trace sentinel layer that samples runs, grades trajectories, labels failure modes, and raises bounded escalation signals without pretending to be final truth.

## Why this fits AoA / ToS
- You already have trace and eval surfaces. The next mature step is not only offline proof but live trace surveillance for drift, regressions, and wrong-boundary behavior.
- OpenAI's current eval guidance explicitly recommends trace grading for workflow-level errors.
- LangSmith now treats online evaluation as a production feedback loop over runs and threads, not just a testing afterthought.

## First artifact hint
A trace sentinel taxonomy and a small set of online graders keyed to artifact classes and failure classes.

## Bounded planting options
- aoa-evals: add trace_failure_taxonomy.yaml and one online grader spec that can run on archived traces.
- aoa-memo: define which trace fields may be retained for sentinel use and which must be redacted or dropped.
- abyss-stack: map sentinel triggers to observability hooks and alert channels without turning them into auto-remediation by default.

## Boundaries to preserve
- Do not store raw sensitive payloads just because a trace may be useful later.
- Do not turn anomaly detection into automatic policy changes.
- Do not let online scoring redefine offline bundle contracts.

## Non-goals
- No full-blown SIEM inside aoa-evals.
- No universal alerting on every run.
- No automated corrective writeback from sentinel judgments.

## Source basis
- Agent evals (OpenAI): https://platform.openai.com/docs/guides/agent-evals
- Evaluation concepts (LangSmith): https://docs.langchain.com/langsmith/evaluation-concepts
