seed_id: seed.future.agent-systems.r9.v0
label: AOA-SEED-R9 AI-Native Documentation Surface
projects:
  - AoA
  - ToS
kind: documentation-seed
pack_status: staged_candidate
repo_homes:
  - Agents-of-Abyss
  - Tree-of-Sophia
  - aoa-skills
  - aoa-evals
  - aoa-memo
summary: Add a thin AI-facing documentation surface above existing source-of-truth files: llms.txt, curated doc maps, resource manifests, and AI-readable entrypoints that help agents retrieve the right canon faster.

# AOA-SEED-R9 AI-Native Documentation Surface

## Fit
Add a thin AI-facing documentation surface above existing source-of-truth files: llms.txt, curated doc maps, resource manifests, and AI-readable entrypoints that help agents retrieve the right canon faster.

## Why this fits AoA / ToS
- Dionysus and the wider ecosystem already care about source-of-truth order. An AI-native documentation surface can improve retrieval without changing ownership.
- OpenAI now publishes a documentation-only MCP server for its own docs, which is a strong pattern for exposing curated documentation surfaces without turning them into action surfaces.
- MCP resources are now an explicit application-controlled primitive, and llms.txt has matured into a practical proposal for curated AI-readable website maps.

## First artifact hint
A docs surface pack: llms.txt, DOCS_AI_MAP.md, and a resource manifest that names canonical entrypoints for agents and human readers alike.

## Bounded planting options
- Agents-of-Abyss: add llms.txt and an AI-facing ecosystem map linking only high-signal canonical docs.
- Tree-of-Sophia: add a ToS AI map that points to authored trunks, lineage notes, and non-collapse guidance, without exporting derived doctrine as canon.
- aoa-* repos: add minimal doc maps that point from AI-readable entrypoints to the actual owning docs and contracts.

## Boundaries to preserve
- Do not let AI docs surfaces become stronger than manifests, source seeds, or owning repo docs.
- Do not use doc maps to flatten layer ownership.
- Do not let llms.txt turn into a copy of the whole website.

## Non-goals
- No AI-only second canon.
- No requirement that every repo expose every internal note.
- No conversion of docs surfaces into tool surfaces by default.

## Source basis
- Docs MCP (OpenAI): https://platform.openai.com/docs/docs-mcp
- Resources (MCP): https://modelcontextprotocol.io/docs/concepts/resources
- llms.txt proposal/spec: https://llmstxt.org/
