seed_id: seed.future.agent-systems.r10.v0
label: AOA-SEED-R10 Tool Approval and Remote Boundary Policy
projects:
  - AoA
kind: safety-seed
pack_status: staged_candidate
repo_homes:
  - aoa-agents
  - abyss-stack
  - aoa-playbooks
  - aoa-memo
summary: Create a single policy for when tools may run automatically, when approval is mandatory, and when a capability is allowed to cross a remote MCP boundary at all.

# AOA-SEED-R10 Tool Approval and Remote Boundary Policy

## Fit
Create a single policy for when tools may run automatically, when approval is mandatory, and when a capability is allowed to cross a remote MCP boundary at all.

## Why this fits AoA / ToS
- Your stack is moving toward protocolized tooling, so tool use needs a boundary policy before it becomes habit.
- OpenAI's remote MCP guide now exposes require_approval, allowed_tools, approval request/response items, and explicit risk guidance for remote MCP and connectors.
- Anthropic's MCP connector currently limits support to tool calls on public HTTP servers, which is a useful reminder that remote MCP is not the same thing as a full local runtime.

## First artifact hint
A TOOL_APPROVAL_POLICY.md with capability classes, approval classes, remote/local boundary rules, and logging/redaction obligations.

## Bounded planting options
- aoa-agents: classify tools as read-only, bounded-write, sensitive-write, and remote-sensitive, with default approval posture.
- abyss-stack: add an implementation note describing which runtimes may expose remote MCP, and which must remain local-only.
- aoa-playbooks: mark steps that can only be executed under approval-aware runtime posture.

## Boundaries to preserve
- Do not expose a capability remotely just because it already exists locally.
- Do not let remote tool invocation bypass approval policies that would apply to the same action locally.
- Do not let approval artifacts become raw secret logs.

## Non-goals
- No universal auto-approval.
- No silent remote mirroring of every internal tool.
- No assumption that all MCP clients expose the same feature set.

## Source basis
- Connectors and remote MCP servers (OpenAI): https://platform.openai.com/docs/guides/tools-remote-mcp
- MCP connector (Anthropic): https://docs.anthropic.com/en/docs/agents-and-tools/mcp-connector
- Tools (MCP): https://modelcontextprotocol.io/docs/concepts/tools
