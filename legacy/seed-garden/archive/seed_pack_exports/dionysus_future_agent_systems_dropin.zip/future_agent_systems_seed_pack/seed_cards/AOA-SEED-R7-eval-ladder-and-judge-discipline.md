seed_id: seed.future.agent-systems.r7.v0
label: AOA-SEED-R7 Eval Ladder and Judge Discipline
projects:
  - AoA
kind: evaluation-seed
pack_status: staged_candidate
repo_homes:
  - aoa-evals
  - aoa-agents
  - aoa-playbooks
  - aoa-memo
summary: Formalize a multi-layer evaluation ladder so deterministic checks, trace grading, LLM judges, pairwise review, and human review each have explicit jobs instead of being blended together.

# AOA-SEED-R7 Eval Ladder and Judge Discipline

## Fit
Formalize a multi-layer evaluation ladder so deterministic checks, trace grading, LLM judges, pairwise review, and human review each have explicit jobs instead of being blended together.

## Why this fits AoA / ToS
- Your ecosystem already has a proof-facing layer in aoa-evals, so the next gain is to order evaluators by authority rather than keep adding more of them.
- OpenAI's current agent evals guidance pushes trace grading for workflow-level errors and treats datasets and eval runs as reproducible evaluation surfaces.
- LangSmith now documents a clear offline/online loop with code evaluators, LLM-as-judge, pairwise review, datasets, runs, and production threads.

## First artifact hint
An EVAL_LADDER.md plus a machine-readable evaluator taxonomy that says what each rung may judge, what evidence it sees, and what kinds of verdicts it may emit.

## Bounded planting options
- aoa-evals: add eval_ladder.yaml describing deterministic, structured-judge, pairwise, trace-level, and human-review rungs.
- aoa-agents: make key artifacts reference which rung is allowed to judge them by default.
- aoa-playbooks: add expected_eval_rungs so scenario flows know which proof surfaces must fire before closure.

## Boundaries to preserve
- Do not let LLM judges overrule deterministic contract failures.
- Do not let pairwise preference masquerade as correctness.
- Do not let shared judges become constitutional meaning.

## Non-goals
- No single super-judge prompt.
- No blanket LLM-as-judge policy across all artifact classes.
- No removal of human review from high-impact boundary changes.

## Source basis
- Agent evals (OpenAI): https://platform.openai.com/docs/guides/agent-evals
- Evaluation concepts (LangSmith): https://docs.langchain.com/langsmith/evaluation-concepts
