seed_id: seed.future.agent-systems.r14.v0
label: AOA-SEED-R14 Outward A2A Boundary and Agent Card
projects:
  - AoA
kind: interop-seed
pack_status: staged_candidate
repo_homes:
  - aoa-agents
  - aoa-routing
  - Agents-of-Abyss
  - abyss-stack
summary: Define the outward-facing agent boundary for AoA agents, including when an internal capability stays local, when it becomes a remote service, and how its Agent Card should describe that boundary.

# AOA-SEED-R14 Outward A2A Boundary and Agent Card

## Fit
Define the outward-facing agent boundary for AoA agents, including when an internal capability stays local, when it becomes a remote service, and how its Agent Card should describe that boundary.

## Why this fits AoA / ToS
- You already think in layered specialized agents. The missing piece is a formal rule for when an internal agent becomes an external one.
- The A2A specification makes Agent Cards the discovery surface and explicitly protects the opacity of internal memory, state, and tools across agent boundaries.
- Google ADK's A2A introduction clearly separates local sub-agents from remote A2A agents, which fits your desire to avoid turning every internal module into a network service.

## First artifact hint
An outward-boundary policy plus one example Agent Card and one example routing rule showing when to prefer local sub-agents versus remote A2A delegation.

## Bounded planting options
- aoa-agents: add OUTWARD_AGENT_BOUNDARY.md and an example agent-card JSON for a single bounded public-facing agent.
- aoa-routing: add notes for when routing may end at a remote agent boundary rather than an internal surface.
- Agents-of-Abyss: add a public interop note describing why outward agents must remain thinner than the federation center.

## Boundaries to preserve
- Do not expose internal memory, local-only tools, or latent doctrine in the Agent Card.
- Do not use A2A where a local sub-agent is enough.
- Do not let remote agent boundaries collapse repo-home ownership.

## Non-goals
- No multi-agent internet-first sprawl.
- No requirement that every repo publish an agent card.
- No automatic A2A conversion of every MCP surface.

## Source basis
- A2A specification: https://a2aproject.github.io/A2A/latest/specification/
- ADK A2A introduction: https://google.github.io/adk-docs/a2a/intro/
