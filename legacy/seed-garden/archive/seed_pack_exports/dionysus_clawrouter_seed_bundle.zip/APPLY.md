# Apply

This bundle is designed to land in `Dionysus` as a bounded donor-origin slice.

## Proposed file placement

- `seed_clawrouter_donor_graft.md` -> repo root
- `seed_clawrouter_donor_graft.map.yaml` -> repo root
- `reports/planting/2026-03-24-clawrouter-donor-graft.proposed.md` -> `reports/planting/`
- apply `seed-registry.patch.diff` to add the donor note to `origin_notes`

## Important constraints

- do **not** change `navigation.next_live_seed`
- do **not** add `seed_index` entries yet
- do **not** open a new wave
- do **not** import wallet / x402 / payment shell surfaces
- keep `src/doctor.ts` split: local observability yes, vendor-dependent AI diagnostics no

## First downstream planting order

1. `AOA-SEED-CR1`
2. `AOA-SEED-CR3`
3. `AOA-SEED-CR2`
4. `AOA-SEED-CR4`
5. `AOA-SEED-CR5`
6. `AOA-SEED-CR6`
7. `AOA-SEED-CR7`
