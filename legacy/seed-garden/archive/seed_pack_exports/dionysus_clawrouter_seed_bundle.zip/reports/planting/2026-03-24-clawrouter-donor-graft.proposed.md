## Planting report

- Date: 2026-03-24
- Wave: none (post-wave donor origin note)
- Seed: seed.clawrouter.donor-graft.v0
- Source ref: `BlockRunAI/ClawRouter` donor internals harvested into Dionysus
- Target repo: `Dionysus`
- Landed surfaces:
  - `seed_clawrouter_donor_graft.md`
  - `seed_clawrouter_donor_graft.map.yaml`
  - `seed-registry.patch.diff`
- Structural artifact: machine-readable transplant map plus registry patch
- Validation:
  - reviewed against `README.md`
  - reviewed against `docs/codex/planting-protocol.md`
  - reviewed against `seed-registry.yaml`
  - reviewed against `schema/seed-registry.contract.yaml`
  - YAML syntax checked for `seed_clawrouter_donor_graft.map.yaml`
- Deferred zones:
  - no `seed_index` entry added yet
  - no wave opened
  - no target-repo landing executed yet
  - no validator run against a checked-out Dionysus repo tree
- Risks / follow-ups:
  - keep `navigation.next_live_seed` unchanged
  - keep donor wallet/payment shell excluded
  - keep `aoa-routing` as navigation-only
  - keep session journal explicitly weaker than `aoa-memo` canon
  - split local ops doctor from vendor-dependent AI diagnostics

### Why this is the smallest coherent slice

This leaves:
- one human-readable donor seed note
- one structural transplant map
- one explicit registry patch
- one bounded report surface

It does not pretend the donor has already landed in downstream repos.
It prepares those landings without disturbing the live ToS expansion seed.
