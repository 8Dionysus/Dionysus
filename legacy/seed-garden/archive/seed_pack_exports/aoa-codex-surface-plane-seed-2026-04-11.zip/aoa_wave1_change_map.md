# AoA wave 1 change map

## Thesis
Wave 1 should introduce one explicit candidate-lineage nerve across checkpoint capture, reviewed harvest, seed staging, planting, derived observability, and proof.

Reference chain:
- `cluster_ref` in local checkpoint / closeout carry surfaces
- `candidate_ref` in reviewed `HARVEST_PACKET`
- `seed_ref` in Dionysus staging / registry
- `object_ref` in planted owner repo

Carry fields:
- `session_ref`
- `owner_hypothesis`
- `owner_confidence`
- `nearest_wrong_target`
- `repeat_shape`
- `promotion_pressure_vector`
- `evidence_refs`
- `supersedes`
- `merged_into`
- `dropped_by`
- `drop_reason`

## Repo by repo

### Agents-of-Abyss
Add one cross-repo doctrine note only.
Suggested file:
- `docs/CANDIDATE_LINEAGE_CROSSWALK.md`

Purpose:
- define naming and ownership boundaries for `cluster_ref -> candidate_ref -> seed_ref -> object_ref`
- forbid the center from owning implementation schemas
- clarify that lineage is cross-repo legibility, not a new sovereignty layer

### aoa-sdk
Suggested additions:
- `docs/CANDIDATE_LINEAGE_CONTROL_PLANE.md`
- `src/aoa_sdk/surfaces/lineage.py`
- `tests/test_candidate_lineage.py`

Suggested changes:
- extend checkpoint ledger snapshots with `cluster_ref`
- extend closeout context / reviewed handoff with `candidate_lineage_hints`
- preserve lineage through `aoa checkpoint build-closeout-context` and `aoa checkpoint execute-closeout-chain`
- do **not** assign `candidate_ref` here

### aoa-skills
Suggested additions:
- `schemas/harvest_candidate_lineage.schema.json`
- `templates/HARVEST_CANDIDATE.template.json`
- `docs/SESSION_GROWTH_LINEAGE.md`

Suggested changes:
- extend `aoa-session-donor-harvest` so reviewed harvest assigns `candidate_ref`
- carry `cluster_ref`, `owner_hypothesis`, `nearest_wrong_target`, `promotion_pressure_vector`, `evidence_refs`
- extend `HARVEST_PACKET_RECEIPT`
- extend `aoa-checkpoint-closeout-bridge` to preserve lineage across donor-harvest / progression / quest handoffs

### Dionysus
Suggested additions:
- `docs/SEED_LINEAGE_CONTRACT.md`
- `schemas/seed_lineage_v1.json`
- `reports/planting/lineage_trace.example.json`

Suggested changes:
- extend `seed-registry.yaml` with `seed_ref`, `candidate_ref`, `cluster_refs`, `lifecycle_status`, `supersedes`, `merged_into`
- standardize `seed_staging/<owner>/<seed_ref>/`
- add planting trace fields that record resulting `object_ref`

### aoa-stats
Suggested additions:
- `schemas/candidate_lineage_summary_v1.json`
- `generated/candidate_lineage_summary.min.json`
- `docs/CANDIDATE_LINEAGE_SUMMARIES.md`

Suggested changes:
- derive stage funnel from reviewed closeout / harvest / seed / planting / eval receipts
- keep raw logs append-only and collapse corrections via `supersedes`
- add derived fields such as `owner_ambiguity_rate`, `misroute_rate`, `time_to_plant`, `evidence_density`

### aoa-evals
Suggested additions:
- `bundles/aoa-candidate-lineage-integrity/EVAL.md`
- `bundles/aoa-owner-fit-routing-quality/EVAL.md`
- `docs/SESSION_GROWTH_KERNEL_EVALS.md`

Suggested changes:
- fixtures for reviewed session artifacts, harvest packets, seed records, and planted outcomes
- scorers for lineage continuity, owner-fit accuracy, and boundedness

## Optional follow-on after wave 1 lands

### aoa-memo
- add writeback for repeated misroutes into failure lessons
- add recovery-pattern entries for successful self-repair windows

### aoa-playbooks
- add `playbooks/session-growth-cycle/PLAYBOOK.md`
- use it only after the lineage and receipts are stable

### aoa-agents
- generate Codex subagent profiles from `profiles/*.profile.json` and `orchestrator_classes/*.class.json`
- keep agent identity separate from skills

## PR sequence
1. `Agents-of-Abyss` + `aoa-sdk` + `aoa-skills`: contract skeleton
2. `Dionysus`: seed-gate and planting lineage
3. `aoa-stats`: derived lineage funnel
4. `aoa-evals`: proof bundles
5. `aoa-memo` + `aoa-playbooks` + `aoa-agents`: reinforcement

## Codex surface map
- `aoa-skills` -> native skills / plugin packaging
- `aoa-agents` -> custom subagents (`.codex/agents/*.toml`)
- `aoa-memo`, `aoa-stats`, `aoa-kag`, possibly Dionysus live registry -> MCP / resources
- `aoa-sdk` -> project guidance + shell/CLI now; optional MCP later
- `aoa-routing` -> support resource for skills / subagents, not main direct surface
- `aoa-techniques` -> source references feeding skills
- `aoa-evals` -> runner skills + proof resources
- `aoa-playbooks` -> launch skills + subagent orchestration
