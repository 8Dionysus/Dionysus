# AoA × Codex surface crosswalk

## Core rule
Do **not** flatten the whole AoA federation into skills.
Use the narrowest Codex-native surface that matches the kind of thing each repo owns.

Codex surface guide:
- **AGENTS.md** = persistent repo law, conventions, build/test rules, routing hints
- **skills** = reusable workflows and bounded execution routes
- **MCP** = external tools, live context, shared memory/resources, remote actions
- **subagents** = role-bearing specialists with different instructions, models, tools, and skill access
- **plugins** = distribution unit when a reusable skill/app bundle should be installable across teams

---

## Crosswalk matrix

| AoA repo | What it owns | Primary Codex surface | Secondary surface | Adapter / export stance | Notes |
|---|---|---|---|---|---|
| `aoa-skills` | bounded execution workflows | **skills** | plugins later | canonical authoring stays in `skills/*`; export to `.agents/skills/*`; local adapters wrap the export, not replace it | direct Codex workflow layer |
| `aoa-agents` | role contracts, personas, orchestrator classes | **subagents** | AGENTS.md | generate `.codex/agents/*.toml` from repo-owned role contracts | agent is not a skill |
| `aoa-playbooks` | recurring multi-layer method | **launcher skills + subagents** | AGENTS.md | playbook stays source-authored; expose thin launch surfaces to Codex | good home for long scenario routes |
| `aoa-memo` | memory, recall, reviewed writeback | **MCP resources/tools** | small skills for bounded recall workflows | expose read/write seams through MCP instead of dumping memory into prompt canon | memory should stay live, reviewable, externalizable |
| `aoa-stats` | derived observability, progression summaries | **MCP resources** | small interpretation skills | stats should be queried, not baked into static skill text | ideal for dashboards, summaries, trend lookups |
| `aoa-routing` | thin navigation and dispatch hints | **support surface, not primary user-facing Codex layer** | AGENTS.md / skill metadata helpers | feed routing hints into skills/subagents; do not turn routing into a second skill empire | routing should stay thin |
| `aoa-sdk` | local-first control plane, CLI, workspace seams | **AGENTS.md + repo tooling guidance** | MCP later, targeted skills now | Codex should learn how to use the `aoa` CLI and workspace contracts; only later expose richer SDK-backed MCP | control plane, not source of meaning |
| `aoa-techniques` | reusable practice patterns | **references for skills/playbooks** | launcher skills when a technique becomes executable | keep techniques source-first; only project bounded execution slices into skills | practice is upstream of execution |
| `aoa-evals` | proof bundles, scoring, fixtures, runners | **launcher skills** | MCP/resources for results | do not flatten eval corpus into skills; expose “run/inspect eval” routes | proof stays evidence-bearing |
| `Dionysus` | seed garden, staging, planting lineage | **MCP/resources + targeted planting skills** | AGENTS.md | expose live seed/registry lookup as context; expose bounded planting workflows as skills | reviewed seed gate, not owning home |
| `Agents-of-Abyss` | federation law, method doctrine, cross-repo ownership | **AGENTS.md / repo guidance** | references | keep central doctrine as guidance, not as a giant operational skill | center governs, does not execute everything |
| `aoa-kag` | derived graph / bounded substrate | **MCP/resources** | support surface only | keep it derived and queryable; avoid making it a semantic sovereignty layer in Codex | useful as context provider |

---

## Design law

### 1. Workflow goes to skills
Use a skill when the slice is:
- repeatable
- bounded
- instruction-rich
- optionally script-assisted
- discoverable by description

Examples:
- `aoa-session-donor-harvest`
- `aoa-checkpoint-closeout-bridge`
- “plant reviewed seed into owner repo”
- “run bounded eval bundle and summarize failures”

### 2. Role goes to subagents
Use a subagent when the slice is:
- a role with stable posture
- better isolated from the parent context
- likely to use different tools or models
- parallelizable or specialization-heavy

Examples:
- `diagnostician`
- `harvest-reviewer`
- `evidence-mapper`
- `playbook-conductor`
- `docs-researcher`

### 3. Live context goes to MCP
Use MCP when the slice is:
- external to the local repo
- frequently changing
- better queried than copied
- a tool/resource/prompt service boundary

Examples:
- `aoa-memo` recall surfaces
- `aoa-stats` summaries
- `Dionysus` seed registry and wave state
- docs servers
- issue trackers
- provenance lookups

### 4. Repo law goes to AGENTS.md
Use `AGENTS.md` for:
- build/test/validate order
- file priority and routing hints
- review posture
- guardrails
- local conventions
- “when this happens, consult that repo/surface first”

---

## Recommended generation targets

### For `aoa-skills`
- keep canonical authoring in `skills/*`
- generate Codex-facing export in `.agents/skills/*`
- preserve `name` and `description` quality for implicit discovery
- keep local wrapper/runtime adapters backward-compatible around the export root

### For `aoa-agents`
- add a generator that emits `.codex/agents/*.toml`
- map agent profile fields into:
  - `name`
  - `description`
  - `developer_instructions`
  - `model`
  - `model_reasoning_effort`
  - `sandbox_mode`
  - optional `mcp_servers`
  - optional `skills.config`

### For repo roots
- ensure each relevant repo has a tight `AGENTS.md`
- use nested `AGENTS.md` only where directory-specific law truly differs
- keep repo law short and executable

### For memory / stats / seeds
- prefer MCP servers/resources over giant prompt bundles
- add narrow skills only for recurring workflows that consume those resources

---

## What not to do
- do **not** turn every repo into a skills mirror
- do **not** make `aoa-routing` the hidden sovereign brain of Codex behavior
- do **not** let `aoa-sdk` become the owner of meaning that belongs to source repos
- do **not** stuff live memory/state into static `SKILL.md`
- do **not** use subagents where a plain skill is enough
- do **not** use skills where a plain `AGENTS.md` rule would do

---

## Practical wave order

### Wave A
- tighten `AGENTS.md` across key repos
- keep `aoa-skills` export clean and validated
- define the first thin Codex contract for `aoa-sdk` usage

### Wave B
- generate `.codex/agents/*.toml` from `aoa-agents`
- pilot 2 to 4 subagents tied to real AoA roles
- let those subagents consume selected skills

### Wave C
- expose `aoa-memo`, `aoa-stats`, and `Dionysus` through MCP/resources
- keep the interfaces narrow and evidence-linked

### Wave D
- add launcher skills for playbooks and eval bundles
- only package as plugins when distribution across teams matters

---

## Working sentence
AoA should meet Codex through **four complementary bridges**:
- **skills** for workflows
- **subagents** for roles
- **MCP** for live context and tools
- **AGENTS.md** for local law

Everything else is adapter craft around that quartet.
