# Patch notes: Downstream Projection Pack

## Merge order

1. Add `aoa-sdk/src/aoa_sdk/recurrence/projections.py`.
2. Merge the appended projection models into `models.py`.
3. Merge API methods into `RecurrenceAPI` before `wiring_plan`.
4. Merge IO persistence helpers.
5. Add the `project` CLI sub-app and commands.
6. Add schemas, examples, docs, and tests.
7. Copy owner-facing docs/schemas/examples into `aoa-routing`, `aoa-stats`, and `aoa-kag`.

## Expected commands

```bash
python -m py_compile \
  src/aoa_sdk/recurrence/models.py \
  src/aoa_sdk/recurrence/projections.py \
  src/aoa_sdk/recurrence/api.py \
  src/aoa_sdk/recurrence/io.py \
  src/aoa_sdk/recurrence/cli.py

python -m pytest -q tests/test_recurrence_downstream_projection_seed.py
```

## Notes for Codex

The current seed includes full versions of `models.py`, `api.py`, `io.py`, and `cli.py` based on the prior Review Decision Closure seed. If the live repo has additional edits, merge structurally rather than replacing blindly.

The output surface paths are intentionally proposed, not automatically committed to downstream repos:

- `aoa-routing/generated/recurrence_owner_hints.min.json`
- `aoa-routing/generated/recurrence_return_hints.min.json`
- `aoa-routing/generated/recurrence_gap_hints.min.json`
- `aoa-stats/generated/recurrence_coverage_summary.min.json`
- `aoa-stats/generated/recurrence_pressure_summary.min.json`
- `aoa-kag/generated/recurrence_regrounding_pack.min.json`
- `aoa-kag/generated/donor_refresh_obligations.min.json`
