# Codex landing brief: Recurrence Downstream Projection Pack

Goal: let recurrence publish narrow downstream packets without transferring authority.

## Landing checklist

1. Verify hardening and graph closure still pass.
2. Merge `projections.py` and projection model inserts.
3. Wire API/IO/CLI.
4. Run seed test.
5. Build a dry projection bundle from latest available recurrence artifacts.
6. Inspect guard report. Do not publish downstream generated surfaces if guard report has `blocked` or `critical` violations.

## Thinness laws

- Routing receives hints, not recurrence graph authority.
- Stats receives counts, not verdicts.
- KAG receives regrounding guidance, not source truth.
- Owner repos keep decisions, status changes, and canon.

## Suggested smoke command

```bash
aoa recur project build \
  --root /srv/workspace \
  --plan .aoa/recurrence/plans/latest.json \
  --doctor .aoa/recurrence/doctor/latest.json \
  --handoff .aoa/recurrence/handoffs/latest.json \
  --beacon .aoa/recurrence/beacons/latest.json \
  --review-queue .aoa/recurrence/review-queues/latest.json \
  --json
```

If any input artifact is missing, run the command with the available subset first. Missing inputs should produce a small empty projection, not a crash.
