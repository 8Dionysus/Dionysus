# AoA Recurrence Downstream Projection Pack Seed

This delta seed adds the fifth recurrence wave: narrow downstream projections for `aoa-routing`, `aoa-stats`, and `aoa-kag`.

It does **not** move recurrence authority downstream. It builds bounded packets:

- routing: owner, return, and gap hints only;
- stats: derived observability counts only;
- KAG: regrounding, donor-refresh, and source-strength hints only;
- guards: authority-transfer checks before publishing projection surfaces.

## Primary landing command

```bash
python scripts/build_downstream_recurrence_projections.py \
  --workspace-root /srv/workspace \
  --plan .aoa/recurrence/plans/latest.json \
  --doctor .aoa/recurrence/doctor/latest.json \
  --handoff .aoa/recurrence/handoffs/latest.json \
  --beacon .aoa/recurrence/beacons/latest.json \
  --review-queue .aoa/recurrence/review-queues/latest.json \
  --decision-report .aoa/recurrence/review-decision-close/latest.json \
  --json
```

Equivalent CLI once wired:

```bash
aoa recur project build --root /srv/workspace --json
```

## Files

- `aoa-sdk/src/aoa_sdk/recurrence/projections.py`
- updated `models.py`, `api.py`, `io.py`, `cli.py`
- `aoa-sdk/scripts/build_downstream_recurrence_projections.py`
- projection schemas and examples
- downstream owner notes for `aoa-routing`, `aoa-stats`, and `aoa-kag`
- `aoa-sdk/tests/test_recurrence_downstream_projection_seed.py`

## Boundary

If a projection starts acting like source truth, proof authority, routing authority, canon mutation, or a full graph export, the guard report should block publication. The downstream packets are lanterns, not thrones.
