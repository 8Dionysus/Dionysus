# Agon Wave IX Seed: Sealed Commit and State Packets

This seed lands Wave IX across `Agents-of-Abyss` and `aoa-sdk`.

## Plant order

```text
1. Agents-of-Abyss
2. aoa-sdk
```

## What this wave does

Wave IX fills the reserved `sealed_commit_slot` and `reveal_slot` from Wave VIII with a pre-protocol state packet grammar.

It defines:

- packet envelope law;
- sealed commit model;
- commit receipt model;
- reveal request / reveal view model;
- move declaration packets;
- evidence, contradiction, summon, witness, revision and inscription candidate packets;
- SDK helper candidates for future typed tooling.

## What this wave does not do

It does not create live arena sessions, execute moves, issue verdicts, write durable scars, schedule retention, mutate rank, promote anything to `Tree-of-Sophia`, or install hidden scheduler behavior.

## Validation commands

In `Agents-of-Abyss`:

```bash
python scripts/build_agon_state_packet_registry.py --check
python scripts/validate_agon_state_packets.py
python -m pytest -q tests/test_agon_state_packets.py
```

In `aoa-sdk`:

```bash
python scripts/build_agon_sdk_state_packet_bindings.py --check
python scripts/validate_agon_sdk_state_packet_bindings.py
python -m pytest -q tests/test_agon_sdk_state_packet_bindings.py
```

## Next wave

Wave X should harden contradiction, closure and summon law over these packet surfaces. It must still avoid live runtime authority unless an explicit runtime wave has landed.
