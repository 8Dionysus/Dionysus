# Agon Wave IX: Sealed Commit and State Packets

This seed gives the sleeping arena its first packet grammar.

The arena still does not wake. The packet layer is pre-protocol, reviewable and non-runtime.

The important shift is this: contestants can no longer be designed as free-floating voices. Future arena sessions will be able to require pre-reveal commitments, witness receipts, reveal checks, explicit move declarations and revision statements.
