# Codex Landing Brief

Land the `Agents-of-Abyss` part first. Run its builder, validator and tests.

Then land the `aoa-sdk` part. Run its builder, validator and tests.

Do not wire these packet helpers into live CLI commands unless a later owner-reviewed runtime wave explicitly asks for it.
