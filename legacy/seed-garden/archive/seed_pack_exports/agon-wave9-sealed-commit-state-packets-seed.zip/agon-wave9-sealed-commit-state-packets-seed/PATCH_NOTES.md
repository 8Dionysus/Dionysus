# Patch Notes

- Adds center-owned Agon state packet model surfaces in `Agents-of-Abyss`.
- Adds requested-only SDK helper candidates in `aoa-sdk`.
- Adds recurrence manifests for state packet surfaces.
- Preserves all stop-lines: no live sessions, no verdicts, no scars, no retention, no rank mutation.
