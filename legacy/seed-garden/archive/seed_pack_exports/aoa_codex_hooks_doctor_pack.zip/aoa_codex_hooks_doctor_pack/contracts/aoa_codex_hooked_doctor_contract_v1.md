# AoA Codex hooked-doctor contract v1

## Purpose

Bind AoA's Codex control-plane seams to deterministic lifecycle hooks so the workspace can self-check at session start, prompt submission, and turn stop without turning hooks into a new sovereign layer.

## Supported Codex events

- `SessionStart` with matcher `startup|resume`
- `UserPromptSubmit`
- `Stop`

## Boundaries

- Read-mostly. Hook scripts may write only under `generated/codex/hooks/`.
- No network access.
- No automatic edits to `.codex/config.toml`, `AGENTS.md`, `.agents/skills`, plugins, MCP configs, or owner repos.
- No blocking on `UserPromptSubmit` by default.
- No `Stop` continuation by default. Autocontinue is optional and explicit.
- Fail open when signals are missing or the workspace is only partially installed.

## Inputs

- Codex hook JSON payload on `stdin`
- Workspace root anchored by `AOA_WORKSPACE_ROOT`
- Project-scoped `.codex/config.toml`
- Project-scoped `.codex/hooks.json`
- Optional latest convergence report in `generated/codex/aoa_codex_convergence_report.json`

## Outputs

### SessionStart

- `systemMessage` warning if critical hook surfaces are missing
- `additionalContext` reminding Codex about the AoA crosswalk:
  - repo law → `AGENTS.md`
  - reusable workflow → skills
  - live / derived context → MCP
  - role delegation → subagents
- event log under `generated/codex/hooks/session_start_*.json`

### UserPromptSubmit

- `additionalContext` only when the prompt touches Codex-control-plane topics such as MCP, skills, plugins, subagents, hooks, `.codex`, or `.agents`
- event log under `generated/codex/hooks/user_prompt_submit_*.json`

### Stop

- writes stamped and latest JSON / Markdown reports under `generated/codex/hooks/`
- emits a `systemMessage` when critical errors or warnings are present
- optional `decision: "block"` continuation only when `--autocontinue-critical` is enabled and `stop_hook_active` is false

## Required surfaces

- `AOA_WORKSPACE_ROOT`
- `.codex/config.toml` with `features.codex_hooks = true`
- `project_root_markers` containing `AOA_WORKSPACE_ROOT`
- `.codex/hooks.json`
- `.codex/hooks/aoa_session_start.py`
- `.codex/hooks/aoa_user_prompt_submit.py`
- `.codex/hooks/aoa_stop_doctor.py`
- `src/aoa_codex_hooks/`

## Diagnostics checked by the manual doctor

- workspace marker
- project config presence and parseability
- `features.codex_hooks`
- `project_root_markers`
- placeholder paths left in `hooks.json`
- missing hook scripts
- overlap with `~/.codex/hooks.json`
- generated hook report directory
- optional convergence report state

## Failure posture

- Missing or partial installation downgrades to warnings / system messages.
- Hook reports are evidence, not authority.
- Hook reports never override owner-repo truth.
