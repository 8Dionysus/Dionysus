#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import shlex
import shutil
from pathlib import Path

HOOK_TIMEOUT_SECONDS = 20
HOOK_DEFINITIONS = {
    "SessionStart": [
        {
            "matcher": "startup|resume",
            "hooks": [
                {
                    "type": "command",
                    "command": "{python} {workspace}/.codex/hooks/aoa_session_start.py",
                    "statusMessage": "AoA session-start seam",
                    "timeout": HOOK_TIMEOUT_SECONDS,
                }
            ],
        }
    ],
    "UserPromptSubmit": [
        {
            "hooks": [
                {
                    "type": "command",
                    "command": "{python} {workspace}/.codex/hooks/aoa_user_prompt_submit.py",
                    "statusMessage": "AoA prompt crosswalk",
                    "timeout": HOOK_TIMEOUT_SECONDS,
                }
            ],
        }
    ],
    "Stop": [
        {
            "hooks": [
                {
                    "type": "command",
                    "command": "{python} {workspace}/.codex/hooks/aoa_stop_doctor.py",
                    "statusMessage": "AoA stop doctor",
                    "timeout": HOOK_TIMEOUT_SECONDS,
                }
            ],
        }
    ],
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Install AoA Codex hooks into a workspace.")
    parser.add_argument("--workspace-root", required=True, help="Target AoA workspace root.")
    parser.add_argument(
        "--pack-root",
        default=None,
        help="Path to the unpacked aoa_codex_hooks_doctor_pack. Defaults to script grandparent.",
    )
    parser.add_argument(
        "--python-bin",
        default="python3",
        help="Python executable used in rendered hook commands.",
    )
    parser.add_argument(
        "--write-config-snippet",
        action="store_true",
        help="Also write .codex/config.hooks.snippet.toml next to the active config layer.",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Allow overwriting an existing .codex/hooks.json.",
    )
    return parser.parse_args()


def render_hooks_json(workspace_root: Path, python_bin: str) -> dict:
    def fmt(command: str) -> str:
        return command.format(
            python=shlex.quote(python_bin),
            workspace=shlex.quote(str(workspace_root.resolve())),
        )

    hooks: dict[str, list[dict]] = {}
    for event_name, groups in HOOK_DEFINITIONS.items():
        rendered_groups = []
        for group in groups:
            rendered = dict(group)
            rendered_hooks = []
            for hook in group["hooks"]:
                hook_payload = dict(hook)
                hook_payload["command"] = fmt(hook_payload["command"])
                rendered_hooks.append(hook_payload)
            rendered["hooks"] = rendered_hooks
            rendered_groups.append(rendered)
        hooks[event_name] = rendered_groups
    return {"hooks": hooks}


def copy_tree(src: Path, dst: Path) -> None:
    for path in sorted(src.rglob("*")):
        relative = path.relative_to(src)
        target = dst / relative
        if path.is_dir():
            target.mkdir(parents=True, exist_ok=True)
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)


def main() -> int:
    args = parse_args()
    pack_root = (
        Path(args.pack_root).expanduser().resolve()
        if args.pack_root
        else Path(__file__).expanduser().resolve().parents[1]
    )
    workspace_root = Path(args.workspace_root).expanduser().resolve()
    overlay_root = pack_root / "workspace-overlay"

    if not overlay_root.exists():
        raise SystemExit(f"overlay root not found: {overlay_root}")

    copy_tree(overlay_root / ".codex" / "hooks", workspace_root / ".codex" / "hooks")
    copy_tree(overlay_root / "src", workspace_root / "src")
    copy_tree(overlay_root / "scripts", workspace_root / "scripts")

    hooks_json_path = workspace_root / ".codex" / "hooks.json"
    if hooks_json_path.exists() and not args.overwrite:
        raise SystemExit(
            f"{hooks_json_path} already exists. Re-run with --overwrite or merge manually."
        )

    hooks_payload = render_hooks_json(workspace_root, args.python_bin)
    hooks_json_path.parent.mkdir(parents=True, exist_ok=True)
    hooks_json_path.write_text(json.dumps(hooks_payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    if args.write_config_snippet:
        snippet_src = pack_root / "templates" / "workspace-root" / ".codex" / "config.hooks.snippet.toml"
        snippet_dst = workspace_root / ".codex" / "config.hooks.snippet.toml"
        snippet_dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(snippet_src, snippet_dst)

    print(json.dumps({
        "workspace_root": str(workspace_root),
        "hooks_json": str(hooks_json_path),
        "copied": [
            str(workspace_root / ".codex" / "hooks"),
            str(workspace_root / "src" / "aoa_codex_hooks"),
            str(workspace_root / "scripts"),
        ],
    }, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
