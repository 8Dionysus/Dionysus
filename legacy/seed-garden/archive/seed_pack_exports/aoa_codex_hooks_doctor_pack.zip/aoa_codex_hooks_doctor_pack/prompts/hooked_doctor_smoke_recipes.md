# Hooked-doctor smoke recipes

## Session-start smoke

Start Codex from the workspace root and watch for a session-start warning or reminder from the AoA hook seam.

## Prompt-crosswalk smoke

Ask something like:

> wire MCP and subagents for this workspace

Expected: the `UserPromptSubmit` hook injects extra developer context about AoA's Codex crosswalk.

## Stop-report smoke

End a turn after touching `.codex`, skills wiring, MCP config, or subagent surfaces.

Expected:

- a fresh report appears under `generated/codex/hooks/`
- the latest report mentions ready / warnings / errors
- Codex may show a hook doctor warning if the seam is partial

## Manual doctor smoke

Run:

```bash
python3 scripts/aoa_codex_hooks_doctor.py --workspace-root . --format markdown
```

Expected: a compact surface report with marker, config, hook feature flag, hooks.json, scripts, and overlap diagnostics.
