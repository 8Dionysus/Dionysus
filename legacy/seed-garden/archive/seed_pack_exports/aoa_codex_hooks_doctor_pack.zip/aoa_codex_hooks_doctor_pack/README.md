# AoA Codex hooks doctor pack

This pack adds a narrow lifecycle seam around the AoA Codex control plane.

It uses Codex hooks for three moments:

- session start
- user prompt submit
- turn stop

The seam stays small on purpose:

- it writes reports and event logs under `generated/codex/hooks/`
- it does **not** auto-edit your Codex config
- it does **not** become a new route authority
- `Stop` continuation is available but **off** by default

## Why this wave

Codex hooks now have a documented lifecycle surface. They are enabled with `[features].codex_hooks = true`, discovered from `hooks.json` next to active config layers, and multiple matching hook files all run together.

This pack also respects AoA's sibling-workspace topology. The workspace root is anchored with `AOA_WORKSPACE_ROOT`, and the config snippet keeps that marker inside `project_root_markers` so Codex can discover the intended root above individual repo `.git` boundaries.

## Pack contents

- `contracts/aoa_codex_hooked_doctor_contract_v1.md`
- `tools/install_aoa_codex_hooks.py`
- `templates/workspace-root/.codex/config.hooks.snippet.toml`
- `templates/workspace-root/.codex/hooks.json`
- `workspace-overlay/.codex/hooks/*.py`
- `workspace-overlay/scripts/aoa_codex_hooks_doctor.py`
- `workspace-overlay/src/aoa_codex_hooks/*.py`
- `workspace-overlay/tests/test_aoa_codex_hooks.py`
- `prompts/hooked_doctor_smoke_recipes.md`

## Installation shape

1. Unpack this pack somewhere inside or next to the AoA workspace.
2. Copy or install the overlay into the workspace root.
3. Merge the config snippet into the workspace `.codex/config.toml`.
4. Render `hooks.json` with absolute workspace-root paths.
5. Trust the workspace project in Codex.
6. Start Codex from the workspace root or through your workspace launcher.

## Fast path

```bash
python3 tools/install_aoa_codex_hooks.py \
  --workspace-root /path/to/AoA-workspace \
  --write-config-snippet
```

This copies the overlay and writes a rendered `.codex/hooks.json`. It does **not** merge the config snippet automatically.

## Manual validation

```bash
python3 scripts/aoa_codex_hooks_doctor.py --workspace-root . --write-report
```

Expected report location:

- `generated/codex/hooks/aoa_codex_hooks_manual_report.json`
- `generated/codex/hooks/aoa_codex_hooks_manual_report.md`

## Notes worth keeping in your teeth

- Hooks are experimental and currently disabled on Windows.
- If `~/.codex/hooks.json` also exists, both user and project hooks run.
- `Stop` can continue the conversation, but this pack leaves that off unless you explicitly enable `--autocontinue-critical`.

## Recommended landing order

1. Land the earlier convergence pack.
2. Land this hooks pack.
3. Verify `/mcp`, `/plugins`, `/skills`, and subagents still look sane.
4. Only then consider optional hook guardrails or stop-continuation.
