#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
from pathlib import Path

WORKSPACE_ROOT = Path(__file__).expanduser().resolve().parents[2]
SRC_DIR = WORKSPACE_ROOT / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from aoa_codex_hooks.events import handle_user_prompt_submit, parse_event


def main() -> int:
    event = parse_event(sys.stdin.read())
    payload = handle_user_prompt_submit(event, WORKSPACE_ROOT)
    if payload:
        print(json.dumps(payload, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
