from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / "repo-overlay/aoa-agents/scripts/build_codex_subagents_v2.py"
VALIDATE = ROOT / "repo-overlay/aoa-agents/scripts/validate_codex_subagents.py"
FIXTURES = ROOT / "tests/fixtures/profiles"
WIRING = ROOT / "repo-overlay/aoa-agents/config/codex_subagent_wiring.v2.json"


def run(*args: str, cwd: Path | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, *args],
        text=True,
        capture_output=True,
        cwd=cwd or ROOT,
        check=False,
    )


def test_generator_emits_five_agents(tmp_path: Path) -> None:
    agents_dir = tmp_path / "agents"
    config_snippet = tmp_path / "config.subagents.generated.toml"
    manifest = tmp_path / "projection_manifest.json"
    result = run(
        str(BUILD),
        "--profiles-root",
        str(FIXTURES),
        "--wiring",
        str(WIRING),
        "--output-dir",
        str(agents_dir),
        "--emit-config-snippet",
        str(config_snippet),
        "--emit-manifest",
        str(manifest),
    )
    assert result.returncode == 0, result.stderr
    emitted = sorted(p.name for p in agents_dir.glob("*.toml"))
    assert emitted == [
        "architect.toml",
        "coder.toml",
        "evaluator.toml",
        "memory-keeper.toml",
        "reviewer.toml",
    ]


def test_coder_is_workspace_write(tmp_path: Path) -> None:
    agents_dir = tmp_path / "agents"
    result = run(
        str(BUILD),
        "--profiles-root",
        str(FIXTURES),
        "--wiring",
        str(WIRING),
        "--output-dir",
        str(agents_dir),
        "--emit-config-snippet",
        str(tmp_path / "config.toml"),
        "--emit-manifest",
        str(tmp_path / "manifest.json"),
    )
    assert result.returncode == 0, result.stderr
    coder = (agents_dir / "coder.toml").read_text(encoding="utf-8")
    assert 'sandbox_mode = "workspace-write"' in coder
    architect = (agents_dir / "architect.toml").read_text(encoding="utf-8")
    assert 'sandbox_mode = "read-only"' in architect


def test_config_snippet_uses_config_relative_paths(tmp_path: Path) -> None:
    result = run(
        str(BUILD),
        "--profiles-root",
        str(FIXTURES),
        "--wiring",
        str(WIRING),
        "--output-dir",
        str(tmp_path / "agents"),
        "--emit-config-snippet",
        str(tmp_path / "config.subagents.generated.toml"),
        "--emit-manifest",
        str(tmp_path / "manifest.json"),
    )
    assert result.returncode == 0, result.stderr
    config_text = (tmp_path / "config.subagents.generated.toml").read_text(encoding="utf-8")
    assert 'config_file = "agents/architect.toml"' in config_text
    assert ".codex/agents/architect.toml" not in config_text


def test_manifest_links_back_to_source_profiles(tmp_path: Path) -> None:
    manifest = tmp_path / "manifest.json"
    result = run(
        str(BUILD),
        "--profiles-root",
        str(FIXTURES),
        "--wiring",
        str(WIRING),
        "--output-dir",
        str(tmp_path / "agents"),
        "--emit-config-snippet",
        str(tmp_path / "config.toml"),
        "--emit-manifest",
        str(manifest),
    )
    assert result.returncode == 0, result.stderr
    payload = json.loads(manifest.read_text(encoding="utf-8"))
    names = [entry["name"] for entry in payload["generated_agents"]]
    assert "architect" in names
    assert "memory-keeper" in names
    assert all("source_profile" in entry for entry in payload["generated_agents"])


def test_validator_accepts_generated_projection(tmp_path: Path) -> None:
    agents_dir = tmp_path / "agents"
    config_snippet = tmp_path / "config.toml"
    manifest = tmp_path / "manifest.json"
    build = run(
        str(BUILD),
        "--profiles-root",
        str(FIXTURES),
        "--wiring",
        str(WIRING),
        "--output-dir",
        str(agents_dir),
        "--emit-config-snippet",
        str(config_snippet),
        "--emit-manifest",
        str(manifest),
    )
    assert build.returncode == 0, build.stderr
    validate = run(
        str(VALIDATE),
        "--profiles-root",
        str(FIXTURES),
        "--wiring",
        str(WIRING),
        "--agents-dir",
        str(agents_dir),
        "--config-snippet",
        str(config_snippet),
    )
    assert validate.returncode == 0, validate.stderr
