# aoa_subagent_projection_contract_v2

## Purpose

Project `aoa-agents` source-authored role profiles into Codex custom-agent TOML files and a workspace config snippet without allowing the projection layer to become a second source of truth.

## Input surfaces

Primary source surfaces inside `aoa-agents`:

- `profiles/*.profile.json`
- optional `generated/agent_registry.min.json` for sanity checks only
- `config/codex_subagent_wiring.v2.json` for projection-time policy

## Output surfaces

Generated surfaces:

- one Codex custom-agent TOML per active role
- one config snippet that registers those agents in `.codex/config.toml`
- optional projection manifest for review

## Non-goals

This projection does **not**:

- redefine role meaning outside `aoa-agents`
- replace source-authored agent profiles
- embed project-level MCP server definitions into each custom agent file by default
- flatten role posture into skill posture
- widen recursive delegation without explicit operator choice

## Projection rules

### 1. Source-of-truth order

1. `profiles/*.profile.json`
2. optional registry cross-check
3. projection wiring
4. generated `.toml`
5. workspace `.codex/config.toml` registration

If generated TOML drifts from profiles, the profile wins.

### 2. Required fields in each generated custom agent file

Every generated custom agent file must contain:

- `name`
- `description`
- `developer_instructions`

This matches the current Codex custom-agent minimum.

### 3. Optional fields

The generator may include:

- `nickname_candidates`
- `sandbox_mode`
- `model`
- `model_reasoning_effort`

The generator should not duplicate MCP server definitions by default if the parent workspace already provides them.

### 4. Developer instruction composition

`developer_instructions` should be built from profile-authored posture, not freehand invention. It should include:

- role identity
- mission
- owns
- does-not-own boundaries
- preferred skill families
- memory posture and rights summary
- evaluation posture
- handoff rule and triggers
- source surfaces
- MCP affinity guidance when present in projection wiring

### 5. Config snippet responsibilities

The config snippet may set:

- `[agents] max_threads`
- `[agents] max_depth`
- `[agents] job_max_runtime_seconds`
- `[agents.<name>] config_file`
- `[agents.<name>] description`
- `[agents.<name>] nickname_candidates`

The snippet should use config-relative paths such as `agents/architect.toml`, because Codex resolves `agents.<name>.config_file` relative to the config file that declares it.

### 6. Safety and boundedness defaults

Default projection posture:

- keep `agents.max_depth = 1`
- keep most agents `sandbox_mode = "read-only"`
- reserve `sandbox_mode = "workspace-write"` for execution-oriented roles such as `coder`
- inherit parent approvals rather than widening them silently

### 7. Validation expectations

Validation should fail when:

- required custom-agent fields are missing
- agent names are duplicated
- filename and `name` diverge
- config snippet points at a missing file
- config snippet role names and generated role names diverge
- nickname candidates are duplicated within a file
- sandbox posture conflicts with projection wiring

## Recommended AoA mapping

- `architect` → read-only, structure and boundary framing
- `coder` → workspace-write, bounded implementation
- `reviewer` → read-only, risk and review posture
- `evaluator` → read-only, proof and comparison posture
- `memory-keeper` → read-only, provenance and recall hygiene

## Future extensions

Later waves can add:

- plugin packaging for the generated subagents
- optional model-tier mapping from `aoa-agents/model_tiers/*.tier.json`
- optional project-level policy generation for `agents.max_threads`
- optional wiring to repo-local skills subsets
