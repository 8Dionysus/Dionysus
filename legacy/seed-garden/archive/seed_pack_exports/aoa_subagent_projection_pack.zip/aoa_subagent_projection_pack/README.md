# aoa_subagent_projection_pack

This pack projects `aoa-agents` source-authored role profiles into Codex custom-agent TOML files and a matching project config snippet.

## What this wave is for

After the workspace MCP layer, skill↔MCP wiring, and local plugin pack, the next missing Codex surface is **subagents**. This pack turns `aoa-agents/profiles/*.profile.json` into narrow, role-bearing Codex agents without flattening roles into skills.

The pack is designed around the current Codex subagent model:

- project-scoped custom agents live in `.codex/agents/`
- each custom agent file must define `name`, `description`, and `developer_instructions`
- optional fields such as `nickname_candidates`, `model`, `model_reasoning_effort`, `sandbox_mode`, `mcp_servers`, and `skills.config` can be included in the custom agent file
- project configuration can register named agents with `agents.<name>.config_file`, `agents.<name>.description`, and `agents.<name>.nickname_candidates`
- `agents.max_threads` defaults to 6 and `agents.max_depth` defaults to 1 unless you override them

This pack intentionally keeps MCP server definitions in the **workspace project config** rather than duplicating them inside every generated agent file. The generated agents instead encode MCP **affinity** in their instructions, so they can inherit the parent session's live MCP surface cleanly.

## Contents

- `contracts/aoa_subagent_projection_contract_v2.md`
- `repo-overlay/aoa-agents/config/codex_subagent_wiring.v2.json`
- `repo-overlay/aoa-agents/scripts/build_codex_subagents_v2.py`
- `repo-overlay/aoa-agents/scripts/validate_codex_subagents.py`
- `repo-overlay/aoa-agents/examples/generated/agents/*.toml`
- `templates/workspace-root/.codex/config.subagents.snippet.toml`
- `templates/workspace-root/.codex/agents/README.md`
- `prompts/subagent_orchestration_recipes.md`
- `tests/`

## Suggested install flow

1. Drop `repo-overlay/aoa-agents/*` into `aoa-agents`.
2. Run the generator:

```bash
python scripts/build_codex_subagents_v2.py   --profiles-root profiles   --wiring config/codex_subagent_wiring.v2.json   --output-dir generated/codex_agents/agents   --emit-config-snippet generated/codex_agents/config.subagents.generated.toml
```

3. Validate the generated projection:

```bash
python scripts/validate_codex_subagents.py   --profiles-root profiles   --wiring config/codex_subagent_wiring.v2.json   --agents-dir generated/codex_agents/agents   --config-snippet generated/codex_agents/config.subagents.generated.toml
```

4. Copy the generated `.toml` files into your workspace `.codex/agents/`.
5. Merge the snippet into your workspace `.codex/config.toml`.
6. Start Codex from the trusted workspace root and confirm the agents show up.

## Why this shape

`aoa-agents` already says that an agent is not a skill, and that the repository owns role contracts, boundaries, preferred skill families, memory posture, evaluation posture, and handoff rules. This pack preserves that separation by projecting role contracts into Codex custom agents instead of turning them into more skills.

## What it does not do

- It does not create or install MCP servers.
- It does not bundle the agents as a plugin.
- It does not hard-pin models by default.
- It does not widen `agents.max_depth` beyond the Codex default posture.

Those can be added later, but this wave keeps the role surface crisp and reviewable.
