#!/usr/bin/env python3
"""Validate generated Codex subagent projection surfaces."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, List, Mapping, Sequence
import tomllib


REQUIRED_AGENT_KEYS = ("name", "description", "developer_instructions")
VALID_SANDBOX = {"read-only", "workspace-write", "danger-full-access"}


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def read_toml(path: Path) -> Mapping[str, Any]:
    with path.open("rb") as handle:
        return tomllib.load(handle)


def load_profiles(profiles_root: Path) -> Dict[str, Mapping[str, Any]]:
    profiles: Dict[str, Mapping[str, Any]] = {}
    for path in sorted(profiles_root.glob("*.profile.json")):
        profile = read_json(path)
        if str(profile.get("status", "active")) != "active":
            continue
        name = str(profile.get("name", "")).strip()
        if not name:
            raise ValueError(f"Active profile missing name: {path}")
        profiles[name] = profile
    return profiles


def validate_agent_file(path: Path, expected_sandbox: str | None) -> List[str]:
    errors: List[str] = []
    try:
        payload = read_toml(path)
    except Exception as exc:  # pragma: no cover
        return [f"{path}: failed to parse TOML: {exc}"]

    for key in REQUIRED_AGENT_KEYS:
        if key not in payload:
            errors.append(f"{path}: missing required key {key!r}")

    name = str(payload.get("name", "")).strip()
    if name and path.stem != name:
        errors.append(f"{path}: filename stem does not match agent name {name!r}")

    nicknames = payload.get("nickname_candidates")
    if nicknames is not None:
        if not isinstance(nicknames, list) or not nicknames:
            errors.append(f"{path}: nickname_candidates must be a non-empty list when present")
        elif len(nicknames) != len(set(nicknames)):
            errors.append(f"{path}: nickname_candidates contains duplicates")

    sandbox_mode = payload.get("sandbox_mode")
    if sandbox_mode is not None and sandbox_mode not in VALID_SANDBOX:
        errors.append(f"{path}: invalid sandbox_mode {sandbox_mode!r}")
    if expected_sandbox and sandbox_mode != expected_sandbox:
        errors.append(f"{path}: sandbox_mode {sandbox_mode!r} != expected {expected_sandbox!r}")

    instructions = str(payload.get("developer_instructions", ""))
    if instructions and "General discipline" not in instructions:
        errors.append(f"{path}: developer_instructions missing 'General discipline' section")

    return errors


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profiles-root", type=Path, required=True)
    parser.add_argument("--wiring", type=Path, required=True)
    parser.add_argument("--agents-dir", type=Path, required=True)
    parser.add_argument("--config-snippet", type=Path, required=True)
    args = parser.parse_args()

    profiles = load_profiles(args.profiles_root)
    wiring = read_json(args.wiring)
    roles_wiring = wiring.get("roles", {})

    errors: List[str] = []
    agent_files = sorted(args.agents_dir.glob("*.toml"))
    if not agent_files:
        errors.append(f"{args.agents_dir}: no agent files found")

    seen_names: set[str] = set()
    for agent_path in agent_files:
        payload = read_toml(agent_path)
        name = str(payload.get("name", "")).strip()
        role_wiring = roles_wiring.get(name, {})
        errors.extend(validate_agent_file(agent_path, role_wiring.get("sandbox_mode")))
        if name in seen_names:
            errors.append(f"{agent_path}: duplicate agent name {name!r}")
        seen_names.add(name)
        if name not in profiles:
            errors.append(f"{agent_path}: no matching active profile named {name!r}")

    try:
        config = read_toml(args.config_snippet)
    except Exception as exc:  # pragma: no cover
        errors.append(f"{args.config_snippet}: failed to parse TOML: {exc}")
        config = {}

    agents_table = config.get("agents", {})
    if not isinstance(agents_table, dict):
        errors.append(f"{args.config_snippet}: missing [agents] table")
        agents_table = {}

    for key in ("max_threads", "max_depth", "job_max_runtime_seconds"):
        if key not in agents_table:
            errors.append(f"{args.config_snippet}: [agents] missing {key}")

    for name in profiles:
        entry = agents_table.get(name)
        if entry is None:
            errors.append(f"{args.config_snippet}: missing [agents.{name}] entry")
            continue
        if not isinstance(entry, dict):
            errors.append(f"{args.config_snippet}: [agents.{name}] must be a table")
            continue
        config_file = entry.get("config_file")
        if not isinstance(config_file, str):
            errors.append(f"{args.config_snippet}: [agents.{name}] missing config_file")
        else:
            resolved = args.config_snippet.parent / config_file
            # support validating snippets outside final .codex placement
            fallback = args.agents_dir / f"{name}.toml"
            if not resolved.exists() and not fallback.exists():
                errors.append(f"{args.config_snippet}: config_file for {name!r} points at missing file {config_file!r}")

    if seen_names != set(profiles):
        missing = sorted(set(profiles) - seen_names)
        extra = sorted(seen_names - set(profiles))
        if missing:
            errors.append(f"Generated agents missing active profiles: {', '.join(missing)}")
        if extra:
            errors.append(f"Generated agents without matching profiles: {', '.join(extra)}")

    if errors:
        raise SystemExit("Validation failed:\n- " + "\n- ".join(errors))

    print("Codex subagent projection surfaces are valid.")


if __name__ == "__main__":
    main()
