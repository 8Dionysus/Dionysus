#!/usr/bin/env python3
"""Build Codex custom-agent TOML files from aoa-agents profiles."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, MutableMapping, Sequence


DEFAULT_WIRING: Dict[str, Any] = {
    "version": 2,
    "workspace_defaults": {
        "agents_max_threads": 4,
        "agents_max_depth": 1,
        "agents_job_max_runtime_seconds": 1800,
    },
    "roles": {
        "architect": {
            "sandbox_mode": "read-only",
            "nickname_candidates": ["Atlas", "Lattice", "Spine"],
            "mcp_affinity": ["aoa_workspace", "aoa_stats"],
            "description_prefix": "AoA architect.",
            "style_notes": [
                "Frame structure before proposing execution.",
                "Escalate cleanly when another owning layer should take over.",
            ],
        },
        "coder": {
            "sandbox_mode": "workspace-write",
            "nickname_candidates": ["Forge", "Rivet", "Patch"],
            "mcp_affinity": ["aoa_workspace"],
            "description_prefix": "AoA coder.",
            "style_notes": [
                "Implement bounded changes with verification.",
                "Do not broaden scope beyond the requested slice.",
            ],
        },
        "reviewer": {
            "sandbox_mode": "read-only",
            "nickname_candidates": ["Sentinel", "Lens", "Check"],
            "mcp_affinity": ["aoa_workspace", "aoa_stats"],
            "description_prefix": "AoA reviewer.",
            "style_notes": [
                "Lead with concrete risks and boundary drift.",
                "Prefer evidence over style-only commentary.",
            ],
        },
        "evaluator": {
            "sandbox_mode": "read-only",
            "nickname_candidates": ["Gauge", "Prism", "Delta"],
            "mcp_affinity": ["aoa_workspace", "aoa_stats"],
            "description_prefix": "AoA evaluator.",
            "style_notes": [
                "Apply bounded proof discipline.",
                "Distinguish observation, comparison, and verdict.",
            ],
        },
        "memory-keeper": {
            "sandbox_mode": "read-only",
            "nickname_candidates": ["Archive", "Ledger", "Mneme"],
            "mcp_affinity": ["aoa_workspace", "aoa_stats", "dionysus"],
            "description_prefix": "AoA memory-keeper.",
            "style_notes": [
                "Preserve provenance and recall hygiene.",
                "Do not collapse memory hints into final source-of-truth claims.",
            ],
        },
    },
}


def _read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def _deep_merge(base: MutableMapping[str, Any], override: Mapping[str, Any]) -> MutableMapping[str, Any]:
    for key, value in override.items():
        if isinstance(value, Mapping) and isinstance(base.get(key), MutableMapping):
            _deep_merge(base[key], value)
        else:
            base[key] = value
    return base


def load_wiring(path: Path | None) -> Dict[str, Any]:
    wiring = json.loads(json.dumps(DEFAULT_WIRING))
    if path is None:
        return wiring
    user = _read_json(path)
    if not isinstance(user, Mapping):
        raise ValueError(f"Wiring file must contain an object: {path}")
    return dict(_deep_merge(wiring, user))


def slugify(value: str) -> str:
    return value.strip().lower().replace(" ", "-").replace("_", "-")


def normalize_role_key(profile: Mapping[str, Any]) -> str:
    name = str(profile.get("name", "")).strip()
    role = str(profile.get("role", "")).strip()
    for candidate in (name, role):
        if candidate in DEFAULT_WIRING["roles"]:
            return candidate
    # fallback from role memory_keeper -> memory-keeper
    role_slug = slugify(role)
    if role_slug in DEFAULT_WIRING["roles"]:
        return role_slug
    name_slug = slugify(name)
    if name_slug in DEFAULT_WIRING["roles"]:
        return name_slug
    return name_slug or role_slug


def iter_profiles(profiles_root: Path) -> Iterable[Path]:
    return sorted(profiles_root.glob("*.profile.json"))


def summarize_memory_rights(memory_rights: Mapping[str, Any] | None) -> str:
    if not memory_rights:
        return "No explicit memory rights provided."
    read_bands = ", ".join(memory_rights.get("default_read_bands", [])) or "none"
    write_bands = ", ".join(memory_rights.get("default_write_bands", [])) or "none"
    scopes = ", ".join(memory_rights.get("allowed_recall_scopes", [])) or "none"
    return f"Read bands: {read_bands}. Write bands: {write_bands}. Recall scopes: {scopes}."


def bullets(items: Sequence[str] | None) -> List[str]:
    return [f"- {item}" for item in (items or [])]


def build_developer_instructions(profile: Mapping[str, Any], role_wiring: Mapping[str, Any]) -> str:
    owns = bullets([str(x) for x in profile.get("owns", [])])
    does_not_own = bullets([str(x) for x in profile.get("does_not_own", [])])
    skills = ", ".join(profile.get("preferred_skill_families", [])) or "none listed"
    cohorts = ", ".join(profile.get("preferred_cohort_patterns", [])) or "none listed"
    tiers = ", ".join(profile.get("preferred_tier_ids", [])) or "none listed"
    evaluation_focus = ", ".join(profile.get("evaluation_focus", [])) or "none listed"
    handoff_triggers = bullets([str(x) for x in profile.get("handoff_triggers", [])])
    source_surfaces = bullets([str(x) for x in profile.get("source_surfaces", [])])
    style_notes = bullets([str(x) for x in role_wiring.get("style_notes", [])])
    mcp_affinity = ", ".join(role_wiring.get("mcp_affinity", [])) or "none"
    memory_posture = str(profile.get("memory_posture", "unspecified"))
    memory_rights_summary = summarize_memory_rights(profile.get("memory_rights"))
    evaluation_posture = str(profile.get("evaluation_posture", "unspecified"))
    handoff_rule = str(profile.get("handoff_rule", "unspecified"))
    mission = str(profile.get("mission", profile.get("summary", ""))).strip()

    sections: List[str] = [
        f"You are the AoA {profile['name']} role.",
        "",
        "Mission",
        mission or "Operate within the role contract.",
        "",
        "Owns",
        *(owns or ["- No explicit owns list provided."]),
        "",
        "Does not own",
        *(does_not_own or ["- No explicit boundary exclusions provided."]),
        "",
        "Preferred skill families",
        f"- {skills}",
        "",
        "Preferred cohort patterns",
        f"- {cohorts}",
        "",
        "Preferred tier ids",
        f"- {tiers}",
        "",
        "Memory posture",
        f"- {memory_posture}",
        f"- {memory_rights_summary}",
        "",
        "Evaluation posture",
        f"- {evaluation_posture}",
        f"- Focus: {evaluation_focus}",
        "",
        "Handoff doctrine",
        f"- Rule: {handoff_rule}",
        *(handoff_triggers or ["- No explicit handoff triggers provided."]),
        "",
        "Operating style",
        *(style_notes or ["- Stay narrow and bounded."]),
        "",
        "MCP affinity",
        f"- Prefer these workspace MCP surfaces when they are available in the parent session: {mcp_affinity}.",
        "- Do not invent new external surfaces if the parent session does not provide them.",
        "",
        "Source surfaces",
        *(source_surfaces or ["- No source surfaces listed."]),
        "",
        "General discipline",
        "- Stay within role boundaries.",
        "- Prefer source-authored AoA surfaces over memory or improvisation.",
        "- Use skills when a bounded workflow already exists instead of rewriting it from scratch.",
        "- Escalate or hand off cleanly when another owning layer should take over.",
    ]
    return "\n".join(sections).rstrip() + "\n"


def derive_description(profile: Mapping[str, Any], role_wiring: Mapping[str, Any]) -> str:
    prefix = str(role_wiring.get("description_prefix", "")).strip()
    summary = str(profile.get("summary", "")).strip()
    if prefix and summary:
        return f"{prefix} {summary}"
    return summary or prefix or f"AoA {profile['name']} role."


def render_toml(agent: Mapping[str, Any]) -> str:
    lines: List[str] = [
        f'name = "{agent["name"]}"',
        f'description = "{agent["description"]}"',
    ]
    if agent.get("sandbox_mode"):
        lines.append(f'sandbox_mode = "{agent["sandbox_mode"]}"')
    if agent.get("model"):
        lines.append(f'model = "{agent["model"]}"')
    if agent.get("model_reasoning_effort"):
        lines.append(f'model_reasoning_effort = "{agent["model_reasoning_effort"]}"')
    nicknames = agent.get("nickname_candidates") or []
    if nicknames:
        rendered = ", ".join(f'"{nick}"' for nick in nicknames)
        lines.append(f"nickname_candidates = [{rendered}]")
    lines.extend([
        'developer_instructions = """',
        agent["developer_instructions"].rstrip(),
        '"""',
    ])
    return "\n".join(lines) + "\n"


def render_config_snippet(agents: Sequence[Mapping[str, Any]], workspace_defaults: Mapping[str, Any], config_file_prefix: str = "agents") -> str:
    lines = [
        "[agents]",
        f'max_threads = {int(workspace_defaults.get("agents_max_threads", 4))}',
        f'max_depth = {int(workspace_defaults.get("agents_max_depth", 1))}',
        f'job_max_runtime_seconds = {int(workspace_defaults.get("agents_job_max_runtime_seconds", 1800))}',
        "",
    ]
    for agent in agents:
        lines.append(f'[agents.{agent["name"]}]')
        lines.append(f'description = "{agent["description"]}"')
        lines.append(f'config_file = "{config_file_prefix}/{agent["name"]}.toml"')
        nicknames = agent.get("nickname_candidates") or []
        if nicknames:
            rendered = ", ".join(f'"{nick}"' for nick in nicknames)
            lines.append(f"nickname_candidates = [{rendered}]")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def build_agents(profiles_root: Path, wiring: Mapping[str, Any]) -> List[Dict[str, Any]]:
    agents: List[Dict[str, Any]] = []
    for profile_path in iter_profiles(profiles_root):
        profile = _read_json(profile_path)
        if str(profile.get("status", "active")) != "active":
            continue
        if "name" not in profile:
            raise ValueError(f"Profile missing required 'name': {profile_path}")
        role_key = normalize_role_key(profile)
        role_wiring = dict(wiring.get("roles", {}).get(role_key, {}))
        agent = {
            "name": str(profile["name"]),
            "description": derive_description(profile, role_wiring),
            "sandbox_mode": role_wiring.get("sandbox_mode"),
            "nickname_candidates": role_wiring.get("nickname_candidates", []),
            "model": role_wiring.get("model"),
            "model_reasoning_effort": role_wiring.get("model_reasoning_effort"),
            "developer_instructions": build_developer_instructions(profile, role_wiring),
            "source_profile": str(profile_path),
            "role_key": role_key,
        }
        agents.append(agent)
    return agents


def write_if_changed(path: Path, content: str, check: bool) -> bool:
    if path.exists():
        existing = path.read_text(encoding="utf-8")
        if existing == content:
            return False
        if check:
            raise SystemExit(f"{path} is out of date.")
    if check:
        raise SystemExit(f"{path} is missing.")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return True


def build_manifest(agents: Sequence[Mapping[str, Any]]) -> Dict[str, Any]:
    return {
        "version": 1,
        "generated_agents": [
            {
                "name": agent["name"],
                "description": agent["description"],
                "sandbox_mode": agent.get("sandbox_mode"),
                "source_profile": agent["source_profile"],
                "role_key": agent["role_key"],
            }
            for agent in agents
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profiles-root", type=Path, default=Path("profiles"))
    parser.add_argument("--wiring", type=Path, default=None)
    parser.add_argument("--output-dir", type=Path, default=Path("generated/codex_agents/agents"))
    parser.add_argument("--emit-config-snippet", type=Path, default=Path("generated/codex_agents/config.subagents.generated.toml"))
    parser.add_argument("--emit-manifest", type=Path, default=Path("generated/codex_agents/projection_manifest.json"))
    parser.add_argument("--config-file-prefix", default="agents")
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()

    wiring = load_wiring(args.wiring)
    agents = build_agents(args.profiles_root, wiring)
    if not agents:
        raise SystemExit(f"No active profiles found under {args.profiles_root}")

    changed = False
    for agent in agents:
        output_path = args.output_dir / f'{agent["name"]}.toml'
        changed |= write_if_changed(output_path, render_toml(agent), args.check)

    config_text = render_config_snippet(
        agents,
        wiring.get("workspace_defaults", {}),
        config_file_prefix=args.config_file_prefix,
    )
    changed |= write_if_changed(args.emit_config_snippet, config_text, args.check)

    manifest_text = json.dumps(build_manifest(agents), indent=2, ensure_ascii=False) + "\n"
    changed |= write_if_changed(args.emit_manifest, manifest_text, args.check)

    if not args.check:
        print(f"Generated {len(agents)} Codex custom agents in {args.output_dir}")
        print(f"Config snippet: {args.emit_config_snippet}")
        print(f"Projection manifest: {args.emit_manifest}")
    else:
        print("Codex subagent projection is up to date.")


if __name__ == "__main__":
    main()
