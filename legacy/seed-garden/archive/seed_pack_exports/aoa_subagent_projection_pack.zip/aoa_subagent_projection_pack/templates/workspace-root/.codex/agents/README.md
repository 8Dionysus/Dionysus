# Workspace `.codex/agents/`

Drop the generated AoA custom-agent TOML files here.

Expected layout:

```text
.codex/
  config.toml
  agents/
    architect.toml
    coder.toml
    reviewer.toml
    evaluator.toml
    memory-keeper.toml
```

Why this directory exists:

- Codex loads custom agents from `.codex/agents/` for project-scoped use.
- The project config can register named agents with `agents.<name>.config_file`.
- Relative `config_file` paths resolve from the config file that declares them, so `config_file = "agents/architect.toml"` is the right project-scoped form when declared in `.codex/config.toml`.

Keep project-level MCP server definitions in `.codex/config.toml`. Let these custom agents inherit that parent surface.
