# AoA subagent orchestration recipes

These are prompt patterns for Codex after the generated AoA custom agents are installed.

## 1. Architect → coder → reviewer

Use `architect` first to frame the change, `coder` to implement the bounded slice, and `reviewer` to inspect the patch for drift, risk, and missing verification.

Prompt:
> Use architect to map the owning surfaces and name the smallest safe implementation slice. Then have coder implement only that slice. Finally have reviewer inspect for boundary drift, missed tests, and unsafe assumptions.

## 2. Architect + memory-keeper before a growth closeout

Use `architect` to identify layer ownership and `memory-keeper` to preserve only bounded, provenance-aware notes.

Prompt:
> Have architect decide whether this belongs to skills, playbooks, memo, or agents. Then use memory-keeper to record only the bounded recall-worthy deltas and keep source-of-truth discipline explicit.

## 3. Evaluator as proof gate

Use `evaluator` after implementation or harvest promotion questions.

Prompt:
> Ask evaluator to compare the candidate change against the expected proof surface, call out what is observed vs inferred, and state whether the evidence is sufficient for promotion.

## 4. Reviewer + evaluator pair

Useful when you want both code-owner skepticism and proof discipline.

Prompt:
> Run reviewer and evaluator in parallel. Reviewer should look for real implementation and regression risks. Evaluator should judge whether the verification evidence actually supports the claim.

## 5. Read-only exploration cohort

For large ambiguous work, keep the first pass read-only.

Prompt:
> Use architect, reviewer, and evaluator as a read-only cohort. Map the route, identify the likely risks, and tell me which bounded workflow should act next. Do not modify files yet.

## 6. Memory boundary check

Prompt:
> Use memory-keeper to inspect whether the proposed note belongs in aoa-memo, Dionysus staging, or nowhere at all. Keep provenance and supersession discipline explicit.

## 7. Coder must stay bounded

Prompt:
> Use coder only for the concrete file edits after architect has named the owning surfaces and the exact slice. Coder should not redesign the route.
