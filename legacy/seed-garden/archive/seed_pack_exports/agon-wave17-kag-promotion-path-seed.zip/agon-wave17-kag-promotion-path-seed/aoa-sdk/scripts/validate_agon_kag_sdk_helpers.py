#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, pathlib, sys
ROOT = pathlib.Path(__file__).resolve().parents[1]
SRC = ROOT / 'config/agon_kag_sdk_helpers.seed.json'
OUT = ROOT / 'generated/agon_kag_sdk_helpers.min.json'
ITEM_KEY = 'sdk_helpers'
EXPECTED_COUNT = 7
ID_FIELDS = ['component_id', 'candidate_id', 'package_id', 'alignment_id', 'intake_id', 'summary_id', 'helper_id']
REQUIRED_FORBIDDEN = ['live_verdict_authority', 'durable_scar_write', 'retention_execution', 'rank_mutation', 'trust_mutation', 'tree_of_sophia_promotion', 'direct_tos_promotion', 'kag_canonization', 'kag_source_truth_claim', 'hidden_scheduler_action', 'assistant_contestant_drift', 'auto_doctrine_rewrite', 'center_takeover_of_owner_truth', 'unreviewed_kag_promotion', 'single_event_promotion', 'stats_promotion_authority', 'eval_promotion_authority']
REQUIRED_STOP_LINES = ['no_live_verdict_authority', 'no_durable_scar_write', 'no_retention_execution', 'no_rank_or_trust_mutation', 'no_tree_of_sophia_promotion', 'no_direct_tos_promotion', 'no_kag_as_canon', 'no_kag_as_source_truth', 'no_hidden_scheduler_action', 'no_assistant_contestant_drift', 'no_auto_doctrine_rewrite', 'no_center_takeover_of_owner_truth', 'no_kag_promotion_without_owner_review', 'no_promotion_from_single_event', 'no_stats_as_promotion_authority', 'no_eval_as_promotion_authority']
ALLOWED_RUNTIME = ('none', 'candidate_only', 'local_dry_run_candidate_only', 'local_rehearsal_candidate_only')

def fail(msg):
    print(msg, file=sys.stderr)
    return 1

def digest_obj(obj):
    return hashlib.sha256(json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()

def key_of(item):
    for field in ID_FIELDS:
        if item.get(field):
            return item[field]
    return item.get('id')

def validate_item(item):
    key = key_of(item)
    if not key:
        return 'missing item key'
    if item.get('wave') not in (None, 'XVII'):
        return f'unexpected wave for {key}: {item.get("wave")}'
    if item.get('live_protocol') is not False:
        return f'live_protocol must be false for {key}'
    if item.get('runtime_effect') not in ALLOWED_RUNTIME:
        return f'invalid runtime_effect for {key}: {item.get("runtime_effect")}'
    forbidden = set(item.get('forbidden_effects', []))
    for required in REQUIRED_FORBIDDEN:
        if required not in forbidden:
            return f'missing forbidden effect {required} for {key}'
    stops = set(item.get('stop_lines', []))
    for required in ('no_tree_of_sophia_promotion', 'no_kag_as_canon', 'no_promotion_from_single_event'):
        if required not in stops:
            return f'missing stop-line {required} for {key}'
    if item.get('assistant_contestant_allowed') is True:
        return f'assistant_contestant_allowed must not be true for {key}'
    if item.get('canonical_status') in ('canon', 'canonical', 'tree_of_sophia_canon', 'kag_canon'):
        return f'canonical status forbidden for {key}'
    if item.get('authority_posture') in ('sovereign', 'authority', 'governing'):
        return f'authority posture leak for {key}'
    if item.get('source_truth_posture') not in (None, 'owner_retained', 'source_owner_retained'):
        return f'source truth posture leak for {key}'
    if item.get('promotion_status') in ('promoted', 'accepted', 'canonical'):
        return f'promotion already granted for {key}'
    return None

def main():
    if not SRC.exists():
        return fail(f'missing source {SRC}')
    if not OUT.exists():
        return fail(f'missing generated registry {OUT}')
    seed = json.loads(SRC.read_text(encoding='utf-8'))
    reg = json.loads(OUT.read_text(encoding='utf-8'))
    items = seed.get(ITEM_KEY, [])
    if seed.get('wave') != 'XVII':
        return fail('seed wave mismatch')
    if len(items) != EXPECTED_COUNT:
        return fail(f'expected {EXPECTED_COUNT} seed items, got {len(items)}')
    if reg.get('count') != EXPECTED_COUNT:
        return fail(f'expected generated count {EXPECTED_COUNT}, got {reg.get("count")}')
    if reg.get('digest') != digest_obj(items):
        return fail('generated digest mismatch')
    seen = set()
    for item in items:
        key = key_of(item)
        if key in seen:
            return fail(f'duplicate item key: {key}')
        seen.add(key)
        err = validate_item(item)
        if err:
            return fail(err)
    print(json.dumps({'ok': True, 'item_key': ITEM_KEY, 'count': len(items)}, sort_keys=True))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
