# Validation Summary

- `Agents-of-Abyss` `agon_kag_promotion_path_registry.min.json`: green
- `aoa-kag` `agon_kag_promotion_candidate_registry.min.json`: green
- `aoa-memo` `agon_kag_memo_evidence_package_registry.min.json`: green
- `aoa-evals` `agon_kag_eval_alignment_registry.min.json`: green
- `aoa-stats` `agon_kag_stats_observability_registry.min.json`: green
- `aoa-sdk` `agon_kag_sdk_helpers.min.json`: green
