# Agon Wave XVII Seed

Wave XVII is the derived-substrate threshold of Agon.

Earlier waves produced actor forms, assistant forms, gates, trials, packet grammar, law, consequence bridges, duel-kernel traces, retention/rank economy, epistemic conflict, and historical candidates.
This wave asks which repeated forms deserve review as KAG candidates.

It does not create Tree of Sophia promotion. It prepares the bridge before the Sophian threshold.
