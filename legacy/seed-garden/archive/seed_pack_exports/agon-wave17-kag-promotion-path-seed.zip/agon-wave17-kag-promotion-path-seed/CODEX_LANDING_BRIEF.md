# Codex Landing Brief

Treat this as a multi-repo seed. Do not merge all directories into one repository.

Do not wire validators into release checks automatically unless the owner asks. After landing, each repo may explicitly adopt the validators into its release contour.

Preserve all stop-lines. Wave XVII is pre-ToS. The next major wave is Sophian Threshold.
