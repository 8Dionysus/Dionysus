# Patch Notes

Adds candidate-only registries and owner surfaces for KAG promotion candidates, evidence bundles, survival criteria, owner review routes, demote/quarantine candidates, KAG-side intakes, memo evidence packages, eval alignment, stats observability, and SDK helper candidates.

No repo receives canon authority, source-truth replacement authority, direct ToS promotion, live verdict authority, scar writing, rank mutation, or hidden scheduler power.
