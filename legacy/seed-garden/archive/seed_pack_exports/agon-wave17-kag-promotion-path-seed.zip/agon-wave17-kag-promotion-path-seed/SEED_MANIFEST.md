# SEED MANIFEST — Agon Wave XVII: KAG Promotion Path

This seed plants Wave XVII across six repositories.

It gives repeated Agon forms a reviewed path into KAG derived substrate without declaring canon, source truth, or Tree of Sophia readiness.

Landing order:

1. `Agents-of-Abyss`
2. `aoa-kag`
3. `aoa-memo`
4. `aoa-evals`
5. `aoa-stats`
6. `aoa-sdk`

Core invariant:

`KAG promotion candidate != KAG acceptance`
`KAG acceptance != canon`
`KAG candidate != Tree of Sophia candidate`
`single event != promotion`
`stats pressure != authority`
`eval alignment != promotion decision`
