## Skill ↔ MCP route discipline

- Prefer AoA skills that declare named MCP dependencies over ad hoc file walking when the route is:
  - sibling-workspace orientation
  - derived stats observability
  - Dionysus seed routing or planting trace
- Treat `aoa_workspace` as the first orientation surface when owner-fit is unclear.
- Treat `aoa_stats` as derived observability only. Do not let it overrule owner truth or bounded eval verdicts.
- Treat `dionysus` as seed-garden and planting-lineage context. Do not mistake staging notes for final owner doctrine.
- If a skill declares MCP dependencies in `agents/openai.yaml`, use those named servers first before falling back to broader exploration.
- Respect `allow_implicit_invocation`. Do not silently force explicit-only skills into automatic use.
- Keep role-bearing work in custom agents. Skills are workflows; agents are actors.
