# Skill ↔ MCP ↔ subagent prompt recipes

These recipes keep subagent use explicit.

## 1. Workspace orientation first

Use the AoA workspace-orientation skill and its declared MCP dependencies first.
Then explicitly spawn the `architect` agent to map the owner repo and the `reviewer`
agent to boundary-check the route.

Return:
- strongest owner repo
- strongest source surface
- next file or surface to inspect
- any boundary warnings

## 2. Derived observability without authority drift

Use the AoA stats-observability skill and its declared MCP dependencies.
Then explicitly spawn the `reviewer` agent to check that the route does not turn
derived views into proof authority, and the `evaluator` agent to inspect evidence-linked
surfaces that deserve closer reading.

Return:
- the most relevant summary surfaces
- evidence refs worth opening next
- what remains only a derived view rather than owner truth

## 3. Manifest-first seed route

Use the Dionysus seed-route skill and its declared MCP dependencies.
Then explicitly spawn the `architect` agent and the `memory-keeper` agent.

Have them follow this order:
manifest -> seed -> closure -> registry -> planting protocol -> owner repo

Return:
- current seed route
- live vs staged distinction
- planting trace if present
- exact owner repo to continue in

## 4. Cross-repo growth diagnosis

Start with the AoA workspace-orientation skill.
If the friction looks like observability drift, continue with the stats-observability skill.
If the friction looks like seed/planting continuity, continue with the seed-route skill.

Explicitly spawn:
- `architect`
- `reviewer`
- `memory-keeper`

Return:
- route diagnosis
- likely owner-fit
- which stronger source should take over
- whether a follow-up skill is needed
