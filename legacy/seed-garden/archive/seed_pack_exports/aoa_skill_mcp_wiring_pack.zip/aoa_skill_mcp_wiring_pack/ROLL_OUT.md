# Rollout for the AoA skill ↔ MCP wiring pack

## 1. Preconditions

Land these first:

- workspace-level MCP pack
- `aoa-stats` MCP pack
- `Dionysus` MCP pack
- custom agents generated from `aoa-agents` into `.codex/agents/`

## 2. Copy the repo overlay

Copy the contents of `repo-overlay/aoa-skills/` into the real `aoa-skills` repo.

Recommended targets:

- `docs/CODEX_SKILL_MCP_WIRING.md`
- `schemas/skill_mcp_wiring_map.schema.json`
- `examples/skill_mcp_wiring.map.json`
- `examples/openai.*.example.yaml`
- `scripts/build_openai_yaml_examples.py`
- `scripts/validate_skill_mcp_wiring.py`
- `tests/test_build_openai_yaml_examples.py`
- `tests/test_validate_skill_mcp_wiring.py`

## 3. Merge workspace guidance

Append or adapt:

- `templates/workspace-root/AGENTS.skill-mcp.section.md` into the workspace `AGENTS.md`
- `templates/workspace-root/.codex/config.skill-mcp.snippet.toml` into the workspace `.codex/config.toml`

The config snippet assumes these server names:

- `aoa_workspace`
- `aoa_stats`
- `dionysus`

Keep those names stable unless you are ready to update the wiring map and all `openai.yaml` files.

## 4. Generate the starter metadata

Run from `aoa-skills`:

```bash
python scripts/build_openai_yaml_examples.py   --map examples/skill_mcp_wiring.map.json   --output-dir examples/generated_openai_yaml
```

This gives you three starter files:

- `openai.workspace-orientation.example.yaml`
- `openai.stats-observability.example.yaml`
- `openai.seed-route.example.yaml`

Treat them as scaffolds, not canon.

## 5. Adapt into real skill folders

For the first three real skills you choose, copy the generated example nearest to that skill's route and rename it to:

```text
skills/<skill-name>/agents/openai.yaml
```

Then adjust only:

- `display_name`
- `short_description`
- `default_prompt`
- the exact MCP dependencies
- `allow_implicit_invocation` if and only if it matches the skill's existing posture

Do not move execution doctrine from `SKILL.md` into `openai.yaml`.

## 6. Validate against the workspace config and local adapter

Run:

```bash
python scripts/validate_skill_mcp_wiring.py   --workspace-config ../.codex/config.toml   --repo-root .   --format text
```

The validator checks:

- each `agents/openai.yaml` parses
- `policy.allow_implicit_invocation` is present
- MCP dependency names exist in the workspace config
- `allow_implicit_invocation` stays aligned with `generated/local_adapter_manifest.min.json` when available

## 7. Exercise the route in Codex

From the AoA workspace root:

1. Launch Codex from the workspace root.
2. Use `/mcp` to verify the servers are active.
3. Try one prompt from `prompts/skill_mcp_subagent_recipes.md`.
4. Confirm Codex reaches the right server and does not drift into ad hoc file walking.

## 8. What should come after this

Only after the first three routes are stable:

- wire more skill families
- consider a local AoA plugin bundle
- consider a bounded automation wave for recurring routes
