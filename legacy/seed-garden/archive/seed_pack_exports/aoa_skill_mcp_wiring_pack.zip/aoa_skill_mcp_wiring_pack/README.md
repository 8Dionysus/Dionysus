# AoA skill ↔ MCP wiring pack v0

This pack prepares the next wave after the project-level MCP spine.

It does not create new skill canon. It wires existing or future AoA skills to named MCP servers,
workspace guidance, and explicit subagent recipes so Codex can move through the workspace with less drift.

## Why this wave now

You already have:

- a workspace-level MCP orientation surface
- a repo-local `aoa-stats` MCP surface
- a repo-local `Dionysus` MCP surface
- subagent scaffolding from `aoa-agents`
- a local adapter contract in `aoa-skills` that treats `.agents/skills` as the Codex-facing export

The missing seam is not another server. It is the wiring layer that tells Codex:

- which named MCP servers a skill depends on
- whether a skill may be invoked implicitly
- which role-bearing agents make sense after that skill activates
- how to keep the skill-side policy aligned with the local adapter manifest

## What is inside

- `contracts/aoa_skill_mcp_wiring_contract_v1.md`: ownership and boundary rules for the seam
- `repo-overlay/aoa-skills/docs/CODEX_SKILL_MCP_WIRING.md`: repo-local wiring doctrine
- `repo-overlay/aoa-skills/schemas/skill_mcp_wiring_map.schema.json`: map schema for example wiring
- `repo-overlay/aoa-skills/examples/skill_mcp_wiring.map.json`: starter AoA wiring map
- `repo-overlay/aoa-skills/examples/openai.*.example.yaml`: generated example `agents/openai.yaml` files
- `repo-overlay/aoa-skills/scripts/build_openai_yaml_examples.py`: generator for example `openai.yaml` files
- `repo-overlay/aoa-skills/scripts/validate_skill_mcp_wiring.py`: validator for skill metadata vs workspace MCP config and local adapter manifest
- `repo-overlay/aoa-skills/tests/`: helper-layer tests
- `templates/workspace-root/AGENTS.skill-mcp.section.md`: workspace guidance section for skill/MCP use
- `templates/workspace-root/.codex/config.skill-mcp.snippet.toml`: Codex config snippet for dependency wiring
- `prompts/skill_mcp_subagent_recipes.md`: explicit prompt recipes for subagent-assisted routes
- `ROLL_OUT.md`: merge order and verification path

## Intended posture

This seam stays narrow.

- `SKILL.md` keeps execution meaning.
- `agents/openai.yaml` keeps Codex-facing metadata and named tool dependencies.
- `.codex/config.toml` keeps server installation and enablement.
- `.codex/agents/*.toml` keeps role-bearing agents.
- `AGENTS.md` keeps durable workspace and repo law.

Nothing here should turn `openai.yaml` into a second doctrine layer or a hidden routing empire.

## Quick local test after merge

Inside `aoa-skills` after copying the repo overlay:

```bash
python -m pytest -q tests/test_build_openai_yaml_examples.py tests/test_validate_skill_mcp_wiring.py
python scripts/build_openai_yaml_examples.py   --map examples/skill_mcp_wiring.map.json   --output-dir examples/generated_openai_yaml

python scripts/validate_skill_mcp_wiring.py   --workspace-config ../.codex/config.toml   --paths examples/generated_openai_yaml/openai.workspace-orientation.example.yaml           examples/generated_openai_yaml/openai.stats-observability.example.yaml           examples/generated_openai_yaml/openai.seed-route.example.yaml   --format json
```

## Suggested rollout order

1. Merge the workspace config and workspace MCP pack first.
2. Merge the repo-local `aoa-stats` and `Dionysus` MCP packs.
3. Copy this pack's `repo-overlay/aoa-skills/` files into `aoa-skills`.
4. Generate the example `openai.yaml` files from the wiring map.
5. Adapt those examples into the first real skill folders you want Codex to use.
6. Run the validator against the workspace `.codex/config.toml` and the local adapter manifest.
7. Add the `AGENTS.md` section and try the prompt recipes.

## What I would do immediately after this lands

1. Wire only three early routes first:
   - workspace orientation
   - stats observability
   - seed routing
2. Keep the dependency list minimal.
3. Keep subagent use explicit in prompts.
4. Only after the wiring feels stable, consider an AoA local plugin bundle.
