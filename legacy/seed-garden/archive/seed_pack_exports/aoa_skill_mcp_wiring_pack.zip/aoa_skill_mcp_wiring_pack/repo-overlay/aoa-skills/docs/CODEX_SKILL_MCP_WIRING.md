# Codex skill ↔ MCP wiring in `aoa-skills`

## Why this seam belongs here

`aoa-skills` already owns skill meaning and the Codex-facing export path.
This makes it the right place to keep the small metadata seam that tells Codex which named MCP servers a skill depends on.

The seam should stay small enough that it does not compete with `SKILL.md`.

## What to keep where

### Keep in `SKILL.md`

- the bounded workflow
- the execution law
- references, scripts, and asset contracts
- evidence posture
- fallbacks and guardrails

### Keep in `agents/openai.yaml`

- display name and short description
- default surrounding prompt
- `allow_implicit_invocation`
- named MCP tool dependencies

### Keep out of `openai.yaml`

- long doctrine
- giant role prompts
- detailed proof logic
- repo-routing law that belongs in stronger surfaces

## First three route families to wire

1. workspace orientation
2. stats observability
3. seed route / planting navigation

These are useful because they connect already-prepared project MCP surfaces to repeatable skill use without flattening ownership.

## Source alignment rule

If `generated/local_adapter_manifest.min.json` already advertises `allow_implicit_invocation` for a skill,
the same value should appear in `agents/openai.yaml`.

The validator in this pack checks that seam when the manifest is available.

## Suggested merge path

1. copy the schema, examples, scripts, and tests from this pack
2. generate or adapt the example `openai.yaml` files
3. place real files under the chosen skill folders
4. run the validator against the workspace `.codex/config.toml`
5. only then mirror or publish the Codex-facing export

## Practical advice

- start with three skills, not thirty
- keep dependencies minimal
- when unsure, prefer `aoa_workspace` first and add deeper servers only when they remove real manual work
- do not make `aoa_stats` or `Dionysus` look like owner truth in skill metadata
