from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path


def write_workspace_config(path: Path) -> None:
    path.write_text(
        """
approval_policy = "on-request"

[mcp_servers.aoa_workspace]
command = "python"
args = ["scripts/aoa_workspace_mcp_server.py"]

[mcp_servers.aoa_stats]
command = "python"
args = ["scripts/aoa_stats_mcp_server.py"]

[mcp_servers.dionysus]
command = "python"
args = ["scripts/dionysus_mcp_server.py"]
""".strip()
        + "\n",
        encoding="utf-8",
    )


def test_validate_reports_success(tmp_path: Path) -> None:
    workspace_config = tmp_path / "config.toml"
    write_workspace_config(workspace_config)

    yaml_path = tmp_path / "openai.stats-observability.example.yaml"
    yaml_path.write_text(
        """
interface:
  display_name: "AoA stats observability"
  short_description: "Inspect derived views."
policy:
  allow_implicit_invocation: false
dependencies:
  tools:
    - type: "mcp"
      value: "aoa_workspace"
      transport: "stdio"
    - type: "mcp"
      value: "aoa_stats"
      transport: "stdio"
""".strip()
        + "\n",
        encoding="utf-8",
    )

    manifest = tmp_path / "local_adapter_manifest.min.json"
    manifest.write_text(
        json.dumps(
            [
                {
                    "name": "stats-observability",
                    "allow_implicit_invocation": False,
                }
            ]
        ),
        encoding="utf-8",
    )

    script = Path(__file__).resolve().parents[1] / "scripts" / "validate_skill_mcp_wiring.py"
    result = subprocess.run(
        [
            sys.executable,
            str(script),
            "--workspace-config",
            str(workspace_config),
            "--local-adapter-manifest",
            str(manifest),
            "--paths",
            str(yaml_path),
            "--format",
            "json",
        ],
        capture_output=True,
        text=True,
        check=True,
    )

    payload = json.loads(result.stdout)
    assert payload["ok"] is True
    assert payload["skills"][0]["errors"] == []


def test_validate_catches_unknown_mcp(tmp_path: Path) -> None:
    workspace_config = tmp_path / "config.toml"
    write_workspace_config(workspace_config)

    yaml_path = tmp_path / "openai.seed-route.example.yaml"
    yaml_path.write_text(
        """
policy:
  allow_implicit_invocation: false
dependencies:
  tools:
    - type: "mcp"
      value: "missing_server"
      transport: "stdio"
""".strip()
        + "\n",
        encoding="utf-8",
    )

    script = Path(__file__).resolve().parents[1] / "scripts" / "validate_skill_mcp_wiring.py"
    result = subprocess.run(
        [
            sys.executable,
            str(script),
            "--workspace-config",
            str(workspace_config),
            "--paths",
            str(yaml_path),
            "--format",
            "json",
        ],
        capture_output=True,
        text=True,
    )

    assert result.returncode != 0
    payload = json.loads(result.stdout)
    assert payload["ok"] is False
    assert any("unknown MCP dependency" in err for err in payload["skills"][0]["errors"])


def test_validate_catches_invocation_mismatch(tmp_path: Path) -> None:
    workspace_config = tmp_path / "config.toml"
    write_workspace_config(workspace_config)

    yaml_path = tmp_path / "openai.workspace-orientation.example.yaml"
    yaml_path.write_text(
        """
policy:
  allow_implicit_invocation: true
dependencies:
  tools:
    - type: "mcp"
      value: "aoa_workspace"
      transport: "stdio"
""".strip()
        + "\n",
        encoding="utf-8",
    )

    manifest = tmp_path / "local_adapter_manifest.min.json"
    manifest.write_text(
        json.dumps(
            [
                {
                    "name": "workspace-orientation",
                    "allow_implicit_invocation": False,
                }
            ]
        ),
        encoding="utf-8",
    )

    script = Path(__file__).resolve().parents[1] / "scripts" / "validate_skill_mcp_wiring.py"
    result = subprocess.run(
        [
            sys.executable,
            str(script),
            "--workspace-config",
            str(workspace_config),
            "--local-adapter-manifest",
            str(manifest),
            "--paths",
            str(yaml_path),
            "--format",
            "json",
        ],
        capture_output=True,
        text=True,
    )

    assert result.returncode != 0
    payload = json.loads(result.stdout)
    assert payload["ok"] is False
    assert any("allow_implicit_invocation mismatch" in err for err in payload["skills"][0]["errors"])
