from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path


def test_build_emits_expected_files(tmp_path: Path) -> None:
    mapping = {
        "schema_version": "1",
        "mcp_registry": {
            "aoa_workspace": {"description": "workspace", "transport": "stdio"}
        },
        "skill_wirings": [
            {
                "slug": "workspace-orientation",
                "display_name": "AoA workspace orientation",
                "short_description": "Orient first.",
                "default_prompt": "Orient before deeper work.",
                "allow_implicit_invocation": True,
                "mcp_dependencies": ["aoa_workspace"],
            }
        ],
    }
    map_path = tmp_path / "skill_mcp_wiring.map.json"
    map_path.write_text(json.dumps(mapping), encoding="utf-8")
    output_dir = tmp_path / "out"

    script = Path(__file__).resolve().parents[1] / "scripts" / "build_openai_yaml_examples.py"
    subprocess.run(
        [sys.executable, str(script), "--map", str(map_path), "--output-dir", str(output_dir)],
        check=True,
    )

    result = output_dir / "openai.workspace-orientation.example.yaml"
    assert result.exists()
    text = result.read_text(encoding="utf-8")
    assert "display_name: AoA workspace orientation" in text
    assert "value: aoa_workspace" in text


def test_build_check_mode_detects_drift(tmp_path: Path) -> None:
    mapping = {
        "schema_version": "1",
        "mcp_registry": {
            "aoa_workspace": {"description": "workspace", "transport": "stdio"}
        },
        "skill_wirings": [
            {
                "slug": "workspace-orientation",
                "display_name": "AoA workspace orientation",
                "short_description": "Orient first.",
                "default_prompt": "Orient before deeper work.",
                "allow_implicit_invocation": True,
                "mcp_dependencies": ["aoa_workspace"],
            }
        ],
    }
    map_path = tmp_path / "skill_mcp_wiring.map.json"
    map_path.write_text(json.dumps(mapping), encoding="utf-8")
    output_dir = tmp_path / "out"
    output_dir.mkdir()
    generated = output_dir / "openai.workspace-orientation.example.yaml"
    generated.write_text("drifted: true\n", encoding="utf-8")

    script = Path(__file__).resolve().parents[1] / "scripts" / "build_openai_yaml_examples.py"
    result = subprocess.run(
        [sys.executable, str(script), "--map", str(map_path), "--output-dir", str(output_dir), "--check"],
        capture_output=True,
        text=True,
    )
    assert result.returncode != 0
    assert "Out of date file" in result.stderr or "Out of date file" in result.stdout
