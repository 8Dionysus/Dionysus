# AoA skill ↔ MCP wiring contract v1

## Purpose

This contract defines the narrow seam that binds AoA skills to named MCP servers, workspace guidance,
and explicit role-bearing agents in Codex.

It exists to improve discoverability and routing without collapsing AoA ownership boundaries.

## Ownership split

- `SKILL.md` owns bounded execution meaning.
- `agents/openai.yaml` owns Codex-facing metadata:
  - user-facing display details
  - invocation posture
  - named tool dependencies
- `.codex/config.toml` owns MCP server configuration and enablement.
- `.codex/agents/*.toml` owns role-bearing custom agents.
- `AGENTS.md` owns durable workspace and repo guidance.
- repo-local source surfaces still own meaning in their own repositories.

## Hard rules

### 1. Do not move doctrine into `openai.yaml`

`openai.yaml` may help Codex choose tools and present skills cleanly.
It must not become the second place where execution law is authored.

### 2. Declare named MCP servers, not file paths

Skill metadata should depend on named servers such as:

- `aoa_workspace`
- `aoa_stats`
- `dionysus`

The server implementation remains elsewhere.
The skill does not own the server.

### 3. Preserve invocation posture

If a skill's local adapter or published export already defines `allow_implicit_invocation`,
the value in `agents/openai.yaml` must match it.

This pack treats mismatch as a wiring error, not as an invitation to rewrite the skill posture silently.

### 4. Keep derived layers non-sovereign

A skill may depend on:

- `aoa_workspace` for orientation
- `aoa_stats` for derived observability
- `dionysus` for seed navigation and planting trace

That dependency does not grant any of those surfaces authority over skill meaning, proof, or final owner truth.

### 5. Keep subagent use explicit

Subagents are role-bearing actors, not hidden side effects of a skill dependency.
This seam may recommend subagents for a route, but prompts must ask for them explicitly.

### 6. Prefer the smallest useful dependency set

Do not attach every server to every skill.
Attach only the servers that remove real manual friction.

## Starter route families

### Workspace orientation

Use when the first problem is ownership, strongest source surface, or sibling-workspace direction.

Recommended servers:
- `aoa_workspace`

Recommended explicit subagents:
- `architect`
- `reviewer`

### Stats observability

Use when the route needs derived views, summary surfaces, active windows, or evidence-linked counters.

Recommended servers:
- `aoa_workspace`
- `aoa_stats`

Recommended explicit subagents:
- `reviewer`
- `evaluator`

### Seed route and planting

Use when the route needs manifest-first seed reading, staging notes, registry navigation, or planting lineage.

Recommended servers:
- `aoa_workspace`
- `dionysus`

Recommended explicit subagents:
- `architect`
- `memory-keeper`

## Validation expectations

A working seam should pass three checks:

1. `agents/openai.yaml` parses and carries `policy.allow_implicit_invocation`.
2. Each MCP dependency name exists in the active workspace `.codex/config.toml`.
3. The invocation policy matches the local adapter manifest when present.

## Non-goals

This contract does not:

- define new skill canon
- replace `AGENTS.md`
- replace repo-local MCP contracts
- replace the subagent contract surface from `aoa-agents`
- bundle everything into one sovereign plugin by default
