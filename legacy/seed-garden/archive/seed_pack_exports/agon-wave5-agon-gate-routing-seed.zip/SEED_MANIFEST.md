# Agon Wave V Seed: Agon Gate Routing

This seed plants **Wave V: Agon Gate Routing**.

It is a multi-repo seed:

- `Agents-of-Abyss/` receives the center handoff request and stop-line note.
- `aoa-routing/` receives the primary routing gate surfaces.

## Purpose

Wave III named lawful moves.
Wave IV bound those moves to future owner homes.
Wave V teaches routing to recognize when ordinary service, thin navigation, or routine cognitive handling is no longer enough and a pre-protocol Agon gate candidate should be emitted.

This seed does **not** open an arena.

It does not create sessions, sealed commits, verdicts, scars, retention, rank mutation, runtime dispatch, or Tree-of-Sophia promotion.

## Planting order

1. Merge `Agents-of-Abyss/` into the root of `Agents-of-Abyss`.
2. Merge `aoa-routing/` into the root of `aoa-routing`.

## Verify after planting

In `Agents-of-Abyss`:

```bash
python scripts/build_agon_gate_routing_handoff_request.py --check
python scripts/validate_agon_gate_routing_handoff_request.py
python -m pytest -q tests/test_agon_gate_routing_handoff_request.py
```

In `aoa-routing`:

```bash
python scripts/build_agon_gate_routing_registry.py --check
python scripts/validate_agon_gate_routing.py
python -m pytest -q tests/test_agon_gate_routing.py
```

## Core law

Routing may say:

> this looks like an Agon gate candidate.

Routing may not say:

> the arena is open.

Wave V creates the gate signal, not the battlefield.
