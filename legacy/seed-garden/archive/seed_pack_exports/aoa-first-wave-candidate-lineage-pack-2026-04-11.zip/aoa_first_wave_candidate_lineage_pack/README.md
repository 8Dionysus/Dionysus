# AoA First Wave Candidate Lineage Pack

This pack prepares the **first internal growth-refinery wave**:

1. one center doctrine note for the reviewable growth refinery
2. one narrow candidate-lineage contract across:
   - `aoa-sdk`
   - `aoa-skills`
   - `Dionysus`

This pack is **not greenfield fantasy**. Several first-wave surfaces are already live in the public tree. Use this pack to:

- align and harden what already exists
- fill the remaining contract gaps
- add the missing cross-repo validator and example chain
- avoid redundant replanting where the live repo already says the same thing honestly

## Recommended landing order

1. `Agents-of-Abyss`
2. `aoa-sdk`
3. `aoa-skills`
4. `Dionysus`
5. run the cross-repo lineage validator
6. record drift, skips, and any consciously deferred edges

## Main contents

- `LIVE_STATE_ALIGNMENT.md`
- `contracts/candidate_lineage_contract_v1.md`
- `CODEX_EXECUTION_PROMPT.md`
- `PR_SLICES.md`
- `ACCEPTANCE_MATRIX.md`
- `proposed-targets/Agents-of-Abyss/...`
- `proposed-targets/aoa-sdk/...`
- `proposed-targets/aoa-skills/...`
- `proposed-targets/Dionysus/...`

## Working rule

Prefer **minimal diffs over duplicate surfaces**.

If a target repo already has an equivalent file:
- reread it
- keep it if it is already honest
- patch only the missing boundary, example, or validator seam
- record the decision in the landing report
