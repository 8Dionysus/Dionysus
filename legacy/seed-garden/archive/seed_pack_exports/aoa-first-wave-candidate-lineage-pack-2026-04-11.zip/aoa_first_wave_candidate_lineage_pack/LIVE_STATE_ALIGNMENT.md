# Live State Alignment

This note exists so Codex does not plant duplicates blindly.

## What is already visibly alive

### `Agents-of-Abyss`
The center already names:
- `docs/REVIEWABLE_GROWTH_REFINERY.md`
- `docs/CANDIDATE_LINEAGE_CROSSWALK.md`

`docs/METHOD_SPINE.md` also already points at both of those surfaces and explicitly names the route:

`cluster_ref -> candidate_ref -> seed_ref -> object_ref`

### `aoa-sdk`
The SDK already carries the control-plane side of the seam:
- `docs/session-growth-checkpoints.md` says checkpoint notes may carry provisional lineage hints rooted in `cluster_ref`
- `docs/CANDIDATE_LINEAGE_CARRY.md` already states that `aoa-sdk` may mint only `cluster_ref`
- `schemas/checkpoint_lineage_hint.schema.json` already exists
- `examples/checkpoint_lineage_hint.example.json` already exists

### `aoa-skills`
The donor-harvest skill already speaks the right language:
- `skills/aoa-session-donor-harvest/SKILL.md` says `candidate_ref` is minted only after reviewed harvest
- `examples/session_growth_artifacts/candidate_lineage_receipt.alpha.json` already exists

The most likely remaining gap here is **hardening around the existing harvest-packet receipt/schema/doc surfaces**, not inventing a second sovereign object class.

### `Dionysus`
The seed-garden side is already alive:
- `docs/CANDIDATE_SEED_IDENTITY.md` exists
- `schemas/seed_lineage_entry.schema.json` exists
- `examples/seed_lineage_entry.example.json` exists

## What this pack still adds on purpose

- one tightened shared contract note
- one stronger cross-repo validator in the center
- one missing closeout-candidate-map example in `aoa-sdk`
- one explicit candidate-ref refinement note in `aoa-skills`
- one safer patch guide for the existing harvest-packet receipt schema
- one aligned example chain that survives from `cluster_ref` to `seed_ref`

## What not to do

Do **not**:
- duplicate center docs under new names
- replace existing repo-local truth with this pack by force
- invent a new lineage repository
- move minting authority out of its owner repo
- split `candidate_ref` into a second parallel identity surface in `aoa-skills`
