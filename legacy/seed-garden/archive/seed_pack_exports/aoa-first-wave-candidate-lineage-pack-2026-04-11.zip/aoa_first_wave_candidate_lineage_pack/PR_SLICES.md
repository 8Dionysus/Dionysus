# PR Slices

## PR-1 — center doctrine hardening
Repo: `Agents-of-Abyss`

Land:
- `docs/REVIEWABLE_GROWTH_REFINERY.md`
- `docs/CANDIDATE_LINEAGE_CROSSWALK.md`
- `scripts/validate_candidate_lineage_contract.py`

Acceptance:
- docs stay non-sovereign
- owner split stays explicit
- validator runs from workspace root against sibling repos

## PR-2 — SDK provisional carry completion
Repo: `aoa-sdk`

Land or patch:
- `docs/CANDIDATE_LINEAGE_CARRY.md`
- `schemas/checkpoint_lineage_hint.schema.json`
- `schemas/closeout_candidate_lineage_map.schema.json`
- `examples/checkpoint_lineage_hint.example.json`
- `examples/closeout_candidate_lineage_map.example.json`

Acceptance:
- `cluster_ref` remains the only minted lineage identity here
- closeout context remains provisional
- no `candidate_ref`, `seed_ref`, or `object_ref` minting appears in SDK surfaces

## PR-3 — reviewed candidate identity hardening
Repo: `aoa-skills`

Land or patch:
- `docs/CANDIDATE_REF_REFINERY.md`
- existing `references/harvest-packet-receipt-schema.yaml`
- `examples/session_growth_artifacts/candidate_lineage_receipt.alpha.json`
- review `skills/aoa-session-donor-harvest/SKILL.md` for drift

Acceptance:
- `candidate_ref` is minted only after reviewed harvest
- harvest-packet receipt retains its existing event kind and governance references
- candidate metadata remains bounded and owner-first

## PR-4 — candidate-to-seed bridge completion
Repo: `Dionysus`

Land or patch:
- `docs/CANDIDATE_SEED_IDENTITY.md`
- `examples/seed_lineage_entry.example.json`
- review `schemas/seed_lineage_entry.schema.json` for drift

Acceptance:
- `seed_ref` is minted only in `Dionysus`
- staged seed identity does not pretend to be final owner truth
- example chain aligns with `aoa-sdk` and `aoa-skills`

## PR-5 — cross-repo validation pass
Repo: workspace-level, executed from center

Acceptance:
- one aligned chain validates:
  - `cluster_ref` matches between SDK and skills
  - `candidate_ref` matches between skills and Dionysus
  - `seed_ref` remains Dionysus-only
  - lifecycle and status posture are structurally valid
