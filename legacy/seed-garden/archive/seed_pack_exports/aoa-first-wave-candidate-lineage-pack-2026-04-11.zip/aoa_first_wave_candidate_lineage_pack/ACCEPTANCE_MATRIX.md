# Acceptance Matrix

| area | must be true | check |
|---|---|---|
| center doctrine | route exists as non-sovereign doctrine | `Agents-of-Abyss/docs/REVIEWABLE_GROWTH_REFINERY.md` |
| center crosswalk | owner split is explicit | `Agents-of-Abyss/docs/CANDIDATE_LINEAGE_CROSSWALK.md` |
| center validator | cross-repo example chain validates | `python Agents-of-Abyss/scripts/validate_candidate_lineage_contract.py --workspace-root <root>` |
| sdk carry | only `cluster_ref` is minted here | inspect `aoa-sdk/docs/CANDIDATE_LINEAGE_CARRY.md` |
| sdk example | checkpoint hint example loads and matches the chain | `aoa-sdk/examples/checkpoint_lineage_hint.example.json` |
| sdk closeout map | reviewed closeout still stays provisional | `aoa-sdk/examples/closeout_candidate_lineage_map.example.json` |
| skills minting | `candidate_ref` is minted only after reviewed harvest | inspect `aoa-skills/skills/aoa-session-donor-harvest/SKILL.md` |
| skills schema continuity | keep `harvest_packet_receipt` and its existing governance ref | inspect patched `references/harvest-packet-receipt-schema.yaml` |
| skills example | candidate example preserves incoming `cluster_ref` | `aoa-skills/examples/session_growth_artifacts/candidate_lineage_receipt.alpha.json` |
| Dionysus minting | `seed_ref` appears only here | inspect `Dionysus/docs/CANDIDATE_SEED_IDENTITY.md` and example |
| Dionysus lifecycle | staged seed may keep `object_ref: null`; planted must not | `Dionysus/examples/seed_lineage_entry.example.json` |
| no sovereignty drift | no route authority moved into derived/routing/memory layers | review changed files only |
