#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ALLOWED_STATUS_POSTURE = {"early", "reanchor", "thin-evidence", "stable"}
ALLOWED_LIFECYCLE = {
    "staged",
    "open-wave",
    "planting-in-progress",
    "planted",
    "superseded",
    "dropped",
}


def read_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise SystemExit(f"missing file: {path}")
    except json.JSONDecodeError as exc:
        raise SystemExit(f"invalid json in {path}: {exc}")


def require(condition: bool, message: str) -> None:
    if not condition:
        raise SystemExit(message)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Validate the first-wave candidate-lineage example chain across sibling repos."
    )
    parser.add_argument(
        "--workspace-root",
        required=True,
        help="Path to the sibling workspace root that contains Agents-of-Abyss, aoa-sdk, aoa-skills, and Dionysus.",
    )
    args = parser.parse_args()

    root = Path(args.workspace_root).expanduser().resolve()

    sdk_path = root / "aoa-sdk" / "examples" / "checkpoint_lineage_hint.example.json"
    skills_path = (
        root
        / "aoa-skills"
        / "examples"
        / "session_growth_artifacts"
        / "candidate_lineage_receipt.alpha.json"
    )
    seed_path = root / "Dionysus" / "examples" / "seed_lineage_entry.example.json"

    sdk = read_json(sdk_path)
    skills = read_json(skills_path)
    seed = read_json(seed_path)

    require(
        sdk.get("schema_version") == "aoa_checkpoint_lineage_hint_v1",
        "aoa-sdk example must use schema_version=aoa_checkpoint_lineage_hint_v1",
    )
    require(
        skills.get("schema_version") == "aoa_candidate_lineage_receipt_v1",
        "aoa-skills example must use schema_version=aoa_candidate_lineage_receipt_v1",
    )
    require(
        seed.get("schema_version") == "dionysus_seed_lineage_entry_v1",
        "Dionysus example must use schema_version=dionysus_seed_lineage_entry_v1",
    )

    require(
        sdk["cluster_ref"] == skills["cluster_ref"],
        "cluster_ref drift between aoa-sdk and aoa-skills examples",
    )
    require(
        skills["candidate_ref"] == seed["candidate_ref"],
        "candidate_ref drift between aoa-skills and Dionysus examples",
    )
    require(
        seed.get("cluster_ref") in {None, skills["cluster_ref"]},
        "Dionysus cluster_ref must be null or match the upstream cluster_ref",
    )

    require(
        sdk["status_posture"] in ALLOWED_STATUS_POSTURE,
        f"invalid aoa-sdk status_posture: {sdk['status_posture']}",
    )
    require(
        skills["status_posture"] in ALLOWED_STATUS_POSTURE,
        f"invalid aoa-skills status_posture: {skills['status_posture']}",
    )
    require(
        seed["status_posture"] in ALLOWED_STATUS_POSTURE,
        f"invalid Dionysus status_posture: {seed['status_posture']}",
    )

    require(
        seed["lifecycle_status"] in ALLOWED_LIFECYCLE,
        f"invalid Dionysus lifecycle_status: {seed['lifecycle_status']}",
    )

    require("candidate_ref" not in sdk, "aoa-sdk example must not mint candidate_ref")
    require("seed_ref" not in sdk, "aoa-sdk example must not mint seed_ref")
    require("object_ref" not in sdk, "aoa-sdk example must not mint object_ref")

    require("seed_ref" not in skills, "aoa-skills example must not mint seed_ref")
    require("object_ref" not in skills, "aoa-skills example must not mint object_ref")

    require(
        isinstance(seed.get("seed_ref"), str) and seed["seed_ref"],
        "Dionysus example must mint a non-empty seed_ref",
    )

    if seed["lifecycle_status"] == "planted":
        require(seed.get("object_ref"), "planted seed must carry object_ref")
    if seed["lifecycle_status"] in {"staged", "open-wave", "planting-in-progress"}:
        require(seed.get("object_ref") in {None, ""}, "pre-plant seed should keep object_ref null/empty")

    print("candidate-lineage contract: OK")
    print(f"workspace_root={root}")
    print(f"cluster_ref={sdk['cluster_ref']}")
    print(f"candidate_ref={skills['candidate_ref']}")
    print(f"seed_ref={seed['seed_ref']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
