# Candidate Lineage Carry

`aoa-sdk` carries provisional checkpoint and reviewed-closeout lineage hints for the growth refinery without claiming owner truth.

## Boundary

`aoa-sdk` may:
- mint and carry `cluster_ref`
- carry `owner_hypothesis`
- carry `owner_shape`
- carry `nearest_wrong_target`
- carry `evidence_refs`
- carry `axis_pressure`
- carry `status_posture`
- carry `supersedes`
- carry `merged_into`
- carry `drop_reason`

`aoa-sdk` does **not** mint:
- `candidate_ref`
- `seed_ref`
- `object_ref`

Checkpoint and closeout lineage stays provisional until reviewed owner-layer harvest, seed staging, and final owner landing resolve the next identifiers.

## Carried shape

The control-plane carry uses:
- `schemas/checkpoint_lineage_hint.schema.json`
- `schemas/closeout_candidate_lineage_map.schema.json`

It lands in two places:
- checkpoint candidate clusters under `lineage_hint`
- reviewed closeout context under `candidate_lineage_map`

The canonical growth-refinery axis remains:

`cluster_ref -> candidate_ref -> seed_ref -> object_ref`

In this repo only the first hop is authoritative.

## Carry rules

- `cluster_ref` should be deterministic for the checkpoint candidate seam
- `owner_hypothesis` stays a hypothesis, not a final owner verdict
- `owner_shape` names the expected owner-side surface shape, not a landed object
- `nearest_wrong_target` keeps the most tempting adjacent owner mistake visible
- `status_posture` stays within `early`, `reanchor`, `thin-evidence`, or `stable`
- `axis_pressure` is a compact checkpoint-to-closeout carry, not a score
- `supersedes`, `merged_into`, and `drop_reason` stay representable even before owner truth exists

## Negative rules

Do not:
- turn checkpoint lineage carry into donor-harvest authority
- upgrade a checkpoint hint into a seed or owner object from `aoa-sdk`
- let reviewed closeout packets pretend the owner repo already accepted the unit
- mint `candidate_ref` because the cluster looks strong
