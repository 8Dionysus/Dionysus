# Candidate To Seed Identity

## Purpose

This note defines the `Dionysus` side of the growth-refinery lineage route.

The route stays:

`cluster_ref -> candidate_ref -> seed_ref -> object_ref`

`Dionysus` is the first honest home of `seed_ref`.

It is **not**:
- the first honest home of reviewed `candidate_ref`
- the final home of planted `object_ref`

## Boundary

Keep the owner split explicit:

- `aoa-sdk` may carry `cluster_ref` and bounded lineage hints
- `aoa-skills` may mint reviewed `candidate_ref`
- `Dionysus` may stage and trace `seed_ref`
- the owner repository may mint or confirm `object_ref`

This bridge is real, but it is not a new sovereign lineage layer.

## What Dionysus must carry

When a reviewed candidate becomes a staged seed, keep these fields legible:

- `cluster_ref`
- `candidate_ref`
- `seed_ref`
- `owner_hypothesis`
- `owner_shape`
- `lifecycle_status`
- `status_posture`
- `evidence_refs`
- `supersedes`
- `merged_into`
- `drop_reason`
- `object_ref`

The repo-local structural surface for that entry should stay at:
- `schemas/seed_lineage_entry.schema.json`
- `examples/seed_lineage_entry.example.json`

## Negative rules

Do not:
- mint `seed_ref` without a reviewed `candidate_ref`
- treat staging as final owner truth
- mint `candidate_ref` here
- require `object_ref` while the seed is only staged
- turn the local example validator into a cross-repo sovereign contract

## Lifecycle posture

The local seed-lineage example is intentionally structural:

- `staged`, `open-wave`, and `planting-in-progress` may keep `object_ref: null`
- `planted` must carry a non-null `object_ref`
- `superseded` must point at `merged_into`
- `dropped` must explain `drop_reason`

That is enough for local consistency without claiming proof that an owner-repo planting already landed.
