# Drift Review: `skills/aoa-session-donor-harvest/SKILL.md`

Review the live skill against the first-wave contract.

## Must remain true

- the skill starts from a **reviewed** session artifact
- `candidate_ref` is minted only after reviewed harvest
- `cluster_ref` may be preserved if carried from upstream
- `owner_hypothesis` and `nearest_wrong_target` stay explicit
- first authoring must not route to `aoa-routing` or `aoa-kag`
- the route stays bounded and owner-first

## Patch only if drift is real

If the live skill already says these things honestly, keep it.

Patch only when:
- terminology drift creates ambiguity
- required lineage fields are missing from outputs or procedure
- the skill starts implying seed or object authority
