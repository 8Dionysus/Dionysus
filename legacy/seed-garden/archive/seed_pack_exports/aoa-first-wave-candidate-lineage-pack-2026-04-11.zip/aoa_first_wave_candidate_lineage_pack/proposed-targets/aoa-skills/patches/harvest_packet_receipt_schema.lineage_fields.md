# Patch Guide: `references/harvest-packet-receipt-schema.yaml`

This patch guide exists because the live repo already points the donor-harvest skill at:

- `detail_event_kind = harvest_packet_receipt`
- `detail_receipt_schema_ref = references/harvest-packet-receipt-schema.yaml`

Do **not** replace that event kind or change the governance ref casually.

## Patch intent

Extend the existing harvest-packet receipt schema so each accepted candidate can carry lineage fields required by the first wave:

- `candidate_ref`
- `cluster_ref`
- `owner_hypothesis`
- `owner_shape`
- `nearest_wrong_target`
- `status_posture`
- `evidence_refs`
- `supersedes`
- `merged_into`
- `drop_reason`

## Rules

- keep the existing receipt kind
- keep the existing publisher/governance references
- add fields in the candidate item shape, not as a second competing receipt object
- do not introduce `seed_ref` here
- do not introduce `object_ref` here
- keep the schema compatible with the donor-harvest skill's existing boundary

## Companion check

After patching the schema, reread:
- `skills/aoa-session-donor-harvest/SKILL.md`
- `examples/session_growth_artifacts/candidate_lineage_receipt.alpha.json`

The doc, schema, and example should all tell the same story.
