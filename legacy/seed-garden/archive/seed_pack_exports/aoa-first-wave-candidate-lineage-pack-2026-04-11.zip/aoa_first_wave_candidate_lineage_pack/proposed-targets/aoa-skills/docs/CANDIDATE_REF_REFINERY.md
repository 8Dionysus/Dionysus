# Candidate Ref Refinery

This note defines the `aoa-skills` side of the growth-refinery lineage route.

The route stays:

`cluster_ref -> candidate_ref -> seed_ref -> object_ref`

`aoa-skills` is the first honest home of reviewed `candidate_ref`.

It is **not**:
- the first home of `cluster_ref`
- the first home of `seed_ref`
- the final home of planted `object_ref`

## Boundary

`aoa-skills` may:
- mint `candidate_ref`
- preserve incoming `cluster_ref`
- preserve `owner_hypothesis`
- preserve `owner_shape`
- preserve `nearest_wrong_target`
- preserve `evidence_refs`
- preserve `status_posture`
- preserve `supersedes`
- preserve `merged_into`
- preserve `drop_reason`

`aoa-skills` must not:
- mint `candidate_ref` before reviewed donor harvest
- mint `seed_ref`
- mint `object_ref`
- collapse reviewed candidate identity into final owner truth
- treat `aoa-routing` or `aoa-kag` as first-authoring homes

## Where this should live

The reviewed candidate identity should remain anchored in the existing donor-harvest path:
- `skills/aoa-session-donor-harvest/SKILL.md`
- the existing harvest-packet receipt schema
- the existing detail receipt/event kind used by the project-core kernel
- one aligned example receipt

This wave should **patch the existing harvest-packet receipt shape**, not invent a second competing detail event kind.

## Minting rule

Mint `candidate_ref` only when:
- the source session artifact is reviewed
- the reusable unit is bounded
- the owner hypothesis is explicit
- the nearest wrong target is explicit
- the candidate survives theme-only rejection

## Candidate carry

Each accepted reviewed candidate should be able to carry:
- `candidate_ref`
- `cluster_ref`
- `owner_hypothesis`
- `owner_shape`
- `nearest_wrong_target`
- `status_posture`
- `evidence_refs`
- `supersedes`
- `merged_into`
- `drop_reason`

## Negative rules

Do not:
- mint `candidate_ref` from live session residue
- treat donor harvest as proof that an owner repo already accepted the unit
- collapse a mixed multi-owner route into one fake candidate
- widen the route so far that the candidate stops being bounded
