You are landing the **AoA first-wave candidate-lineage pack** into the live sibling workspace.

Your job is to strengthen the existing first-wave route without creating duplicate doctrine or parallel sovereign objects.

## Scope

This wave includes only:
- center doctrine/crosswalk hardening in `Agents-of-Abyss`
- provisional lineage carry completion in `aoa-sdk`
- reviewed candidate identity hardening in `aoa-skills`
- candidate-to-seed bridge hardening in `Dionysus`

Do **not** expand this wave into:
- `aoa-stats`
- `aoa-evals`
- `aoa-playbooks`
- `aoa-memo`
- `aoa-routing`
- `aoa-kag`

unless a tiny doc-link or validation pointer is strictly required.

## Order

1. reread any live equivalent files first
2. land or patch center docs
3. land or patch `aoa-sdk`
4. land or patch `aoa-skills`
5. land or patch `Dionysus`
6. run the cross-repo validator
7. report:
   - what was created
   - what was patched
   - what was already equivalent and kept
   - what was deferred

## Boundary discipline

Keep the chain narrow:

`cluster_ref -> candidate_ref -> seed_ref -> object_ref`

Authority must remain split:
- `aoa-sdk` mints only `cluster_ref`
- `aoa-skills` mints only `candidate_ref`
- `Dionysus` mints only `seed_ref`
- final owner repo mints or confirms `object_ref`

## Minimal-diff rule

If a target file already exists and is semantically aligned:
- keep it
- patch only missing edges
- do not duplicate the same doctrine under a second filename

## Required artifacts to check

### `Agents-of-Abyss`
- `docs/REVIEWABLE_GROWTH_REFINERY.md`
- `docs/CANDIDATE_LINEAGE_CROSSWALK.md`
- `scripts/validate_candidate_lineage_contract.py`

### `aoa-sdk`
- `docs/CANDIDATE_LINEAGE_CARRY.md`
- `schemas/checkpoint_lineage_hint.schema.json`
- `schemas/closeout_candidate_lineage_map.schema.json`
- `examples/checkpoint_lineage_hint.example.json`
- `examples/closeout_candidate_lineage_map.example.json`

### `aoa-skills`
- `docs/CANDIDATE_REF_REFINERY.md`
- existing `references/harvest-packet-receipt-schema.yaml` patched rather than replaced
- `examples/session_growth_artifacts/candidate_lineage_receipt.alpha.json`
- `skills/aoa-session-donor-harvest/SKILL.md` checked for drift against the contract

### `Dionysus`
- `docs/CANDIDATE_SEED_IDENTITY.md`
- `examples/seed_lineage_entry.example.json`
- `schemas/seed_lineage_entry.schema.json` checked for drift, not duplicated

## Validation

Run the center validator from the workspace root after landing:

```bash
python Agents-of-Abyss/scripts/validate_candidate_lineage_contract.py --workspace-root /path/to/workspace
```

If repo-local validators exist, run them too.

## Output format

Return:
1. a concise landing summary
2. the exact files changed
3. validation results
4. any boundary risks or deferred work
