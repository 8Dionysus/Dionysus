# Candidate Lineage Contract v1

## Purpose

This contract names one narrow, reviewable route for a growth object moving across existing AoA owners.

It does **not** create:
- a new sovereign layer
- a new repository
- a new universal object class above the existing owners

## Canonical chain

`cluster_ref -> candidate_ref -> seed_ref -> object_ref`

## Owner split

| stage | identifier | owner repo | authority posture |
|---|---|---|---|
| checkpoint carry | `cluster_ref` | `aoa-sdk` | provisional control-plane carry |
| reviewed candidate | `candidate_ref` | `aoa-skills` | reviewed reusable candidate identity |
| seed staging | `seed_ref` | `Dionysus` | seed-garden and dispatch identity |
| owner landing | `object_ref` | final owner repo | final source-owned object truth |

## Shared metadata that should survive or update

Each stronger stage should preserve or explicitly update:

- `owner_hypothesis`
- `owner_shape`
- `nearest_wrong_target`
- `evidence_refs`
- `axis_pressure`
- `status_posture`
- `supersedes`
- `merged_into`
- `drop_reason`

## Status posture grammar

Use one bounded grammar across the route:

- `early`
- `reanchor`
- `thin-evidence`
- `stable`

This posture is for route legibility.
It is **not** a total score.

## Lifecycle language

The route may pass through:

- `checkpointed`
- `reviewed`
- `harvested`
- `seeded`
- `planted`
- `proved`
- `promoted`
- `superseded`
- `dropped`

Not every lineage must reach every stage.

## Repo-local rules

### `aoa-sdk`
May:
- mint and carry `cluster_ref`
- carry provisional lineage hints
- build reviewed closeout context that still remains provisional

Must not:
- mint `candidate_ref`
- mint `seed_ref`
- mint `object_ref`

### `aoa-skills`
May:
- mint `candidate_ref`
- preserve incoming `cluster_ref`
- emit candidate-bearing harvest output after reviewed donor harvest

Must not:
- mint `seed_ref`
- treat reviewed candidate identity as planted owner truth
- route first-authoring to `aoa-routing` or `aoa-kag`

### `Dionysus`
May:
- mint `seed_ref`
- preserve `candidate_ref`
- preserve incoming `cluster_ref` when present
- track staging / planting lifecycle

Must not:
- mint `candidate_ref`
- replace final owner `object_ref`
- treat staged seed identity as final owner truth

### final owner repo
May:
- mint or confirm `object_ref`
- supersede or merge earlier route stages honestly

Must not:
- rewrite the meaning of earlier stages retroactively as if they never existed

## Negative rules

Do not:
- invent a new lineage sovereign
- move authority into `aoa-stats`, `aoa-memo`, `aoa-routing`, or `aoa-kag`
- use one global score as the route readout
- promote checkpoint hints directly into seed identity
- skip reviewed donor harvest when minting `candidate_ref`

## First-wave acceptance

First wave is complete when:
1. the center names the route
2. `aoa-sdk` carries only `cluster_ref` and provisional hints
3. `aoa-skills` mints reviewed `candidate_ref`
4. `Dionysus` mints `seed_ref`
5. one example chain validates across those three repos
