# Agon Wave 0 Seed: Imposition Gate

Target repository: `Agents-of-Abyss`

This seed opens the first Agon move without implementing the arena.
It turns the center from **Agon preparation** to **Agon imposition**:

> Agon is not adapted to the current system.  
> The current system is placed under Agon scrutiny.

## What this seed lands

```text
docs/AGON_IMPOSITION_POSTURE.md
docs/AGON_DOUBT_AUDIT.md
docs/AGON_SURVIVAL_CRITERIA.md
docs/PRE_AGON_BASELINE.md
docs/AGON_WAVE0_LANDING.md
schemas/agon-imposition-readiness.schema.json
generated/agon_imposition_readiness.min.json
scripts/agon_imposition_common.py
scripts/build_agon_imposition_readiness.py
scripts/validate_agon_imposition_readiness.py
tests/test_agon_imposition_readiness.py
examples/agon_doubt_audit.example.json
quests/AOA-Q-AGON-0000-imposition-gate.md
quests/AOA-Q-AGON-0001-agent-recharter-entry.md
```

## What this seed does not do

It does **not** create a new `Agon-of-Abyss` sibling repository.

It does **not** implement `aoa-agon`, arena sessions, sealed commits, contradiction ledger, verdicts, scars, retention, runtime transport, or A2A packets.

It does **not** rewrite `Tree-of-Sophia`, `aoa-agents`, `aoa-evals`, `aoa-memo`, `aoa-routing`, or any owner repository.

It does **not** claim that Agon is live.

It creates the review surface that decides which existing assumptions survive the Agon turn.

## Landing posture for Codex

Merge `repo/` into the root of `Agents-of-Abyss`.

After merge, run:

```bash
python scripts/build_agon_imposition_readiness.py --check
python scripts/validate_agon_imposition_readiness.py
python -m pytest -q tests/test_agon_imposition_readiness.py
```

Then decide whether to wire the validator into the repository's broader release check or keep it as an explicit Agon Wave 0 validation command until the next release contour is cut.

## Relationship to existing Agon preparation

`docs/AGON_PREPARATION_POSTURE.md` remains useful as the conservative holding boundary.
This seed does not delete it.

Wave 0 adds the stronger turning boundary:

- preparation described where Agon may later live;
- imposition declares that the existing system is now audited by Agon survival criteria.

The old posture was a lantern.
This wave is the anvil.
