# aoa-stats-telemetry seed

This seed proposes a machine-first, evidence-linked, multi-layer statistics and telemetry model for AoA.

Purpose:
- record quantity without mistaking it for quality
- record quality without pretending a single score explains everything
- keep every aggregate linked to inspectable evidence
- let agents write minimal, predictable receipts automatically
- let Codex derive higher-order views later without stealing meaning from owner repos

Suggested landing posture:
- source-owned receipts stay close to their owner surfaces or runtime artifacts
- federated statistics stay derived and machine-readable
- progression stays multi-axis and bounded
- UI comes later

Open first:
1. `CODEX_HANDOFF.md`
2. `seed/docs/STATISTICS_ARCHITECTURE.md`
3. `seed/schemas/stats-event-envelope.schema.json`
4. `seed/integration/SESSION_HARVEST_AND_AUTOMATION_BRIDGE.md`
