# Codex handoff

This package is a seed, not a patch.

Intent:
- give AoA a portable statistics contract without inventing a sovereign truth empire
- keep quantity, quality, progression, and evidence legible but separate
- make session-harvest family the first instrumented path

Recommended order:
1. Keep source-owned meaning in existing owner repos.
2. Add a shared envelope schema for event receipts.
3. Add typed event schemas for the first instrumented family.
4. Emit append-only machine-readable receipts.
5. Build derived object and window summaries.
6. Add progression and automation rollups only after evidence refs are stable.

Do not:
- replace eval verdicts with counters
- replace owner meaning with derived aggregates
- let logs duplicate raw artifacts instead of linking to them
- infer progression from activity count alone
- treat memo witness as proof authority
