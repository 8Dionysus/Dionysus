# Layer boundaries

## Owner posture
- `aoa-skills` owns bounded workflow meaning
- `aoa-techniques` owns reusable practice meaning
- `aoa-evals` owns bounded proof meaning
- `aoa-playbooks` owns scenario composition
- `aoa-agents` owns role and checkpoint contract meaning
- `aoa-memo` owns memory and provenance-thread support surfaces

## Statistics posture
Statistics is derived.
It should consume source-owned receipts, evidence refs, and bounded verdicts.
It should not become the owner of workflow meaning, proof meaning, or quest state.

## Best initial landing
Keep local receipts near the owner surface.
Build cross-repo read models in a derived stats layer or observatory-style adjunct.
