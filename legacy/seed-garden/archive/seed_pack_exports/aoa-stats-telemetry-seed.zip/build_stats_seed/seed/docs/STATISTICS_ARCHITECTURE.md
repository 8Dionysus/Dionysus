# Statistics architecture

## One sentence
AoA statistics should be an evidence-linked observability layer built from source-owned receipts, bounded eval verdicts, and multi-axis progression summaries.

## Five layers

### 1. Event facts
Append-only machine-readable receipts that say what happened.
Examples:
- a skill was activated and completed
- a fork was presented and one branch was chosen
- a self-repair cycle started and ended
- an automation candidate was detected

These are facts, not proof.

### 2. Evidence links
Every meaningful event should point to inspectable artifacts rather than duplicating them.
Examples:
- witness trace
- verification result
- diff
- approval record
- health check
- improvement log
- playbook harvest
- eval report

### 3. Bounded evaluations
Quality should enter through review notes and eval verdicts, not through counts alone.
Statistics may quote or summarize verdicts, but must not replace them.

### 4. Progression readings
Progression should be route-scoped or quest-scoped and multi-axis.
It should record small deltas, holds, cautions, reanchors, and downgrades.

### 5. Derived views
Views are for machines first.
Examples:
- per-object usage summary
- repeated-window movement summary
- fork calibration summary
- automation pipeline maturity summary
- route or quest progression summary

## Canonical split
- counts answer: how often and how widely
- verdicts answer: how well on this bounded surface
- progression answers: what changed on named axes
- logs answer: where to inspect the evidence

## Anti-collapse rules
- do not let one global score pretend to own quality
- do not let raw activity counts imply competence
- do not let memory witness stand in for proof
- do not duplicate raw logs when a ref is enough
- do not let derived stats become owner truth
