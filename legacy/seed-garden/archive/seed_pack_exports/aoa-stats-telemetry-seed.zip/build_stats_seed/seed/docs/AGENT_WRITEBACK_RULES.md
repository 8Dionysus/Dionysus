# Agent writeback rules

## Goal
An agent should always know what to write and when.

## Minimum rule
Every instrumented workflow emits at least one start-or-finish receipt.
Better posture is one finish receipt with bounded evidence refs.

## Common envelope requirements
Every receipt should include:
- `event_kind`
- `event_id`
- `observed_at`
- `run_ref`
- `session_ref`
- `actor_ref`
- `object_ref`
- `evidence_refs`
- `payload`

## Write moments
- on skill completion
- on eval result publication
- on harvest packet completion
- when a fork is chosen
- when a repair cycle closes
- when a progression delta is reviewed
- when an automation candidate is emitted

## Replacement rule
Do not mutate old receipts silently.
Use a new receipt with `supersedes` when correction is necessary.
