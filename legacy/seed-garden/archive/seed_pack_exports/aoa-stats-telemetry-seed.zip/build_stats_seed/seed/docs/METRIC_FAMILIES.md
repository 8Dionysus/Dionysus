# Metric families

## Quantity family
- activation_count
- completion_count
- verification_present_rate
- distinct_session_count
- distinct_actor_count
- repeat_usage_rate

## Quality family
- bounded_claim_support_rate
- mixed_support_rate
- no_support_rate
- review_accept_rate
- evidence_density
- artifact_completeness_rate
- drift_incident_rate
- reopen_rate

## Progression family
- axis_delta_totals
- hold_count
- reanchor_count
- downgrade_count
- caution_count
- unlock_hint_count

## Fork family
- branch_selection_count
- predicted_gain_hit_rate
- predicted_risk_hit_rate
- regret_signal_rate
- reanchor_after_fork_rate

## Automation family
- automation_candidate_count
- seed_ready_rate
- checkpoint_required_rate
- not_now_rate
- candidate_to_seed_conversion_rate
- seed_to_playbook_conversion_rate

## Diagnostic family
- diagnosis_count_by_type
- repair_resolution_rate
- repair_reopen_rate
- diagnosis_precision_proxy
- diagnosis_to_repair_latency_window
