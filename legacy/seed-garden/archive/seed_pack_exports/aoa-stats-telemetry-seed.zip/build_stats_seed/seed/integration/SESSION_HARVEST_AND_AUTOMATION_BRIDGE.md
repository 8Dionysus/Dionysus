# Session-harvest and automation bridge

## First-wave integration

### aoa-session-donor-harvest
Emit:
- `harvest_packet_receipt`
- counts by extract kind
- owner-layer distribution
- promotion candidates and deferrals
- evidence density summary

### aoa-session-route-forks
Emit:
- `decision_fork_receipt`
- branch options
- chosen branch
- predicted gain, cost, risk
- later realized outcome refs when available

### aoa-session-self-diagnose
Emit:
- diagnosis type
- symptom
- probable cause
- confidence band
- evidence refs

### aoa-session-self-repair
Emit:
- repair cycle start and close
- linked diagnosis refs
- action family
- verification artifact refs
- resolution, reanchor, or reopen status

### aoa-session-progression-lift
Emit:
- `progression_delta_receipt`
- scope
- axis deltas
- verdict
- caution refs

### aoa-automation-opportunity-scan
Emit:
- `automation_candidate_receipt`
- repeat signal
- determinism and reversibility posture
- checkpoint_required flag
- seed_ready flag
- next artifact hint
