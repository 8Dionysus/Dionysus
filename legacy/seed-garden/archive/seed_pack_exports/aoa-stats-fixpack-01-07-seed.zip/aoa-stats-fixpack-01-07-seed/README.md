# aoa-stats fixpack 01-07 seed

This package is a Codex-ready seed for the remaining seams around receipts, stats, and live observability.

It is **not** a patch bundle.
It assumes Codex will read the live repo state and choose the smallest coherent edits that preserve the current AoA layer split.

## Scope

1. Sync the shared event vocabulary with real emitted and consumed receipt kinds.
2. Give session diagnosis a first-class receipt kind.
3. Make receipt validation registry-aware, not just shape-aware.
4. Fill committed fixtures for the new summary surfaces that are already advertised.
5. Upgrade evidence refs from contract docs to concrete run artifacts where possible.
6. Resolve canonical ownership of the shared receipt envelope / event-kind registry.
7. Add an operational readiness check for all required live publishers.

## Guidance

- Keep owner repos in charge of meaning.
- Keep `aoa-stats` in charge of derived views and cross-repo summary building.
- Preserve append-only correction posture through `supersedes`.
- Prefer the smallest coherent change set that closes each seam.
- Update docs, examples, generated surfaces, and tests together when a seam moves.

## Recommended order

1. Shared event vocabulary
2. Diagnosis receipt kind
3. Registry-aware validation
4. Committed fixtures for core/runtime summaries
5. Artifact-grade evidence refs
6. Envelope ownership governance
7. Live publisher readiness check

## Key current-state anchors

- `aoa-stats` already has a `supersedes`-aware active view and already builds core-skill and runtime-closeout summaries.
- The shared envelope enum in `aoa-evals` still lags behind the live event family.
- `aoa-session-self-diagnose` still emits `SKILL_RUN_RECEIPT` + `CORE_SKILL_APPLICATION_RECEIPT` instead of a diagnosis-specific detail receipt.
- The bounded example feed still leans on `SKILL.md` refs in several places.
- The committed core-skill and runtime-closeout summaries are still empty.

Use `CODEX_HANDOFF.md` first, then `seed/manifest.yaml`, then the numbered task notes.
