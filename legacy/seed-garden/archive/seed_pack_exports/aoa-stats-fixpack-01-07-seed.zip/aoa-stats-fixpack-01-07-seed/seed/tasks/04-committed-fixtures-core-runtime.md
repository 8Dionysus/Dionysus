# 04. Committed fixtures for core/runtime summaries

## Why

The repo already advertises `core_skill_application_summary` and `runtime_closeout_summary`, but the committed example-driven summaries are still empty placeholders.

## Primary move

Add bounded example receipts that exercise both surfaces, then regenerate committed outputs and tests.

## Suggested touchpoints

- `aoa-stats/examples/session_harvest_family.receipts.example.json`
- or a new sibling example feed if that is cleaner
- `aoa-stats/generated/core_skill_application_summary.min.json`
- `aoa-stats/generated/runtime_closeout_summary.min.json`
- `aoa-stats/generated/summary_surface_catalog.min.json`
- `aoa-stats/tests/*`

## Guidance

Either:
- extend the existing bounded example feed, or
- add a second bounded example feed and update the build path/tests accordingly

Choose whichever keeps the repo most legible.

## Acceptance

- committed `core_skill_application_summary.min.json` contains at least one finished kernel-skill example
- committed `runtime_closeout_summary.min.json` contains at least one bounded runtime closeout example
- summary metadata reflects the updated example feed(s)
- tests cover both surfaces
