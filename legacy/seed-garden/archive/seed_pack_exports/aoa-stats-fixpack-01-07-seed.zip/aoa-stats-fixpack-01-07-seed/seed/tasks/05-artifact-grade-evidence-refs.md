# 05. Artifact-grade evidence refs

## Why

The bounded example feed still points several primary evidence refs at `SKILL.md`. That is fine for contract reading, but weak for real traceability.

## Primary move

Upgrade primary evidence refs to concrete per-run artifacts while optionally keeping contract refs as secondary/background references.

## Suggested touchpoints

- example receipt feeds in `aoa-stats/examples/`
- owner-local receipt publishers in emitting repos
- docs that describe evidence ref posture
- any artifact-path conventions already used under `.aoa/` or repo-local artifacts

## Desired evidence posture

Primary refs should prefer:
- harvest packets
- diagnosis packets
- repair packets
- fork cards
- progression artifacts
- quest promotion artifacts
- runtime closeout artifacts

Contract refs like `SKILL.md` can remain as secondary refs when helpful.

## Acceptance

- bounded examples no longer rely on `SKILL.md` as the primary evidence for harvest/fork/progression/automation/diagnosis/quest cases
- at least one example shows both:
  - a primary artifact ref
  - a secondary contract ref
- evidence refs stay inspectable and machine-usable
