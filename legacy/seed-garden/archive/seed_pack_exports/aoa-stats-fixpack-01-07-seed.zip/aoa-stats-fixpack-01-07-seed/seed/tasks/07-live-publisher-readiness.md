# 07. Live publisher readiness

## Why

The live registry already marks seven owner-local receipt logs as required. Automation should be able to verify that those publishers are truly alive.

## Primary move

Add a machine-runnable readiness check that audits all required live publishers.

## Suggested touchpoints

- `aoa-stats/scripts/refresh_live_stats.py`
- `aoa-stats/scripts/validate_repo.py`
- or a new `aoa-stats/scripts/check_live_publishers.py`
- `aoa-stats/config/live_receipt_sources.json`
- `aoa-stats/docs/LIVE_SESSION_USE.md`
- optional systemd/watcher docs if the readiness check should be wired into automation

## Readiness dimensions

At minimum:
- path exists
- readable
- syntactically valid JSONL/JSON shape
- compatible with registry-aware validation

Optional but useful:
- non-empty
- modified recently
- last line parses
- known event kinds only

## Acceptance

- there is one explicit command that audits all required live publishers
- the command fails loudly on missing/invalid required sources
- docs describe the command and expected output
- the check can be reused by automation before or after live refresh
