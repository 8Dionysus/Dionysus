# 02. Diagnosis as a first-class receipt

## Why

`aoa-session-self-diagnose` already produces a `DIAGNOSIS_PACKET`, but telemetry still collapses it into a generic `SKILL_RUN_RECEIPT`.

## Primary move

Add a bounded detail receipt kind for diagnosis, then keep the existing core-skill application receipt pointing back to that detail receipt.

## Suggested touchpoints

- `aoa-skills/skills/aoa-session-self-diagnose/SKILL.md`
- `aoa-skills/skills/aoa-session-self-diagnose/references/` (new diagnosis receipt schema)
- `aoa-stats/scripts/build_views.py`
- `aoa-stats/tests/*`
- example receipt feeds and any live publisher that emits diagnosis results

## Minimum target state

- `DIAGNOSIS_PACKET` remains the rich artifact
- `diagnosis_packet_receipt` becomes the bounded detail receipt
- `core_skill_application_receipt` still points back to the diagnosis detail receipt
- object/window summaries count diagnosis as its own event kind

## Keep out of scope

- no need to invent a dedicated diagnosis summary surface unless the live repo now clearly wants it
- do not bloat the diagnosis receipt to equal the packet itself

## Acceptance

- `aoa-session-self-diagnose` emits `diagnosis_packet_receipt`
- the shared registry knows that kind
- example/live feeds can include it without validation hacks
- `core_skill_application_receipt.payload.detail_event_kind` can reference it cleanly
