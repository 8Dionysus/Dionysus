# 03. Registry-aware validation

## Why

The current validator checks `event_kind` as a non-empty string. That is shape-safe but vocabulary-blind.

## Primary move

Make validation load or consult the canonical event-kind registry and reject unknown kinds early with actionable errors.

## Suggested touchpoints

- `aoa-stats/scripts/build_views.py`
- `aoa-stats/tests/*`
- possibly a new helper module or registry loader under `aoa-stats/scripts/` or `aoa-stats/schemas/`

## Target behavior

- valid known kinds pass
- unknown kinds fail at validation
- valid known but currently unsummarized kinds are allowed
- the error message points back to the canonical registry source

## Acceptance

- an unknown `event_kind` fails `python scripts/build_views.py --check`
- tests cover at least:
  - known kind passes
  - misspelled kind fails
  - a receipt chain with `supersedes` still validates and resolves cleanly
