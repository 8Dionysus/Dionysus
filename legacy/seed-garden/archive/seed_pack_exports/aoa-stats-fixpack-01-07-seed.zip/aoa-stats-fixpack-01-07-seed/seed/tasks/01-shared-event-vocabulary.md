# 01. Shared event vocabulary

## Why

The shared envelope enum lags behind the live event family. `aoa-stats` already consumes/builds summaries for kinds that the shared enum does not list yet.

## Current seam

The shared envelope currently covers the original eight event kinds only.
At minimum, the live system already needs room for:
- `quest_promotion_receipt`
- `core_skill_application_receipt`
- `runtime_wave_closeout_receipt`

A diagnosis-specific kind is also the next logical addition.

## Primary move

Build one explicit cross-repo event-kind registry from two sources:

1. actual emitted kinds across required live publishers
2. current builder branches / summary derivation code

Then sync the shared envelope to that registry.

## Suggested touchpoints

- `aoa-evals/schemas/stats-event-envelope.schema.json`
- `aoa-stats/schemas/` (new shared registry surface if chosen)
- `aoa-stats/scripts/build_views.py`
- `aoa-stats/tests/*`
- owner-repo receipt schema references that mention the shared envelope

## Minimum target state

A single machine-readable registry or canonical schema lists the active event family.
Minimum additions expected:
- `quest_promotion_receipt`
- `core_skill_application_receipt`
- `runtime_wave_closeout_receipt`
- `diagnosis_packet_receipt`

Inventory other kinds from:
- `aoa-skills/.aoa/live_receipts/session-harvest-family.jsonl`
- `aoa-skills/.aoa/live_receipts/core-skill-applications.jsonl`
- `aoa-evals/.aoa/live_receipts/eval-result-receipts.jsonl`
- `aoa-playbooks/.aoa/live_receipts/playbook-receipts.jsonl`
- `aoa-techniques/.aoa/live_receipts/technique-receipts.jsonl`
- `aoa-memo/.aoa/live_receipts/memo-writeback-receipts.jsonl`
- `abyss-stack/.aoa/live_receipts/runtime-wave-closeouts.jsonl`

## Acceptance

- one canonical event vocabulary exists
- the shared envelope no longer lags behind the live system
- unknown or misspelled event kinds can be detected from the registry
- docs point to the canonical registry, not to competing definitions
