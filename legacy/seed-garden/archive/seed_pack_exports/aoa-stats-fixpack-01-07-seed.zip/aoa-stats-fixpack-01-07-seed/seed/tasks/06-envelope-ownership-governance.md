# 06. Envelope ownership governance

## Why

`aoa-stats` already claims ownership of derived summary schemas and builders, while the shared event envelope still lives in `aoa-evals`. That leaves canonical ownership blurred.

## Primary recommendation

Make `aoa-stats` the canonical home of the shared cross-repo receipt envelope / event-kind registry.

Reason:
- `aoa-stats` is the cross-repo consumer/validator/builder of the family
- owner repos still keep payload meaning in their own schemas
- `aoa-evals` should keep `eval_result_receipt` payload semantics, not the whole event family

## Acceptable fallback

If the live repo strongly prefers keeping the shared envelope in `aoa-evals`, then:
- document that choice explicitly
- make `aoa-stats` reference or mirror it with a clear precedence rule
- remove ambiguous wording from README / docs

## Suggested touchpoints

- `aoa-stats/README.md`
- `aoa-stats/docs/BOUNDARIES.md`
- `aoa-stats/docs/ARCHITECTURE.md`
- `aoa-evals/README.md`
- `aoa-evals/docs/*` that mention the shared envelope
- schema headers / comments / docs that describe the canonical source

## Acceptance

- one repo/file is explicitly canonical
- the other repo references or mirrors it with a clear precedence rule
- no docs imply competing ownership
