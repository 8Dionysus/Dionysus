# ADR draft: canonical ownership of the shared receipt envelope

## Context

Cross-repo receipt validation and summary building now live operationally in `aoa-stats`, while the shared event envelope schema still sits in `aoa-evals`.

## Recommendation

Make `aoa-stats` the canonical home of:

- the shared cross-repo receipt envelope
- the event-kind registry used by the stats builder / validator

Keep owner repos authoritative for:

- payload-specific schemas
- payload meaning
- repo-local artifacts and live publishers

Keep `aoa-evals` authoritative for:

- `eval_result_receipt` payload semantics
- verdict interpretation
- proof-layer meaning

## Why this recommendation fits the current split

- `aoa-stats` is the cross-repo consumer, validator, and builder of derived read models
- the shared event family now reaches well beyond eval-specific receipts
- this avoids making `aoa-evals` a quiet owner of the whole receipt ecosystem

## Fallback

If live project governance prefers the shared envelope to stay in `aoa-evals`, then define:

- the canonical source file
- the mirror/reference file
- the precedence rule
- the sync/update rule

Do not leave ownership implicit.
