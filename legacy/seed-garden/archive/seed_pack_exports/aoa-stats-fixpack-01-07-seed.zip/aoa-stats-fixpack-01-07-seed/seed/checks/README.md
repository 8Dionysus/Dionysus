# Acceptance / verification

Run these after the fixpack lands, adapting paths if the live repo chooses a slightly different layout.

## Suggested checks

```bash
cd /srv/aoa-stats
python scripts/build_views.py --check
python scripts/validate_repo.py
python -m pytest -q tests
```

If a live-publisher readiness command is added:

```bash
python scripts/check_live_publishers.py
```

## Human review questions

1. Is there one clear event vocabulary?
2. Does diagnosis have its own receipt kind?
3. Will a misspelled event kind fail fast?
4. Are core/runtime committed summaries still empty?
5. Do primary evidence refs lead to run artifacts?
6. Is canonical ownership of the shared envelope explicit?
7. Can automation verify that all required live publishers are present and valid?
