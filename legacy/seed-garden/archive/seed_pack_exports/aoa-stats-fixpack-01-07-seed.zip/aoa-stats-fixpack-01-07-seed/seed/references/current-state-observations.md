# Current-state observations captured for this seed

These are the seams this seed is targeting. Re-check live repo state before editing.

1. `aoa-stats` already documents and implements `supersedes`-aware active receipt collapse.
2. `aoa-stats` already advertises and builds:
   - `core_skill_application_summary`
   - `runtime_closeout_summary`
3. The shared event envelope enum is still narrower than the currently used event family.
4. `aoa-session-self-diagnose` still emits:
   - `SKILL_RUN_RECEIPT`
   - `CORE_SKILL_APPLICATION_RECEIPT`
   while its main artifact is `DIAGNOSIS_PACKET`.
5. The bounded example feed still uses several `SKILL.md` primary refs.
6. The committed `core_skill_application_summary.min.json` is empty.
7. The committed `runtime_closeout_summary.min.json` is empty.
8. The canonical live source registry already marks seven owner-local logs as required.

This package assumes those seams still need closing. If the live repo has already fixed some of them, shrink the task instead of forcing redundant edits.
