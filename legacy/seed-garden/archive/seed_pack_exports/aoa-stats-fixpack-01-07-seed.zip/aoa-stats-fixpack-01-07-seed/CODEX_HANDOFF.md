# CODEX_HANDOFF

You are applying a fixpack seed inside a live AoA federation where the repos already contain the first rollout of:

- session-harvest family
- automation opportunity scan
- aoa-stats derived observability
- core-skill application receipts
- runtime closeout summaries
- supersedes-aware active views

## Operating posture

1. Re-read the live repo state before editing.
2. Prefer the smallest coherent diffs that preserve the current repo split.
3. Treat this package as **guidance plus acceptance criteria**, not as a frozen patch.
4. Do not widen `aoa-stats` into workflow authority or proof authority.
5. Keep owner repos authoritative for payload meaning.
6. Update docs, schemas, builders, example feeds, generated surfaces, and tests together.
7. When the live repo already fixes a seam, skip or shrink the corresponding task instead of forcing this seed.

## High-confidence recommendations

- Inventory the **actual emitted event kinds** across all required live publishers before freezing the shared registry.
- Minimum registry additions almost certainly include:
  - `quest_promotion_receipt`
  - `core_skill_application_receipt`
  - `runtime_wave_closeout_receipt`
  - `diagnosis_packet_receipt`
- Recommended canonical ownership:
  - `aoa-stats` owns the shared cross-repo receipt envelope / event-kind registry
  - owner repos own payload schemas and payload meaning
  - `aoa-evals` remains owner of `eval_result_receipt` payload semantics, not of the whole shared event family

## Success condition

After the fixpack lands, the system should have:

- one explicit shared event vocabulary
- diagnosis as a first-class detail receipt
- validation that rejects unknown event kinds early
- non-empty committed fixtures for core-skill and runtime-closeout summaries
- example/live evidence refs that point to inspectable run artifacts
- a clear canonical owner for the shared envelope
- an automated readiness check for all required live publishers
