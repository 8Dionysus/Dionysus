# Codex handoff: ToS graph curation surface in `abyss-stack`

## Intent

Implement a **v1 route-first graph curation surface** for Tree of Sophia inside `abyss-stack`.

This is **not** a new authority layer. It is a runtime/body surface for:

- projecting canonical ToS tree + relation-pack data into Neo4j
- making the current bounded route visible and editable
- generating safe file patches back into the mounted `Tree-of-Sophia` checkout
- validating ToS after apply
- reprojecting Neo4j after successful writes

Default stance: **safe, reversible, localhost-only, read-first, write-by-explicit-toggle**.

---

## Non-negotiables

1. **ToS remains source of truth.**
   - Canonical truth lives in `Tree-of-Sophia/tree/**/node.json`
   - Canonical route-local relations live in `Tree-of-Sophia/tree/relations/**/edges.csv`
   - `intake/` remains a review ledger / candidate layer, not authority
   - Neo4j is a projection/query layer only

2. **Do not merge runtime and meaning layers.**
   - `abyss-stack` owns runtime, deployment, storage, service posture
   - `Tree-of-Sophia` owns authored meaning, canonical tree, canonical relation packs, registries

3. **Module first, profile second.**
   - Add a compose module first
   - Then add a profile inclusion
   - Do not hide this inside existing modules

4. **Localhost only.**
   - Host exposure must remain `127.0.0.1`
   - No widening to `0.0.0.0` on the host

5. **Minimal reversible v1.**
   - One lightweight helper service first
   - Do not split into API + web + worker unless the repo shape forces it
   - Prefer a single service with UI + API

6. **Respect repo guidance.**
   - Follow `abyss-stack/AGENTS.md`
   - Follow `abyss-stack/config-templates/AGENTS.md`
   - Follow `abyss-stack/scripts/AGENTS.md`
   - When invoking or writing into mounted ToS, respect `Tree-of-Sophia/AGENTS.md`, `tree/AGENTS.md`, and `intake/AGENTS.md`

---

## Architectural decision

### Chosen shape

Add a new helper service:

- service name: `tos-graph`
- compose module: `compose/modules/52-tos-graph.yml`
- profile: `compose/profiles/curation.txt`
- build context: `config-templates/Services/tos-graph/`
- public-safe config family: `config-templates/Configs/tos-graph/`

### Why this shape

- `abyss-stack` already has Neo4j in `10-storage.yml`
- lightweight helper services already live under `config-templates/Services/*`
- current helper-service pattern is Python + container-local app + uvicorn
- profiles are ordered lists of modules
- new capability should enter through a module, then optional profile inclusion

### Why not put this in ToS

Because this is runtime/UI/projection/edit tooling, not authored meaning.

### Why not edit Neo4j directly

Because ToS doctrine is explicit:

- tree for orientation
- graph for relation
- source for authority

So Neo4j is a fast shadow, not the sun.

---

## Scope of v1

### Must have

1. Read current canonical ToS data from a mounted source checkout
   - `tree/**/node.json`
   - `tree/relations/**/edges.csv`
   - `tree/registries/predicates.csv`
   - `tree/registries/classes.csv`

2. Project canonical data into Neo4j
   - include node family
   - include route/work/author metadata
   - include source file path
   - include digest / last-seen checksum
   - include enough node payload for inspector rendering
   - include edge attributes from relation pack

3. UI with three panes
   - left: rooted route/tree navigator
   - center: graph scene
   - right: inspector + edit / patch preview

4. Route-first default
   - start from current bounded Zarathustra route
   - do not default to whole-corpus graph soup

5. Inspector support for source nodes
   - `source_anchor`
   - `key_terms`
   - `distilled_thesis`
   - `relations`
   - `language_witnesses`
   - `translation_tensions`

6. Inspector support for relation rows
   - `edge_id`
   - `edge_kind`
   - `from_id`
   - `predicate_id`
   - `to_id`
   - `layer`
   - `anchor_mode`
   - `anchor_start_secondary`
   - `anchor_end_secondary`
   - `anchor_segment_ids`
   - `witness_scope`
   - `connectivity_role`
   - `confidence`
   - `note`

7. Patch-based editing
   - preview before apply
   - file-targeted patch plan, not blind database mutation
   - explicit write mode toggle
   - show affected files before apply

8. Validation after apply
   - run ToS validators from mounted checkout
   - abort / roll back on validation failure
   - only reproject Neo4j after successful validation

### Nice to have if cheap

- expand-neighbors graph action
- family filters
- edge list table for selected route
- node-path deep link
- local saved viewport state per route
- diff view before apply

### Explicitly out of scope for v1

- multi-user auth
- collaborative editing
- whole-world-thought atlas UX
- source OCR / ingestion workflows
- automatic ontology expansion
- editing mirrored `Knowledge/federation/tos-source/` as if it were canon
- silent git commits
- LLM-driven autonomous canonical writes

---

## Critical data sources and writeback rules

### Read sources

Read directly from the mounted `Tree-of-Sophia` source checkout, not from the mirrored federation handoff.

Use `AOA_TOS_ROOT` as the source-checkout root unless the repo shape clearly requires a narrower variable.

Mount it into the container at something stable like:

- `/workspace/Tree-of-Sophia`

### Write targets

#### Canonical node edits

Write into the correct `tree/**/node.json` file.

#### Canonical relation edits

Treat relation edits as **dual-surface work**:

1. canonical route-local pack:
   - `tree/relations/.../edges.csv`

2. companion candidate ledger:
   - `intake/thus-spoke-zarathustra/prologue-1/mode-b/edges.csv` for the current bounded route
   - for future routes, resolve the matching intake ledger dynamically from repo structure rather than hardcoding assumptions

Why dual-surface:
- canonical relation pack is documented as a reviewed projection from intake
- `tree/` is canon, but `intake/` still carries the review ledger and status split

### Registry posture

`predicate_id` must remain registry-first.

For v1:
- only allow selecting existing `predicate_id` values from `tree/registries/predicates.csv`
- do not implement free-form new predicate creation in the first pass
- compatibility should be checked against `tree/registries/classes.csv`

This avoids accidental registry drift.

---

## Important count / documentation tension to account for

Do **not** hardcode edge counts from one document alone.

There is a visible documentation tension in current repo surfaces:

- canonical relation-pack contract says canonical pack has **125 promoted edges**
- current route-local canonical `tree/relations/.../edges.csv` has **126 lines total**, i.e. header + 125 rows
- but the current `intake/.../mode-b/README.md` describes the edge ledger as:
  - 122 `promoted`
  - 3 `deferred_literal`
  - 2 `deferred_analogy`
  - 1 `deferred_commentary`

So Codex should:

1. trust current files + validators over prose counts
2. surface any mismatch as a warning in logs / UI diagnostics
3. avoid embedding brittle numeric assumptions into codepaths

---

## Recommended service shape

### Service name

`tos-graph`

### Runtime posture

- one Python service
- serves both API and web UI
- host-facing health endpoint
- localhost-only published port
- internal connection to Neo4j over service network
- mounted ToS source checkout
- mounted writable log directory for patch previews / apply reports

### Suggested host port

- `127.0.0.1:5410:5410`

### Suggested container internals

- app path: `/app`
- ToS source mount: `/workspace/Tree-of-Sophia`
- patch / report logs: `/app/logs`

### Suggested env

Use secret-bearing values in `Secrets/Configs/tos-graph.env`, not public-safe templates.

Suggested env keys:

- `TOS_GRAPH_PORT=5410`
- `TOS_GRAPH_NEO4J_URI=bolt://neo4j:7687`
- `TOS_GRAPH_NEO4J_USER=neo4j`
- `TOS_GRAPH_NEO4J_PASSWORD=...`
- `TOS_GRAPH_TOS_ROOT=/workspace/Tree-of-Sophia`
- `TOS_GRAPH_WRITE_ENABLED=false`
- `TOS_GRAPH_ROUTE_DEFAULT=friedrich-nietzsche/thus-spoke-zarathustra/prologue-1`
- `TOS_GRAPH_LOG_ROOT=/app/logs`

If the stack already centralizes Neo4j auth elsewhere, reuse the existing contract rather than duplicating secrets gratuitously.

---

## UI choice

### Primary recommendation

Use **Cytoscape.js** for the main graph pane.

Why:
- graph visualization and analysis fit
- interactive graph UX
- layout support
- JSON-friendly data flow
- better primary fit for relation exploration than a pure node-diagram editor

### Secondary / optional note

If Codex strongly prefers a node-editor feel for manual arrangement, a later second-surface can use React Flow.
But do **not** make React Flow the primary v1 explorer unless there is a clear implementation advantage in the repo context.

### UX posture

Do not build one giant force graph and call it clarity.

Prefer:

- route-first loading
- explicit expand controls
- stable family styling
- filters over spectacle
- visible provenance over decorative graph motion

---

## Data model for projection

### Projected node fields

At minimum project:

- `node_id`
- `node_type` or family
- `canonical_label` if available
- `source_anchor`
- `key_terms`
- `distilled_thesis`
- `interpretation_layers`
- `relations`
- `route_path`
- `source_file_path`
- `source_file_sha256`
- `language_witnesses` (for source nodes)
- `translation_tensions` (for source nodes)
- raw payload snapshot for inspector use

### Projected edge fields

At minimum project every canonical relation-pack field:

- `edge_id`
- `edge_kind`
- `from_id`
- `predicate_id`
- `to_id`
- `layer`
- `anchor_mode`
- `anchor_start_secondary`
- `anchor_end_secondary`
- `anchor_segment_ids`
- `witness_scope`
- `connectivity_role`
- `confidence`
- `note`
- `route_path`
- `source_file_path`
- `source_file_sha256`

### Labels / indexes

Use practical labels / indexes, for example:

- labels by family: `Source`, `Concept`, `Principle`, `Lineage`, `Event`, `State`, `Support`, `Analogy`, `Synthesis`
- indexes / constraints on `node_id`, `edge_id`
- optional route index

Keep the projection schema boring and inspectable.

---

## API shape

Keep it thin and operator-legible.

Suggested endpoints:

- `GET /health`
- `GET /api/routes`
- `GET /api/tree?route=...`
- `GET /api/graph?route=...`
- `GET /api/nodes/{node_id}`
- `GET /api/edges/{edge_id}`
- `POST /api/project/sync`
- `POST /api/patch/preview`
- `POST /api/patch/apply`
- `POST /api/validate`

### `POST /api/patch/preview`

Should return:

- affected repo files
- old vs new snippets or structured diffs
- validators that will run on apply
- whether write mode is enabled
- warnings about intake/tree dual-surface alignment

### `POST /api/patch/apply`

Should:

1. verify write mode enabled
2. write patches to mounted checkout
3. run validation suite
4. if validation fails:
   - revert or restore from in-memory / temp-file backup
   - return failure payload with validator stderr/stdout
5. if validation passes:
   - reproject Neo4j for affected route
   - return success payload with changed files and validation summary

---

## File plan in `abyss-stack`

### New files

```text
compose/modules/52-tos-graph.yml
compose/profiles/curation.txt

config-templates/Configs/tos-graph/
  README.md
  config.yaml

config-templates/Services/tos-graph/
  Dockerfile
  requirements.txt
  app/
    main.py
    config.py
    neo4j_store.py
    tos_reader.py
    tos_writer.py
    projector.py
    validators.py
    patching.py
    models.py
    ui/
      ...static assets...
```

### Files likely to update

```text
README.md
docs/ARCHITECTURE.md
docs/SERVICE_CATALOG.md
docs/PROFILES.md
docs/PROFILE_RECIPES.md
docs/DEPLOYMENT.md
docs/STORAGE_LAYOUT.md
docs/RENDER_TRUTH.md
config-templates/README.md
scripts/aoa-install-layout
scripts/aoa-bootstrap-configs
scripts/aoa-check-layout
scripts/aoa-profile-endpoints
scripts/aoa-smoke
scripts/aoa-internal-probes   # only if needed by implementation
scripts/validate_stack.py
```

### Optional docs file

Add a focused doc:

```text
docs/TOS_GRAPH_CURATION.md
```

with:
- purpose
- boundaries
- startup
- source mount contract
- writeback / validation contract
- route-first UX note

### Presets

Do **not** add a preset in v1 unless there is a very common operating bundle that truly benefits from a named preset.

Profile composition is already enough:
- `core + curation`
- `agentic + federation + curation`

---

## Compose module sketch

Use the same general helper-service posture as existing Python helper services.

Rough shape:

```yaml
services:
  tos-graph:
    build: "${AOA_STACK_ROOT:-/srv/abyss-stack}/Services/tos-graph"
    container_name: tos-graph
    env_file:
      - "${AOA_STACK_ROOT:-/srv/abyss-stack}/Secrets/Configs/tos-graph.env"
    environment:
      TOS_GRAPH_TOS_ROOT: /workspace/Tree-of-Sophia
      TOS_GRAPH_LOG_ROOT: /app/logs
    volumes:
      - "${AOA_STACK_ROOT:-/srv/abyss-stack}/Logs/tos-graph:/app/logs:Z"
      - "${AOA_TOS_ROOT:-/srv/Tree-of-Sophia}:/workspace/Tree-of-Sophia:rw,Z"
    depends_on:
      neo4j:
        condition: service_started
    ports:
      - "127.0.0.1:5410:5410"
    healthcheck:
      test: ["CMD", "python", "-c", "import urllib.request; urllib.request.urlopen('http://127.0.0.1:5410/health', timeout=2).read()"]
      interval: 5s
      timeout: 3s
      retries: 12
      start_period: 5s
    restart: unless-stopped
```

Notes:
- keep host bind on `127.0.0.1`
- make the ToS source mount `rw` only if write mode is needed
- if Codex wants stricter safety, mount `ro` by default and add a second explicit write toggle path later

---

## Suggested Dockerfile posture

Mirror the existing lightweight helper-service pattern:

- Python base image
- `COPY requirements.txt`
- `pip install`
- `COPY app`
- run via `uvicorn`

Do not over-engineer the container.

---

## Verification path

### Repo-level in `abyss-stack`

Run at minimum:

```bash
python scripts/validate_stack.py
scripts/aoa-profile-modules --profile core --profile curation --paths
scripts/aoa-profile-endpoints --profile core --profile curation
scripts/aoa-render-services --profile core --profile curation
scripts/aoa-render-config --profile core --profile curation --write /tmp/abyss-core-curation.rendered.yml
```

Then:

```bash
scripts/aoa-up --profile core --profile curation
scripts/aoa-wait --profile core --profile curation
scripts/aoa-smoke --profile core --profile curation
```

### ToS validation path after writeback

When a patch touches ToS canonical surfaces, run from the mounted ToS repo:

```bash
python scripts/validate_tree_node_contracts.py
python scripts/validate_tree_relation_pack.py
python scripts/validate_intake_pack.py
python scripts/validate_tree_example_sync.py
python scripts/generate_kag_export.py
python scripts/validate_kag_export.py
```

Prefer targeted short-circuiting for preview, but on actual apply use the full relevant suite.

---

## Acceptance criteria

1. `core + curation` renders and starts cleanly.
2. `tos-graph` is reachable at `http://127.0.0.1:5410/health`.
3. The current bounded Zarathustra route can be loaded without whole-repo graph overload.
4. Source node inspector displays multilingual witness data and translation tensions.
5. Relation inspector displays canonical relation-pack fields.
6. Neo4j data can be regenerated from ToS canonical files.
7. Editing an existing relation row yields a patch preview that names both:
   - canonical relation pack file
   - companion intake edge ledger file (when applicable)
8. Apply is blocked when write mode is off.
9. Apply in write mode runs ToS validators and rolls back on failure.
10. Successful apply reprojects the affected route and reflects the change in UI.
11. No host-facing exposure widens beyond localhost.
12. No code path treats Neo4j as canonical truth.

---

## Guardrails for Codex

- Do not ask for a redesign if a narrow v1 can ship.
- Do not move authored meaning into `abyss-stack`.
- Do not rewrite ToS schema doctrine.
- Do not assume the mirrored `tos-source` seam is sufficient for canonical editing.
- Do not silently bypass `intake/` when relation-ledger parity matters.
- Do not create free-form predicates in v1.
- Do not hardcode brittle numeric expectations from docs when validators/files can decide.
- Do not add a giant JS build system if a small static UI is enough.
- Do not commit secret-bearing runtime files or rendered configs.

---

## Short implementation sequence

1. Add service build context under `config-templates/Services/tos-graph/`
2. Add config template family under `config-templates/Configs/tos-graph/`
3. Add compose module `52-tos-graph.yml`
4. Add profile `curation.txt`
5. Update layout/bootstrap/check scripts
6. Update validation script(s) and endpoint docs
7. Implement read + projection
8. Implement inspector + route-first UI
9. Implement patch preview
10. Implement apply + validation + rollback
11. Add docs and smoke checks

---

## Ready-to-paste instruction for Codex

Implement the v1 described in this file directly inside `abyss-stack`, following existing repo conventions and AGENTS guidance. Preserve the boundary that ToS canonical files are the source of truth and Neo4j is only a projection layer. Add a minimal helper service `tos-graph`, a new compose module `52-tos-graph.yml`, and a `curation` profile. Make the UI route-first and focused on the current bounded Zarathustra route. Default to read-only; writes must be explicit, patch-based, and validated against the mounted `Tree-of-Sophia` checkout before Neo4j is reprojected. Prefer one lightweight Python helper service over a multi-service frontend/backend split unless the repo strongly requires otherwise.
