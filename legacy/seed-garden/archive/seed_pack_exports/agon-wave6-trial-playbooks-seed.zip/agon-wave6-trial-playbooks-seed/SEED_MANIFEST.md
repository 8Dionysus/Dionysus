# Agon Wave VI Seed: Trial Playbooks

This seed plants **Wave VI: Trial Playbooks**.

It is a multi-repository seed:

```text
Agents-of-Abyss/   center handoff, stop-lines, owner request
aoa-playbooks/     primary trial choreography landing
```

Wave VI does **not** create a live arena protocol. It does not create sessions, sealed commits, verdicts, scars, retention, rank mutation, or Tree-of-Sophia promotion. It turns the first mechanical Agon trials into reviewable, recurring playbook-layer choreography.

## Planting order

1. Merge `Agents-of-Abyss/` into the `Agents-of-Abyss` repository.
2. Merge `aoa-playbooks/` into the `aoa-playbooks` repository.

The center goes first because it publishes the owner request and stop-lines. `aoa-playbooks` goes second because it accepts trial choreography authority without absorbing arena law.

## Verification

In `Agents-of-Abyss`:

```bash
python scripts/build_agon_trial_playbook_request.py --check
python scripts/validate_agon_trial_playbook_request.py
python -m pytest -q tests/test_agon_trial_playbook_request.py
```

In `aoa-playbooks`:

```bash
python scripts/build_agon_trial_playbook_registry.py --check
python scripts/validate_agon_trial_playbooks.py
python -m pytest -q tests/test_agon_trial_playbooks.py
```

## What is planted

Seven pre-protocol mechanical trial playbooks:

```text
AOA-P-0033 agon-broken-trace-trial
AOA-P-0034 agon-fallback-honor-trial
AOA-P-0035 agon-contradiction-endurance-trial
AOA-P-0036 agon-costly-closure-trial
AOA-P-0037 agon-assistant-escalation-trial
AOA-P-0038 agon-prediction-trial
AOA-P-0039 agon-expensive-summon-intent-trial
```

These IDs follow the currently visible `AOA-P-0032` playbook line. If the live repository has advanced, Codex should reassign IDs while preserving trial IDs and slugs.

## Core invariant

```text
A trial playbook choreographs a repeatable pre-protocol test.
It does not open the arena.
```
