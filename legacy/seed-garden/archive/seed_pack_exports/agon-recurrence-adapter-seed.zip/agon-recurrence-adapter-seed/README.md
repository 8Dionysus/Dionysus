# Agon Recurrence Adapter

This seed is a multi-repository adapter between the already-planted Agon waves and the recurrence control plane.

It adds:

```text
Agents-of-Abyss/   center request, stop-lines, center recurrence component
aoa-sdk/           recurrence adapter registry and review-surface examples
aoa-agents/        actor formation recurrence component
aoa-routing/       gate routing recurrence component
aoa-playbooks/     trial playbook recurrence component
aoa-techniques/    technique binding recurrence component
aoa-skills/        skill binding recurrence component
```

It does not create arena runtime.

It does not open sessions.

It does not issue verdicts.

It does not write scars.

It does not schedule retention.

It does not mutate ranks.

It does not promote anything to `Tree-of-Sophia`.

The adapter makes Agon surfaces observable by recurrence as review pressure.
