# Patch Notes

- Adds center request for an Agon recurrence adapter.
- Adds `aoa-sdk` recurrence adapter registry and examples.
- Adds recurrence component manifests and hook binding sets for Agon surfaces in:
  - `Agents-of-Abyss`
  - `aoa-agents`
  - `aoa-routing`
  - `aoa-playbooks`
  - `aoa-techniques`
  - `aoa-skills`
- Keeps all components pre-protocol and observation-only.
- Does not change existing core profile schemas, move registries, routing registries, playbook bundles, technique candidates, or skill candidates.
