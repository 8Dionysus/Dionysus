# Codex Landing Brief: Agon Recurrence Adapter

Treat this as a reviewable interlude between Agon Wave VI and Wave VII.

Do not merge it as a scheduler, installer, protocol runtime, or hidden automation layer.

The intended effect is narrow:

```text
Agon surfaces -> recurrence component manifests -> hook observations -> review queues / dossiers / owner summaries
```

Owner repos keep their meaning. Recurrence produces observations. The future Court / Memo / Stats Prebinding wave can then consume reviewable recurrence surfaces.
