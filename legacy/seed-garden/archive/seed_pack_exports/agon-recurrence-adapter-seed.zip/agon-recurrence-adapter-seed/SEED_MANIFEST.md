# Agon Recurrence Adapter Seed

## Interlude

Recurrence Interlude R4: **Agon Recurrence Adapter**.

## Purpose

Waves 0–VI planted Agon law, actor formation, assistant civil boundaries, formation trial, lawful moves, owner bindings, gate routing, and trial playbooks.

Recurrence has also been planted as a control plane for repeated signals, review queues, dossiers, owner summaries, and wiring rollout.

This seed connects them.

It teaches Recurrence to observe Agon surfaces as owner-owned recurrence components without creating arena sessions, verdicts, scars, retention, rank mutation, or Tree-of-Sophia promotion.

## Planting order

```text
1. Agents-of-Abyss
2. aoa-sdk
3. Agents-of-Abyss/manifests recurrence component
4. aoa-agents
5. aoa-routing
6. aoa-playbooks
7. aoa-techniques
8. aoa-skills
```

The center lands first because it requests the adapter and publishes the stop-lines. `aoa-sdk` lands second because recurrence control-plane registry belongs there. Owner manifests land after that because they expose source-owned Agon surfaces to recurrence without transferring authority.

## Verification

In `Agents-of-Abyss`:

```bash
python scripts/build_agon_recurrence_adapter_request.py --check
python scripts/validate_agon_recurrence_adapter_request.py
python -m pytest -q tests/test_agon_recurrence_adapter_request.py
```

In `aoa-sdk`:

```bash
python scripts/build_agon_recurrence_adapter_registry.py --check
python scripts/validate_agon_recurrence_adapter.py
python -m pytest -q tests/test_agon_recurrence_adapter.py
```

Owner manifests are recurrence inputs. They should be reviewed with the generic recurrence tooling after the Hook Pack / Review Surfaces / Wiring Rollout are landed.

## Core invariant

```text
Recurrence observes repeated Agon pressure.
Recurrence does not decide Agon outcomes.
```

This seed is not Wave VII. It is the bridge that lets Wave VII consume recurrence review surfaces instead of raw noise.
