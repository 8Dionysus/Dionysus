# Rollout order

1. Install the AoA subagent TOMLs in one of two places:
   - personal: `~/.codex/agents/`
   - project/workspace: `.codex/agents/`

2. Choose workspace scope:
   - default-safe: use `~/.codex/AGENTS.md` and personal agents
   - sibling-workspace: set `project_root_markers = ["AOA_WORKSPACE_ROOT"]` in `~/.codex/config.toml`,
     add the `AOA_WORKSPACE_ROOT` marker to the shared root, and place `AGENTS.md` plus `.codex/` there

3. Test explicit spawning with one of the prompt recipes in `prompts/`.

4. Only after subagents feel stable, implement the real read-only `aoa-stats` MCP server.

5. After `aoa-stats` MCP proves calm, choose the next surface:
   - `Dionysus` for seed / staging / planting lineage
   - `aoa-memo` for provenance-aware memory recall
   - `aoa-playbooks` for launcher patterns over recurring multi-layer routes

6. Keep one rule sacred:
   every new Codex surface should preserve existing ownership lines instead of flattening them.
