#!/usr/bin/env python3
"""Build Codex custom-agent TOML files from aoa-agents profile JSON files.

Usage:
    python build_codex_subagents.py \
      --source-root /path/to/aoa-agents \
      --out /path/to/.codex/agents
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

REASONING_MAP = {
    "architect": "high",
    "coder": "medium",
    "reviewer": "high",
    "evaluator": "high",
    "memory-keeper": "medium",
}

SANDBOX_MAP = {
    "architect": "read-only",
    "coder": "workspace-write",
    "reviewer": "read-only",
    "evaluator": "read-only",
    "memory-keeper": "read-only",
}

NICKNAMES = {
    "architect": ["Atlas", "Frame", "Keystone"],
    "coder": ["Forge", "Anvil", "Needle"],
    "reviewer": ["Lens", "Gauge", "Sieve"],
    "evaluator": ["Axiom", "Scale", "Verdict"],
    "memory-keeper": ["Archive", "Ledger", "Thread"],
}


def toml_string_list(items: list[str]) -> str:
    return "[" + ", ".join(json.dumps(item, ensure_ascii=False) for item in items) + "]"


def make_description(profile: dict[str, Any]) -> str:
    name = profile["name"]
    summary = str(profile.get("summary", "")).rstrip(".")
    return f"AoA {name.replace('-', ' ')} specialist. Use for {summary}."


def emit(profile: dict[str, Any]) -> str:
    name = profile["name"]
    mission = profile.get("mission", "")
    owns = profile.get("owns", [])
    does_not_own = profile.get("does_not_own", [])
    preferred_skill_families = profile.get("preferred_skill_families", [])
    handoff_triggers = profile.get("handoff_triggers", [])

    body: list[str] = []
    body.append(f"You are the AoA {name} subagent.")
    body.append("")
    body.append("Mission")
    body.append(f"- {mission}")
    body.append("")
    body.append("Own")
    body.extend(f"- {item}" for item in owns)
    body.append("")
    body.append("Do not absorb")
    body.extend(f"- {item}" for item in does_not_own)
    body.append("")
    body.append("Preferred skill families")
    body.extend(f"- {item}" for item in preferred_skill_families)
    body.append("")
    body.append("Operating rules")
    body.append("- Stay source-of-truth aware. Name the owner repo or owner surface before widening scope.")
    body.append("- Cite concrete files, docs, schemas, or generated surfaces for important claims.")
    if name == "coder":
        body.append("- Make the smallest defensible change. Keep unrelated files untouched.")
        body.append("- Run only the validation that the nearest repo AGENTS requires for the slice you changed.")
        body.append("- Emit explicit state deltas: files changed, commands run, checks run, and remaining follow-up.")
    elif name == "reviewer":
        body.append("- Lead with concrete findings and contradiction risks, not vague style commentary.")
        body.append("- Check boundedness, evidence sufficiency, and handoff readiness.")
        body.append("- Emit a verification result with pass/fail/ambiguity plus evidence references.")
    elif name == "architect":
        body.append("- Lead with boundary map and route framing before proposing structural change.")
        body.append("- When ambiguity persists, recommend handoff instead of silently stealing neighboring-layer meaning.")
        body.append("- Emit a bounded route/frame note with owner repo, boundary call, in-scope slice, out-of-scope slice, and next hop.")
    elif name == "evaluator":
        body.append("- Judge only against named criteria.")
        body.append("- Prefer comparison discipline and arbitration notes over broad philosophical verdicts.")
        body.append("- Emit a bounded evaluation note naming criteria, comparison basis, verdict, and unresolved points.")
    elif name == "memory-keeper":
        body.append("- Preserve provenance and retention posture without turning memory into the owner of every artifact.")
        body.append("- Prefer explicit lineage and owner handoff over silent writeback.")
        body.append("- Emit a provenance note or memory-candidate pack with owner repo, evidence chain, retention posture, and unresolved ownership questions.")
    body.append("")
    body.append("Escalate when")
    body.extend(f"- {item}" for item in handoff_triggers)
    return "\n".join(body)


def profile_to_toml(profile: dict[str, Any]) -> str:
    name = profile["name"]
    lines = []
    lines.append("# Generated from aoa-agents profile JSON.")
    lines.append(f"name = {json.dumps(name)}")
    lines.append(f"description = {json.dumps(make_description(profile), ensure_ascii=False)}")
    lines.append(f"model_reasoning_effort = {json.dumps(REASONING_MAP.get(name, 'medium'))}")
    lines.append(f"sandbox_mode = {json.dumps(SANDBOX_MAP.get(name, 'read-only'))}")
    lines.append(f"nickname_candidates = {toml_string_list(NICKNAMES.get(name, []))}")
    lines.append('developer_instructions = """')
    lines.append(emit(profile))
    lines.append('"""')
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-root", required=True, help="Path to aoa-agents checkout root")
    parser.add_argument("--out", required=True, help="Output directory for .toml files")
    args = parser.parse_args()

    source_root = Path(args.source_root)
    profiles_dir = source_root / "profiles"
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    if not profiles_dir.is_dir():
        raise SystemExit(f"Profiles directory not found: {profiles_dir}")

    count = 0
    for profile_path in sorted(profiles_dir.glob("*.profile.json")):
        with profile_path.open("r", encoding="utf-8") as f:
            profile = json.load(f)
        target = out_dir / f"{profile['name']}.toml"
        target.write_text(profile_to_toml(profile), encoding="utf-8")
        count += 1

    print(f"Wrote {count} subagent files to {out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
