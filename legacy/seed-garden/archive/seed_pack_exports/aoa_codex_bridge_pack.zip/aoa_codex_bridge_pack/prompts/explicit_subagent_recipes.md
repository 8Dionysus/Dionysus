# Explicit subagent recipes for AoA work

Codex only spawns subagents when asked directly. These prompt starters are shaped for the generated AoA agents.

## Cross-repo route framing

Spawn `architect` to map owner repos, source-of-truth boundaries, and cross-repo risks for this task. Wait for the result, then summarize the smallest next step.

## Bounded implementation pass

Have `architect` frame the route and boundary risks, `coder` make the smallest defensible change, and `reviewer` verify boundedness plus missing validation. Wait for all and summarize what changed, what was checked, and what remains open.

## Arbitration / regression pass

Ask `reviewer` to surface contradictions and `evaluator` to compare the strong options or judge regression significance. Wait for both and summarize the deciding criteria.

## Provenance / harvest pass

Spawn `memory-keeper` to trace provenance, candidate lineage, and retention posture. Then have `reviewer` check evidence sufficiency and handoff readiness.
