# AoA Codex bridge pack v0

This pack turns the crosswalk into a concrete starting scaffold:

- AoA role profiles projected into Codex custom subagents
- a workspace-level `AGENTS.md` for sibling-repo law
- a home-level fallback `AGENTS.md`
- a `project_root_markers` trick for true cross-sibling workspace discovery
- a first read-only MCP contract for `aoa-stats`
- explicit prompt recipes for invoking subagents

## What is inside

- `subagents/`: ready-to-copy Codex custom-agent TOMLs
- `templates/home/`: fallback home-level Codex guidance
- `templates/workspace-root/`: files for a shared sibling workspace root
- `tools/build_codex_subagents.py`: generator that rebuilds the TOMLs from `aoa-agents/profiles/*.profile.json`
- `contracts/aoa_stats_mcp_contract_v0.md`: first MCP seam for `aoa-stats`
- `prompts/`: explicit subagent invocation starters
- `notes/rollout_order.md`: install order

## Two install modes

### 1) Default-safe

Use personal Codex scope only:

- copy `subagents/*.toml` to `~/.codex/agents/`
- copy `templates/home/AGENTS.md` to `~/.codex/AGENTS.md`
- optionally merge `templates/home/config.snippet.toml` into `~/.codex/config.toml`

This works even if each AoA repo stays its own separate git-rooted project.

### 2) True sibling-workspace mode

Use this if you want one shared root above multiple AoA repos to act as the Codex project root:

- merge `templates/home/config.snippet.toml` into `~/.codex/config.toml`
- place `templates/workspace-root/AOA_WORKSPACE_ROOT` at the shared root
- place `templates/workspace-root/AGENTS.md` at the shared root
- place `templates/workspace-root/.codex/config.toml` at the shared root
- place `subagents/*.toml` in `<workspace-root>/.codex/agents/`

Why this exists:
with default Codex project-root discovery, an inner repo `.git` wins. A workspace root above sibling repos will not be read unless you deliberately change root markers.

## First test

Use one explicit prompt from `prompts/explicit_subagent_recipes.md`.

Start with:

> Have `architect` frame the route and boundary risks, `coder` make the smallest defensible change, and `reviewer` verify boundedness plus missing validation. Wait for all and summarize.

## What I would do next

1. Install the subagents and test explicit spawn behavior.
2. Keep `aoa-stats` MCP read-only and generated-surface-first.
3. Only then wire `Dionysus` as the next MCP/resource surface.
