# aoa-stats MCP contract v0

Purpose: give Codex read-only access to `aoa-stats` as a derived observability layer without letting the MCP surface become proof authority, workflow authority, or route authority.

## Why `aoa-stats` is a good first MCP surface

- It already consumes source-owned receipts and emits machine-readable generated summaries.
- It has a compact runtime entry capsule at `generated/summary_surface_catalog.min.json`.
- Its own repo law explicitly says source repos own meaning and `aoa-stats` owns derived views only.

## v0 principles

- Read-only only.
- Prefer `generated/*` and `config/live_receipt_sources.json`.
- Do not read raw owner-local receipt logs under `/srv/*/.aoa/live_receipts/*.jsonl` by default.
- Return file path, mtime, and schema hints where available.
- Do not interpret stats as proof, promotion, or owner meaning.

## Allowed paths

- `generated/*.json`
- `config/live_receipt_sources.json`
- `config/live_receipt_sources.example.json`
- `schemas/stats-event-envelope.schema.json`
- `docs/BOUNDARIES.md`
- `docs/ARCHITECTURE.md`
- `docs/LIVE_SESSION_USE.md`
- `AGENTS.md`

## Proposed tools

### `stats_catalog`

Read `generated/summary_surface_catalog.min.json`.

Returns:
- available summary surfaces
- surface refs
- schema refs when present
- owner repo markers when present

### `stats_surface_read`

Inputs:
- `surface_name` or `surface_ref`

Reads one whitelisted generated summary file, for example:
- `object_summary.min.json`
- `core_skill_application_summary.min.json`
- `repeated_window_summary.min.json`
- `route_progression_summary.min.json`
- `fork_calibration_summary.min.json`
- `automation_pipeline_summary.min.json`
- `runtime_closeout_summary.min.json`
- `stress_recovery_window_summary.min.json`
- `surface_detection_summary.min.json`
- `summary_surface_catalog.min.json`

Returns:
- parsed JSON
- path
- last modified time

### `stats_source_registry`

Read `config/live_receipt_sources.json` so Codex can understand which owner-local logs feed the derived surfaces without opening the logs themselves.

Returns:
- the source registry
- compact explanation of each registered source path

### `stats_boundary_rules`

Return a compact boundary capsule from `AGENTS.md` and/or `docs/BOUNDARIES.md`:
- what `aoa-stats` owns
- what it does not own
- anti-collapse rules
- validation commands

## Explicit non-goals

- no write tools
- no mutation of generated surfaces
- no raw live receipt tailing in v0
- no cross-repo promotion logic
- no candidate lineage inference beyond what committed/generated surfaces already expose

## Good first implementation target

A small STDIO MCP server inside `aoa-stats/tools/` or `aoa-stats/scripts/` that only exposes the four read-only tools above and validates requested paths against the allow-list.

## After v0

Possible v1 additions:
- `stats_window_compare`
- `stats_surface_schema`
- `stats_candidate_lineage_summary` once that surface exists
- controlled debug-only intake tools behind an explicit flag
