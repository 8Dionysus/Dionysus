# AGENTS.md

Workspace-level guidance for the sibling AoA workspace.

This file is meant for a shared root that contains sibling repositories such as:
`Agents-of-Abyss`, `aoa-agents`, `aoa-skills`, `aoa-evals`, `aoa-stats`, `aoa-memo`,
`aoa-playbooks`, `aoa-routing`, `aoa-sdk`, `Dionysus`, `Tree-of-Sophia`, and others.

Follow the nearest repo-local `AGENTS.md` after this one. This file sets cross-repo law, not repo-local doctrine.

## Cross-repo operating law

- Keep source-of-truth ownership explicit. Do not flatten AoA into one meta-repo in your head.
- Roles live in subagents. Workflows live in skills. Live or derived context belongs behind MCP or explicit reads. Repo law lives in `AGENTS.md`.
- When a task crosses repositories, name the owner repo for each claim and each changed artifact.
- Prefer the smallest source-owned change slice that preserves lineage and reviewability.
- Do not let `aoa-routing`, `aoa-stats`, `Dionysus`, or `aoa-sdk` silently become authority for neighboring layers.

## Default routing by need

- boundary ambiguity, source-of-truth fit, multi-repo decomposition -> `architect`
- approved bounded implementation -> `coder`
- boundedness, contradiction, handoff readiness -> `reviewer`
- explicit comparison, arbitration, regression significance -> `evaluator`
- provenance continuity, retention posture, memory-candidate preparation -> `memory-keeper`

## Layer reminders

- `aoa-skills` owns bounded workflow meaning.
- `aoa-agents` owns role contracts and posture. An agent is not a skill.
- `aoa-playbooks` owns recurring multi-surface scenario composition.
- `aoa-evals` owns proof doctrine and bounded verdict surfaces.
- `aoa-stats` owns derived views only. Read `generated/*` and the summary catalog first. Do not treat stats as proof or route authority.
- `Dionysus` is seed-garden and staging lineage, not the final owner when a stronger repo already exists.
- `aoa-routing` is thin navigation and dispatch support, not sovereignty.
- `aoa-sdk` is control-plane and typed consumer space, not a new center of meaning.

## Cross-repo validation posture

- For each changed repo, follow its nearest `AGENTS.md` validation section.
- Do not claim checks you did not run.
- When a task only changes crosswalk docs, do not pretend repo-level code validation happened.

## Explicit multi-agent recipes

Use direct requests when you want subagents:

1. "Spawn architect to map owner repos and boundary risks, then summarize the smallest next step."
2. "Have architect frame the route, coder make the smallest change, and reviewer verify boundedness. Wait for all and summarize."
3. "Spawn memory-keeper to trace provenance and candidate lineage, then reviewer to check evidence sufficiency."
