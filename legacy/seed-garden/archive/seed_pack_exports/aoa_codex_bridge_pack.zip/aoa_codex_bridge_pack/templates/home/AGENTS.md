# AGENTS.md

Global Codex guidance for AoA work.

Use this when you want cross-repo AoA law even before project-scoped workspace discovery is configured.

- Keep source-of-truth ownership explicit.
- Prefer repo-local `AGENTS.md` for repo law and validation, but keep these federation rules in mind.
- Roles belong in subagents. Workflows belong in skills. Derived/live context belongs in MCP or explicit file reads.
- Do not flatten `aoa-stats`, `aoa-routing`, `Dionysus`, or `aoa-sdk` into owner layers.
- For non-trivial AoA tasks, explicitly use: `architect`, `coder`, `reviewer`, `evaluator`, `memory-keeper`.
- Treat `aoa-stats` as derived and weaker than owner surfaces.
- Treat `Dionysus` as seed staging and lineage, not final ownership when a stronger repo exists.
