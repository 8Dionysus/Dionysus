# Wave 3 PR slices

## PR-1 Center doctrine extension
Repo:
- `Agents-of-Abyss`

Land:
- `docs/OWNER_LANDING_AND_PRUNING.md`

Acceptance:
- terminology aligns with `REVIEWABLE_GROWTH_REFINERY`
- owner status surface is weaker than landed object
- negative rules name stats/memo/routing boundaries

## PR-2 Provisional closeout follow-through map
Repo:
- `aoa-sdk`

Land:
- `docs/CLOSEOUT_FOLLOWTHROUGH_MAP.md`
- `schemas/closeout_owner_followthrough_map.schema.json`
- `examples/closeout_owner_followthrough_map.example.json`

Acceptance:
- `cluster_ref` allowed
- `candidate_ref`, `seed_ref`, `object_ref` forbidden
- map points toward owner status surfaces, not final ownership claims

## PR-3 Owner landing + follow-through contracts
Repo:
- `aoa-skills`

Land:
- `docs/OWNER_STATUS_SURFACES.md`
- `docs/GOVERNED_FOLLOWTHROUGH.md`
- landing/follow-through schemas and examples

Acceptance:
- `candidate_ref` required
- status posture vocabulary is explicit
- follow-through verdict vocabulary is explicit
- surfaces are reviewed-only

## PR-4 Seed-to-owner landing trace
Repo:
- `Dionysus`

Land:
- `docs/SEED_OWNER_LANDING_TRACE.md`
- trace schema and example

Acceptance:
- `seed_ref` required
- trace can end in landed, reanchored, merged, deferred, or dropped
- `Dionysus` still not final owner

## PR-5 Derived landing/prune summaries
Repo:
- `aoa-stats`

Land:
- owner landing summary doc/schema/example
- supersession/drop summary doc/schema/example

Acceptance:
- summaries are reviewed-only and derived-only
- no global growth score
- no owner truth inference from staging alone

## PR-6 Narrower owner-followthrough playbook
Repo:
- `aoa-playbooks`

Land:
- `playbooks/owner-followthrough-campaign/PLAYBOOK.md`

Acceptance:
- route starts after candidate identity exists
- route coordinates landing/reanchor/seed/drop without claiming owner authority
- stop and rollback posture are explicit

## PR-7 Prune writeback extension
Repo:
- `aoa-memo`

Land:
- `docs/GROWTH_REFINERY_PRUNE_WRITEBACK.md`

Acceptance:
- drop/supersede rules map to existing memo kinds
- strongest available lineage refs are preserved when known
- memo does not mint lineage identities
