# aoa_wave3_owner_landing_followthrough_pack

This pack proposes the next honest wave after:

1. center doctrine + candidate-lineage chain
2. stats/evals/playbooks/memo convergence

Wave 3 focuses on what happens **after** a reviewed `candidate_ref` exists:

- the candidate should land in tracked owner status surfaces
- the route should emit one bounded follow-through decision
- seed staging should connect cleanly to owner landing or honest drop/supersede
- stats should expose owner-landing and supersession/drop read models
- memo should preserve only bounded failure/recovery context, not become lineage authority
- a narrower playbook should exist for repeated owner-followthrough campaigns

This pack does not replace wave 1 or wave 2. It builds on them.

## Why this wave now

The current public AoA tree already says:
- checkpoint carry may name provisional lineage hints rooted in `cluster_ref`
- surviving candidates should land promptly in tracked owner status surfaces
- `Dionysus` is seed garden and dispatch, not final owner
- the session-growth cycle already expects `route_follow_through_decision`, `seed_trace`, `owner_landing_bundle`, `writeback_record`, and `stats_refresh_record`
- growth funnel and memo writeback seams already exist

What is still missing is a narrower operational law for:
- owner landing
- governed follow-through
- supersession / merge / drop
- prune discipline

## Main contracts

See:
- `contracts/owner_status_surface_contract_v1.md`
- `contracts/governed_followthrough_contract_v1.md`
- `contracts/supersession_drop_law_v1.md`

## Main proposed targets

- `proposed-targets/Agents-of-Abyss/docs/OWNER_LANDING_AND_PRUNING.md`
- `proposed-targets/aoa-sdk/docs/CLOSEOUT_FOLLOWTHROUGH_MAP.md`
- `proposed-targets/aoa-skills/docs/OWNER_STATUS_SURFACES.md`
- `proposed-targets/aoa-skills/docs/GOVERNED_FOLLOWTHROUGH.md`
- `proposed-targets/Dionysus/docs/SEED_OWNER_LANDING_TRACE.md`
- `proposed-targets/aoa-stats/docs/OWNER_LANDING_SUMMARY.md`
- `proposed-targets/aoa-stats/docs/SUPERSESSION_DROP_SUMMARY.md`
- `proposed-targets/aoa-memo/docs/GROWTH_REFINERY_PRUNE_WRITEBACK.md`
- `proposed-targets/aoa-playbooks/playbooks/owner-followthrough-campaign/PLAYBOOK.md`

## Order of work

1. center extension
2. `aoa-sdk` closeout follow-through map
3. `aoa-skills` owner status + follow-through contracts
4. `Dionysus` seed-to-owner landing trace
5. `aoa-stats` owner landing and supersession/drop summaries
6. `aoa-playbooks` owner-followthrough campaign
7. `aoa-memo` prune writeback seam

## Validation

Run:

```bash
python tools/validate_wave3_owner_landing.py --pack-root .
```

The validator checks cross-file coherence for:
- `cluster_ref` staying provisional in `aoa-sdk`
- `candidate_ref` appearing in landing/follow-through surfaces
- `seed_ref` appearing only in `Dionysus` trace and later
- owner landing status posture and verdict vocabularies
- supersede/drop fields and stats summary presence
