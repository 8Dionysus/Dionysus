Keep seed-owner trace subordinate to seed registry and planting protocol. Do not let it become final owner truth.
