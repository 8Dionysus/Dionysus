Prefer existing seam docs if present. Keep the new landing/follow-through surfaces reviewed-only and small. Do not add runtime authority.
