If a more natural home than CLOSEOUT_FOLLOWTHROUGH_MAP.md already exists in the closeout or session-growth docs, merge there and keep the schema/example stable.
