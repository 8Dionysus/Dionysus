Prefer extending existing doctrine docs near REVIEWABLE_GROWTH_REFINERY and CANDIDATE_LINEAGE_CROSSWALK rather than creating a wide new tree.
