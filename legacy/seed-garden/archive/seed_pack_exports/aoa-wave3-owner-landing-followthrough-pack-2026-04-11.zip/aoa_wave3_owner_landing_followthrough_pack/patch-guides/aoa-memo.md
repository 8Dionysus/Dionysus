Merge prune writeback into existing growth-refinery writeback doc if that is the repo’s clearer home.
