Add new summaries to generated catalog only if repo conventions require it. Keep the summaries derived-only and reviewed-only.
