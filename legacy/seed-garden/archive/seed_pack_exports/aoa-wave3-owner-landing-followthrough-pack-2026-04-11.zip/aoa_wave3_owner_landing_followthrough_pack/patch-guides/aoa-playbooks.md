If a better existing playbook name exists, adapt into that family and leave a relocation note.
