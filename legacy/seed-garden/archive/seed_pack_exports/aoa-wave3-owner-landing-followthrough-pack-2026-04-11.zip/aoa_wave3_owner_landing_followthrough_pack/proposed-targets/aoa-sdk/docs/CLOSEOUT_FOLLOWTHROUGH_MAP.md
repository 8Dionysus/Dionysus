# Closeout Follow-through Map

## Purpose
This surface lets reviewed closeout point surviving candidate pressure toward the first honest owner status landing.

It stays inside `aoa-sdk` because it is still a control-plane carry and reviewed-closeout navigation aid.
It does not mint reviewed candidate or landed owner truth.

## What it may carry
- `cluster_ref`
- a temporary `candidate_slot`
- owner hypothesis
- owner shape
- nearest wrong target
- recommended owner repo
- recommended first status posture
- evidence refs
- recommended decision class:
  - `land_direct`
  - `stage_seed`
  - `reanchor_owner`
  - `prove_first`
  - `defer`
  - `drop`

## What it may not carry
- real `candidate_ref`
- `seed_ref`
- `object_ref`

## Why it exists
Checkpoint carry can survive to reviewed closeout.
Closeout still needs one narrow map that says:
where should this reviewed pressure land first,
without pretending the landing already happened.
