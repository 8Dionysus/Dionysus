# Supersession Drop Summary

## Purpose
Expose one small derived read model for turnover:
- merge
- supersession
- drop

This is for visible pruning discipline, not for blame.

## Inputs
- reviewed owner landing bundles
- seed owner landing traces
- reviewed owner-local receipts that carry supersede or drop fields

## Questions answered
- what is getting replaced
- what is being dropped
- why discard happens
- where reanchor replaces drop

## Negative rules
Do not:
- invent drop reasons when owner surfaces did not record them
- infer supersession from silence
- turn this summary into ranking authority
