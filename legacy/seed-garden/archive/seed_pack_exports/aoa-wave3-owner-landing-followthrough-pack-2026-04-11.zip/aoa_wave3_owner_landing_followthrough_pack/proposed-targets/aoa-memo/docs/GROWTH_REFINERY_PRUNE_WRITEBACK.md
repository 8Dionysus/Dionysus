# Growth Refinery Prune Writeback

## Purpose
Extend the existing growth-refinery writeback seam with explicit prune cases.

## Write back failure lessons when
- a candidate repeatedly lands in the wrong owner
- the route repeatedly drops for the same bounded reason
- merge or supersession repeatedly happens because the initial owner-fit guess was weak
- seed staging repeatedly adds no value compared with direct owner landing

## Write back recovery patterns when
- the same reanchor move fixes owner fit more than once
- the same merge pattern preserves truth while reducing duplication
- the same proof-first rule prevents repeated thin-evidence landings

## Strongest lineage refs
Preserve the strongest available chain without minting it:
- `cluster_ref`
- `candidate_ref`
- `seed_ref`
- `object_ref`

## Negative rules
Do not:
- let prune writeback become the first record of drop truth
- let memory decide whether a candidate should be dropped
