# Owner Landing and Pruning

This note extends the center-level growth-refinery doctrine.

## Why this note exists
The reviewable growth-refinery chain already names:
`cluster_ref -> candidate_ref -> seed_ref -> object_ref`

What still needs a center-level guardrail is the stretch after `candidate_ref` appears:
- first owner-side status landing
- governed follow-through decision
- honest seed-to-owner trace
- visible merge, supersession, or drop

## Owner status surfaces
A tracked owner status surface is:
- weaker than a landed owner object
- stronger than runtime-local checkpoint carry
- stronger than an unlanded seed alone
- useful because it keeps reviewed candidates from disappearing into implied future work

## Canonical outcomes after reviewed candidate identity
A reviewed candidate may:
- land directly in an owner status surface
- stage a seed and later land
- reanchor to a different owner
- merge into an existing tracked object
- defer
- drop

Not every candidate should stage a seed.
Not every candidate should become a stable landed object.

## Prune law
Growth refinery includes:
- promotion
- stabilization
- merge
- supersession
- drop

Discard is part of honesty, not a failure of the doctrine.

## Negative rules
Do not:
- let `aoa-sdk` mint reviewed or landed identities
- let `Dionysus` become final owner truth
- let `aoa-stats` become landing authority
- let `aoa-memo` become prune authority
- let `aoa-routing` become owner status canon
