# Seed Owner Landing Trace

## Purpose
A seed is not the final owner object.
But once a reviewed candidate becomes a seed, the route needs a visible trace that says what happened next.

## Required identity
- `candidate_ref`
- `seed_ref`
- target owner repo
- target owner shape

## Allowed outcomes
- `landed_owner_status`
- `landed_owner_object`
- `reanchored`
- `merged`
- `deferred`
- `dropped`

## Why this exists
Without this trace:
- seed staging can look like completion
- stats can overread staging as landing
- pruning can disappear
- later memory writeback loses concrete route context

## Negative rules
Do not:
- let this trace outrank owner receipts
- let seed status alone count as proof or final landing
