# Owner Status Surfaces

## Purpose
A reviewed candidate should land promptly in a tracked owner status surface when it survives closeout and is not yet a stable landed owner object.

This surface is for:
- first owner landing
- reanchor after owner-fit correction
- thin-evidence holding
- later merge, supersession, or drop

## What this surface is not
It is not:
- raw checkpoint carry
- seed truth
- final object truth
- proof authority
- schedule authority

## Required identity
- `candidate_ref`
- strongest available earlier refs when known
- owner repo
- owner shape
- nearest wrong target

## Allowed status postures
- `early`
- `reanchor`
- `thin_evidence`
- `stable`
- `merged`
- `superseded`
- `dropped`

## Update law
Use explicit update fields:
- `supersedes`
- `merged_into`
- `drop_reason`

Do not silently replace the status history.
