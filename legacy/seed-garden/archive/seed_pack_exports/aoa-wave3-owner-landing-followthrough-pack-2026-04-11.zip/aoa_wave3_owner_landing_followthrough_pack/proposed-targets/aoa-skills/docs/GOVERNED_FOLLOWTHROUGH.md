# Governed Follow-through

## Purpose
Once a reviewed candidate exists, the route often still needs one small honest verdict:
what happens next.

This verdict must stay reviewable and bounded.
It does not become automation authority by itself.

## Allowed verdicts
- `land_direct`
- `stage_seed`
- `reanchor_owner`
- `prove_first`
- `merge_into_existing`
- `defer`
- `drop`

## Required reasoning fields
- why this verdict now
- why the nearest wrong target is still wrong
- what artifact comes next
- what stops the route
- whether approval is required

## Negative rules
Do not:
- call this a live queue
- call this a scheduler right
- treat a seed verdict as proof of landing
- treat a landing verdict as proof completion
