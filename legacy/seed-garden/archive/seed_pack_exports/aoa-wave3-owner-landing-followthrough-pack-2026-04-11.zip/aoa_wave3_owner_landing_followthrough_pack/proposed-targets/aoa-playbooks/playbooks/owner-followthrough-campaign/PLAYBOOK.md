---
id: AOA-P-0026
name: owner-followthrough-campaign
status: experimental
summary: Carry a reviewed candidate or seed through owner landing, reanchor, merge, defer, or drop without confusing tracked status surfaces for final owner truth.
scenario: owner_followthrough_campaign
trigger: reviewed_candidate_or_seed_needing_honest_next_owner_move
prerequisites:
  - reviewed_candidate_identity_named
  - owner_repo_and_owner_shape_named
  - nearest_wrong_target_named
  - proof_need_named_if_any
participating_agents:
  - architect
  - coder
  - reviewer
  - evaluator
required_skills:
  - aoa-session-route-forks
  - aoa-session-self-diagnose
  - aoa-session-self-repair
  - aoa-source-of-truth-check
  - aoa-change-protocol
  - aoa-contract-test
---
# owner-followthrough-campaign

## Intent
Use this playbook when the route has already passed reviewed harvest and now needs a bounded owner follow-through campaign.

This playbook is narrower than `session-growth-cycle`.
It starts after candidate identity exists.

## Expected artifacts
- `route_followthrough_decision`
- `reviewed_owner_landing_bundle`
- optional `seed_owner_landing_trace`
- optional proof packet
- optional prune writeback note
- optional stats refresh record

## Main decisions
1. land directly, stage seed, reanchor, prove first, merge, defer, or drop
2. decide whether seed staging adds value or only delays honest landing
3. decide whether thin-evidence landing is still useful
4. decide whether prune should happen now and be made visible

## Stop conditions
- owner boundary becomes unclear
- proof widens beyond bounded packet
- seed staging starts masquerading as completion
- drop reason is not explicit
