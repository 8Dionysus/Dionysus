# Wave 3 Acceptance Matrix

## Global
- [ ] No new sovereign lineage or landing layer is introduced.
- [ ] `cluster_ref` stays provisional.
- [ ] `candidate_ref` appears only after reviewed harvest.
- [ ] `seed_ref` appears only in `Dionysus` or later traces.
- [ ] owner landing surfaces are tracked status, not final landed object truth.
- [ ] supersede / merge / drop outcomes are explicit and reviewable.
- [ ] no global score is introduced.

## Center
- [ ] doctrine note names owner status surfaces and pruning law.
- [ ] negative rules keep stats, memo, routing, and seed layers bounded.

## aoa-sdk
- [ ] follow-through map exists.
- [ ] map does not mint `candidate_ref`, `seed_ref`, or `object_ref`.
- [ ] map can point to `early`, `reanchor`, or `thin_evidence` posture.

## aoa-skills
- [ ] owner landing bundle exists and requires `candidate_ref`.
- [ ] follow-through decision exists and uses bounded verdict vocabulary.
- [ ] landing bundle and decision both carry evidence refs.
- [ ] nearest wrong target remains explicit.

## Dionysus
- [ ] seed trace exists and requires `seed_ref`.
- [ ] trace can record stage-to-owner movement or honest drop.
- [ ] lifecycle stays weaker than owner truth.

## aoa-stats
- [ ] owner landing summary exists.
- [ ] supersession/drop summary exists.
- [ ] summaries use reviewed owner-local artifacts and traces only.
- [ ] staging alone does not count as landed.

## aoa-playbooks
- [ ] owner-followthrough playbook exists.
- [ ] route begins after candidate identity.
- [ ] route names fallback, rollback, and safe-stop posture.

## aoa-memo
- [ ] prune writeback rules map to existing memory kinds.
- [ ] drop and reanchor can be preserved without becoming source truth.
- [ ] strongest available lineage refs remain optional but explicit.
