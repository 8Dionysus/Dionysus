# supersession_drop_law_v1

## Purpose
Make pruning, replacement, merge, and discard visible.

Growth refinery is not only for promotion.
It must also support:
- honest drop
- merge into a stronger object
- supersession by a later better route
- reanchor after owner-fit correction

## Required visible fields
Use these when applicable:
- `supersedes`
- `superseded_by`
- `merged_into`
- `drop_reason`
- `drop_stage`
- `drop_evidence_refs`

## Minimal reasons
Suggested drop reason classes:
- `wrong_owner`
- `too_broad`
- `thin_evidence_persisted`
- `duplicate`
- `replaced_by_stronger_candidate`
- `seed_not_worth_staging`
- `repair_cost_not_honest`
- `proof_failed`
- `manual_route_preferred`

## Negative rules
Do not:
- hide discard behind disappearance
- treat drop as shameful noise
- let stats infer a reason when owner surfaces did not record it
- let memo become the first home of drop truth
