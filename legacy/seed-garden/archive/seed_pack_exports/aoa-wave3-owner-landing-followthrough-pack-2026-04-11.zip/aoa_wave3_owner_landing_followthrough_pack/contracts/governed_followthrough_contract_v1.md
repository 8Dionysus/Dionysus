# governed_followthrough_contract_v1

## Purpose
Define one bounded next-step decision after a reviewed candidate exists.

This decision is not a background runner.
It is not schedule authority.
It is a reviewable decision surface for the next honest move.

## Required identity
- `candidate_ref`
- strongest available earlier refs when known
- owner hypothesis fields
- evidence refs

## Allowed verdicts
- `land_direct`
- `stage_seed`
- `reanchor_owner`
- `prove_first`
- `merge_into_existing`
- `defer`
- `drop`

## Required fields
- `verdict`
- `why_now`
- `why_not_nearest_wrong_target`
- `owner_repo`
- `owner_shape`
- `stop_conditions`
- `next_artifact_kind`
- `approval_posture`

## Optional bounded fields
- `seed_required`
- `proof_bundle_hint`
- `writeback_hint`
- `stats_refresh_hint`

## Forbidden claims
This decision must not:
- pretend the route already ran
- create a live queue or scheduler right
- infer owner truth from seed staging alone
- infer proof completion from candidate landing alone
