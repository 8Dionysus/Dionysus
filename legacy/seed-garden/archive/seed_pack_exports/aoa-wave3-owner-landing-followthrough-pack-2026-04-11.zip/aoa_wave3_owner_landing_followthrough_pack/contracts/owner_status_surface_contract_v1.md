# owner_status_surface_contract_v1

## Purpose
Define the first tracked owner-side status surface for a reviewed growth-refinery candidate.

This surface is weaker than a landed owner object.
It exists so a candidate does not remain only in:
- runtime-local `.aoa` carry
- chat memory
- seed staging
- implied future work

## Required identity
- `candidate_ref`
- strongest available earlier lineage refs when known:
  - `cluster_ref`
- owner route fields:
  - `owner_repo`
  - `owner_shape`
  - `nearest_wrong_target`

## Required posture
One of:
- `early`
- `reanchor`
- `thin_evidence`
- `stable`
- `merged`
- `superseded`
- `dropped`

Meanings:
- `early`: first honest owner landing, evidence promising but not settled
- `reanchor`: previous owner target changed after review
- `thin_evidence`: land is useful but still weak
- `stable`: repeatedly reviewed enough to stop calling it early or thin
- `merged`: candidate joined another tracked object
- `superseded`: replaced by a later better landing
- `dropped`: intentionally discarded with reason

## Required evidence
- `evidence_refs`
- `reviewed_at`
- `status_note`

## Forbidden claims
This surface must not:
- mint `seed_ref`
- mint `object_ref`
- outrank owner-local landed objects
- outrank proof bundles
- act as scheduler authority

## Update law
Corrections use:
- `supersedes`
- `merged_into`
- `drop_reason`

Never silently overwrite status history.
