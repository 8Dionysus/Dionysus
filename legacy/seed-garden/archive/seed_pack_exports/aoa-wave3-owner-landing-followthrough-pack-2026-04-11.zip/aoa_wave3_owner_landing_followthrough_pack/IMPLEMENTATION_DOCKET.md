# Wave 3 Implementation Docket
## Name
Owner landing, governed follow-through, supersession, and prune discipline.

## Problem this wave solves

Wave 1 gave the chain.
Wave 2 gave derived funnel, proof, recurring cycle, and memo-side support.

What remains too loose is the route after a reviewed candidate exists:
- where does it land first
- how is the next move recorded
- when does seed staging become owner landing
- how is honest drop, merge, or supersession recorded
- how do we prevent candidate drift from staying only in runtime-local carry or chat memory

## Core moves

### 1. Center
Add one narrow extension note:
- `docs/OWNER_LANDING_AND_PRUNING.md`

Purpose:
- define owner status surfaces as tracked but weaker than landed owner objects
- name the allowed postures and terminal outcomes
- keep routing, memo, stats, and seed layers from claiming landing authority

### 2. aoa-sdk
Add a reviewed-closeout map surface:
- `docs/CLOSEOUT_FOLLOWTHROUGH_MAP.md`
- `schemas/closeout_owner_followthrough_map.schema.json`
- `examples/closeout_owner_followthrough_map.example.json`

This map may carry:
- `cluster_ref`
- `candidate_ref_hint` or `candidate_slot`
- owner hypothesis
- nearest wrong target
- recommended first owner status surface
- evidence refs
- requested next decision class

It must not mint:
- `candidate_ref`
- `seed_ref`
- `object_ref`

### 3. aoa-skills
Add the explicit landing/follow-through surfaces:
- `docs/OWNER_STATUS_SURFACES.md`
- `docs/GOVERNED_FOLLOWTHROUGH.md`
- `schemas/reviewed_owner_landing_bundle.schema.json`
- `examples/reviewed_owner_landing_bundle.example.json`
- `schemas/route_followthrough_decision.schema.json`
- `examples/route_followthrough_decision.example.json`

Meaning:
- `reviewed_owner_landing_bundle` is the first tracked owner status landing
- `route_followthrough_decision` is the bounded next-step verdict after reviewed candidate identity exists

### 4. Dionysus
Add one trace surface that keeps seed staging honest:
- `docs/SEED_OWNER_LANDING_TRACE.md`
- `schemas/seed_owner_landing_trace.schema.json`
- `examples/seed_owner_landing_trace.example.json`

Meaning:
- seed staging remains weaker than owner object truth
- but the trace must show whether the seed led to landing, reanchor, merge, or drop

### 5. aoa-stats
Add two narrow read models:
- `docs/OWNER_LANDING_SUMMARY.md`
- `schemas/owner_landing_summary.schema.json`
- `examples/owner_landing_summary.example.json`
- `docs/SUPERSESSION_DROP_SUMMARY.md`
- `schemas/supersession_drop_summary.schema.json`
- `examples/supersession_drop_summary.example.json`

These summaries are:
- derived only
- reviewed only
- non-sovereign
- useful for visible pruning and turnover

### 6. aoa-playbooks
Add a narrower scenario route:
- `playbooks/owner-followthrough-campaign/PLAYBOOK.md`

This playbook is used when:
- a candidate already exists
- the route is no longer about first harvest
- the task is to land, reanchor, seed, merge, defer, or drop honestly

### 7. aoa-memo
Add one writeback extension:
- `docs/GROWTH_REFINERY_PRUNE_WRITEBACK.md`

This note should say:
- when drop/supersede deserves failure lesson memory
- when reanchor/merge deserves recovery pattern memory
- memo still does not become landing or lineage authority

## Repo order

1. `Agents-of-Abyss`
2. `aoa-sdk`
3. `aoa-skills`
4. `Dionysus`
5. `aoa-stats`
6. `aoa-playbooks`
7. `aoa-memo`

## Verify gates after each repo

- repo-local schema/doc validators if present
- any existing `pytest`
- pack validator after each major repo lands
- final cross-repo smoke check against example surfaces

## Final acceptance

Wave 3 is accepted when:
- a reviewed candidate can land in a tracked owner status surface
- a bounded follow-through decision exists and does not pretend to be scheduler authority
- seed staging can be traced into landing, reanchor, merge, or drop
- derived summaries expose landing turnover and supersession/drop without inventing total scores
- memo can preserve bounded prune/recovery context without becoming source of truth
