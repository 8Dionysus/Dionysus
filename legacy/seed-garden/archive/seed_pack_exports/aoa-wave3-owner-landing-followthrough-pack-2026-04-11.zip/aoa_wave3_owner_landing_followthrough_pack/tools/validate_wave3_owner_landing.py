#!/usr/bin/env python3
import argparse
import json
from pathlib import Path

ALLOWED_POSTURES = {"early", "reanchor", "thin_evidence", "stable", "merged", "superseded", "dropped"}
ALLOWED_VERDICTS = {"land_direct", "stage_seed", "reanchor_owner", "prove_first", "merge_into_existing", "defer", "drop"}
ALLOWED_OUTCOMES = {"landed_owner_status", "landed_owner_object", "reanchored", "merged", "deferred", "dropped"}

def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--pack-root", default=".")
    args = parser.parse_args()
    root = Path(args.pack_root)

    sdk_map = load_json(root / "proposed-targets/aoa-sdk/examples/closeout_owner_followthrough_map.example.json")
    landing = load_json(root / "proposed-targets/aoa-skills/examples/reviewed_owner_landing_bundle.example.json")
    decision = load_json(root / "proposed-targets/aoa-skills/examples/route_followthrough_decision.example.json")
    seed_trace = load_json(root / "proposed-targets/Dionysus/examples/seed_owner_landing_trace.example.json")
    owner_summary = load_json(root / "proposed-targets/aoa-stats/examples/owner_landing_summary.example.json")
    drop_summary = load_json(root / "proposed-targets/aoa-stats/examples/supersession_drop_summary.example.json")

    # sdk map must keep cluster_ref but not mint candidate_ref / seed_ref / object_ref
    assert "cluster_ref" in sdk_map, "sdk followthrough map must carry cluster_ref"
    serialized_sdk = json.dumps(sdk_map)
    assert "candidate_ref" not in serialized_sdk, "sdk followthrough map must not mint candidate_ref"
    assert "seed_ref" not in serialized_sdk, "sdk followthrough map must not mint seed_ref"
    assert "object_ref" not in serialized_sdk, "sdk followthrough map must not mint object_ref"

    # landing requires candidate_ref and allowed posture
    assert landing["candidate_ref"] == decision["candidate_ref"] == seed_trace["candidate_ref"], "candidate_ref must stay aligned across landing/decision/seed trace"
    assert landing["status_posture"] in ALLOWED_POSTURES, "landing status posture invalid"

    # decision vocabulary
    assert decision["verdict"] in ALLOWED_VERDICTS, "followthrough verdict invalid"
    assert decision["owner_repo"] == landing["owner_repo"], "owner repo should align between decision and landing"

    # seed trace requires seed_ref and allowed outcome
    assert "seed_ref" in seed_trace and seed_trace["seed_ref"], "seed trace must carry seed_ref"
    assert seed_trace["outcome"] in ALLOWED_OUTCOMES, "seed trace outcome invalid"

    # stats summaries present key fields
    assert "counts_by_posture" in owner_summary, "owner landing summary missing posture counts"
    assert "drop_reason_counts" in drop_summary, "supersession/drop summary missing drop reasons"

    # playbook and docs exist
    required_paths = [
        root / "proposed-targets/Agents-of-Abyss/docs/OWNER_LANDING_AND_PRUNING.md",
        root / "proposed-targets/aoa-playbooks/playbooks/owner-followthrough-campaign/PLAYBOOK.md",
        root / "proposed-targets/aoa-memo/docs/GROWTH_REFINERY_PRUNE_WRITEBACK.md",
        root / "contracts/owner_status_surface_contract_v1.md",
        root / "contracts/governed_followthrough_contract_v1.md",
        root / "contracts/supersession_drop_law_v1.md",
    ]
    for p in required_paths:
        assert p.exists(), f"missing required file: {p}"

    print(json.dumps({
        "ok": True,
        "checked": {
            "sdk_provisional_map": True,
            "owner_landing_bundle": True,
            "followthrough_decision": True,
            "seed_owner_trace": True,
            "stats_summaries": True,
            "playbook_and_memo_docs": True
        }
    }, indent=2))

if __name__ == "__main__":
    main()
