You are landing Wave 3 of the AoA growth refinery.

Goal:
Implement the owner-landing / governed-followthrough / supersession-drop wave using the files in this pack.

Do not invent a new sovereign layer.
Do not widen routing, stats, memo, or seed layers into ownership authority.
Do not mint `candidate_ref` in `aoa-sdk`.
Do not mint `seed_ref` outside `Dionysus`.
Do not introduce one total growth score.

Read first:
1. `README.md`
2. `IMPLEMENTATION_DOCKET.md`
3. `PR_SLICES.md`
4. `ACCEPTANCE_MATRIX.md`
5. contracts in `contracts/`

Then land repo by repo in this order:
1. `Agents-of-Abyss`
2. `aoa-sdk`
3. `aoa-skills`
4. `Dionysus`
5. `aoa-stats`
6. `aoa-playbooks`
7. `aoa-memo`

Rules:
- keep diffs minimal and local
- prefer patching existing doctrine/seam docs over inventing parallel docs when a natural home already exists
- keep examples tiny but structurally honest
- keep schemas narrow and reviewable
- preserve existing repo boundaries
- stop if the repo already has a better-named home and adapt there instead of forcing the proposed path

Implementation asks:
- introduce the target docs/schemas/examples
- wire wording so the wave reads as a continuation of wave 1 and wave 2
- if one proposed file path is wrong but the repo already has a more natural home, move the content there and record the relocation in your report
- run available validation after each repo
- run the pack validator at the end

Required final report:
- touched files by repo
- any path relocations
- validation results
- explicit note about any acceptance boxes still not satisfied
