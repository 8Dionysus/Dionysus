# Implementation Docket: Wave 5 Codex Plane Portability and Regeneration

## Goal

Move the checked-in AoA Codex plane from hand-maintained path-bound files to **manifest-driven regeneration** while preserving the current public deployment shape.

This wave is about **portability without losing explicitness**.

## Repo targets

### 1. `8Dionysus`

#### Add doctrine and install law
Create:

- `docs/CODEX_PLANE_REGENERATION.md`

Patch:

- `docs/WORKSPACE_INSTALL.md`

The doctrine note should state:

- `8Dionysus` owns the source-authored shared-root Codex install subset
- the checked-in `.codex/config.toml` and `.codex/hooks.json` are generated deployment artifacts for the current chosen live root
- when the live root changes, edit the manifest/profile and rerender before projection
- do not hand-edit the generated path-bound files

#### Add source-owned manifest tree
Create:

- `config/codex_plane/runtime_manifest.v1.json`
- `config/codex_plane/profiles/linux-python3.json`
- optional second profile(s) as needed later

The manifest should own:

- project root markers
- feature flags that stay project-owned
- stable MCP server names and repo targets
- stable hook events, script-relative locations, timeouts, status messages
- role registration metadata that is already projected into `.codex/config.toml`

The profile should own:

- python launcher choice
- prefix args if any
- example render target only for fixtures/examples

#### Add renderer and validator
Create:

- `scripts/render_codex_plane.py`
- `scripts/validate_codex_plane_regeneration.py`

`render_codex_plane.py` should:

- read the manifest and one profile
- take `--workspace-root`
- render `8Dionysus/.codex/config.toml`
- render `8Dionysus/.codex/hooks.json`
- optionally emit a report under `.codex/generated/` when used locally

`validate_codex_plane_regeneration.py` should:

- recompute the expected render for the chosen root
- fail when checked-in `.codex/config.toml` or `.codex/hooks.json` drift from the manifest/profile pair

#### Regenerate the checked-in deployment
Use the current live public root first so there is no behavior change:

- workspace root: `/srv`
- manifest: `config/codex_plane/runtime_manifest.v1.json`
- profile: `config/codex_plane/profiles/linux-python3.json`

Then confirm the regenerated result still contains:

- `project_root_markers = ["AOA_WORKSPACE_ROOT", ".git"]`
- named MCP servers `aoa_workspace`, `aoa_stats`, `dionysus`
- hook commands under `/srv/.codex/hooks/`
- MCP `cwd` values under `/srv/<repo>`

### 2. `aoa-sdk`

Create a small note:

- `docs/CODEX_PLANE_PORTABILITY.md`

It should clarify:

- workspace discovery remains `aoa-sdk`'s job
- Codex-plane rendering remains `8Dionysus`'s shared-root install job
- source-discovery overrides do not replace Codex-plane regeneration
- if the live root changes, rerender `8Dionysus`'s shared-root `.codex/` surfaces instead of patching SDK code or MCP names ad hoc

Optionally add one short link from `docs/workspace-layout.md` or `README.md` route-by-need.

## Acceptance checks

### `8Dionysus`
- manifest/profile tree exists
- renderer can reproduce checked-in `.codex/config.toml` and `.codex/hooks.json`
- validator fails on drift
- `docs/WORKSPACE_INSTALL.md` explicitly mentions rerendering/adapting path-bound Codex wiring before projection when the root changes

### `aoa-sdk`
- note exists and is boundary-clean
- no SDK code starts owning the Codex-plane manifest

## Important stop lines

- do not rename MCP servers
- do not move role meaning out of `aoa-agents`
- do not move MCP implementation ownership out of `aoa-sdk`, `aoa-stats`, or `Dionysus`
- do not collapse source-owned install logic into user-global `~/.codex/`
- do not make `.codex/config.toml` or `.codex/hooks.json` the edit surface after this wave; the manifest/profile pair must become the edit surface

