# Wave 5: Codex Plane Portability and Regeneration

This pack hardens the AoA Codex plane so the current workspace install can be **re-rendered** for a different live root instead of being hand-edited path by path.

## Why this wave now

The current public workspace root in `8Dionysus` is already alive and useful, but its checked-in `.codex/config.toml` and `.codex/hooks.json` still carry deployment-specific absolute paths such as `/srv/aoa-sdk` and `/srv/.codex/hooks/...`. `8Dionysus/docs/WORKSPACE_INSTALL.md` already says those path-bound surfaces should be regenerated or adapted when the public workspace root changes. This wave turns that note into an explicit contract, renderer, validator, and install discipline.

## What this wave owns

- a source-owned Codex-plane manifest under `8Dionysus/config/codex_plane/`
- profile-based rendering for the checked-in `8Dionysus/.codex/config.toml` and `8Dionysus/.codex/hooks.json`
- drift validation against the manifest/profile pair
- a narrow `aoa-sdk` note clarifying how workspace discovery and Codex-plane regeneration should relate

## What this wave does not own

- it does **not** change MCP server names
- it does **not** move meaning from owner repos into `8Dionysus`
- it does **not** make project config relative-path semantics a new authority gamble
- it does **not** replace `project_workspace_root.py`; it feeds it

## Main files

- `contracts/codex_plane_regeneration_contract_v1.md`
- `proposed-targets/8Dionysus/docs/CODEX_PLANE_REGENERATION.md`
- `proposed-targets/8Dionysus/config/codex_plane/runtime_manifest.v1.json`
- `proposed-targets/8Dionysus/scripts/render_codex_plane.py`
- `proposed-targets/8Dionysus/scripts/validate_codex_plane_regeneration.py`
- `proposed-targets/aoa-sdk/docs/CODEX_PLANE_PORTABILITY.md`
- `tools/validate_wave5_portability_regeneration.py`

## Intended landing order

1. `8Dionysus` doctrine note + manifest/profile tree
2. `8Dionysus` renderer + validator
3. regenerate checked-in `.codex/config.toml` and `.codex/hooks.json` for the current live root
4. patch `docs/WORKSPACE_INSTALL.md` to make regeneration explicit before projection when roots change
5. add the small `aoa-sdk` note so workspace discovery and Codex-plane rendering do not drift apart

## Local pack validation

The pack-level validator renders the current `/srv` example from the manifest/profile pair and checks that:

- MCP server names remain `aoa_workspace`, `aoa_stats`, `dionysus`
- generated config and hooks reproduce the current absolute-path pattern
- hook commands point into the workspace `.codex/hooks/` tree
- repository paths resolve from the declared workspace root, not from ad-hoc hardcoding

