# PR Slices: Wave 5 Codex Plane Portability and Regeneration

## PR-1: `8Dionysus` doctrine + manifest/profile
Add:

- `docs/CODEX_PLANE_REGENERATION.md`
- `config/codex_plane/runtime_manifest.v1.json`
- `config/codex_plane/profiles/linux-python3.json`

Patch:

- `docs/WORKSPACE_INSTALL.md`

Goal:
Make the source-owned regeneration contract explicit before any codegen lands.

## PR-2: `8Dionysus` renderer + validator + regenerated checked-in `.codex/`
Add:

- `scripts/render_codex_plane.py`
- `scripts/validate_codex_plane_regeneration.py`

Regenerate:

- `.codex/config.toml`
- `.codex/hooks.json`

Goal:
Turn the current path-bound Codex plane into a reproducible deploy artifact.

## PR-3: `aoa-sdk` portability note
Add:

- `docs/CODEX_PLANE_PORTABILITY.md`

Patch a short link into one route surface if desired.

Goal:
Keep workspace discovery and Codex-plane regeneration aligned without cross-ownership drift.

