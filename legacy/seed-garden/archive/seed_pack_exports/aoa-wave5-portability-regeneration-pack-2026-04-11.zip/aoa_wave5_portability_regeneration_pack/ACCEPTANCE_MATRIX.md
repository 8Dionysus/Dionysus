# Acceptance Matrix: Wave 5 Codex Plane Portability and Regeneration

## Cross-wave success

| check | pass condition |
|---|---|
| source-owned edit surface | manifest/profile pair exists and is clearly documented as the edit surface |
| no behavior regression | regenerated `.codex/config.toml` and `.codex/hooks.json` preserve the current `/srv` deployment behavior |
| portability path | changing `--workspace-root` on the renderer changes output paths without hand-editing generated files |
| ownership discipline | `8Dionysus` owns manifest/rendering, owner repos still own MCP implementations and agent meaning |

## `8Dionysus`

| check | pass condition |
|---|---|
| doctrine note | `docs/CODEX_PLANE_REGENERATION.md` exists |
| install note | `docs/WORKSPACE_INSTALL.md` explicitly says to rerender/adapt path-bound Codex wiring when roots change |
| manifest | `config/codex_plane/runtime_manifest.v1.json` exists and declares stable MCP names, hooks, roles, and root markers |
| profile | at least one working profile exists |
| renderer | `scripts/render_codex_plane.py` can render config and hooks for `/srv` |
| drift validator | `scripts/validate_codex_plane_regeneration.py` fails when generated files drift |
| generated config | `.codex/config.toml` is produced by the renderer and includes the stable server names |
| generated hooks | `.codex/hooks.json` is produced by the renderer and points to `/.codex/hooks/` under the rendered root |

## `aoa-sdk`

| check | pass condition |
|---|---|
| portability note | `docs/CODEX_PLANE_PORTABILITY.md` exists |
| boundary clarity | note says SDK owns discovery/inspection, not the Codex-plane manifest |

## Explicit failure cases

- MCP server names changed
- `.codex/config.toml` or `.codex/hooks.json` are still treated as hand-edited primary sources
- renderer only works for `/srv` and cannot take another workspace root
- SDK code is patched to chase deployment-path drift instead of the `8Dionysus` renderer being used

