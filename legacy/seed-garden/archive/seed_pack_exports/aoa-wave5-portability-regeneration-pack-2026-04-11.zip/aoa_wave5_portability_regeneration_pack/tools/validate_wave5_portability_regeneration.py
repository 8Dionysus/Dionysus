from __future__ import annotations

import importlib.util
import json
import sys
import tempfile
from pathlib import Path


def _load_renderer(renderer_path: Path):
    spec = importlib.util.spec_from_file_location("aoa_codex_plane_renderer", renderer_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Unable to load renderer: {renderer_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> int:
    pack_root = Path(__file__).resolve().parents[1]
    renderer_path = pack_root / "proposed-targets" / "8Dionysus" / "scripts" / "render_codex_plane.py"
    renderer = _load_renderer(renderer_path)
    manifest_path = pack_root / "proposed-targets" / "8Dionysus" / "config" / "codex_plane" / "runtime_manifest.v1.json"
    profile_path = pack_root / "proposed-targets" / "8Dionysus" / "config" / "codex_plane" / "profiles" / "linux-python3.json"
    example_config_path = pack_root / "proposed-targets" / "8Dionysus" / "config" / "codex_plane" / "examples" / "current-srv.config.toml"
    example_hooks_path = pack_root / "proposed-targets" / "8Dionysus" / "config" / "codex_plane" / "examples" / "current-srv.hooks.json"
    example_paths_path = pack_root / "proposed-targets" / "8Dionysus" / "config" / "codex_plane" / "examples" / "current-srv.paths.json"

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    profile = json.loads(profile_path.read_text(encoding="utf-8"))

    workspace_root = Path("/srv")
    rendered_config = renderer.render_config_toml(
        manifest=manifest,
        profile=profile,
        workspace_root=workspace_root,
        manifest_rel="config/codex_plane/runtime_manifest.v1.json",
        profile_rel="config/codex_plane/profiles/linux-python3.json",
    )
    rendered_hooks = json.dumps(
        renderer.render_hooks_json(manifest=manifest, profile=profile, workspace_root=workspace_root),
        ensure_ascii=False,
        indent=2,
    ) + "\n"
    rendered_paths = json.dumps(
        renderer.render_paths_report(manifest=manifest, profile=profile, workspace_root=workspace_root),
        ensure_ascii=False,
        indent=2,
    ) + "\n"

    assert example_config_path.read_text(encoding="utf-8") == rendered_config, "current-srv config example drift"
    assert example_hooks_path.read_text(encoding="utf-8") == rendered_hooks, "current-srv hooks example drift"
    assert example_paths_path.read_text(encoding="utf-8") == rendered_paths, "current-srv paths example drift"

    # Stable names must remain unchanged.
    server_names = [server["name"] for server in manifest["mcp_servers"]]
    assert server_names == ["aoa_workspace", "aoa_stats", "dionysus"], server_names
    assert manifest["project_root_markers"] == ["AOA_WORKSPACE_ROOT", ".git"]
    assert set(manifest["hooks"]) == {"SessionStart", "UserPromptSubmit", "Stop"}

    # Alternate workspace render should move the paths, not the names.
    alt_root = Path("/work/aoa")
    alt_config = renderer.render_config_toml(
        manifest=manifest,
        profile=profile,
        workspace_root=alt_root,
        manifest_rel="config/codex_plane/runtime_manifest.v1.json",
        profile_rel="config/codex_plane/profiles/linux-python3.json",
    )
    assert "/work/aoa/aoa-sdk" in alt_config
    assert "/srv/aoa-sdk" not in alt_config
    alt_hooks = renderer.render_hooks_json(manifest=manifest, profile=profile, workspace_root=alt_root)
    stop_command = alt_hooks["hooks"]["Stop"][0]["hooks"][0]["command"]
    assert "/work/aoa/.codex/hooks/aoa_stop_doctor.py" in stop_command

    # End-to-end render/check smoke test.
    with tempfile.TemporaryDirectory() as tmp:
        tmpdir = Path(tmp)
        dest_config = tmpdir / "config.toml"
        dest_hooks = tmpdir / "hooks.json"
        dest_report = tmpdir / "report.json"
        args = [
            "--manifest", str(manifest_path),
            "--profile", str(profile_path),
            "--workspace-root", str(workspace_root),
            "--dest-config", str(dest_config),
            "--dest-hooks", str(dest_hooks),
            "--dest-report", str(dest_report),
        ]
        old_argv = sys.argv
        try:
            sys.argv = [str(renderer_path), *args]
            assert renderer.main() == 0
            sys.argv = [str(renderer_path), *args, "--check"]
            assert renderer.main() == 0
        finally:
            sys.argv = old_argv

    print("wave5 portability/regeneration validator: ok")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
