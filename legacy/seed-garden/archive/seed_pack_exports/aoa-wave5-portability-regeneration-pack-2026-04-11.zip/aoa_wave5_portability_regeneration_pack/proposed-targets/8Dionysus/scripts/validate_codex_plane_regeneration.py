from __future__ import annotations

import argparse
import importlib.util
import sys
from pathlib import Path


def _load_renderer(renderer_path: Path):
    spec = importlib.util.spec_from_file_location("aoa_codex_plane_renderer", renderer_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Unable to load renderer: {renderer_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Validate generated AoA Codex plane surfaces against the manifest/profile.")
    parser.add_argument("--repo-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--workspace-root", type=Path, default=Path("/srv"))
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    repo_root = args.repo_root.expanduser().resolve()
    renderer_path = repo_root / "scripts" / "render_codex_plane.py"
    renderer = _load_renderer(renderer_path)

    manifest_path = repo_root / "config" / "codex_plane" / "runtime_manifest.v1.json"
    profile_path = repo_root / "config" / "codex_plane" / "profiles" / "linux-python3.json"
    config_path = repo_root / ".codex" / "config.toml"
    hooks_path = repo_root / ".codex" / "hooks.json"

    manifest = renderer._load_json(manifest_path)
    profile = renderer._load_json(profile_path)
    workspace_root = args.workspace_root.expanduser().resolve()
    expected_config = renderer.render_config_toml(
        manifest=manifest,
        profile=profile,
        workspace_root=workspace_root,
        manifest_rel=manifest_path.as_posix(),
        profile_rel=profile_path.as_posix(),
    )
    expected_hooks = renderer.render_hooks_json(
        manifest=manifest,
        profile=profile,
        workspace_root=workspace_root,
    )

    if not config_path.exists():
        print(f"missing {config_path}", file=sys.stderr)
        return 1
    if not hooks_path.exists():
        print(f"missing {hooks_path}", file=sys.stderr)
        return 1
    actual_config = config_path.read_text(encoding="utf-8")
    actual_hooks = hooks_path.read_text(encoding="utf-8")

    import json

    ok = True
    if actual_config != expected_config:
        print("config.toml drift detected", file=sys.stderr)
        ok = False
    expected_hooks_text = json.dumps(expected_hooks, ensure_ascii=False, indent=2) + "\n"
    if actual_hooks != expected_hooks_text:
        print("hooks.json drift detected", file=sys.stderr)
        ok = False
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
