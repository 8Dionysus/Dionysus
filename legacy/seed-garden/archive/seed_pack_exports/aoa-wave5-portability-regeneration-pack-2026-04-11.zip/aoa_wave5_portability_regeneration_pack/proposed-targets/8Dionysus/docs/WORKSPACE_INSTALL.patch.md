# Suggested patch for `8Dionysus/docs/WORKSPACE_INSTALL.md`

Add one short paragraph near the existing note about path-bound wiring:

> The checked-in `.codex/config.toml` and `.codex/hooks.json` are source-owned generated deployment artifacts for the current chosen public workspace root. If that root changes, rerender them from `config/codex_plane/runtime_manifest.v1.json` and the selected profile before projection. Do not hand-edit them as the primary change surface.

Optionally add one command example:

```bash
python 8Dionysus/scripts/render_codex_plane.py \
  --manifest 8Dionysus/config/codex_plane/runtime_manifest.v1.json \
  --profile 8Dionysus/config/codex_plane/profiles/linux-python3.json \
  --workspace-root /srv \
  --dest-config 8Dionysus/.codex/config.toml \
  --dest-hooks 8Dionysus/.codex/hooks.json
```
