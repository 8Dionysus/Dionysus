# Suggested patch for `aoa-sdk/docs/workspace-layout.md`

Add a brief note after the override section:

> Workspace discovery overrides in `aoa-sdk` are not a substitute for Codex-plane deployment regeneration. When the live public workspace root changes, rerender the source-owned `8Dionysus/.codex/` deployment surfaces from the shared Codex-plane manifest/profile pair instead of patching SDK discovery code or MCP server names ad hoc.
