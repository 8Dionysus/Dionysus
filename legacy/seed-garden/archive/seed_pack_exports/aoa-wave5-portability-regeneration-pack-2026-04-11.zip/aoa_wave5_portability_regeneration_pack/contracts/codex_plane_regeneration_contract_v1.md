# Codex Plane Regeneration Contract v1

## Purpose

Define how the AoA shared-root Codex install surfaces become **regenerable deployment artifacts** instead of hand-maintained path snapshots.

This contract exists because the checked-in public workspace install already uses deployment-specific absolute paths, while the workspace install note already says those path-bound surfaces should be regenerated or adapted when the live root changes.

## Scope

This contract governs only the shared-root Codex install subset owned by `8Dionysus`:

- `8Dionysus/.codex/config.toml`
- `8Dionysus/.codex/hooks.json`

It does **not** govern:

- user-global `~/.codex/config.toml`
- owner-repo MCP implementation code
- `aoa-agents` role meaning
- live generated reports under `.codex/generated/`

## Ownership split

### `8Dionysus` owns
- the source-authored regeneration doctrine
- the manifest/profile pair that describes the current deployable Codex plane
- the renderer and regeneration validator
- the checked-in generated `.codex/config.toml` and `.codex/hooks.json` for the currently chosen live public root

### Owner repos still own
- `aoa-sdk`: workspace MCP implementation and workspace discovery
- `aoa-stats`: stats MCP implementation
- `Dionysus`: seed MCP implementation
- `aoa-agents`: role meaning and source agent profiles

## Canonical source surfaces

### Primary edit surfaces
- `8Dionysus/config/codex_plane/runtime_manifest.v1.json`
- `8Dionysus/config/codex_plane/profiles/*.json`

### Generated source-owned deploy surfaces
- `8Dionysus/.codex/config.toml`
- `8Dionysus/.codex/hooks.json`

### Validation surfaces
- `8Dionysus/scripts/render_codex_plane.py`
- `8Dionysus/scripts/validate_codex_plane_regeneration.py`

## Stable names that must not drift

### Project root markers
- `AOA_WORKSPACE_ROOT`
- `.git`

### MCP server names
- `aoa_workspace`
- `aoa_stats`
- `dionysus`

### Hook events
- `SessionStart`
- `UserPromptSubmit`
- `Stop`

## Render law

1. Edit the manifest/profile pair.
2. Render the checked-in `.codex/config.toml` and `.codex/hooks.json` for the intended live workspace root.
3. Validate drift.
4. Project the shared-root surfaces into the live workspace root.

After this contract lands, the generated `.codex/config.toml` and `.codex/hooks.json` are **not** the primary edit surface.

## Path law

- generated outputs may remain path-bound and explicit
- portability comes from regeneration, not from silent ad hoc editing
- if the live workspace root changes, rerender before projection
- do not patch SDK code, server names, or hooks to chase root drift when regeneration is the correct fix

## Minimal manifest content

The manifest must be able to describe:

- project root markers
- Codex feature flags that stay project-owned
- registered agent roles already projected into project config
- stable MCP server registry: name, owner repo, script relative path, cwd repo-relative subpath
- stable hook registry: event, matcher if any, script relative path, timeout, status message
- canonical repo directory mapping beneath the workspace root

## Profile content

A profile may vary launcher/runtime details without changing semantic server names:

- python launcher command
- prefix args if needed
- optional example render target for fixtures

Profiles must not redefine owner meaning.

## Non-goals

- inventing new MCP names during regeneration
- turning runtime-generated reports into source truth
- making `8Dionysus` the owner of `aoa-sdk`, `aoa-stats`, `Dionysus`, or `aoa-agents`
- replacing `project_workspace_root.py`; the renderer feeds the projected surfaces that tool copies

