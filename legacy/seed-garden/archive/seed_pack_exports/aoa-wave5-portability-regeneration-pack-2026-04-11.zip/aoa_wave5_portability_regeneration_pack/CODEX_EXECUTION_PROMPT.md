Use the attached Wave 5 pack to implement **Codex plane portability/regeneration** for AoA.

Mission:
turn the checked-in path-bound AoA Codex install surfaces into manifest-driven generated artifacts without changing the current live deployment behavior.

Read first:
1. `IMPLEMENTATION_DOCKET.md`
2. `PR_SLICES.md`
3. `contracts/codex_plane_regeneration_contract_v1.md`
4. `ACCEPTANCE_MATRIX.md`

Execution order:
1. land PR-1 fully
2. land PR-2 fully
3. land PR-3 fully

Hard requirements:
- keep MCP server names exactly `aoa_workspace`, `aoa_stats`, `dionysus`
- keep `project_root_markers = ["AOA_WORKSPACE_ROOT", ".git"]`
- do not move role meaning out of `aoa-agents`
- do not move MCP implementation ownership out of the existing owner repos
- do not hand-edit `.codex/config.toml` or `.codex/hooks.json` after the manifest/profile renderer exists
- regenerate the checked-in `.codex/` pair for the current live `/srv` deployment first, then validate

Required outputs before you stop:
- short implementation summary by PR slice
- paths of files created/changed
- command transcript or concise command list used for regeneration/validation
- explicit note saying whether regenerated `.codex/config.toml` and `.codex/hooks.json` now match the manifest/profile pair
- any unresolved drift or follow-up risk

Validation checklist:
- run the new regeneration validator in `8Dionysus`
- run the pack-level validator if copied locally
- confirm the generated config still points to `/srv/aoa-sdk`, `/srv/aoa-stats`, `/srv/Dionysus`, and `/srv/.codex/hooks/...`

