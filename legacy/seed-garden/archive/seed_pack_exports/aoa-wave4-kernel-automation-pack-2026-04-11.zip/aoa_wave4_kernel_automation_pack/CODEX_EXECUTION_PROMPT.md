# Codex Execution Prompt: Wave 4 Session-Growth Kernel and Reviewed Automation

You are integrating **AoA Wave 4 Session-Growth Kernel and Reviewed Automation**.

Read first, in this order:

1. `README.md`
2. `IMPLEMENTATION_DOCKET.md`
3. `PR_SLICES.md`
4. `ACCEPTANCE_MATRIX.md`
5. `contracts/session_growth_kernel_activation_contract_v1.md`

Then implement in PR order:

1. `aoa-sdk`
2. `aoa-skills`
3. `aoa-playbooks`
4. `aoa-stats`
5. cross-repo validator pass

## Non-negotiable boundaries

- Do not mint `candidate_ref` or `seed_ref` in `aoa-sdk`.
- Do not create real scheduling authority in `aoa-playbooks`.
- Do not let stats behave like routing, proof, or schedule authority.
- Do not let automation packets bypass approval, rollback, or checkpoint posture.
- Do not let generic receipts replace detail packet meaning.
- Do not create hidden runners.

## Implementation style

- Prefer additive docs, schemas, examples, and generated compact surfaces.
- Prefer the smallest diff that makes the wave legible.
- Keep all new surfaces reviewable and bounded.
- Preserve existing repo boundaries.
- When a file path already exists in the target repo, patch it rather than duplicating doctrine.

## Verification

After each repo slice, run its native checks.
At the end, run the cross-repo validator from this pack against the sibling workspace root.

## Final deliverable

Produce:

- landed files
- a short repo-by-repo summary
- exact verify commands run
- any deferred edges that should become a later wave
