# Acceptance Matrix: Wave 4 Session-Growth Kernel and Reviewed Automation

| repo | required surface | acceptance checks |
|---|---|---|
| `aoa-sdk` | deterministic kernel signal rules + closeout follow-through decision | reviewed-only posture stays explicit; sdk does not mint `candidate_ref`; schema + example validate |
| `aoa-skills` | kernel maturity doc + packet/receipt examples | route forks, diagnosis, repair, progression, automation scan all have example packets; detail receipts stay subordinate; automation scan keeps `seed_ready` and `checkpoint_required` explicit |
| `aoa-playbooks` | `reviewed-automation-followthrough` playbook | playbook stays review-governed; expected artifacts and return anchors exist; automation seeds stay candidate-only |
| `aoa-stats` | branch summary + automation follow-through summary | read models stay derived-only; no schedule authority; example and generated surfaces validate |
| cross-repo | wave validator | can verify wave-4 files across sibling repos and detect missing seams |

## Cross-repo pass conditions

All of these should be true:

1. `aoa-sdk` can describe why one reviewed route suggests a specific next kernel skill.
2. `aoa-skills` can show concrete packet examples for the remaining scaffold kernel skills.
3. `aoa-playbooks` can coordinate a reviewed automation follow-through scenario without acting as scheduler truth.
4. `aoa-stats` can describe branch and automation follow-through movement as derived summaries.
5. no layer outranks owner truth, proof truth, or approval posture.

## Explicit failure cases

Fail the wave if any of these appear:

- sdk mints reviewed candidate or seed identity
- playbooks claim real schedules
- stats infer schedule activation from automation seeds
- repair packet implies silent mutation
- automation packet acts like approval or runtime authority
