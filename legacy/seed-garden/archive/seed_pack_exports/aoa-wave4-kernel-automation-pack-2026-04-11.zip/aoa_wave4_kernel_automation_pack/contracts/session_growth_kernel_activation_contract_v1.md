# Session-Growth Kernel Activation Contract v1

## Purpose

This contract defines the next narrow wave after lineage, convergence, and owner landing.

Its job is to make the remaining scaffold kernel skills easier to use as a governed post-closeout cycle:

- branch choice
- diagnosis
- repair
- progression
- automation opportunity scanning

## Scope

This contract is for:

`aoa-sdk -> aoa-skills -> aoa-playbooks -> aoa-stats`

## Boundary posture

- `aoa-sdk` may recommend the next kernel class after reviewed closeout, but it does not execute that class by itself.
- `aoa-skills` owns the bounded packet shapes and receipts for the remaining scaffold kernel skills.
- `aoa-playbooks` may coordinate a recurring reviewed automation follow-through scenario, but it does not become scheduler truth.
- `aoa-stats` may summarize branch and automation follow-through movement, but it remains derived-only.

## Core objects

### 1. `closeout_followthrough_decision`

Owner: `aoa-sdk`

Purpose:
Carry one reviewed recommendation about which next kernel skill best matches the current reviewed route.

Required fields:

- `session_ref`
- `reviewed_closeout_context_ref`
- `cluster_ref`
- optional `candidate_ref`
- `recommended_next_skill`
- `also_considered`
- `reason_codes`
- `checkpoint_required`
- `approval_posture`
- `defer_allowed`
- `owner_hypothesis`
- `nearest_wrong_target`
- `status_posture`

### 2. detail packets in `aoa-skills`

Owners: specific kernel skills

Required packet families in this wave:

- `FORK_CARDS`
- `DIAGNOSIS_PACKET`
- `REPAIR_PACKET`
- `PROGRESSION_DELTA`
- `AUTOMATION_OPPORTUNITY_PACKET`

Each detail packet should have:

- one detail receipt
- one generic `CORE_SKILL_APPLICATION_RECEIPT` pointing back to the detail receipt

### 3. reviewed automation follow-through playbook

Owner: `aoa-playbooks`

Expected artifacts:

- `route_follow_through_decision`
- `automation_opportunity_packet`
- `playbook_seed_candidate`
- `real_run_review_note`
- `automation_followthrough_record`

### 4. derived stats summaries

Owner: `aoa-stats`

Required summaries:

- `session_growth_branch_summary`
- `automation_followthrough_summary`

## Negative rules

Do not:

- mint `candidate_ref` in `aoa-sdk`
- let playbooks claim real scheduler truth
- let stats infer live scheduling from seed examples
- let automation packets act as approval verdicts
- let repair packets imply silent mutation
- create one total progression score from branch or automation data

## Ready-for-next-wave signs

This wave is ready when:

- the remaining scaffold kernel skills have concrete example packets
- branch choice is explicit after reviewed closeout
- one reviewed automation scenario can be coordinated end-to-end without scheduler authority
- branch and automation movement can be described as derived stats
