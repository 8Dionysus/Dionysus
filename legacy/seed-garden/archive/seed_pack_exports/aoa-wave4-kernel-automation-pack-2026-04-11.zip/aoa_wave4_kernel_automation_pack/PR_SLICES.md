# PR Slices: Wave 4 Session-Growth Kernel and Reviewed Automation

## PR-1: aoa-sdk deterministic kernel signals

Target repo: `aoa-sdk`

Land:

- `docs/SESSION_GROWTH_KERNEL_SIGNAL_RULES.md`
- `schemas/closeout_followthrough_decision.schema.json`
- `examples/closeout_followthrough_decision.example.json`
- doc updates in checkpoint and closeout handoff surfaces

Acceptance:

- docs name deterministic signal rules
- schema validates the example
- no sdk surface mints `candidate_ref` or `seed_ref`

## PR-2: aoa-skills kernel maturity surfacing

Target repo: `aoa-skills`

Land:

- `docs/SESSION_GROWTH_KERNEL_MATURITY.md`
- packet examples and detail receipts for route forks, diagnosis, repair, progression, automation scan
- optional generated kernel maturity surface

Acceptance:

- every remaining scaffold kernel skill has at least one example packet
- every example detail receipt remains smaller than the packet it cites
- generic core receipts point back to detail receipts
- automation scan keeps `seed_ready` vs `not_now` explicit

## PR-3: aoa-playbooks reviewed automation follow-through

Target repo: `aoa-playbooks`

Land:

- `playbooks/reviewed-automation-followthrough/PLAYBOOK.md`
- automation-seed adjunct updates
- one human-readable automation prompt example

Acceptance:

- playbook stays scenario-level and review-governed
- no real scheduler authority appears
- artifacts and return anchors are explicit

## PR-4: aoa-stats branch and automation follow-through summaries

Target repo: `aoa-stats`

Land:

- branch summary docs, schema, example, generated surface
- automation follow-through docs, schema, example, generated surface

Acceptance:

- summaries read as derived views only
- no hidden proof, routing, or scheduling authority
- examples and generated surfaces validate

## PR-5: cross-repo validator and audit

Landing home:

- center or workspace tooling repo of choice

Land:

- `tools/validate_wave4_kernel_automation.py`
- optional fixture validator
- audit notes

Acceptance:

- validator can detect the four-wave seam across sibling repos
- validator catches forbidden authority drift when obvious required files are missing
