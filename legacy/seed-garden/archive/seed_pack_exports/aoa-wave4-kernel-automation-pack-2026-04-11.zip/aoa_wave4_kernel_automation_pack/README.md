# AoA Wave 4 Session-Growth Kernel and Reviewed Automation Pack

This wave hardens the next layer after:

- wave 1 candidate lineage
- wave 2 stats / evals / playbooks / memo convergence
- wave 3 owner landing and prune follow-through

It is built for the route:

`aoa-sdk -> aoa-skills -> aoa-playbooks -> aoa-stats`

## Why this wave exists

The live public repos already show the bones of this wave:

- `aoa-sdk` carries reviewed-only closeout handoff and provisional checkpoint lineage hints, but deterministic auto-emission still stops short of `aoa-session-route-forks`, `aoa-session-self-repair`, and `aoa-session-progression-lift`.
- `aoa-skills` already names the permanent seven-skill session-growth kernel, but most of that kernel still sits at `scaffold`.
- `aoa-playbooks` already exposes automation seeds, but only as examples and candidate composition surfaces, not live schedules.
- `aoa-stats` already exposes `candidate_lineage_summary` and `automation_pipeline_summary`, but not the branch-level or follow-through-level read models that make kernel movement legible.

What is still missing is not another bridge. What is missing is one governed cycle that makes the remaining scaffold kernel skills easier to use, easier to review, and easier to summarize without turning any layer into hidden scheduler authority.

## What this pack contains

- `IMPLEMENTATION_DOCKET.md`
- `PR_SLICES.md`
- `ACCEPTANCE_MATRIX.md`
- `CODEX_EXECUTION_PROMPT.md`
- `contracts/session_growth_kernel_activation_contract_v1.md`
- `patch-guides/` for each target repo
- `fixtures/` with synthetic cross-repo examples
- `tools/validate_wave4_kernel_automation.py`
- `tools/validate_pack_fixtures.py`

## Recommended landing order

1. `aoa-sdk` deterministic signal rules and closeout follow-through map
2. `aoa-skills` kernel maturity docs plus packet examples for forks, diagnosis, repair, progression, and automation scan
3. `aoa-playbooks` reviewed automation follow-through playbook and automation-seed adjuncts
4. `aoa-stats` branch and automation follow-through derived summaries
5. cross-repo validator and post-landing audit

## Out of scope

Do not widen this wave into:

- live schedule authority
- hidden autonomous runners
- stats as routing authority
- stats as proof authority
- playbooks as scheduler registry
- sdk minting reviewed candidate or seed identity
- repair packets silently mutating live runtime state
- automation seeds bypassing approval, rollback, or health-check posture

## Verify after landing

Repo-local:

```bash
# aoa-sdk
python -m pytest -q

# aoa-skills
python scripts/build_catalog.py --check
python scripts/validate_skills.py
python scripts/validate_agent_skills.py
python -m pytest -q tests

# aoa-playbooks
python scripts/validate_playbooks.py
python -m pytest -q tests

# aoa-stats
python scripts/build_views.py --check
python scripts/validate_repo.py
python -m pytest -q tests
```

Cross-repo:

```bash
python tools/validate_wave4_kernel_automation.py --workspace-root /path/to/workspace
```
