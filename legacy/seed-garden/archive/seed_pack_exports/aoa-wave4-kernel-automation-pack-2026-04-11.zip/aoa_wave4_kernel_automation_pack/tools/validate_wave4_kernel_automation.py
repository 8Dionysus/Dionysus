#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

def ensure(condition: bool, message: str, failures: list[str]) -> None:
    if not condition:
        failures.append(message)

def load_json_if_exists(path: Path):
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))

def main() -> int:
    parser = argparse.ArgumentParser(description="Validate AoA wave 4 kernel/automation seams across a sibling workspace.")
    parser.add_argument("--workspace-root", required=True)
    args = parser.parse_args()

    root = Path(args.workspace_root).resolve()
    failures: list[str] = []

    sdk_root = root / "aoa-sdk"
    skills_root = root / "aoa-skills"
    playbooks_root = root / "aoa-playbooks"
    stats_root = root / "aoa-stats"

    required_paths = [
        sdk_root / "docs" / "SESSION_GROWTH_KERNEL_SIGNAL_RULES.md",
        sdk_root / "examples" / "closeout_followthrough_decision.example.json",
        skills_root / "docs" / "SESSION_GROWTH_KERNEL_MATURITY.md",
        playbooks_root / "playbooks" / "reviewed-automation-followthrough" / "PLAYBOOK.md",
        stats_root / "generated" / "session_growth_branch_summary.min.json",
        stats_root / "generated" / "automation_followthrough_summary.min.json",
    ]
    for path in required_paths:
        ensure(path.exists(), f"missing required wave4 path: {path}", failures)

    closeout = load_json_if_exists(sdk_root / "examples" / "closeout_followthrough_decision.example.json")
    branch = load_json_if_exists(stats_root / "generated" / "session_growth_branch_summary.min.json")
    auto_summary = load_json_if_exists(stats_root / "generated" / "automation_followthrough_summary.min.json")

    if closeout is not None:
        ensure("candidate_ref" not in (closeout.get("minted_by") or ""),
               "closeout example appears to narrate candidate_ref minting inside sdk", failures)
        ensure(closeout.get("recommended_next_skill") in {
            "aoa-session-route-forks",
            "aoa-session-self-diagnose",
            "aoa-session-self-repair",
            "aoa-session-progression-lift",
            "aoa-automation-opportunity-scan",
            "aoa-quest-harvest",
        }, "recommended_next_skill is outside the expected kernel set", failures)

    if branch is not None:
        ensure("counts_by_recommended_next_skill" in branch,
               "branch summary missing counts_by_recommended_next_skill", failures)

    if auto_summary is not None:
        ensure("schedule_activation_count" not in auto_summary,
               "automation followthrough summary should not claim schedule activation", failures)
        ensure("seed_ready_count" in auto_summary and "not_now_count" in auto_summary,
               "automation followthrough summary missing seed readiness split", failures)

    playbook_path = playbooks_root / "playbooks" / "reviewed-automation-followthrough" / "PLAYBOOK.md"
    if playbook_path.exists():
        text = playbook_path.read_text(encoding="utf-8")
        ensure("not a scheduler" in text.lower() or "not a scheduler." in text.lower(),
               "playbook should explicitly disclaim scheduler authority", failures)

    if failures:
        print("wave4 workspace validation failed:", file=sys.stderr)
        for item in failures:
            print(f"- {item}", file=sys.stderr)
        return 1

    print("wave4 kernel/automation seams look present")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
