#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parents[1]

def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))

def ensure(condition: bool, message: str, failures: list[str]) -> None:
    if not condition:
        failures.append(message)

def main() -> int:
    failures: list[str] = []

    closeout = load_json(BASE / "fixtures" / "aoa-sdk" / "closeout_followthrough_decision.example.json")
    automation = load_json(BASE / "fixtures" / "aoa-skills" / "automation_opportunity_packet.example.json")
    diagnosis = load_json(BASE / "fixtures" / "aoa-skills" / "diagnosis_packet.example.json")
    repair = load_json(BASE / "fixtures" / "aoa-skills" / "repair_packet.example.json")
    branch = load_json(BASE / "fixtures" / "aoa-stats" / "session_growth_branch_summary.min.json")
    auto_summary = load_json(BASE / "fixtures" / "aoa-stats" / "automation_followthrough_summary.min.json")

    ensure(closeout["recommended_next_skill"] == "aoa-automation-opportunity-scan",
           "closeout example should recommend automation scan", failures)
    ensure(automation["candidate_ref"] == closeout["candidate_ref"],
           "automation packet candidate_ref should match closeout decision candidate_ref", failures)
    ensure(repair["candidate_ref"] == diagnosis["candidate_ref"],
           "repair packet candidate_ref should match diagnosis packet candidate_ref", failures)
    ensure("schedule_out_of_scope" in auto_summary["blocker_aggregates"],
           "automation summary should preserve schedule_out_of_scope blocker", failures)
    ensure("aoa-automation-opportunity-scan" in branch["counts_by_recommended_next_skill"],
           "branch summary should aggregate automation scan branch", failures)
    ensure(auto_summary["playbook_seed_candidate_count"] <= auto_summary["automation_candidate_count"],
           "playbook seed candidate count cannot exceed automation candidate count", failures)
    ensure(closeout["nearest_wrong_target"] == automation["nearest_wrong_target"],
           "nearest wrong target should remain consistent between closeout decision and automation packet", failures)

    if failures:
        print("fixture validation failed:", file=sys.stderr)
        for item in failures:
            print(f"- {item}", file=sys.stderr)
        return 1

    print("wave4 pack fixtures validated")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
