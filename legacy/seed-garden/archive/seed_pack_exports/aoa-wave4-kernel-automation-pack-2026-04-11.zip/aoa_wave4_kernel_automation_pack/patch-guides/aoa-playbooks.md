# Patch Guide: aoa-playbooks

## Intent

Give reviewed automation follow-through one explicit scenario-level home.

## Suggested file additions

- `playbooks/reviewed-automation-followthrough/PLAYBOOK.md`
- `examples/automations/reviewed-automation-followthrough.prompt.example.md`

## Suggested file edits

- `docs/AUTOMATION_SEEDS.md`
- `generated/playbook_automation_seeds.json`
- `generated/playbook_handoff_contracts.json`

## Scenario boundary

Use this playbook when:

- a reviewed route exists
- automation readiness is a serious candidate but not yet scheduler truth
- checkpoint, approval, rollback, and real-run review posture must stay explicit

Do not use it when:

- the route still needs first-pass donor harvest
- the route is already a direct owner landing with no automation question
- someone is trying to smuggle in real schedule authority
