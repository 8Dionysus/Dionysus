# Patch Guide: aoa-skills

## Intent

Give the remaining scaffold kernel skills concrete packet and receipt surfaces so they become easier to review and easier to land.

## Suggested file additions

- `docs/SESSION_GROWTH_KERNEL_MATURITY.md`
- example packets under `examples/session-growth-kernel/`
- example detail receipts under `examples/session-growth-kernel/receipts/`
- optional generated readiness summary such as `generated/project_core_kernel_maturity.min.json`

## Skills to harden in this wave

- `aoa-session-route-forks`
- `aoa-session-self-diagnose`
- `aoa-session-self-repair`
- `aoa-session-progression-lift`
- `aoa-automation-opportunity-scan`

## Example packet minimums

Every packet should show:

- source reviewed artifact ref
- strongest available lineage refs
- owner hint or owner target
- status posture
- explicit stop or defer condition

## Receipt minimums

Every detail receipt should:

- cite the packet ref
- stay smaller than the packet
- remain descriptive and append-only
- never replace packet meaning

Generic core receipts should point back to the detail receipt and never outrank it.
