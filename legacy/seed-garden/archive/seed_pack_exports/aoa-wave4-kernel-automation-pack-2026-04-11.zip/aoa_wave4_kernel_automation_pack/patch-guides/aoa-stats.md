# Patch Guide: aoa-stats

## Intent

Expose derived movement for branch choice and automation follow-through without inventing authority.

## Suggested file additions

- `docs/SESSION_GROWTH_BRANCH_SUMMARY.md`
- `schemas/session_growth_branch_summary.schema.json`
- `examples/session_growth_branch_summary.example.json`
- `generated/session_growth_branch_summary.min.json`
- `docs/AUTOMATION_FOLLOWTHROUGH_SUMMARY.md`
- `schemas/automation_followthrough_summary.schema.json`
- `examples/automation_followthrough_summary.example.json`
- `generated/automation_followthrough_summary.min.json`

## Summary constraints

### session_growth_branch_summary

Carry:

- counts by recommended next skill
- reason code aggregates
- defer counts
- owner target aggregates
- posture aggregates

### automation_followthrough_summary

Carry:

- candidate count
- seed ready vs not now
- checkpoint required count
- playbook seed candidate count
- real-run reviewed count
- blocker aggregates

## Must not do

- infer schedule activation from a seed example
- outrank owner-local reviewed receipts
- outrank eval verdicts
