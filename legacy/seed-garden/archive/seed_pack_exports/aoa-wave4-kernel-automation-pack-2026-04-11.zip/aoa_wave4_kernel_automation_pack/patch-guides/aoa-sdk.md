# Patch Guide: aoa-sdk

## Intent

Make reviewed closeout capable of naming one honest next kernel class without turning sdk into execution authority.

## Suggested file additions

- `docs/SESSION_GROWTH_KERNEL_SIGNAL_RULES.md`
- `schemas/closeout_followthrough_decision.schema.json`
- `examples/closeout_followthrough_decision.example.json`

## Suggested file edits

- `docs/session-growth-checkpoints.md`
- `docs/aoa-surface-detection-closeout-handoff.md`

## Must preserve

- `cluster_ref` remains provisional
- `candidate_ref` is foreign carry only, never sdk-minted
- reviewed-only posture
- no auto-run of kernel skills from sdk

## Deterministic signal examples

- multiple plausible next moves -> `aoa-session-route-forks`
- repeated friction or blocked automation readiness -> `aoa-session-self-diagnose`
- reviewed diagnosis already exists and smallest repair is clear -> `aoa-session-self-repair`
- explicit axis movement with no repair need -> `aoa-session-progression-lift`
- recurring manual route with stable trigger/output hints -> `aoa-automation-opportunity-scan`
- repeated reviewed quest unit with promotion pressure -> `aoa-quest-harvest`
