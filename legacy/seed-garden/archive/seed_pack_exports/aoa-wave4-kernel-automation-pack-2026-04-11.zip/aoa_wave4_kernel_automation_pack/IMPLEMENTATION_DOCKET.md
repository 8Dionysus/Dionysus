# Implementation Docket: Wave 4 Session-Growth Kernel and Reviewed Automation

## Narrow purpose

Make the remaining scaffold session-growth kernel surfaces easier to carry through reviewed follow-through without granting scheduler authority to any one repo.

The wave focuses on four concrete gaps:

1. deterministic branch signaling after reviewed closeout
2. practical packet and receipt examples for the remaining scaffold kernel skills
3. one scenario-level reviewed automation follow-through playbook
4. two derived stats read models that describe branch choice and automation follow-through

## Route

`aoa-sdk -> aoa-skills -> aoa-playbooks -> aoa-stats`

This route stays deliberately narrower than the full growth refinery:

- lineage identity is assumed from waves 1-3
- owner landing and prune law are assumed from wave 3
- proof and memo writeback already have their own convergence wave
- runtime scheduling remains outside this wave

---

## 1. aoa-sdk

### Goal

Turn reviewed closeout into more legible follow-through class selection without collapsing the sdk into skill authority.

### Add or extend

- `docs/SESSION_GROWTH_KERNEL_SIGNAL_RULES.md`
- `schemas/closeout_followthrough_decision.schema.json`
- `examples/closeout_followthrough_decision.example.json`
- `docs/session-growth-checkpoints.md`
- `docs/aoa-surface-detection-closeout-handoff.md`

### Required content

Document deterministic signals for when a reviewed route should suggest:

- `aoa-session-route-forks`
- `aoa-session-self-diagnose`
- `aoa-session-self-repair`
- `aoa-session-progression-lift`
- `aoa-automation-opportunity-scan`
- `aoa-quest-harvest`

Add one `closeout_followthrough_decision` shape that may carry:

- `session_ref`
- `reviewed_closeout_context_ref`
- `cluster_ref`
- optional foreign `candidate_ref`
- `recommended_next_skill`
- `also_considered`
- `reason_codes`
- `checkpoint_required`
- `approval_posture`
- `defer_allowed`
- `owner_hypothesis`
- `nearest_wrong_target`
- `status_posture`

### Negative rules

- sdk must not mint `candidate_ref`
- sdk must not mint `seed_ref`
- this decision surface stays recommendation and carry, not execution

---

## 2. aoa-skills

### Goal

Materialize the remaining scaffold session-growth kernel skills as practical, reviewable packet surfaces.

### Add or extend

- `docs/SESSION_GROWTH_KERNEL_MATURITY.md`
- example packets and receipts for:
  - `aoa-session-route-forks`
  - `aoa-session-self-diagnose`
  - `aoa-session-self-repair`
  - `aoa-session-progression-lift`
  - `aoa-automation-opportunity-scan`
- one generated readiness summary for the seven-skill kernel, for example:
  - `generated/project_core_kernel_maturity.min.json`

### Required content

For each remaining scaffold kernel skill, surface:

- one example packet
- one example detail receipt
- one pointer from the generic `CORE_SKILL_APPLICATION_RECEIPT` back to the detail receipt
- one short maturity note that says what keeps the skill at scaffold / linked / reviewed

For automation scanning specifically, preserve:

- `seed_ready` vs `not_now`
- `checkpoint_required`
- `playbook_seed_candidate`
- `next_artifact_hint`
- `nearest_wrong_target`

### Negative rules

- do not pretend an example packet is a real execution log
- do not let generic core receipts replace detail meaning
- do not let automation classification act like scheduler authority

---

## 3. aoa-playbooks

### Goal

Give the kernel one honest scenario-level home for reviewed automation follow-through.

### Add or extend

- `playbooks/reviewed-automation-followthrough/PLAYBOOK.md`
- `docs/AUTOMATION_SEEDS.md`
- `generated/playbook_automation_seeds.json`
- `generated/playbook_handoff_contracts.json`
- optional human-readable automation prompt example under `examples/automations/`

### Required content

The playbook should coordinate:

- reviewed route artifact
- branch choice
- automation candidate inspection
- seed-ready vs not-now decision
- checkpoint / approval posture
- real-run review gate
- safe return anchor

Expected artifacts:

- `route_follow_through_decision`
- `automation_opportunity_packet`
- `playbook_seed_candidate`
- `real_run_review_note`
- `automation_followthrough_record`

### Negative rules

- playbook automation seeds remain examples and candidate composition surfaces
- the playbook must not create real scheduler truth
- no hidden execution loops

---

## 4. aoa-stats

### Goal

Expose two derived read models so reviewed kernel movement becomes visible without outranking owner truth.

### Add or extend

- `docs/SESSION_GROWTH_BRANCH_SUMMARY.md`
- `schemas/session_growth_branch_summary.schema.json`
- `examples/session_growth_branch_summary.example.json`
- `generated/session_growth_branch_summary.min.json`
- `docs/AUTOMATION_FOLLOWTHROUGH_SUMMARY.md`
- `schemas/automation_followthrough_summary.schema.json`
- `examples/automation_followthrough_summary.example.json`
- `generated/automation_followthrough_summary.min.json`

### Required lenses

`session_growth_branch_summary` should carry:

- branch counts by `recommended_next_skill`
- defer counts
- owner-target aggregates
- status-posture aggregates
- reason-code aggregates

`automation_followthrough_summary` should carry:

- automation candidate count
- `seed_ready` vs `not_now`
- checkpoint-required count
- playbook-seed-candidate count
- real-run-reviewed count
- defer count
- blocker aggregates

### Negative rules

- do not infer scheduling from automation seeds
- do not infer proof from branch choice
- do not infer owner landing from automation readiness

---

## PR slices

See `PR_SLICES.md`.

## Acceptance

See `ACCEPTANCE_MATRIX.md`.
