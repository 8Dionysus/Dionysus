# Later Waves

Wave 3 makes roles, recurring scenarios, and derived substrate posture explicit under stress.

The next clean expansion points are:

- `aoa-evals`: repeated-window proof for stress handoffs, playbook re-entry quality, and KAG regrounding success
- `aoa-stats`: multi-repo derived vectors that include role posture, scenario recovery, and projection-health trendlines
- `aoa-routing`: stronger use of playbook stress lanes and KAG quarantine signals in next-hop hints
- `aoa-memo`: reviewed failure lessons that summarize repeated agent-handoff or playbook re-entry patterns
- concrete owner repos such as `ATM10-Agent` and `abyss-stack`: direct consumption of agent stress profiles and playbook re-entry gates where it fits

Do not widen there until wave 3 yields real stress envelopes, playbook gates, and KAG regrounding tickets worth consuming.
