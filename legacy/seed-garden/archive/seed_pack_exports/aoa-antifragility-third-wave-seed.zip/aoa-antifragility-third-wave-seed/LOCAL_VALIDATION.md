# Local Validation Notes

This seed was locally checked for:

- JSON schema validity
- example-to-schema validation for:
  - `aoa-agents`
  - `aoa-playbooks`
  - `aoa-kag`

The proposed objects are intentionally additive.
They are designed to fit beside existing profile, playbook, generated-surface, and KAG lift-pack conventions rather than replacing them.
