# Codex Handoff

Assume waves 1 and 2 are already landed, or that equivalent owner-local receipts, routing hints, memo lessons, runtime receipts, and control-plane notes exist.

Use this seed as a **bounded behavior-scenario-substrate packet**.
The goal is to make stress shape who acts, how recurring routes bend, and how derived knowledge steps back when it drifts.

## Primary objective

Teach the system to become more explicit under stress at three decisive seams:

1. **agents** narrow behavior, escalate earlier, and hand off with evidence
2. **playbooks** expose degraded lanes, stop conditions, evidence harvest, and re-entry gates
3. **KAG** publishes derived health and regrounding tickets, then prefers source-first or quarantine when needed

## P0 deliverables

- `aoa-agents`: doctrine + one stress-posture schema/example + one stress-handoff envelope schema/example
- `aoa-playbooks`: doctrine + one stress-lane schema/example + one re-entry gate schema/example
- `aoa-kag`: doctrine + one projection-health receipt schema/example + one regrounding-ticket schema/example

## Acceptance criteria

1. agent stress posture is additive, explicit, and role-scoped
2. stress handoffs carry evidence, blocked actions, and re-entry conditions
3. playbooks document degraded lanes without pretending to own receipt truth
4. playbook re-entry decisions cite explicit evidence and remain reviewable
5. KAG projection health and regrounding stay derived-layer owned and do not rewrite source meaning
6. derived substrate drift results in narrower consumer posture, not broader convenience
7. no hidden escalation or mutation widening appears anywhere in the landing

## Suggested sequence

### 1. Agents first
Land `aoa-agents` first so role contracts and handoff envelopes become available to playbook and KAG docs.

### 2. Playbooks second
Land `aoa-playbooks` next so recurring scenarios can consume agent handoffs and express degraded lanes plus re-entry gates.

### 3. KAG third
Land `aoa-kag` last so projection-health receipts and regrounding tickets can reference the already-shaped handoff and playbook posture.

## Hard guardrails

- do not convert agent stress posture into hidden routing or mutation authority
- do not let playbooks replace source-owned receipts, eval reports, or runtime closeout
- do not let KAG silently self-heal by republishing drifted projections without evidence
- do not promote quarantine to a permanent black hole without review
- do not widen memory writeback under stress
- do not treat derived consumer convenience as stronger than owner evidence

## Soft promotion rule

If multiple agent profiles, multiple playbook families, or multiple KAG projection families converge on nearly identical fields, promote shared pieces later.
Before then, local ownership is cleaner than premature abstraction.
