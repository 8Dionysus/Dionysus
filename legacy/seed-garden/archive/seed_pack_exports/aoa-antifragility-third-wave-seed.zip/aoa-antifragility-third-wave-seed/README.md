# AoA Antifragility Third Wave Seed

This package is a repo-relative overlay seed for the third antifragility wave across the public AoA surface.

Wave 1 established doctrine, source-owned receipts, bounded proof, and derived vectors.
Wave 2 made stress portable across routing, recall, runtime, and control-plane activation.
Wave 3 makes stress visible where behavior, scenario composition, and derived substrate meaning actually bend.

## Overlay model

Each top-level directory in this seed matches a target repository root.

Example:

- `aoa-agents/docs/AGENT_STRESS_POSTURE.md`
- `aoa-playbooks/schemas/playbook_stress_lane_v1.json`
- `aoa-kag/examples/projection_health_receipt.example.json`

Codex should treat these as **repo-relative overlays**, not blind copy instructions.
Live repository conventions remain authoritative.

## Wave 3 shape

Wave 3 is intentionally about role, scenario, and substrate posture:

1. make agent stress posture explicit in `aoa-agents`
2. make scenario-level stress lanes and re-entry gates explicit in `aoa-playbooks`
3. make KAG projection health, quarantine, and regrounding explicit in `aoa-kag`

## Core guardrails

- role contracts narrow behavior under stress before mutation widens
- playbooks coordinate recurring routes, but do not become the source of receipts or proof
- KAG may degrade to source-first or quarantine derived surfaces, but it does not become authored truth
- handoffs must carry evidence, blocked actions, and re-entry conditions
- do not add hidden autonomous escalation or auto-repair loops
- do not let derived substrate confidence outrank owner-local evidence

## Recommended apply order

1. `aoa-agents`
2. `aoa-playbooks`
3. `aoa-kag`

## What this seed intentionally is not

- not a request to centralize role, scenario, and substrate semantics in one repo
- not a replacement for wave 1 source-owned receipts or wave 2 stress transport
- not a license for agents to improvise broader authority under pressure
- not a request to silently regenerate or republish KAG surfaces after drift

## Validation expectation

At minimum, Codex should leave the workspace with:

- additive docs that fit each repo's ownership boundaries
- schema-valid examples for `aoa-agents`, `aoa-playbooks`, and `aoa-kag`
- explicit stress handoff, playbook lane, and KAG regrounding shapes
- no authority drift out of source repos and into derived convenience layers
- no hidden widening of mutation posture under stress
