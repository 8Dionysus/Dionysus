# AoA Growth Refinery Docket Pack

This pack is the next internal wave after the Codex-plane landing.

It is aimed at one job:

turn the current AoA session-growth pieces into one reviewable growth refinery with
a readable lineage path from checkpoint carry to owner-layer landing.

## Files

- `IMPLEMENTATION_DOCKET.md`
  - repo-by-repo change plan
  - proposed new docs / schemas / generated surfaces
  - order of operations
  - acceptance checks
- `CODEX_EXECUTION_PROMPT.md`
  - a direct prompt for Codex to execute the docket in bounded PR slices
- `PR_SLICES.md`
  - suggested cut points for small reviewable batches

## Center of gravity

The immediate target is not another Codex integration wave.

The immediate target is a cross-repo lineage nerve:

`cluster_ref -> candidate_ref -> seed_ref -> object_ref`

with proof, derived observability, playbook method, and memo writeback around it.
