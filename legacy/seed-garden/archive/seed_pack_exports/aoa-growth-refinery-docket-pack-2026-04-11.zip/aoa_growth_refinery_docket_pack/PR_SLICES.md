# Suggested PR slices

## PR-1 — Center doctrine
Repo:
- `Agents-of-Abyss`

Files:
- add `docs/REVIEWABLE_GROWTH_REFINERY.md`
- add `docs/CANDIDATE_LINEAGE_CROSSWALK.md`
- update `docs/METHOD_SPINE.md`

Deliverable:
one clear doctrine anchor and one crosswalk table

---

## PR-2 — SDK lineage carry
Repo:
- `aoa-sdk`

Files:
- update `docs/session-growth-checkpoints.md`
- update `docs/aoa-surface-detection-closeout-handoff.md`
- update `docs/aoa-surface-detection-first-wave.md`
- add `docs/CANDIDATE_LINEAGE_CONTROL_PLANE.md`
- add schema/example for lineage hints

Deliverable:
checkpoint and closeout can carry `cluster_ref` and lineage hints without minting reviewed candidates

---

## PR-3 — Skills reviewed candidate contract
Repo:
- `aoa-skills`

Files:
- update donor-harvest / bridge / family skills
- update checkpoint docs/template/schema/example
- add lineage contract + candidate schemas/examples

Deliverable:
reviewed donor harvest can mint `candidate_ref`

---

## PR-4 — Dionysus seed identity
Repo:
- `Dionysus`

Files:
- update `seed-registry.yaml`
- update `generated/seed_route_map.min.json`
- update planting report template + protocol
- add seed lifecycle contract + examples

Deliverable:
reviewed candidate can become a staged seed with `seed_ref`

---

## PR-5 — Stats funnel
Repo:
- `aoa-stats`

Files:
- update architecture / README / live source registry / build scripts
- add lineage and funnel schemas/examples/generated surfaces

Deliverable:
derived funnel exists without reading raw checkpoint note state

---

## PR-6 — Proof wave
Repo:
- `aoa-evals`

Files:
- add three bundles:
  - `aoa-candidate-lineage-integrity`
  - `aoa-owner-fit-routing-quality`
  - `aoa-repair-boundedness`
- update index / selection / supporting proof infra

Deliverable:
the route is falsifiable

---

## PR-7 — Playbook method
Repo:
- `aoa-playbooks`

Files:
- add `playbooks/session-growth-cycle/PLAYBOOK.md`
- update handoff / failure-recovery docs
- refresh generated playbook surfaces

Deliverable:
the recurring route has one playbook-owned home

---

## PR-8 — Memo closure
Repo:
- `aoa-memo`

Files:
- add growth-refinery memory writeback doc
- add failure lesson + recovery pattern examples
- update runtime writeback seam / memory scopes as needed

Deliverable:
the route can remember how it failed and recovered

---

## PR-9 — Maturity/status pass
Repos:
- only the repos that now have real proof and real runs

Deliverable:
revisit scaffold/proven/public posture honestly, or keep current status if the evidence is still too thin
