You are implementing the next internal AoA wave: the reviewable growth refinery.

Read first:
1. `IMPLEMENTATION_DOCKET.md`
2. `Agents-of-Abyss/docs/FEDERATION_RULES.md`
3. `Agents-of-Abyss/docs/METHOD_SPINE.md`
4. the target repo README before any mutation
5. the target repo AGENTS.md before any mutation

Mission:
turn the current session-growth pieces into one explicit lineage route:

`cluster_ref -> candidate_ref -> seed_ref -> object_ref`

Execution rules:
- work in the PR slices listed in `PR_SLICES.md`
- do not skip ahead to proof or playbook if the upstream contract is missing
- keep every change bounded, reviewable, and repo-owned
- prefer docs + schema + example + validator changes before aggressive automation
- refresh generated surfaces only in the repo that owns them
- do not move source ownership into routing, stats, SDK, or workspace glue
- do not silently widen claims

Non-negotiable stop lines:
- no `candidate_ref` before reviewed donor harvest
- no `seed_ref` outside `Dionysus`
- no raw `aoa-sdk` checkpoint logs in `aoa-stats`
- no `aoa-routing` authority inflation
- no premature skill maturity upgrades

Working rhythm:
- start with PR-1
- after each PR slice:
  - run that repo's documented validation battery
  - summarize exactly what changed
  - list unresolved seams
  - list follow-on PR dependencies

Success condition:
the final result must leave the system with a readable, reviewable lineage path and stronger boundaries than before.
