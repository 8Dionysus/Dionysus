# AoA Reviewable Growth Refinery
## Implementation docket, next internal wave

Date anchor: 2026-04-11

## 0. Mandate

The current Codex-plane is now strong enough to stop being the headline.

The next headline is internal:

build one reviewable growth refinery that can:

- notice growth signals during work
- carry them without promoting them mid-session
- re-read and review them at closeout
- mint a bounded reviewed candidate
- stage that candidate through the seed garden when needed
- land it in the right owner layer
- prove that the movement was honest
- remember failure and recovery patterns
- keep the whole route legible without creating a new sovereign layer

The intended identity chain is:

`cluster_ref -> candidate_ref -> seed_ref -> object_ref`

## 1. Guardrails

Do **not** solve this by creating a new authority layer.

Keep these boundaries explicit:

- `Agents-of-Abyss` names the federation and its crosswalks, but does not absorb repo-local meaning.
- `aoa-sdk` stays control-plane only.
- `aoa-skills` owns bounded execution meaning.
- `aoa-playbooks` owns recurring scenario-level method.
- `aoa-stats` stays derived-only.
- `Dionysus` stays seed garden / dispatch / lineage trace, not final ownership.
- `aoa-routing` stays thin.
- `aoa-memo` stores explicit memory, not proof.
- `aoa-evals` stores bounded proof, not workflow meaning.

## 2. Current pressure points to resolve

1. Checkpoint carry exists, but the surviving object does not yet travel through one explicit lineage contract.
2. Reviewed donor harvest exists, but it still emits a bounded `HARVEST_PACKET` without a visibly standardized `candidate_ref`.
3. Seed staging exists, but the public seed surfaces do not yet advertise a dedicated `seed_ref` bridge for session-growth candidates.
4. Derived observability exists, but there is no dedicated `candidate_lineage_summary` / `growth_funnel_summary`.
5. Proof infrastructure exists, but there are no public eval bundles yet for lineage integrity, owner-fit routing, or repair boundedness.
6. Playbook method exists, but there is no single `session-growth-cycle` playbook that owns the whole recurring route.
7. Memory seams exist, but failure/recovery writeback is not yet wired explicitly to this cycle.

## 3. Workstreams

### Workstream A
Doctrine + lineage identity

### Workstream B
Seed / owner / stats continuity

### Workstream C
Proof + method + memory closure

Run them in that order.

---

## 4. Repo-by-repo docket

## A. `Agents-of-Abyss`

### Why this repo
The center already owns federation rules and method spine.
It should define the shared crosswalk, not the repo-local payload details.

### Add
- `docs/REVIEWABLE_GROWTH_REFINERY.md`
- `docs/CANDIDATE_LINEAGE_CROSSWALK.md`

### Update
- `docs/METHOD_SPINE.md`
- optionally `README.md` route text, only if the new doctrine needs one compact route line

### What to put there

#### `docs/REVIEWABLE_GROWTH_REFINERY.md`
Define:

- purpose of the refinery
- reviewable posture
- explicit non-goals
- lifecycle terms:
  - observed
  - checkpointed
  - reviewed
  - harvested
  - seeded
  - planted
  - proved
  - promoted
  - superseded
  - dropped
- shared refs:
  - `cluster_ref`
  - `candidate_ref`
  - `seed_ref`
  - `object_ref`
- the split between:
  - carry
  - owner meaning
  - proof
  - derived view
  - memory writeback

#### `docs/CANDIDATE_LINEAGE_CROSSWALK.md`
Define, in one table:

- which repo first authors each ref
- where that ref may be copied downstream
- which fields are provisional vs reviewed vs landed
- when `supersedes`, `merged_into`, `drop_reason`, and `dropped_by` are legal
- which layer may say “promoted”
- which layer may never claim final ownership

#### `docs/METHOD_SPINE.md`
Add one explicit paragraph that:

- `checkpoint -> reviewed closeout -> donor harvest -> diagnose/repair/progression -> seed/planting -> proof -> memory writeback`
becomes playbook-owned method once it is recurring

### Acceptance checks
- center docs stay crosswalk-level, not repo-local schema empires
- no new center claim violates federation boundaries
- the new docs point back to `docs/FEDERATION_RULES.md`

### Validation
- `python scripts/build_center_entry_map.py --check`
- `python scripts/validate_center_entry_map.py`
- `python scripts/validate_ecosystem.py`
- `python -m pytest -q tests`

---

## B. `aoa-sdk`

### Why this repo
This is already the checkpoint-aware control plane.
It is the right place to carry provisional lineage hints, but not to mint reviewed candidates.

### Update
- `docs/session-growth-checkpoints.md`
- `docs/aoa-surface-detection-closeout-handoff.md`
- `docs/aoa-surface-detection-first-wave.md`

### Add
- `docs/CANDIDATE_LINEAGE_CONTROL_PLANE.md`
- one schema + example pair under the existing surface/checkpoint schema area:
  - `schemas/candidate_lineage_hint.schema.json`
  - `examples/candidate_lineage_hint.example.json`

### Implementation tasks

#### 1. Checkpoint carry fields
Extend the checkpoint-note / closeout-context / handoff payloads to carry:

- `cluster_ref`
- `cluster_kind`
- `cluster_members`
- `repeat_shape`
- `owner_hypothesis`
- `owner_hypothesis_confidence`
- `nearest_wrong_target`
- `evidence_refs`
- `promotion_pressure_vector`
- `carry_status` with values like:
  - `checkpointed`
  - `reviewed_carry`
  - `discarded_before_harvest`

#### 2. Closeout handoff
Extend `SurfaceCloseoutHandoff` so surviving reviewed items can preserve:

- `cluster_ref`
- optional `lineage_hints`
- optional `route_fork_hint`
- optional `diagnosis_hint`
- optional `progression_hint`
- optional `repair_preconditions`

Do **not** mint `candidate_ref` here.

#### 3. Deterministic auto-emission, next slice
Keep the current reviewed-only handoff discipline, but add deterministic generation rules for:

- `aoa-session-route-forks`
  - when more than one owner or method route survives reviewed closeout
- `aoa-session-progression-lift`
  - when reviewed evidence preserves meaningful multi-axis deltas
- `aoa-session-self-repair`
  - only when a reviewed diagnosis object already exists or when an explicit repair precondition contract is satisfied

#### 4. CLI / status surfaces
Wherever the SDK currently prints checkpoint status or handoff status, expose the new provisional lineage hints clearly and honestly.

### Hard stop rules
- no `candidate_ref` minted in `aoa-sdk`
- no `seed_ref` in `aoa-sdk`
- no mid-session harvest packet
- no stats refresh from raw checkpoint notes
- checkpoint surfaces stay additive and read-only apart from local note capture

### Acceptance checks
- reviewed checkpoint note clusters can survive into closeout handoff with `cluster_ref`
- handoff JSON can explain why a later route-fork / progression / repair target exists
- current reviewed-only boundary still holds
- no non-skill surface becomes executable-now authority

### Validation
- `python scripts/build_workspace_control_plane.py --check`
- `python scripts/validate_workspace_control_plane.py`
- `python -m pytest -q`
- `python -m ruff check .`

---

## C. `aoa-skills`

### Why this repo
This is where a reviewed session becomes bounded execution meaning.
This is the right place to mint `candidate_ref`.

### Update
- `skills/aoa-session-donor-harvest/SKILL.md`
- `skills/aoa-checkpoint-closeout-bridge/SKILL.md`
- `skills/aoa-session-route-forks/SKILL.md`
- `skills/aoa-session-self-diagnose/SKILL.md`
- `skills/aoa-session-self-repair/SKILL.md`
- `skills/aoa-session-progression-lift/SKILL.md`
- `skills/aoa-quest-harvest/SKILL.md`
- `docs/ADAPTIVE_SKILL_ORCHESTRATION.md`
- `docs/CHECKPOINT_NOTE_PATH.md`
- `templates/SESSION_CANDIDATE_HARVEST.template.md`
- `schemas/session_checkpoint_note.schema.json`
- `examples/session_checkpoint_note.example.json`
- `SKILL_INDEX.md`

### Add
- `docs/CANDIDATE_LINEAGE_CONTRACT.md`
- `schemas/candidate_ref.schema.json`
- `schemas/harvest_candidate_packet.schema.json`
- `examples/harvest_candidate_packet.example.json`

### Implementation tasks

#### 1. Donor harvest mints the reviewed candidate
Extend donor harvest outputs so each accepted reusable unit gets:

- `candidate_ref`
- optional upstream `cluster_ref`
- `candidate_kind`
- `owner_repo`
- `owner_hypothesis`
- `nearest_wrong_target`
- `lineage_stage = "harvested_reviewed"`
- `evidence_refs`
- `promotion_pressure_vector`
- `supersedes`
- `merged_into`
- `drop_reason`
- `hold_reason`

#### 2. HARVEST_PACKET contract
Extend the packet so it distinguishes:

- accepted candidates
- hold candidates
- dropped residue
- quest residue

Keep one primary owner per accepted candidate.

#### 3. Bridge skill
Update `aoa-checkpoint-closeout-bridge` so it explicitly passes:

- `cluster_ref`
- surviving checkpoint cluster details
- closeout-context lineage hints

into donor harvest / progression lift / quest harvest.

#### 4. Neighbor session-growth skills
Make the rest of the kernel consume `candidate_ref` when relevant:

- `route-forks` may attach route decisions to a candidate
- `self-diagnose` may diagnose a candidate route or candidate drift
- `self-repair` may produce the smallest repair packet for a diagnosed candidate
- `progression-lift` may emit reviewed deltas tied to candidate or route refs
- `quest-harvest` may turn a repeated reviewed quest unit into a promotion verdict while preserving `candidate_ref`

#### 5. Receipts
Ensure detail receipts and `CORE_SKILL_APPLICATION_RECEIPT` keep lineage linkage, but remain subordinate to the packet or detail object.

### Hard stop rules
- donor harvest stays post-session and explicit-only
- the packet still does not become hidden routing authority
- derivative layers still do not become first authoring targets
- do not upgrade scaffold skills to canonical merely because the contract exists

### Acceptance checks
- one reviewed session can mint one or more `candidate_ref` values
- each accepted candidate has one primary owner
- `nearest_wrong_target` remains explicit
- `candidate_ref` survives the family handoff surfaces
- `candidate_ref` is absent when the outcome is pure drop / pure hold

### Validation
- `python scripts/build_catalog.py --check`
- `python scripts/validate_skills.py --fail-on-review-truth-sync`
- `python scripts/report_skill_evaluation.py --fail-on-canonical-gaps`
- `python scripts/report_technique_drift.py --techniques-repo ../aoa-techniques --fail-on-drift`
- `python scripts/build_openai_yaml_examples.py --map examples/skill_mcp_wiring.map.json --output-dir examples --check`
- `python scripts/validate_agent_skills.py --repo-root .`
- `python scripts/validate_support_resources.py --repo-root . --check-portable`
- `python scripts/validate_tiny_router_inputs.py --repo-root .`
- `python -m pytest -q tests`

---

## D. `Dionysus`

### Why this repo
This is already the seed garden and dispatch layer.
It is the right place to mint `seed_ref` and hold the seed-stage lineage trace.

### Update
- `seed-registry.yaml`
- `generated/seed_route_map.min.json`
- `templates/planting-report.template.md`
- `docs/codex/planting-protocol.md`
- `docs/CODEX_MCP.md` only if the repo-local MCP should expose the new lineage fields

### Add
- `docs/CANDIDATE_SEED_LIFECYCLE.md`
- `schema/candidate-seed-lineage.contract.yaml`
- `templates/candidate-seed-staging.template.md`
- `examples/candidate_seed_registry_entry.example.yaml`

### Implementation tasks

#### 1. Seed identity
For reviewed candidates that enter the seed garden, mint:

- `seed_ref`
- `candidate_ref`
- optional `cluster_ref`
- `seed_kind`
- `seed_lifecycle_status`

Use lifecycle values like:

- `staged`
- `gated_next`
- `opened_wave`
- `planted`
- `superseded`
- `dropped`

#### 2. Registry entry shape
Extend registry entries so they can preserve:

- `seed_ref`
- `candidate_ref`
- optional `cluster_ref`
- `target_repo`
- optional `target_object_ref`
- `planting_report_ref`
- `supersedes`
- `lifecycle_note`

#### 3. Planting report
Extend the planting report template so it can record:

- source `seed_ref`
- source `candidate_ref`
- target repo
- target path(s)
- target `object_ref`
- what changed during planting
- what stayed behind in Dionysus

#### 4. Seed route map
Expose enough compact lineage data in `generated/seed_route_map.min.json` for low-context readers and MCP consumers.

### Hard stop rules
- Dionysus does not become the final owner of the object
- staging notes do not override opened-wave truth
- registry remains navigation overlay / lineage trace, not owner canon

### Acceptance checks
- every staged growth candidate gets a `seed_ref`
- one landed seed can point to one or more target object refs
- registry cleanup updates lifecycle markers in the same pass as landing cleanup
- planting trace remains readable even if the target repo PR trail is thin

### Validation
- `python scripts/validate_seed_surfaces.py`
- `python scripts/build_seed_route_map.py --check`
- `python scripts/validate_seed_route_map.py`
- `python -m pytest -q tests`
- `python -m pytest -q tests/test_dionysus_mcp_state.py`
- `python scripts/dionysus_mcp_server.py`

---

## E. `aoa-stats`

### Why this repo
It already owns the derived read models.
It is the right place for the funnel view, but not for promotion authority.

### Update
- `docs/ARCHITECTURE.md`
- `README.md`
- `config/live_receipt_sources.json`
- `generated/summary_surface_catalog.min.json`
- `scripts/build_views.py`
- `scripts/refresh_live_stats.py`
- `scripts/check_live_publishers.py`

### Add
- `docs/GROWTH_FUNNEL_SUMMARIES.md`
- `schemas/candidate_lineage_summary.schema.json`
- `schemas/growth_funnel_summary.schema.json`
- `generated/candidate_lineage_summary.min.json`
- `generated/growth_funnel_summary.min.json`
- `examples/candidate_lineage_summary.example.json`
- `examples/growth_funnel_summary.example.json`

### Implementation tasks

#### 1. New derived surfaces
Add two compact summaries:

- `candidate_lineage_summary.min.json`
- `growth_funnel_summary.min.json`

#### 2. Suggested derived fields
At minimum include:

- counts by stage:
  - checkpointed
  - reviewed
  - harvested
  - seeded
  - planted
  - proved
  - promoted
  - superseded
  - dropped
- `owner_ambiguity_rate`
- `misroute_rate`
- `time_to_seed`
- `time_to_plant`
- `thin_evidence_rate`
- `repair_after_diagnosis_success_rate`
- `supersession_rate`

#### 3. Source registry
Do **not** add raw `aoa-sdk` checkpoint note logs as live stats sources.

Instead, add only reviewed / owner-local feeds needed for the funnel.
Likely additions are:

- new reviewed harvest receipts from `aoa-skills`
- new seed / planting lineage receipts from `Dionysus`

#### 4. Summary surface catalog
Register the new surfaces in `generated/summary_surface_catalog.min.json` and the builder.

### Hard stop rules
- stats must stay derived-only
- no single total score
- no direct read of runtime-local checkpoint carry as if it were owner truth

### Acceptance checks
- summary surfaces can be generated from reviewed receipts without `aoa-sdk` raw local notes
- the catalog exposes the new surfaces cleanly
- the stats layer still cannot decide owner meaning or promotion

### Validation
- `python scripts/build_views.py --check`
- `python scripts/validate_repo.py`
- `python -m pytest -q tests`
- `python scripts/check_live_publishers.py`
- `python scripts/refresh_live_stats.py`

---

## F. `aoa-evals`

### Why this repo
This is the proof layer.
It is where the growth route becomes falsifiable instead of merely elegant.

### Update
- `EVAL_INDEX.md`
- `EVAL_SELECTION.md`
- any shared proof infra docs that need a short reference to the new bundles

### Add
- `bundles/aoa-candidate-lineage-integrity/EVAL.md`
- `bundles/aoa-owner-fit-routing-quality/EVAL.md`
- `bundles/aoa-repair-boundedness/EVAL.md`
- matching fixtures, runners, scorers, reports, and schemas under the normal repo pattern

### Implementation tasks

#### 1. Candidate lineage integrity
Check claims like:

- refs do not jump illegally
- `candidate_ref` is never minted before reviewed harvest
- `seed_ref` is only minted in Dionysus
- `object_ref` always points back to a real owner-layer landing
- supersession remains append-only and reviewable

#### 2. Owner-fit routing quality
Check claims like:

- accepted candidates land in the right owner repo
- nearest wrong target was meaningfully rejected
- derivative layers were not chosen first for source-owned meaning

#### 3. Repair boundedness
Check claims like:

- repair packets stay minimal
- rollback markers are explicit
- self-repair does not widen into hidden project takeover
- diagnosis precedes repair unless an explicit bounded exception exists

### Hard stop rules
- no giant capability claim
- no global intelligence score
- keep each bundle claim narrow and inspectable

### Acceptance checks
- bundles appear in `EVAL_INDEX.md`
- each bundle has fixtures for both passing and failing cases
- each bundle can emit a bounded eval result receipt
- bundles do not claim broader growth than their evidence supports

### Validation
- `python scripts/validate_repo.py`
- `python scripts/build_catalog.py --check`
- `python scripts/generate_runtime_candidate_template_index.py --check`
- `python scripts/generate_runtime_candidate_intake.py --check`
- `python scripts/generate_phase_alpha_eval_matrix.py --check`
- `python -m pytest -q tests`

---

## G. `aoa-playbooks`

### Why this repo
Once the route is recurring and multi-layer, this is where method belongs.

### Add
- `playbooks/session-growth-cycle/PLAYBOOK.md`

### Update
- `docs/HANDOFF_CONTRACTS.md`
- `docs/FAILURE_RECOVERY.md`
- `docs/AUTOMATION_SEEDS.md` only if the cycle should expose downstream automation hooks
- generated playbook surfaces through the existing builders

### Implementation tasks

#### 1. New playbook
Author one playbook that owns the recurring route:

`checkpoint -> reviewed closeout -> donor harvest -> route-forks/diagnose/repair/progression -> seed/planting -> proof -> memo writeback`

Include:

- entry conditions
- stop lines
- role expectations
- handoff contracts
- fallback posture
- rollback posture
- proof hooks
- memory writeback hooks

#### 2. Reuse existing exemplars
Use the posture of current real authored examples such as:
- `playbooks/self-agent-checkpoint-rollout/PLAYBOOK.md`
- `playbooks/witness-to-compost-pilot/PLAYBOOK.md`

but do not collapse their meanings into the new cycle.

#### 3. Receipts
Ensure the playbook can publish owner-local live receipts for closeout/stats integration.

### Hard stop rules
- do not inflate one bounded workflow into a playbook if it belongs in `aoa-skills`
- do not let the playbook silently own proof or memory meaning

### Acceptance checks
- the playbook clearly coordinates multiple surfaces, roles, and evidence expectations
- the playbook can reference candidate / seed / object lineage without becoming owner canon
- generated registries include the new playbook

### Validation
- `python scripts/generate_playbook_activation_surfaces.py --check`
- `python scripts/generate_playbook_federation_surfaces.py --check`
- `python scripts/generate_playbook_review_status.py --check`
- `python scripts/generate_playbook_review_packet_contracts.py --check`
- `python scripts/generate_playbook_review_intake.py --check`
- `python scripts/generate_playbook_landing_governance.py --check`
- `python scripts/generate_playbook_composition_surfaces.py --check`
- `python scripts/generate_phase_alpha_surfaces.py --check`
- `python scripts/validate_playbooks.py`
- `python -m pytest -q tests`

---

## H. `aoa-memo`

### Why this repo
This is where the refinery should remember how it fails and recovers.

### Update
- `docs/RUNTIME_WRITEBACK_SEAM.md`
- `docs/PLAYBOOK_MEMORY_SCOPES.md`
- optionally `docs/RECURRENCE_MEMORY_SUPPORT_SURFACES.md`

### Add
- `docs/SESSION_GROWTH_MEMORY_WRITEBACK.md`
- `examples/failure_lesson_memory.growth_refinery.example.json`
- `examples/recovery_pattern_memory.growth_refinery.example.json`

### Implementation tasks

#### 1. Failure lesson mapping
Define how to capture:

- misrouted owner placements
- false promotions
- thin-evidence landings
- over-harvested session residue
- diagnosis failures
- repair widening accidents

#### 2. Recovery pattern mapping
Define how to capture:

- successful re-anchor moves
- successful nearest-wrong-target avoidance
- honest hold / defer decisions
- bounded repair sequences
- proof-before-promotion patterns

#### 3. Writeback seam
Give the cycle one explicit writeback contract:
from reviewed growth event -> memory object candidate -> reviewed memory landing

### Hard stop rules
- memory does not become proof
- memory does not become routing authority
- keep explicit evidence refs

### Acceptance checks
- one growth-cycle failure can land as a failure lesson object
- one repeated successful recovery can land as a recovery-pattern object
- refs to candidate / seed / object lineage stay readable in the memory object, but memory does not own them

### Validation
- `python scripts/validate_memo.py`
- `python scripts/validate_memory_surfaces.py`
- `python scripts/validate_memory_object_surfaces.py`
- `python scripts/validate_lifecycle_audit_examples.py`
- `python -m pytest -q tests`

---

## 5. Optional / non-critical path

## `aoa-agents`
Only touch this repo if the new playbook needs a source-authored role posture or subagent recipe update.
Do not make it a critical blocker.

If touched, likely update:
- `docs/WORKSPACE_CHECKPOINT_GROWTH_ROLE_POSTURE.md`
- `docs/CODEX_SUBAGENT_PROJECTION.md` only if role guidance changes
- maybe one generated subagent recipe surface

Validation:
- `python scripts/validate_agents.py`
- `python -m pytest -q tests`

## `8Dionysus`
Only touch this repo after the internal wave lands, and only if the workspace doctor / install docs need one new route pointer or one new smoke check.

---

## 6. Recommended PR slices

### PR-1
`Agents-of-Abyss` doctrine:
- add refinery doc
- add lineage crosswalk
- update method spine

### PR-2
`aoa-sdk` carry:
- add lineage hints
- update checkpoint + closeout handoff docs / payloads
- no new candidate minting

### PR-3
`aoa-skills` reviewed candidate:
- donor-harvest contract
- bridge updates
- lineage-aware family handoffs

### PR-4
`Dionysus` seed identity:
- `seed_ref`
- lifecycle status
- planting trace fields

### PR-5
`aoa-stats` funnel:
- source registry additions
- candidate/funnel summaries
- summary surface catalog update

### PR-6
`aoa-evals` proof wave:
- lineage integrity
- owner-fit routing
- repair boundedness

### PR-7
`aoa-playbooks` cycle:
- `session-growth-cycle` playbook
- generated playbook surfaces refreshed

### PR-8
`aoa-memo` writeback:
- failure lesson + recovery pattern examples
- session-growth memory writeback seam

### PR-9
status / maturity pass:
- reconsider scaffold status only after real proof and real runs

---

## 7. Definition of done for this wave

This wave is done when all of the following are true:

1. A reviewed checkpoint cluster can survive into closeout as a named `cluster_ref`.
2. Donor harvest can mint a reviewed `candidate_ref`.
3. Dionysus can stage that candidate under a real `seed_ref`.
4. Owner landing can point back to a real `object_ref`.
5. `aoa-stats` can derive a readable growth funnel without reading raw checkpoint note state.
6. `aoa-evals` can falsify lineage mistakes, owner-fit mistakes, and repair widening.
7. `aoa-playbooks` owns the recurring method.
8. `aoa-memo` can preserve failure and recovery lessons from the cycle.
9. No repo boundary was blurred in the process.

---

## 8. First instruction to Codex

Implement this docket in PR order, smallest honest slice first.

Non-negotiable stop lines:

- do not mint `candidate_ref` before reviewed donor harvest
- do not mint `seed_ref` outside `Dionysus`
- do not add raw `aoa-sdk` checkpoint logs to `aoa-stats`
- do not turn `aoa-routing` into owner authority
- do not upgrade scaffold skills to canonical without proof and real-run evidence
