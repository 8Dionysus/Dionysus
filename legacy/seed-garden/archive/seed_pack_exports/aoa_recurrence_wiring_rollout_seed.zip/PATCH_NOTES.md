# Patch Notes

This is a delta-on-review-surfaces seed.

## New recurrence commands

The pack extends `aoa recur ...` with:

- `aoa recur wiring-plan`
- `aoa recur rollout-bundle`

## New control-plane surfaces

The pack writes new families under `.aoa/recurrence/`:

- `wiring-plans/`
- `rollout-bundles/`

## Template snippets

The seed also includes example snippets for:

- Codex SessionStart / UserPromptSubmit / Stop hooks
- git pre-commit and pre-push hooks
- GitHub Actions CI wiring
