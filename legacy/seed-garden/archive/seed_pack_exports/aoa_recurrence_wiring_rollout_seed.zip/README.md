# Recurrence Wiring and Rollout Seed

Delta seed on top of the recurrence review-surfaces pack.

This pack adds two things:

- a machine-readable wiring plan for Codex hooks, git hooks, and CI
- a bounded rollout bundle that treats recurrence adoption as a reviewable campaign rather than hidden glue

## What it does not do

- install hooks by itself
- create a scheduler
- widen recurrence into agent autonomy
