# Codex Landing Brief: Recurrence Wiring and Rollout

Land this after the review-surfaces pack.

## Aim

Use the already-planted recurrence control-plane to produce:

- a clear wiring plan for Codex, git, and CI seams
- a bounded rollout bundle that keeps drift and rollback explicit

## Boundaries to preserve

- The wiring plan is advisory and reviewable. It is not an installer.
- The rollout bundle is a cadence surface, not a scheduler.
- Drift windows should stay evidence-backed and rollback-conscious.

## Suggested landing order

1. Replace the changed recurrence package files under `aoa-sdk/src/aoa_sdk/recurrence/`.
2. Add the schemas, examples, and template snippets.
3. Inspect the generated wiring plan before copying any snippet into live hooks or CI.
4. Use the rollout bundle as a campaign surface while the recurrence plane is still widening.
