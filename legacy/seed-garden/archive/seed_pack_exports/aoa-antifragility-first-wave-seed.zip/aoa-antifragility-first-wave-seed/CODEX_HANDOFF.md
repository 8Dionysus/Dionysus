# Codex Handoff

Assume a sibling-workspace layout where top-level directory names map to live repositories.

Use this seed as a **bounded intent + contract packet**. Reconcile with the current repository shape instead of copying blindly.

## Primary objective

Make antifragility a project-wide posture by turning failure into:

1. bounded containment
2. machine-readable evidence
3. valid degraded continuation
4. explicit adaptation that can be verified later

## Implementation posture

Prefer additive changes.

Use existing repo naming, validation, generation, and documentation conventions whenever there is a conflict with this seed's draft naming.

If shared schema ownership is awkward, keep the contract local in the concrete owner repo for wave 1 and document promotion criteria rather than forcing early centralization.

## P0 deliverables

- `Agents-of-Abyss`: doctrine + first-wave scope
- `ATM10-Agent`: concrete first stressor family, source-owned receipt contracts, examples, and notes for additive wiring
- `aoa-techniques`: portable techniques for degrade/reground/recover and receipt-first failure analysis
- `aoa-evals`: one bounded eval bundle and one report schema
- `aoa-stats`: one derived vector schema + doctrine
- `aoa-skills`: one authoring addendum for fallback and receipt contracts

## Acceptance criteria

1. no repo claims authority it does not own
2. examples validate against the proposed schemas
3. `ATM10-Agent` antifragility docs stay compatible with existing degraded hybrid-query posture
4. no single total score replaces split-axis reporting
5. docs clearly distinguish:
   - source-owned receipts
   - eval-owned proof
   - stats-owned derived views

## Suggested implementation sequence

### 1. Center doctrine
Land the two AoA center docs first so downstream repo wording can inherit the same language.

### 2. Concrete source-owned receipts
In `ATM10-Agent`, keep the first wave concrete:
- the golden family is hybrid-query degradation where retrieval succeeds but KAG fails or yields no useful expansion
- emit source-owned stressor receipts around that path
- emit adaptation deltas only when there is an explicit change, not on every degraded run

### 3. Portable practice
Promote the repeatable failure-handling loops to `aoa-techniques`.

### 4. Proof surface
Add a bounded eval bundle in `aoa-evals` that scores split axes without pretending to own workflow meaning.

### 5. Derived view
Add `aoa-stats` vector surfaces that consume receipts and eval reports without claiming new authority.

## Hard guardrails

- do not add auto-running remediation
- do not replace existing owner-local run artifacts
- do not require a new endpoint if existing operator or run surfaces can publish additive evidence
- do not infer antifragility from raw log volume alone
- do not store "antifragility" as a single trust number

## Soft promotion rule

If two or more owner repos adopt the same source-owned receipt contract with near-zero divergence, then promote the common parts later. Before that, local ownership is acceptable and cleaner.
