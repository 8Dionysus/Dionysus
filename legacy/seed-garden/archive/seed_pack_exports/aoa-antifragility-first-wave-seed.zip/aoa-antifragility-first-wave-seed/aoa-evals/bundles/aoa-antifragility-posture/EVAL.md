# Eval Bundle: AoA Antifragility Posture

## Status
Proposed bounded eval bundle

## Purpose

Evaluate whether a concrete owner surface demonstrates antifragile posture for a named stressor family without stealing ownership away from source repos.

## Intended scope

This bundle is best used for:

- one repo
- one surface or tightly related surface family
- one named stressor family
- one bounded review window

Wave 1 exemplar:
- repo: `ATM10-Agent`
- surface: `hybrid-query`
- stressor family: retrieval succeeds while the KAG stage fails or yields no useful expansion

## Inputs

Required:
- source-owned stressor receipts
- owner-local artifacts for the same runs
- optional adaptation deltas if reviewed changes were made

Optional:
- operator recovery evidence
- contract summaries
- bounded regression windows

## Axes

The bundle reports split axes rather than one sovereign score.

### Containment
Was damage bounded to a named surface, run, or action lane.

### Fallback fidelity
Did degraded behavior remain truthful and weaker than the normal path.

### False-action prevention
Did the surface avoid widening authority, unsafe mutation, or hidden confident guesses.

### Recovery latency
How quickly could the surface regain a healthier path or publish a usable reviewed next step.

### Adaptation gain
After an explicit change, is there evidence that the same stressor is handled better.

### Operator burden
Did the recovery posture stay manageable for a human operator.

### Trust calibration
Did the surface communicate uncertainty, degradation, and blind spots appropriately.

## Required output

The machine-readable report should conform to:

- `schemas/antifragility_eval_report_v1.json`

## Blind spots

This bundle does not prove:
- global project quality
- universal resilience
- correctness of unrelated surfaces
- long-term trend quality without repeated-window evidence

## Evaluation posture

The evaluator should prefer:
- source-owned receipts
- owner-local artifacts
- explicit blind spots
- narrow verdicts

The evaluator should avoid:
- inferring quality from aggregate volume alone
- pretending stats summaries are primary evidence
- compressing all axes into one prestige number

## Suggested verdict bands

Axis-level status:
- `pass`
- `warn`
- `fail`
- `na`

A narrative summary may mention an overall posture, but the split axes must remain visible in the report.

## Wave 1 note

For the first wave, this bundle is intended to be lightweight and documentation-first. Repo-native runners and check scripts can follow later.
