# AoA Antifragility First Wave Seed

This package is a repo-relative overlay seed for the first antifragility wave across the public AoA surface.

The intent is not to impose a brittle top-down rewrite. The intent is to give Codex a compact, additive set of target files, contracts, examples, and guardrails that can be reconciled with the live workspace.

## Overlay model

Each top-level directory in this seed matches a target repository root.

Example:

- `Agents-of-Abyss/docs/ANTIFRAGILITY.md`
- `ATM10-Agent/schemas/stressor_receipt_v1.json`
- `aoa-stats/schemas/antifragility_vector_v1.json`

Codex should treat these as **repo-relative overlays**, not as blind copy instructions. Existing conventions inside each repository remain authoritative.

## Wave 1 shape

Wave 1 is intentionally narrow and high-leverage:

1. define antifragility as a federation posture in `Agents-of-Abyss`
2. make the first concrete stressor family real in `ATM10-Agent`
3. publish portable practice in `aoa-techniques`
4. define bounded proof in `aoa-evals`
5. define derived vector reporting in `aoa-stats`
6. add a lightweight skill-authoring addendum in `aoa-skills`

## Core guardrails

- source repos keep ownership of meaning
- degraded modes must stay valid, reviewable, and machine-readable
- `aoa-stats` derives summaries and must not become a score empire
- memory and routing are later-wave leverage points, not forced central owners here
- do not widen automation or hidden auto-repair behavior
- do not collapse trust or antifragility into one sovereign scalar

## Recommended apply order

1. `Agents-of-Abyss`
2. `ATM10-Agent`
3. `aoa-techniques`
4. `aoa-evals`
5. `aoa-stats`
6. `aoa-skills`

## What this seed intentionally is not

- not a finished implementation patchset
- not a central schema takeover
- not a demand for new endpoints where additive surfaces already exist
- not a request to auto-execute recovery behavior

## Validation expectation

At minimum, Codex should leave the workspace with:

- additive docs that fit each repo's ownership boundaries
- schemas and examples that validate together
- no broken repo-level conventions
- no authority drift into `aoa-stats`
- no hidden automation widening in `ATM10-Agent`
