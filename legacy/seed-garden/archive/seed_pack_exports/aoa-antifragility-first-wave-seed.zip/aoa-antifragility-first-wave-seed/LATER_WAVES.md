# Later Waves

This seed keeps wave 1 narrow on purpose. The next clean expansion points are:

- `aoa-routing`: stress posture hints, degraded-route preference, reground-first next hops
- `aoa-memo`: explicit failure-lesson objects and reviewable recall of prior stressors
- `aoa-sdk`: control-plane activation rules that treat stress posture as a first-class dispatch input
- `abyss-stack`: runtime containment, service degradation contracts, and repair-safe closeout receipts
- `aoa-agents`: role posture for mutation appetite, escalation threshold, and proof threshold
- `aoa-playbooks`: recurring incident families, handoff paths, and recovery method surfaces
- `aoa-kag`: provenance-aware correction loops when derived knowledge lags or drifts

Wave 2 should happen only after wave 1 produces concrete receipts, eval outputs, and derived vectors worth routing and recalling.
