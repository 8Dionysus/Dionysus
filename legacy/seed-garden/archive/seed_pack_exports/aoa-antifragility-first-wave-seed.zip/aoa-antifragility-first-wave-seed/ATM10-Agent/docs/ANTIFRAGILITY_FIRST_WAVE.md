# ANTIFRAGILITY FIRST WAVE

## Goal

Make the existing degraded hybrid-query posture legible as source-owned antifragility rather than leaving it as an implicit operational virtue.

## Golden family

Wave 1 focuses on:

- retrieval succeeds
- KAG stage fails or returns no useful expansion
- the run continues as a valid degraded result
- the surface stays machine-readable and operator-safe

## Why this is the right first family

This repo already has the essential shape:

- bounded degraded hybrid-query states
- machine-readable run artifacts
- recovery surfaces for operator context
- automation guard rails that avoid silent widening

The missing piece is a clearer owner-local contract that turns these events into explicit source-owned receipts and later adaptation deltas.

## Proposed source-owned contracts

### `stressor_receipt_v1`
Emit when a named stressor is observed and the run either degrades or cleanly stops.

Wave 1 trigger examples:
- `planner_status=retrieval_only_fallback`
- `planner_status=kag_only_fallback`
- `planner_status=grounding_unavailable`
- other future degraded states that still produce bounded artifacts

### `adaptation_delta_v1`
Emit only when there is an explicit reviewed change that cites one or more prior stressor receipts.

Do not emit an adaptation delta for every degraded run.

## Suggested touchpoints

These are intentionally non-binding and should be reconciled with live code:

- hybrid-query runner paths that already write `run.json` and `hybrid_query_results.json`
- any owner-local status publishing that already reports degraded planner state
- existing operator-context recovery surfaces where additive evidence can be shown without creating a new endpoint
- existing smoke and contract summaries where bounded evidence can be linked

## Owner-local field posture

### Stressor receipt should answer
- what stressor occurred
- what was bounded
- what fallback was used
- what evidence supports the event
- whether mutation stayed blocked

### Adaptation delta should answer
- which stressor receipts motivated the change
- what surface changed
- what effect was expected
- how improvement will later be checked

## Guardrails

- do not replace existing run artifacts
- do not widen automation or remediation behavior
- do not add hidden auto-repair logic
- do not treat recovery UI as permission to auto-execute safe actions
- do not make `aoa-stats` the source of truth for these events

## Acceptance shape for wave 1

A healthy wave 1 landing would make it possible to point to:

- one owner-local stressor receipt example
- one owner-local adaptation delta example
- one clear mapping from degraded hybrid-query artifacts to those contracts
- one future eval path that can assess the family across a bounded window
