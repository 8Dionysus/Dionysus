# Technique: Receipt-First Failure Analysis

## Status
Proposed public technique

## Purpose

Convert failure review from folklore into bounded, evidence-led iteration.

This technique assumes that the first trustworthy object after a stress event is the source-owned receipt, not the summary dashboard, not memory, and not retrospective confidence.

## Good fit

Use this technique when:

- a degraded run completed but needs follow-up learning
- the same stressor family repeats across a window
- a team wants to decide whether a change deserves promotion
- a later eval or stats view needs owner-local grounding

## Inputs

- source-owned stressor receipts
- owner-local run artifacts
- optional adaptation deltas
- optional bounded eval reports

## Outputs

- one named stressor family
- one bounded hypothesis for improvement
- one explicit change candidate
- one verification plan tied to receipts or eval outputs

## Procedure

### 1. Collect owner-local receipts
Start from source-owned evidence. Avoid opening with dashboards, memory, or narrative summaries.

### 2. Group by named family
Group events by stressor class and current surface.

Useful grouping axes:
- repo
- surface
- stressor class
- degraded mode taken
- blocked mutation posture

### 3. Separate facts from guesses
Facts should point to receipts, artifacts, or explicit eval outputs.
Guesses should stay labeled as hypotheses.

### 4. Identify the narrowest plausible change
Prefer one explicit change over a sprawling theory patch.

Possible change surfaces:
- config
- routing hint
- prompt
- policy
- code
- operator surface wording

### 5. Define how improvement will be checked
Do not stop at "we changed something."
Name the receipt or eval path that should show the difference next time.

### 6. Publish an adaptation delta
When a reviewed change lands, publish a bounded adaptation delta that cites the originating stressor receipts.

## Validation checklist

A healthy analysis should let a later reviewer answer:

- which source receipts justified this change
- what exact surface changed
- what effect was expected
- what evidence would count as improvement
- whether the change was later verified, reverted, or left unresolved

## Anti-patterns

Avoid:
- jumping straight from failure to architectural mythology
- inferring causality from raw log volume
- using a dashboard aggregate as the only source
- treating memory recall as proof
- writing an adaptation delta with no originating receipts

## Portability

This pattern is portable across:
- hybrid retrieval systems
- automation guard rails
- runtime service containment
- operator recovery surfaces
- derived knowledge correction loops
