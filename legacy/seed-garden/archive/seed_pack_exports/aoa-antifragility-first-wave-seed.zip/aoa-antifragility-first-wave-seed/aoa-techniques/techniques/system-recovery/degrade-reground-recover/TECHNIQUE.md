# Technique: Degrade -> Reground -> Recover

## Status
Proposed public technique

## Purpose

When a subsystem weakens, fails, or returns low-confidence expansion, do not choose between brittle success theater and full collapse.

Instead:

1. detect the stressor
2. bound the damage
3. continue in a valid degraded mode when safe
4. reground against stronger or more authoritative sources
5. recover later through an explicit adaptation loop

## Good fit

Use this technique when:

- a derived or optional stage fails but an earlier stage still produced usable grounded output
- a retrieval, memory, routing, or runtime helper is degraded
- continuing with a smaller truthful answer is safer than inventing a fuller one
- the system needs to preserve operator trust under partial outage

## Bad fit

Do not use this technique to justify:

- hidden widening of automation
- silent fallback to uncited guesses
- skipping proof and evidence emission
- pretending the degraded mode is equivalent to the full mode

## Inputs

- owner-local run artifacts
- surface status or error state
- bounded source evidence
- fallback policy for the current surface

## Outputs

- one bounded degraded result or an explicit safe stop
- one source-owned stressor receipt
- optional later adaptation delta after a reviewed change

## Procedure

### 1. Detect
Name the stressor class in owner-local language.

Example classes:
- `kag_stage_failed`
- `no_useful_expansion`
- `service_unavailable`
- `low_confidence_recall`

### 2. Contain
Bound the impact to the current surface, turn, run, or operator action.

Containment questions:
- what can still be trusted
- what must be withheld
- what state mutation must be blocked

### 3. Degrade honestly
Switch to the weakest valid mode that still preserves truthfulness and bounded utility.

Examples:
- retrieval-only answer
- read-only operator surface
- manual confirmation lane
- safe stop with explicit next step

### 4. Reground
Prefer stronger sources over speculative completion.

Reground options:
- source-owned retrieval results
- canonical run artifacts
- owner-local policy surfaces
- operator confirmation for mutation paths

### 5. Emit evidence
Publish a source-owned stressor receipt with:
- what failed
- what stayed bounded
- what fallback was taken
- what evidence supports the event

### 6. Recover later
When a reviewed change is made, cite the originating stressor receipt in an adaptation delta.

## Validation checklist

A use of this technique is healthy when:

- degraded mode is weaker, not broader
- evidence is source-owned and machine-readable
- blocked actions stay blocked
- later adaptation cites the original stressor
- a reviewer can compare before and after behavior

## Portable notes

This technique pairs well with:
- receipt-first failure analysis
- bounded antifragility eval bundles
- derived vector summaries that consume receipts and eval reports

## Minimal anti-drift rule

If the reground step starts inventing new meaning instead of leaning on owner-local authority, the technique is being used incorrectly.
