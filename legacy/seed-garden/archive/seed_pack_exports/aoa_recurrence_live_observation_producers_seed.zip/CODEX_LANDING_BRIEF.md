# Codex landing brief: Live Observation Producers

Land this seed after the hardening/compatibility and graph-closure seeds.

## Patch order

1. Add `aoa-sdk/src/aoa_sdk/recurrence/live_observations.py`.
2. Merge the `RecurrenceAPI.live_producers()` and `RecurrenceAPI.live_observations()` methods from the provided `api.py`.
3. Add the `aoa recur live producers` and `aoa recur live observe` commands from the provided `cli.py`, or use `scripts/collect_live_recurrence_observations.py` as the stable fallback.
4. Add docs and examples.
5. Run the test:

```bash
python -m pytest -q tests/test_recurrence_live_observation_seed.py
```

## First smoke run

```bash
python scripts/collect_live_recurrence_observations.py --workspace-root /srv/workspace --json
```

Then feed the output to beacons:

```bash
aoa recur beacon .aoa/recurrence/observations/live.latest.json --root /srv/workspace --json
```

## Stop-lines

- Do not auto-promote techniques.
- Do not auto-activate skills.
- Do not author eval bundles.
- Do not create playbooks.
- Do not spawn agents.
- Do not mutate generated surfaces.
- Do not use runtime evidence as proof canon before owner review.
