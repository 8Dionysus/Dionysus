# AoA Recurrence Live Observation Producers Seed

This is the next recurrence seed after hardening compatibility and graph closure/snapshot.

It adds a read-only producer layer that collects live owner-authored evidence into `ObservationPacket` surfaces:

- technique intake and canonical-readiness pressure
- skill trigger omissions and collision pressure
- runtime evidence-selection candidates and overclaim alarms
- playbook real-run harvest, subagent recipe, fallback, gate, and automation-seed pressure
- generated-surface staleness
- repeated recurrence event patterns

The seed is intentionally not an owner decision engine. It feeds the existing `observe -> beacon -> ledger -> review` path.
