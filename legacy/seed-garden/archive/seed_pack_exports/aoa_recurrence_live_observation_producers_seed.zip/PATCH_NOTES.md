# Patch notes

## New files

- `aoa-sdk/src/aoa_sdk/recurrence/live_observations.py`
- `aoa-sdk/scripts/collect_live_recurrence_observations.py`
- `aoa-sdk/docs/RECURRENCE_LIVE_OBSERVATION_PRODUCERS.md`
- `aoa-sdk/docs/LIVE_OBSERVATION_COMMANDS_INSERT.md`
- `aoa-sdk/schemas/live_observation_run.schema.json`
- `aoa-sdk/examples/recurrence/live_observation_packet.example.json`
- `aoa-sdk/examples/recurrence/live_observation_run.example.json`
- `aoa-sdk/tests/test_recurrence_live_observation_seed.py`

## Updated files

- `aoa-sdk/src/aoa_sdk/recurrence/api.py`
- `aoa-sdk/src/aoa_sdk/recurrence/cli.py`

The updated API/CLI files are supplied as full replacements based on the previous recurrence seed stack. If local Codex state has drifted, apply the new imports and methods manually instead of clobbering unrelated changes.
