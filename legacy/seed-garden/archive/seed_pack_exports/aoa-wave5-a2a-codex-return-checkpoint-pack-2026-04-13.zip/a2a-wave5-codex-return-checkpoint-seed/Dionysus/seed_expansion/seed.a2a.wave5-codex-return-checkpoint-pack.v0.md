# seed.a2a.wave5-codex-return-checkpoint-pack.v0

Wave 5 seed direction:

- Codex remains the primary local control plane
- local agents must still be projection-aligned with the Codex workspace install surface
- A2A child runs must map terminal state into return, checkpoint bridge, and reviewed closeout
- progression and self-agent checkpoint posture now influence delegation law
- runtime publication stays owner-local and canonical-envelope only
