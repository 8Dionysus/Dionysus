# A2A Codex Local Agent Alignment

This note binds A2A child delegation to the current role, projection, progression, and checkpoint posture in `aoa-agents`.

## Core rule

For current local bounded delegation, the default execution surface should be a Codex-local projected role target, not an ad-hoc runtime-only worker identity.

A child route should therefore stay answerable to:

- role profile truth
- Codex projection truth
- quest passport law
- cohort hints
- recurrence / return law
- progression overlay when required
- self-agent checkpoint posture when relevant

## Child selection order

1. verify the quest passport permits delegation
2. verify the route is not `d3+` without splitting
3. narrow the child role
4. prefer the Codex-local projected role target for local execution
5. only use an explicit remote target when the route really needs a separate endpoint or continuity lane

## Progression gate

When a governed actor route depends on accumulated mastery or authority rights, summon should read a reviewed progression overlay instead of pretending all local child roles are equally unlocked.

## Self-agent gate

When the route is self-agent or policy-sensitive, the child lane must also respect the published checkpoint stack:

- approval
- rollback marker
- health check
- memory scope
- iteration limit

## Return rule

If the child route loses shape or ends in a terminal degraded state, it should map back into `transition_decision` with:

- `decision = "return"`
- `anchor_artifact`
- `reentry_note`
- explicit `next_hop`

A child route should not masquerade as honest continuity by retrying blindly.
