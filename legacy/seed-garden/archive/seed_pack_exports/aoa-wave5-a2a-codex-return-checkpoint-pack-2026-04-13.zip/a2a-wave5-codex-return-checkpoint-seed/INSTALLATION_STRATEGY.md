# Installation Strategy

## Recommendation

Install **this package only**.

Treat wave 1 through wave 4 as reference material, not prerequisites.

## Why

- wave 4 already displaced the older wave chain
- the project now has stronger recurrence, checkpoint, progression, and Codex workspace surfaces
- replaying all prior packs would recreate duplicate A2A islands and outdated assumptions

## Preferred landing order

### Stage 1. Doctrine and boundary notes

Land these first, or fold their content into stronger live equivalents if Codex finds them:

- `8Dionysus/docs/A2A_CODEX_WORKSPACE_ALIGNMENT.md`
- `Agents-of-Abyss/docs/A2A_WAVE5_CONSOLIDATED_NOTE.md`
- `aoa-agents/docs/A2A_CODEX_LOCAL_AGENT_ALIGNMENT.md`
- `aoa-skills/docs/A2A_SUMMON_RETURN_AND_CHECKPOINTS.md`
- `aoa-playbooks/docs/A2A_RETURN_REENTRY_ADJUNCTS.md`
- `aoa-routing/docs/A2A_RETURN_NAV_AND_CODEX_LOCAL_SELECTION.md`
- `aoa-evals/docs/A2A_RETURN_PROGRESSION_CHECKPOINT_PROOF.md`
- `aoa-memo/docs/A2A_RETURN_SUPPORT_AND_REVIEWED_EXPORTS.md`
- `aoa-stats/docs/A2A_RETURN_AND_CHECKPOINT_EVENT_MAPPING.md`
- `aoa-sdk/docs/A2A_WAVE5_CODEX_RETURN_CHECKPOINT.md`
- `abyss-stack/docs/A2A_CODEX_FRIENDLY_LOCAL_AGENTS.md`

### Stage 2. Skill layer

Land the refreshed `aoa-skills/skills/aoa-summon/` bundle and its schemas.

### Stage 3. SDK helper slice

Land the full updated `aoa-sdk/src/aoa_sdk/a2a/rebase/` slice, examples, and tests.

### Stage 4. Validation

Use repo-native validators after reconciliation:

- `aoa-agents`: `python scripts/validate_agents.py && python -m pytest -q`
- `aoa-skills`: `python scripts/build_catalog.py --check && python scripts/validate_skills.py --fail-on-review-truth-sync && python -m pytest -q tests`
- `aoa-routing`: `python scripts/validate_router.py && python scripts/build_router.py --check && python -m pytest -q tests`
- `aoa-playbooks`: run the repo README verify battery
- `aoa-sdk`: `python scripts/build_workspace_control_plane.py --check && python scripts/validate_workspace_control_plane.py && python -m pytest -q && python -m ruff check .`

## Single-pass Codex rule

If a stronger live file already exists:

1. keep the live stronger name
2. fold this package into it
3. add one short supersession or direction note if needed
4. avoid parallel `wave5_*` namespaces inside the live repos unless the repo clearly wants that pattern

## Practical answer to the old-wave question

- **Do not** apply wave 1, wave 2, and wave 3.
- **Do not** mechanically replay wave 4.
- Use **wave 5 only** as the living install surface.
- Use earlier waves only as compare-and-fold reference if Codex needs lineage.
