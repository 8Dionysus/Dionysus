# A2A Return Reentry Adjuncts

This note records the playbook-layer adjunct for A2A child routes under the current recurrence discipline.

## Core rule

A child route that degrades or loses shape should return through scenario-owned anchors and re-entry modes, not through runtime improvisation.

## What a playbook may name

- allowed return anchors
- allowed re-entry modes
- when a child lane should relaunch from checkpoint
- when a child lane should stop at review gate or rollback gate
- when a local Codex child route is a clean scenario helper

## What a playbook must not become

- automatic spawning logic
- a second role registry
- hidden Codex runtime wiring
- transport authority

## Child-lane guidance

When a playbook needs a local helper, prefer a compact role split that can merge back short ledgers and named artifacts rather than raw traces.

If the child route ends under stress, the playbook may point back to:

- `same_phase`
- `previous_phase`
- `router_reentry`
- `checkpoint_relaunch`
- `review_gate`
- `rollback_gate`
- `safe_stop`

The playbook still says where the route may return. It does not become the runtime that performs the return.
