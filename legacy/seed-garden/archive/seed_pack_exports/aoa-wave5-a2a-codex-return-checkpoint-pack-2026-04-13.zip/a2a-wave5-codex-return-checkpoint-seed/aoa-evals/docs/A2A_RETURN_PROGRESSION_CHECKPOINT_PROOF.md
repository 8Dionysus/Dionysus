# A2A Return, Progression, and Checkpoint Proof Posture

This note records the proof-facing questions that current A2A child routes should be able to answer.

## Proof targets

A healthy proof surface should be able to check:

1. did summon respect the quest passport?
2. if progression posture was required, was the unlock evidence present?
3. if the route was self-agent or policy-sensitive, was the checkpoint stack complete enough?
4. if the child route degraded, was `return` mapped to a named anchor?
5. did the chosen re-entry mode match the scenario and checkpoint posture?
6. did the checkpoint bridge keep the fixed closeout order?
7. were memo exports candidate-oriented rather than raw-trace writeback?
8. did runtime publication stay inside canonical owner-local event families?

## Boundary

This note does not create a new eval canon by itself.

It records what future or local eval bundles should prove if A2A child delegation becomes part of a recurring or promoted route.
