# Acceptance Criteria

A healthy landing should make it possible to point to all of the following:

1. a summon decision can prefer `codex_local` without breaking source ownership
2. `aoa-summon` can block or gate when:
   - `d3+` needs split first
   - progression unlock is missing
   - self-agent checkpoint posture is incomplete
   - stress posture narrows or blocks the lane
3. a failed or narrowed child run can produce a bounded return plan with:
   - `anchor_artifact`
   - `reentry_mode`
   - `reentry_note`
   - `next_hop`
4. a checkpoint bridge plan binds:
   - reviewed artifact
   - optional checkpoint note
   - optional Codex rollout trace
   - fixed execution order:
     `aoa-session-donor-harvest -> aoa-session-progression-lift -> aoa-quest-harvest`
5. runtime publication still uses canonical event kinds and owner-local lanes
6. memo export stays reviewed and candidate-oriented
7. no raw child trace is written into memo canon
8. the included pytest battery passes after reconciliation
