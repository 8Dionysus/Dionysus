# Supersession Map

## Waves 1 to 3

Reference only.

Keep the historical ideas, but do not install them:

- bounded delegation
- governed remote interop
- registry and push continuity exploration

Discard their install order and any assumptions that predate:
- quest passports
- recurrence / return law
- checkpoint closeout bridge
- progression overlays
- self-agent checkpoint posture
- Codex workspace projection as the primary local install story

## Wave 4

Wave 4 remains the nearest ancestor, but this package absorbs its living baseline.

Use wave 4 only when Codex wants a comparison diff for:
- prior `aoa_sdk.a2a.rebase` helper behavior
- earlier summon lane rules
- earlier owner publication mapping

Do not replay wave 4 as a separate mandatory install step.

## Wave 5 rule

Wave 5 is the living landing:

- local execution defaults to Codex-local child targets
- remote transport stays explicit
- return is first-class
- checkpoint bridge planning is explicit
- progression and self-agent gates are part of summon assessment
- stats keep the canonical event family
