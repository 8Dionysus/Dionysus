# AoA A2A Wave 5 Codex / Return / Checkpoint Seed

This package folds the earlier A2A wave ideas into the current AoA shape where:

- Codex is the primary control-plane entry
- local child agents still need Codex-friendly install and projection paths
- recurrence and `return` are now explicit public law
- checkpoint-aware session growth already feeds reviewed closeout
- progression and self-agent checkpoint posture now matter for governed delegation
- owner-local receipt families already exist and `aoa-stats` only accepts canonical event kinds

## What this seed plants

1. Codex-local child targeting as the default local execution surface
2. summon gating that reads:
   - quest passport
   - stress posture
   - progression overlay when required
   - self-agent checkpoint stack when relevant
3. return planning that maps failed or narrowed child runs back into:
   - `transition_decision`
   - named anchors
   - explicit re-entry modes
4. checkpoint-bridge planning that stays subordinate to:
   - `aoa-checkpoint-closeout-bridge`
   - reviewed closeout
   - owner-local publication lanes
5. memo export planning that stays reviewed and candidate-oriented
6. runtime receipt mapping that reuses canonical event kinds instead of minting a new stats family

## Standalone posture

Use this package as the current install surface.

Do **not** mechanically replay wave 1, wave 2, wave 3, or wave 4 first. Those packages are lineage and comparison material now.

If Codex wants ancestry for a particular file, compare against the older waves and fold only the live surviving law into the stronger current name.

## Target repos

- `8Dionysus`
- `Agents-of-Abyss`
- `aoa-agents`
- `aoa-skills`
- `aoa-playbooks`
- `aoa-routing`
- `aoa-evals`
- `aoa-memo`
- `aoa-stats`
- `aoa-sdk`
- `abyss-stack`

## Package shape

- repo-target doctrine notes
- refreshed `aoa-summon` skill surface
- full updated `aoa_sdk.a2a.rebase` helper slice
- examples and tests
- one explicit install strategy for Codex

## Core rule

The transport seam may grow, but the current public order stays:

- source repos own meaning
- Codex-facing projections stay projections
- local child runs prefer the Codex workspace install surface
- return is governed re-entry, not retry theater
- checkpoint bridges stay mechanical until reviewed closeout applies skill meaning
- runtime publication stays owner-local
- stats remain canonical-envelope only
