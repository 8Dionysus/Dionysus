# A2A Wave 5 Consolidated Note

This note records the current AoA-center posture for A2A-related work after the project grew beyond the earlier bootstrap waves.

## Center rule

A2A is now read through the live federation shape, not through the old wave chain.

The current surviving law is:

- source repos own meaning
- Codex remains the primary local control plane
- local child agents must remain Codex-friendly
- remote child runs must map terminal state into:
  - return
  - checkpoint bridge planning
  - reviewed closeout
- owner-local publication and canonical stats envelopes remain the terminal evidence spine

## What this means

A2A is useful here as an interop seam, but it does not become:

- a second role registry
- a second closeout world
- a second memory canon
- a second workspace install story

The federation remains source-first and reviewable even when child routes widen into local or remote delegation.
