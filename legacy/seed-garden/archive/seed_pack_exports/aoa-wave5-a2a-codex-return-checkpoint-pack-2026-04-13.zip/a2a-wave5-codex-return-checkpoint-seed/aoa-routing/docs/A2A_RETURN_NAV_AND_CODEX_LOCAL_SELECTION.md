# A2A Return Navigation and Codex Local Selection

This note records the additive routing posture for current A2A child routes.

## Core rule

Routing may help an actor find the next honest re-entry surface or local execution surface.

Routing does not decide whether summon is permitted.

## Safe routing contributions

Routing may point toward:

- `generated/return_navigation_hints.min.json`
- the owning source repo surface for the anchor that return should inspect
- public memo recall surfaces that support checkpoint continuity
- Codex-local install surfaces when the route is clearly local, such as:
  - project `/.codex/agents/`
  - the projected role target path for the requested role

## Boundary

Routing may say:

- “inspect the owner surface first”
- “this re-entry should likely be checkpoint-shaped”
- “this looks like a local Codex child role, not a remote transport need”

Routing must not say:

- that summon is approved
- that a checkpoint is semantically valid on its own
- that a router hint outranks the source-owned projection chain
