# A2A Codex Workspace Alignment

This note records the workspace-facing rule for local child agents in the current AoA install shape.

## Core rule

Even when A2A-style child delegation is used, local child agents should still land through the Codex-friendly workspace surfaces:

- `/AOA_WORKSPACE_ROOT`
- `/.agents/`
- `/.codex/`
- `/.codex/agents/`

The local child route should not invent a second install tree beside the current workspace projection path.

## Projection chain

Keep the current order:

1. `aoa-agents/profiles/*.profile.json`
2. `aoa-agents/config/codex_subagent_wiring.v2.json`
3. `aoa-agents/generated/codex_agents/agents/*.toml`
4. live workspace install under `/.codex/agents/`

A local child target may be described in an A2A helper or packet, but the install and projection story still belongs to the existing Codex workspace path.

## Boundary

- `8Dionysus` still owns the selected shared-root workspace projection
- `aoa-agents` still owns role and projection meaning
- `aoa-sdk` still owns workspace discovery and control-plane helpers
- `abyss-stack` may host runtime workers, but it should not replace the project-level Codex install story

## Practical consequence

For current local bounded child work, the honest first target is usually:

- a Codex-local role target under `/.codex/agents/`

Remote A2A transport remains available later when the route explicitly needs a separate endpoint, host, or continuity lane.
