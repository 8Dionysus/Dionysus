# Apply With Codex

Use this package as a controlled fold, not a blind file drop.

## Codex posture

- prefer current repo-native names when stronger live names already exist
- preserve source-of-truth boundaries
- do not introduce a second A2A authority surface where a live repo already owns the law
- keep local child execution Codex-first by default
- keep remote A2A explicit and secondary
- map terminal child state into reviewed closeout and return planning, not into a shadow runtime loop

## Reconciliation rules

### `8Dionysus`
Keep workspace install truth with:
- `/AOA_WORKSPACE_ROOT`
- `/.agents/`
- `/.codex/`

Do not mint a second workspace install story inside `aoa-sdk` or `abyss-stack`.

### `aoa-agents`
Keep:
- source role profiles
- Codex projection chain
- quest passports
- cohort hints
- self-agent checkpoint contract
- recurrence / return contract

Do not turn the A2A note into a second role registry.

### `aoa-skills`
Keep `aoa-summon` as the bounded delegation workflow.
Do not hide it inside SDK helpers.

### `aoa-playbooks`
Keep scenario-level return anchors and re-entry modes here.
Do not turn playbooks into auto-spawn logic.

### `aoa-routing`
Keep routing advisory only.
Hints may point to:
- source-owned return surfaces
- memo recall support
- Codex local install surfaces
But routing must not own summon permission.

### `aoa-sdk`
This is the control-plane helper slice.
It may build:
- Codex local child targets
- summon decisions
- return plans
- checkpoint bridge plans
- reviewed closeout requests
It must not auto-run skill meaning or invent new owner-local receipt families.

### `abyss-stack`
Keep runtime publication here.
If a local or remote child run produces terminal runtime evidence, publish it under the existing owner lane.

## Merge discipline

When a target repo already has a stronger equivalent:

- copy the law, not the filename
- reuse the repo’s existing directory idiom
- prefer short additive notes over broad rewrites
- keep examples and tests even if docs get folded into stronger live surfaces
