# A2A Codex-Friendly Local Agents

This note records the runtime-facing rule for local child agents in the current AoA shape.

## Core rule

`abyss-stack` may host runtime workers, wrappers, or A2A transport endpoints.

For current local bounded child work, however, the live local agent identity should still remain compatible with the project-level Codex install surface.

## Practical consequences

- local child targets should point back to `/.codex/agents/`
- runtime-local retry should not bypass `return`
- terminal runtime evidence should publish into the existing runtime owner lane
- checkpoint relaunch should stay subordinate to reviewed closeout and the bridge skill

## Boundary

`abyss-stack` hosts runtime mechanics.
It does not replace:

- role truth in `aoa-agents`
- workspace install truth in `8Dionysus`
- closeout law in `aoa-sdk`
