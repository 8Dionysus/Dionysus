# aoa-summon

## Purpose

Delegate one bounded child route while preserving:

- quest passport law
- Codex-first local execution posture
- stress narrowing
- progression and self-agent gates
- return planning
- checkpoint-aware reviewed closeout
- owner-local publication mapping

## When to use

Use this skill when a parent lane already has a real anchor and needs a narrower child actor to return named AoA artifacts.

Typical fits:

- bounded reviewer or evaluator pass
- bounded leaf implementation under low risk
- local Codex child verification
- explicit remote review helper when local execution is not enough

## Required inputs

- `quest_passport`
- `summon_request`
- one parent anchor:
  - `route_anchor`
  - `parent_task_id`
  - or `session_ref`
- named `expected_outputs`

## Required contextual rules

- default `transport_preference` is `codex_local`
- if `require_progression` is true, provide a reviewed progression overlay
- if the route is self-agent or policy-sensitive, provide a reviewed self-agent checkpoint surface

## Optional inputs

- `stress_bundle`
- `checkpoint_note_ref`
- `codex_trace_ref`
- `reviewed_artifact_path`
- `audit_refs`
- `playbook_ref`

## Lane rules

### codex-local leaf

Good fit when all are true:

- difficulty is `d0_probe`, `d1_patch`, or bounded `d2_slice`
- risk is `r0_readonly` or `r1_repo_local`
- the parent anchor is explicit
- outputs are named
- the requested role is a clean leaf helper

### codex-local reviewed

Good fit when the route is still local but the child should narrow scope instead of widening it:

- reviewer
- evaluator
- architect-like review helper

### explicit remote reviewed

Use only when the route truly needs a separate endpoint, transport continuity, or non-local execution surface.

Remote does not bypass the same passport, return, checkpoint, or closeout law.

### split required

If `difficulty` is `d3+`, do not directly launch child execution.

Split first.

### progression gate

If the child route depends on reviewed unlock posture and no adequate progression overlay exists, stop and gate the summon.

### self-agent checkpoint gate

If the route is self-agent or policy-sensitive and approval / rollback / health posture is incomplete, stop and gate the summon.

### human gate

If control mode, stress posture, or missing evidence blocks honest delegation, return a human-gated result instead of pretending the summon happened.

## Outputs

The result should be able to include:

- `decision`
- `lane`
- `execution_surface`
- `cohort_pattern`
- `reason_codes`
- `requested_posture`
- `blocked_actions`
- `codex_local_target`
- `owner_publication_plan`
- `memo_export_plan`
- `return_plan`
- `checkpoint_bridge_plan`
- `closeout_required`

## Verification

- verify that the passport and anchor are present
- verify that outputs are named
- verify that `d3+` routes split first
- verify that stress posture can only narrow or block
- verify that progression and self-agent gates are not bypassed
- verify that terminal publication stays inside canonical owner families
- verify that memo export stays reviewed and candidate-oriented
- verify that failed or narrowed child runs can map into `return`

## References

- `references/summon-request-v3.schema.json`
- `references/summon-result-v3.schema.json`
- `references/passport-lane-matrix.v3.md`
- `references/no-raw-traces-rule.md`
