# A2A Summon Return and Checkpoints

This note binds the summon workflow to the current live AoA surfaces.

## Core rule

`aoa-summon` is no longer just “call another agent”.

It must now stay legible across five adjacent laws:

1. quest passport
2. stress posture
3. progression overlay when required
4. self-agent checkpoint posture when relevant
5. return / checkpoint / closeout landing when the child lane degrades or ends

## Local-first rule

If the child route is local and bounded, prefer a Codex-local projected role target.

Do not treat a local helper as a second hidden runtime species.

## Terminal rule

If the child route fails, stalls, or must reground:

- build a return plan
- optionally build a checkpoint bridge plan
- feed the reviewed closeout path
- keep owner-local receipt publication explicit
