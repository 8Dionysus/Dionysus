# A2A Return Support and Reviewed Exports

This note records the memo-side posture for current A2A child routes.

## Core rule

A child route may contribute reviewed memo candidates.

It may not dump raw execution traces into memo canon.

## Return support mapping

When a child route returns:

- the return decision may survive as a `decision`
- the stable return point may survive as an `anchor`
- checkpoint-shaped bounded working state may survive as a `state_capsule`
- bounded execution or review traces may survive as `episode` or `audit_event`

## Candidate posture

Deep or distillation outputs remain candidate-shaped:

- `claim`
- `pattern`
- `bridge`

Stress or recovery context may also produce draft adjunct candidates for:

- failure lessons
- recovery patterns

## Boundary

- live scratchpad stays out of memo canon
- recall support does not grant summon permission
- memo does not decide retry or tier rights
