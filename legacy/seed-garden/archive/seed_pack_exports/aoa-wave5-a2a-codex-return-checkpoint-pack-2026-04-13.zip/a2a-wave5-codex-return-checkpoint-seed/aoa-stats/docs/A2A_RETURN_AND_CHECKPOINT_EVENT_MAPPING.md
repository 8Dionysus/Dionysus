# A2A Return and Checkpoint Event Mapping

This note records the stats-facing rule for current A2A child-route publication.

## Core rule

Do not mint a new event family just because return or checkpoint planning became richer.

Use the existing canonical event family and carry the extra semantics inside payload fields.

## Current mapping

Terminal runtime evidence for an A2A child route should still publish as:

- `runtime_wave_closeout_receipt`

Useful payload fields may now include:

- `execution_surface`
- `decision_lane`
- `return_required`
- `return_anchor_artifact`
- `return_reentry_mode`
- `checkpoint_note_ref`
- `codex_trace_ref`
- `codex_role`
- `codex_config_path`

## Owner lane

The publication target remains the runtime owner lane, for example:

- `abyss-stack.runtime-wave-closeouts`

## Anti-pattern

Do not create:

- `a2a_return_receipt`
- `a2a_checkpoint_receipt`
- `a2a_codex_local_receipt`

Those would widen the stats envelope family without need.
