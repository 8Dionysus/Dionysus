# QUESTBOOK.md — aoa-techniques

This file is the public tracked surface for deferred canon-hardening, donor-refinery, and generated-source alignment obligations that belong to `aoa-techniques`.

Use it for:
- promotion-readiness follow-through
- donor-refinery debts that survive the current diff
- generated/source alignment around capsules, exports, and manifests
- repeat routes that should be harvested into durable technique canon

Do not use it for:
- raw donor notes that still belong in intake or review
- snippet ideas that have not survived a bounded diff
- private working chatter or local-only paths
- re-explaining technique meaning that already lives in source docs

## Frontier
- `AOA-TECH-Q-0001` — land repo-local questbook surface for canon hardening and donor-refinery follow-ups
- `AOA-TECH-Q-0002` — track promotion-readiness and donor-refinery follow-ups without bloating technique docs

## Near
- `AOA-TECH-Q-0003` — keep technique capsules, KAG export, and repo-doc surface manifests aligned with source-owned technique sections

## Latent / parked
- `AOA-TECH-Q-0004` — harvest repeated review and evidence-note repair routes into durable technique canon

## Harvest candidates
- `AOA-TECH-Q-0004` — harvest repeated review and evidence-note repair routes into durable technique canon

## Backing files

- `quests/*.yaml`
- `schemas/quest.schema.json`
- `schemas/quest_dispatch.schema.json`
- `generated/quest_catalog.min.example.json`
- `generated/quest_dispatch.min.example.json`
