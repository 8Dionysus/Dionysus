# Touchpoints not included in this package

This seed intentionally avoids editing existing canonical files to reduce merge friction.
After landing the new files, Codex can decide whether to add minimal links or role notes in the following places.

## `aoa-techniques`
- `README.md` start-here path
- `docs/START_HERE.md` if you want a short QUESTBOOK pointer
- `TECHNIQUE_INDEX.md` only if a compact tracked-obligation note would help

## `aoa-skills`
- `README.md` start-here path
- `docs/PUBLIC_SURFACE.md` if you want a short QUESTBOOK pointer
- generated governance surfaces only after a real builder exists

## `aoa-evals`
- `README.md` or `docs/README.md`
- `EVAL_INDEX.md` only if you want a tiny note about proof-gap quests
- comparison or trace bridge docs only if wording truly needs to change

## `aoa-kag`
- `README.md` or `CHARTER.md`
- `docs/FEDERATION_KAG_READINESS.md` if you want a short quest reference
- generated exports only after real builders or validators exist

## `abyss-stack`
- `README.md`
- `CHARTER.md` or `BOUNDARIES.md`
- runtime automation or deployment surfaces only after control-mode language is settled

## `Tree-of-Sophia`
- `README.md`
- `BOUNDARIES.md`
- knowledge-model or node-contract docs only if the operational boundary needs a one-paragraph pointer

## `Dionysus`
- `README.md`
- `docs/codex/planting-protocol.md`
- validator or export scripts only after real quest projections become useful

## `8Dionysus`
- `README.md`
- `GLOSSARY.md`
- keep changes minimal so the profile repo stays an orientation layer

## `ATM10-Agent`
- no structural second-wave changes are included
- only the domain clarification note is provided as an optional delta