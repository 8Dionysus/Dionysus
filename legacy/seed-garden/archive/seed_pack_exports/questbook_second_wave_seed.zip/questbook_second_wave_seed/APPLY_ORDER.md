# Apply order — second wave

Recommended landing order:

1. `aoa-techniques`
2. `aoa-skills`
3. `aoa-evals`
4. `aoa-kag`
5. `abyss-stack`
6. `Tree-of-Sophia`
7. `Dionysus`
8. `8Dionysus`
9. optional `ATM10-Agent/docs/QUESTBOOK_DOMAIN_NOTE.md`

## Why this order

- `aoa-techniques -> aoa-skills -> aoa-evals` follows the visible canon -> execution -> proof chain
- `aoa-kag` comes after the source-owned layers it lifts from
- `abyss-stack` comes after source-layer questbooks so infra can stay clearly downstream of source-owned meaning
- `Tree-of-Sophia` gets a tailored wave after the AoA public layers because its questbook shape must stay source-first and non-flattening
- `Dionysus` comes late because it is the seed garden and dispatch layer, not the owner of the planted doctrine
- `8Dionysus` profile comes last because it is orientation, not source truth
- the ATM10 note is an optional correction delta to the first wave

## Suggested landing posture

Land the new files first.
Then let Codex decide whether to add one-paragraph pointers in existing READMEs, CHARTERs, or boundary docs.