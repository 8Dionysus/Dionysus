# QUESTBOOK integration — Dionysus seed garden

## Purpose

This note shows how `QUESTBOOK.md` fits into `Dionysus` as the public tracked surface for planting obligations.

## Role split

- wave manifests define planting order
- seed files define seed meaning
- closure notes define finished state for closed waves
- `seed-registry.yaml` remains the navigation overlay
- planting protocol and validator surfaces remain operational contracts
- `QUESTBOOK.md` tracks deferred obligations that survive a bounded planting change

## Good anchors in this repo

Use stable anchors such as:
- `README.md` source-of-truth order
- `seed-registry.yaml`
- `docs/codex/planting-protocol.md`
- wave manifest files
- validator scripts and reports
- `archive/seed_pack_exports/` for derived transport surfaces only

## Initial posture

Good seed-garden quests usually answer:
- which manifest, registry, or protocol seam drifted
- which live seed or closure state needs explicit follow-through
- which export or transport surface needs validity checks
- which future-wave staging obligation survived current review