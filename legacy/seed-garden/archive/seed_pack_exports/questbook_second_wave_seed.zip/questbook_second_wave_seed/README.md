# QUESTBOOK second-wave seed

This package extends the first-wave QUESTBOOK rollout to the remaining repositories in the current AoA / ToS ecosystem.

It is intentionally add-first.
It prefers new files, repo-local questbooks, starter quests, and example generated projections over risky edits to existing canonical docs.

Codex can land these files, adapt placement where local conventions demand it, and then thread minimal README / CHARTER / boundary links afterward.

## What this seed covers

Second-wave repo-specific seeds are included for:

- `aoa-techniques`
- `aoa-skills`
- `aoa-evals`
- `aoa-kag`
- `abyss-stack`
- `Tree-of-Sophia`
- `Dionysus`
- `8Dionysus`

An optional delta note is also included for `ATM10-Agent` to clarify the separation between project QUESTBOOK and Minecraft-domain quest or inventory language.

## Package posture

- human-facing document name: `QUESTBOOK.md`
- machine-facing object name: `work_quest_v1`
- machine-facing dispatch projection name: `quest_dispatch_v1`
- example generated files end with `.example.json` until each target repo gains a real builder or validator
- questbooks track deferred obligations that outlive a single diff
- questbooks do **not** replace source-owned meaning, seed manifests, roadmaps, or local ignored scratchpads

## Coverage

With first wave plus this package, every currently visible public repository in the ecosystem has a QUESTBOOK seed or delta note.

See `APPLY_ORDER.md`, `SEED_MANIFEST.yaml`, and `TOUCHPOINTS_NOT_INCLUDED.md`.