# QUESTBOOK integration — abyss-stack

## Purpose

This note shows how `QUESTBOOK.md` fits into `abyss-stack` without confusing infra work with source-owned AoA or ToS meaning.

## Role split

- `abyss-stack` owns runtime, deployment, lifecycle, security, storage, and platform posture
- specialized AoA repositories still own their own doctrine and public meaning
- `QUESTBOOK.md` tracks deferred infra obligations that survive the current bounded diff
- high-risk routes should default toward stronger control modes and human gates

## Good anchors in this repo

Use stable anchors such as:
- `CHARTER.md`
- `BOUNDARIES.md`
- `docs/ARCHITECTURE.md`
- `docs/PROFILES.md`
- `docs/PRESETS.md`
- `docs/PROFILE_RECIPES.md`
- `docs/RENDER_TRUTH.md`
- `docs/FIRST_RUN.md`
- `docs/DOCTOR.md`
- `docs/WINDOWS_BRIDGE.md`
- `docs/REFERENCE_PLATFORM.md`
- `docs/MACHINE_FIT_POLICY.md`

## Initial posture

Infra quests should answer one of these:
- which platform or profile obligation survived the current diff
- which guardrail is required before a risky mutation route
- which machine-fit or bridge follow-up must stay visible
- which route is too risky for small local wrappers and must stay human-gated