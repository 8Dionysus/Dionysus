# QUESTBOOK domain note — ATM10-Agent

`ATM10-Agent` already carries game-facing and operator-facing surfaces whose names overlap with quest and inventory language from the Minecraft domain.

This matters for QUESTBOOK integration.

## Core clarification

The project-level `QUESTBOOK.md` is a repo-maintenance and deferred-obligation surface.

It is **not** the same thing as:
- Minecraft quest content
- inventory surfaces
- world-facing or game-facing domain objects
- operator intents that happen to use quest-shaped language

## Practical guidance

Keep the human-facing document name `QUESTBOOK.md`.

Keep the machine-facing object and dispatch names:
- `work_quest_v1`
- `quest_dispatch_v1`

If UI or operator wording needs disambiguation later, prefer labels such as:
- `project quests`
- `repo questbook`
- `maintenance quests`

and reserve game-facing quest or inventory wording for the actual ATM10 domain layer.

## Why this note exists

The first-wave seed treated `open_quest_book` as a convenient public intent donor.
Your clarification makes the boundary sharper: the ATM10 layer already carries Minecraft-shaped semantics, so project QUESTBOOK should remain explicitly separate rather than leaning on accidental name overlap.