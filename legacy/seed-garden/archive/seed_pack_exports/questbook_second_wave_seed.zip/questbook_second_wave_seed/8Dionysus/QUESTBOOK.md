# QUESTBOOK.md — 8dionysus

This file is the public tracked surface for deferred orientation-layer obligations that belong to the `8Dionysus` profile repository.

Use it for:
- repo-map drift that survives current edits
- glossary and start-here maintenance
- onboarding or retirement of public repos in the ecosystem map
- other orientation-layer repairs that are too durable for a one-off diff

Do not use it for:
- owning the meaning of any specialized repo
- duplicating specialized roadmaps or questbooks
- private collaboration notes
- turning the profile layer into a hidden command center

## Frontier
- `DION-PROFILE-Q-0001` — land a minimal profile questbook for orientation-layer obligations only
- `DION-PROFILE-Q-0002` — track repo-map, start-here, and glossary drift when source repos change public entry surfaces

## Near
- `DION-PROFILE-Q-0003` — track new repo onboarding or retirement in the public ecosystem map without silently overriding source truth

## Harvest candidates
- none yet

## Backing files

- `quests/*.yaml`
- `schemas/quest.schema.json`
- `schemas/quest_dispatch.schema.json`
- `generated/quest_catalog.min.example.json`
- `generated/quest_dispatch.min.example.json`
