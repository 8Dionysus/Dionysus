# QUESTBOOK integration — 8Dionysus profile repo

## Purpose

This note shows how a minimal `QUESTBOOK.md` fits into the profile repository.

## Core boundary

The profile repo is a coordination and orientation surface.
It points toward source repositories.
It should not silently replace them.

## Good uses

Use profile quests for:
- link and repo-map drift
- glossary or start-here upkeep
- onboarding or retirement of public repos in the visible ecosystem map

## Bad uses

Do not use profile quests for:
- repo-local work that belongs in a source repo
- doctrine for AoA, ToS, KAG, infra, or the app layer
- hidden prioritization that would overrule source repositories

## Good anchors in this repo

Use stable anchors such as:
- `README.md`
- `GLOSSARY.md`

Keep this questbook intentionally small.