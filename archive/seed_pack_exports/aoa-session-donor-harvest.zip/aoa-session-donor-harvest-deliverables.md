# aoa-session-donor-harvest deliverables

## Main artifact

- `aoa-session-donor-harvest-patch.zip`
  - patch-ready repo-relative files for `aoa-skills`
  - includes canonical skill bundle, config updates, eval fixtures, quest-harvest boundary tightening, and generated-style portable export

## Extra artifacts

- `aoa-session-donor-harvest.patch`
  - unified diff against the currently published upstream files that were inspected during grounding
- `aoa-session-donor-harvest-codex-portable.zip`
  - minimal Codex-facing portable export under `.agents/skills/aoa-session-donor-harvest/SKILL.md`

## Included repo-relative paths

- `skills/aoa-session-donor-harvest/SKILL.md`
- `skills/aoa-session-donor-harvest/techniques.yaml`
- `skills/aoa-session-donor-harvest/checks/review.md`
- `skills/aoa-session-donor-harvest/examples/runtime.md`
- `skills/aoa-session-donor-harvest/references/owner-layer-map.md`
- `skills/aoa-session-donor-harvest/agents/openai.yaml`
- `SKILL_INDEX.md`
- `config/portable_skill_overrides.json`
- `config/skill_pack_profiles.json`
- `config/skill_policy_matrix.json`
- `tests/fixtures/skill_evaluation_cases.yaml`
- `tests/fixtures/skill_evaluation_snapshots/aoa-session-donor-harvest/*`
- `tests/fixtures/skill_evaluation_snapshots/aoa-quest-harvest/quest_harvest_vs_session_donor_harvest_boundary.md`
- `skills/aoa-quest-harvest/SKILL.md`
- `.agents/skills/aoa-session-donor-harvest/SKILL.md`
