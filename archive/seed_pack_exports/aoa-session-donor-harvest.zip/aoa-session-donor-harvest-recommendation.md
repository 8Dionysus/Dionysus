# Recommendation

## Call

Create a new core skill, `aoa-session-donor-harvest`, and keep `aoa-quest-harvest` narrow.

## Why

`aoa-quest-harvest` is currently honest as a small explicit-only post-session promotion triage skill. The broader job you described starts earlier: extracting reusable donor units from a reviewed session and only then deciding the honest owner layer. That broader job also needs `aoa-techniques` as a first-class destination, while `aoa-quest-harvest` currently routes among quest, skill, playbook, orchestrator, proof, and memo only.

## Suggested relation

- `aoa-session-donor-harvest`: reviewed session artifact -> donor pack -> owner-layer recommendation -> smallest next artifact
- `aoa-quest-harvest`: repeated reviewed quest unit -> final promotion verdict among quest/skill/playbook/agent/eval/memo

## Tiny follow-up change to `aoa-quest-harvest`

Keep the body mostly intact, but add one input line:

- donor harvest packet from `aoa-session-donor-harvest`

That keeps the narrow quest specialization while letting the new upstream skill feed it.
