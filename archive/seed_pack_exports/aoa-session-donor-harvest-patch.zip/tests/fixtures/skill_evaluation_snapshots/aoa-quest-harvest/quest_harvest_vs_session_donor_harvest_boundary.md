# Evaluation Snapshot

## Prompt

Compare a single repeated reviewed quest unit that only needs a final promotion verdict with a broader reviewed-session donor harvest, and choose the clearer fit.

## Expected selection

use

## Why

The broader donor harvest has already happened. What remains is the narrower final decision about where one repeated reviewed quest unit honestly belongs.

## Expected object

A promotion verdict that names the repeated unit, the right owner surface, and the nearest wrong target that must stay rejected.

## Boundary notes

This is a quest-harvest case, not a session-donor-harvest case. Do not reopen broad session extraction once the work is already narrowed to one repeated quest unit.

## Verification hooks

The response should reject the broader session-harvest framing, keep the decision bounded to one repeated unit, and produce a promotion verdict rather than a multi-candidate donor pack.
