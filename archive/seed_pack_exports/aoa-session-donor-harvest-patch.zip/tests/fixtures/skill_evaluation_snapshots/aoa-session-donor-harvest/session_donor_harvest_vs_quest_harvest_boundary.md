# Evaluation Snapshot

## Prompt

Compare a reviewed session artifact that still contains several reusable donor candidates with a narrower repeated-quest promotion decision, and choose the clearer fit.

## Expected selection

use

## Why

The source still needs broader donor extraction and owner-layer routing across multiple candidate units. That is upstream of the narrower final-promotion decision handled by `aoa-quest-harvest`.

## Expected object

A donor harvest pack that names each reusable unit, the chosen owner layer, and the nearest wrong target for each accepted candidate.

## Boundary notes

This is a session-donor-harvest case, not a quest-harvest case. Keep the broader session-level extraction separate from the later final-promotion triage for one repeated quest unit.

## Verification hooks

The response should explicitly reject `aoa-quest-harvest`, name why multiple donor units still need routing, and produce a donor-harvest-shaped output.
