# Evaluation Snapshot

## Prompt

A reviewed session already isolated one repeated quest-shaped unit, and the only remaining ambiguity is whether that one unit should stay a quest or be promoted into skill, playbook, memo, proof, or agent surfaces.

## Expected selection

do_not_use

## Why

The broader donor harvest has already been done. What remains is the narrower final promotion verdict for one repeated quest unit, which belongs to `aoa-quest-harvest`.

## Expected object

A deflection toward `aoa-quest-harvest` for the narrower final promotion verdict.

## Boundary notes

Do not use this skill when the session output has already been narrowed to one repeated quest-shaped unit. Use the narrower quest-promotion triage instead.

## Verification hooks

The response should explicitly defer to `aoa-quest-harvest` and should avoid re-opening broader owner-layer harvesting that is already resolved.
