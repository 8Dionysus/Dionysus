# aoa-session-donor-harvest patch notes

This patch adds a new core scaffold skill for post-session donor extraction and owner-layer routing.

## Included changes

- canonical skill bundle under `skills/aoa-session-donor-harvest/`
- new `SKILL_INDEX.md` row
- portable selector metadata in `config/portable_skill_overrides.json`
- pack-profile inclusion plus a dedicated `repo-session-donor-harvest-only` profile
- policy entry in `config/skill_policy_matrix.json`
- trigger, adjacency, and snapshot eval fixtures for the new skill
- one boundary-tightening edit to `skills/aoa-quest-harvest/SKILL.md`
- generated-style portable export under `.agents/skills/aoa-session-donor-harvest/SKILL.md`

## Suggested repo-side follow-up after apply

Run the usual skill-layer validation and generation path:

```bash
python scripts/build_catalog.py
python scripts/validate_skills.py
python scripts/build_catalog.py --check
python scripts/build_agent_skills.py --repo-root .
python scripts/validate_agent_skills.py --repo-root .
python scripts/lint_trigger_evals.py --repo-root .
```
