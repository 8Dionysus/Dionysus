# Codex import brief

Use this seed as a delta pack, not as an authority override.

## Merge rules

- Respect the target repo's existing source-of-truth hierarchy.
- If the repo has `docs/SOURCE_OF_TRUTH.md`, follow it.
- If the repo already has `docs/QWEN3_MODEL_STACK.md` or an equivalent runtime posture file, merge the Fedora Intel host profile into that file instead of creating a duplicate.
- Keep active commands in `docs/RUNBOOK.md`.
- Keep blocked or recoverable experiments in `docs/ARCHIVED_TRACKS.md` or the repo equivalent.
- Keep root `README.md` short and link-first.
- Keep long command blocks out of `README.md` and `MANIFEST.md`.

## Host profile objective

Introduce a Fedora host profile for:

- Intel Core Ultra 9 285H
- 32 GiB LPDDR5/X 8400
- `llama.cpp` as the primary GGUF runtime for local work
- daily model lane centered on Gemma 4 E2B/E4B and Qwen3.5 4B/9B
- explicit KV-cache posture
- Vulkan as the first GPU validation lane
- SYCL, OpenVINO, and TurboQuant as additive experimental lanes only

## Acceptance criteria

Codex should adapt names and file placement to the target repo, but the end state should satisfy all of the following:

1. There is one canonical runtime document for this host profile.
2. There is one canonical runbook section with active Fedora commands.
3. There is one archived or experimental section for blocked lanes.
4. The repo gets runnable scripts for:
   - Fedora dependency bootstrap
   - building `llama.cpp` variants
   - running a preset
   - collecting a benchmark matrix
5. Daily defaults are explicit:
   - CPU + oneMKL BLAS first
   - CPU + OpenBLAS fallback
   - Vulkan next
   - Gemma 4 E4B Q4_K_M balanced
   - Gemma 4 E2B Q8_0 safe
   - Qwen3.5 4B or 9B as daily Qwen lane
   - default context 4K to 8K
   - KV default `q4_0/q4_0` balanced and `q8_0/q8_0` safe
6. Experimental lanes stay clearly marked:
   - SYCL
   - OpenVINO CPU/GPU/NPU
   - TurboQuant forks

## Important posture

- Do not silently rewrite an existing OpenVINO-first architecture statement if the target repo already uses one.
- Instead, add a Fedora `llama.cpp-first` host profile as additive unless the repo owner explicitly promotes it to canonical.
- If the target repo already owns a Windows host profile, keep this Fedora profile separate and explicit.
- For Qwen3.5, prefer CPU or Vulkan before SYCL or OpenVINO.
- For Gemma 4, do not rely on cache reuse as a promoted optimization yet.
- For TurboQuant, keep the lane in a lab-only branch or archived track until the repo explicitly blesses a fork and validation method.

## Suggested merge targets for AoA-style repos

- runtime posture -> `docs/QWEN3_MODEL_STACK.md`
- active commands -> `docs/RUNBOOK.md`
- blocked experiments -> `docs/ARCHIVED_TRACKS.md`
- short current state -> `MANIFEST.md`
- next steps -> `ROADMAP.md`

## Minimal patch strategy

Prefer the smallest diff that gives the repo:

- a clear host profile
- a runnable path
- a clean lab boundary
- no duplicated doctrine
