# TurboQuant lab notes

Status: lab-only, not a promoted default for the Fedora Intel 285H host profile.

## Why this exists

TurboQuant is too important to ignore and too early to bless blindly.

The paper signal is strong:

- research reports quality-neutral KV-cache compression around 3.5 bits per channel
- community ports are moving fast
- upstream `llama.cpp` discussion traffic is high

But this host profile still needs discipline:

- no mainline `llama.cpp` support yet
- public fork energy is centered on CUDA and some Metal-oriented testing
- no clean Intel production path should be assumed today

## Current practical posture

Do not merge TurboQuant instructions into the main runbook as a normal path.

Instead:

- keep a dedicated lab branch or tool subtree
- pin the exact fork and commit
- preserve rollback instructions to mainline `llama.cpp`
- benchmark against:
  - `q8_0/q8_0`
  - `q4_0/q4_0`
  - `iq4_nl/iq4_nl` if you are already testing it

## Candidate forks to watch

- `TheTom/llama-cpp-turboquant`
- `spiritbuun/llama-cpp-turboquant-cuda`

## Promotion gate

TurboQuant can move beyond the lab only when all of the following are true:

1. There is a credible Intel-compatible path for this host.
2. The repo has artifacted measurements on real target tasks.
3. Degradation is either absent or explicitly accepted.
4. Build, pin, and rollback steps are clear.
5. The repo owner explicitly promotes the lane.

## Suggested evaluation matrix

Run the same prompt set across:

- CPU + mainline `q8_0/q8_0`
- CPU + mainline `q4_0/q4_0`
- Vulkan + mainline `q8_0/q8_0`
- Vulkan + mainline `q4_0/q4_0`
- TurboQuant fork path when Intel-compatible
- context sizes: `4096`, `8192`, `16384`
- models:
  - `gemma-4-E4B-it`
  - `gemma-4-E2B-it`
  - `Qwen3.5 4B`
  - `Qwen3.5 9B`

## What to artifact

For every run, keep:

- exact command
- binary commit or tag
- backend
- model handle and quant
- context size
- KV cache mode
- prompt log
- stdout
- stderr
- parsed timings
- qualitative notes for breakage, template oddities, or reasoning regressions
