# Fedora Intel llama.cpp seed

Merge-oriented seed for Codex. This package is meant to be absorbed into an existing repository, not copied blindly as a parallel doctrine tree.

## Intent

Target host:

- Intel Core Ultra 9 285H
- 32 GiB RAM
- LPDDR5/X 8400
- Fedora 43 now, with an easy re-check path for Fedora 44 after it ships

Target runtime goal:

- daily local inference and serving with `llama.cpp`
- primary model lanes for `Gemma 4` and `Qwen3.5`
- explicit KV-cache posture, including practical defaults for `q8_0`, `q4_0`, and `iq4_nl`
- lab-only watch surfaces for `TurboQuant`, `SYCL`, and `OpenVINO`

## Design posture

This seed follows the repo shape visible in the user's public ecosystem:

- short root entrypoints
- runtime posture in canonical runtime docs
- active commands in a runbook
- blocked or recoverable experiments in archived tracks
- no giant README duplication
- Codex should merge deltas into the target repo's current source-of-truth surface

## File map

- `CODEX_IMPORT_BRIEF.md`
  - merge instructions for Codex
- `SEED_MANIFEST.json`
  - machine-readable manifest
- `proposed-docs/QWEN3_MODEL_STACK.seed.md`
  - canonical runtime posture for this Fedora Intel host profile
- `proposed-docs/RUNBOOK.seed.md`
  - active runnable commands only
- `proposed-docs/ARCHIVED_TRACKS.seed.md`
  - blocked, lab-only, or recoverable runtime paths
- `proposed-docs/MANIFEST_NOTE.seed.md`
  - concise status snippet
- `proposed-docs/ROADMAP_NOTE.seed.md`
  - next-step snippet
- `scripts/install_fedora_llamacpp_deps.sh`
  - Fedora package bootstrap
- `scripts/build_llamacpp_variants.sh`
  - build CPU, Vulkan, SYCL, and optional OpenVINO variants
- `scripts/run_llama_preset.sh`
  - source a preset and run `llama-cli` or `llama-server`
- `scripts/bench_preset_matrix.py`
  - execute a small preset matrix and artifact logs
- `presets/*.env`
  - ready-to-edit profiles
- `configs/preset_matrix.json`
  - starter benchmark matrix
- `lab/TURBOQUANT_LAB.md`
  - lab-only posture and acceptance gate
- `SOURCES_2026-04-05.md`
  - upstream references used to assemble this seed

## Suggested Codex merge order

1. Inspect the target repo's `README`, `MANIFEST`, `ROADMAP`, and `docs/SOURCE_OF_TRUTH.md` if they exist.
2. Merge `proposed-docs/QWEN3_MODEL_STACK.seed.md` into the canonical runtime doc for the repo.
3. Merge `proposed-docs/RUNBOOK.seed.md` into the active runbook.
4. Merge `proposed-docs/ARCHIVED_TRACKS.seed.md` into the archived or recoverable tracks doc.
5. Add scripts under the repo's preferred scripts path.
6. Keep `README.md` link-first. Do not dump command blocks into it.
7. Promote Vulkan, SYCL, OpenVINO, or TurboQuant only after measured validation on the target host.

## Non-goals

- no claim that TurboQuant is production-ready on Intel for this host today
- no silent replacement of an existing OpenVINO-first repo baseline
- no promise that `Qwen3.5` is stable on SYCL or OpenVINO
- no assumption that a community GGUF should override a repo's own conversion pipeline
