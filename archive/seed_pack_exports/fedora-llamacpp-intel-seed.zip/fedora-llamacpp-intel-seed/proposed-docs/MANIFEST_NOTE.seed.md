## Fedora Intel llama.cpp host profile candidate

- Added a Fedora host-profile seed for Intel Core Ultra 9 285H + 32 GiB LPDDR5/X 8400.
- Daily runtime posture: `llama.cpp-first`, with `CPU + oneMKL BLAS` as default and `Vulkan` as the first GPU validation lane.
- Daily model posture: `Gemma 4 E4B Q4_K_M` balanced, `Gemma 4 E2B Q8_0` safe, `Qwen3.5 4B/9B` as measured candidate lanes.
- Daily KV posture: `q4_0/q4_0` balanced, `q8_0/q8_0` safe.
- Experimental lanes remain explicit: `SYCL`, `OpenVINO CPU/GPU/NPU`, `TurboQuant forks`.
