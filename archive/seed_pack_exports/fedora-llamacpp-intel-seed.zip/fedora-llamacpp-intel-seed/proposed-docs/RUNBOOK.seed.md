# RUNBOOK seed for Fedora Intel llama.cpp host

This seed contains active commands only. Merge these commands into the repo's real runbook rather than leaving them as a standalone shadow doc.

## 1. Fedora system packages

```bash
sudo dnf install -y \
  git cmake ninja-build gcc-c++ make pkgconf-pkg-config \
  python3 python3-pip jq \
  openblas-devel \
  vulkan-loader-devel vulkan-tools glslc \
  clinfo openssl-devel
```

## 2. Optional Intel oneAPI repo and core packages

```bash
sudo ./scripts/install_fedora_llamacpp_deps.sh --with-intel-oneapi-repo
sudo dnf install -y intel-cpp-essentials intel-oneapi-mkl-devel intel-deep-learning-essentials
```

## 3. Preflight

```bash
cat /etc/fedora-release
uname -r
vulkaninfo | head -n 20
clinfo -l || true
```

If oneAPI is installed:

```bash
source /opt/intel/oneapi/setvars.sh
sycl-ls || true
```

## 4. Build llama.cpp variants

Assume `llama.cpp` is already cloned at `~/src/llama.cpp`.

```bash
./scripts/build_llamacpp_variants.sh ~/src/llama.cpp
```

This script tries to build:

- `build-cpu` with oneMKL if available
- `build-openblas` fallback
- `build-vk`
- `build-sycl` if oneAPI is available
- `build-ov` only if OpenVINO environment is already installed and sourced

## 5. CPU daily smoke, Gemma 4 E4B balanced

```bash
./scripts/run_llama_preset.sh   ./presets/gemma4_e4b_cpu_balanced.env   ~/src/llama.cpp/build-cpu
```

## 6. CPU safe smoke, Gemma 4 E2B

```bash
./scripts/run_llama_preset.sh   ./presets/gemma4_e2b_cpu_safe.env   ~/src/llama.cpp/build-cpu
```

## 7. Vulkan smoke, Gemma 4 E4B

```bash
./scripts/run_llama_preset.sh   ./presets/gemma4_e4b_vulkan_balanced.env   ~/src/llama.cpp/build-vk
```

## 8. Qwen3.5 9B CPU safe smoke

Expected model path: `${MODEL_DIR}/Qwen3.5-9B-Q4_K_M.gguf`

```bash
MODEL_DIR=~/models \
./scripts/run_llama_preset.sh   ./presets/qwen35_9b_cpu_safe.env   ~/src/llama.cpp/build-cpu
```

## 9. Qwen3.5 9B Vulkan experimental smoke

```bash
MODEL_DIR=~/models \
./scripts/run_llama_preset.sh   ./presets/qwen35_9b_vulkan_experimental.env   ~/src/llama.cpp/build-vk
```

## 10. Server path for repeated long prefixes

Use this for prompt caching and reusable slot storage.

```bash
MODEL_DIR=~/models \
./scripts/run_llama_preset.sh   ./presets/qwen35_9b_server_cache.env   ~/src/llama.cpp/build-cpu
```

## 11. SYCL lab smoke for Qwen3.5

Use only as a lab check.

```bash
MODEL_DIR=~/models \
source /opt/intel/oneapi/setvars.sh && \
./scripts/run_llama_preset.sh   ./presets/qwen35_9b_sycl_lab.env   ~/src/llama.cpp/build-sycl
```

## 12. OpenVINO GPU smoke

Only if OpenVINO is installed and the build exists.

```bash
source /opt/intel/openvino/setupvars.sh && \
MODEL_DIR=~/models \
./scripts/run_llama_preset.sh   ./presets/openvino_gpu_smoke.env   ~/src/llama.cpp/build-ov
```

## 13. OpenVINO NPU smoke

Only if OpenVINO is installed and the machine exposes NPU device access.

```bash
source /opt/intel/openvino/setupvars.sh && \
MODEL_DIR=~/models \
./scripts/run_llama_preset.sh   ./presets/openvino_npu_smoke.env   ~/src/llama.cpp/build-ov
```

## 14. Benchmark matrix

```bash
python3 ./scripts/bench_preset_matrix.py \
  --matrix ./configs/preset_matrix.json \
  --llama-root ~/src/llama.cpp \
  --runs-dir ./runs/llamacpp-fedora
```

## 15. Quick troubleshooting

### CPU build missing `icx` or `icpx`

Use the OpenBLAS build:

```bash
./scripts/run_llama_preset.sh \
  ./presets/gemma4_e4b_cpu_balanced.env \
  ~/src/llama.cpp/build-openblas
```

### Vulkan build fails

- confirm `vulkaninfo` works
- confirm the host has a working Vulkan ICD
- rebuild only the Vulkan variant

```bash
cmake -S ~/src/llama.cpp -B ~/src/llama.cpp/build-vk -G Ninja -DGGML_VULKAN=1
cmake --build ~/src/llama.cpp/build-vk --config Release -j
```

### Qwen3.5 on SYCL misbehaves

Do not promote the SYCL lane. Keep it lab-only and archive logs.

### OpenVINO NPU fails

Lower context and keep single-session:

```bash
export GGML_OPENVINO_DEVICE=NPU
./build-ov/bin/llama-cli -m ~/models/Llama-3.2-1B-Instruct-Q4_0.gguf -c 512
```

## Source refs

See `SOURCES_2026-04-05.md` in this seed.
