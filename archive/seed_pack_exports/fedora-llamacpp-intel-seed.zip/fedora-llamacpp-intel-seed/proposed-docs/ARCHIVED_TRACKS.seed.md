# Archived / experimental tracks seed

Merge this into the repo's archived or recoverable runtime doc. These are not daily promoted paths for the Fedora Intel 285H host profile.

## 1. OpenVINO for Qwen3.5

Status: blocked for promotion

Reasons:

- upstream `llama.cpp` OpenVINO docs are explicit that the backend is still work in progress
- validated model list includes `Qwen3-8B`, not `Qwen3.5`
- fresh upstream issue reports that Qwen3.5 does not load with the OpenVINO backend

Action:

- keep as a lab-only lane
- do not present as the default Qwen path
- if retained, pin exact build info and archive logs

## 2. OpenVINO GPU/NPU operational limits

Status: recoverable but constrained

Known limits from upstream docs:

- GPU stateless execution has a known issue
- NPU requires explicit small context
- model caching on NPU is not supported
- `llama-server -np > 1` is not supported on NPU
- `--context-shift` is not supported with the OpenVINO backend
- encoder models are not supported in the current backend implementation

Action:

- keep OpenVINO additive
- use for narrow Intel experiments only
- do not treat as the broad repo default without explicit measured promotion

## 3. SYCL for Qwen3.5 on Intel GPU

Status: lab-only

Reason:

- fresh upstream issue reports gibberish, hangs, or crashes for Qwen3.5 on Intel Arc with SYCL

Action:

- only use for smoke checks
- keep `-fa 0` available as a temporary lab workaround where needed
- store logs under artifacts if this lane is explored

## 4. Gemma 4 cache reuse

Status: blocked for promotion

Reason:

- fresh upstream issue reports `cache reuse is not supported` for Gemma 4 models despite expected settings

Action:

- do not sell `--cache-reuse` as a Gemma 4 optimization in public docs
- keep server cache reuse tuned for Qwen first, not Gemma 4

## 5. TurboQuant

Status: lab-only

Reasons:

- strong research signal and active community ports
- not in mainline `llama.cpp`
- public fork activity is currently concentrated around CUDA and some Metal-oriented testing
- no clean Intel production path should be assumed for this host

Action:

- isolate in a dedicated lab branch or tool subtree
- require explicit benchmark parity and rollback notes before any promotion
- do not mix TurboQuant instructions into the main runbook as if it were a settled daily path

## 6. Large model daily use on 32 GiB LPDDR5/X host

Status: not promoted

Non-promoted daily candidates on this host:

- `Qwen3.5-35B-A3B`
- `gemma-4-31B-it`

Action:

- allow only as explicit experiments
- keep context conservative
- save logs and memory traces if tested
