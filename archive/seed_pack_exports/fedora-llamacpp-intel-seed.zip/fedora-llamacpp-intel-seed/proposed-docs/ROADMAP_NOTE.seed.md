## Fedora Intel llama.cpp runtime next steps

1. Validate `build-cpu` and `build-vk` on the repo host.
2. Smoke `Gemma 4 E4B`, `Gemma 4 E2B`, and `Qwen3.5 4B/9B`.
3. Measure `q8_0` vs `q4_0` KV-cache on CPU and Vulkan.
4. Decide whether the Vulkan lane is promotable for daily use.
5. Keep `SYCL`, `OpenVINO`, and `TurboQuant` in explicit lab status until upstream issue pressure drops and local measurements justify promotion.
