# Model Stack and Host Runtime Profiles (llama.cpp-first)
Current as of: 2026-04-05

This seed is intended to be merged into the repo's canonical runtime document. It describes a Fedora host profile for Intel Core Ultra 9 285H + 32 GiB LPDDR5/X 8400.

## Architecture posture

- Runtime backend choice is a host-profile decision.
- This host profile does not redefine repo-wide architecture. It defines the local runtime posture for one machine.
- On this host, `llama.cpp` is the primary GGUF runtime for local text inference, benchmarking, and small local serving.
- Existing repo host profiles remain valid until explicitly replaced or promoted.

## Canonical current host profile

- Host profile id: `llamacpp_fedora_intel_285h`
- Status: candidate until measured on the target repo machine
- Operating system: Fedora 43 now, re-check on Fedora 44 after release
- Runtime family: `llama.cpp-first`
- Primary backends:
  1. `CPU + oneMKL BLAS`
  2. `CPU + OpenBLAS` fallback
  3. `Vulkan` on Intel Arc 140T
- Experimental backends:
  - `SYCL`
  - `OpenVINO CPU/GPU/NPU`
  - `TurboQuant forks`
- Promotion rule: keep `CPU + oneMKL BLAS` as the default until another path is measured and explicitly promoted.

## Local hardware/runtime profile

- CPU: `Intel Core Ultra 9 285H`
- RAM: `32 GiB`
- Memory type: `LPDDR5/X 8400`
- iGPU: `Intel Arc 140T`
- NPU: `Intel AI Boost`
- Memory posture: shared-memory laptop, so context growth and KV-cache policy matter more than model-card max context alone.

## Backend ranking for this host

### 1. CPU + oneMKL BLAS

Use as the daily baseline.

Reasons:

- cleanest `llama.cpp` path on Intel CPU
- explicit upstream build guidance
- avoids current Intel GPU backend edge cases
- best baseline for comparing KV-cache choices

### 2. CPU + OpenBLAS

Use as the fast fallback when oneAPI is not available.

### 3. Vulkan

Use as the first GPU validation lane on this laptop.

Reasons:

- upstream build path is straightforward
- works with the integrated Arc GPU through the standard `llama.cpp` device/offload surface
- better current risk profile for Qwen3.5 than SYCL or OpenVINO on Intel

### 4. SYCL

Keep as a lab lane.

Reasons:

- upstream says SYCL is the Intel GPU path
- but Qwen3.5 still has fresh upstream instability reports on Intel Arc

### 5. OpenVINO CPU/GPU/NPU

Keep additive and experimental on this host profile.

Reasons:

- useful for Intel hardware exploration
- validated on Core Ultra Series 1/2 in upstream docs
- but the backend is still explicitly work in progress and has active limits for GPU and NPU
- Qwen3.5 is not a good promoted target here yet

### 6. TurboQuant forks

Keep lab-only.

Reasons:

- promising paper and community ports
- not mainline `llama.cpp`
- current public momentum is centered on CUDA and some Metal community testing, not an Intel production path

## Active model lanes

| Role | Model | Quant | Posture | Notes |
| --- | --- | --- | --- | --- |
| Primary balanced | `gemma-4-E4B-it` | `Q4_K_M` | default | official GGUF, balanced daily lane |
| Primary safe/fast | `gemma-4-E2B-it` | `Q8_0` | default | official GGUF, safest small model lane |
| Qwen daily small | `Qwen3.5 4B` | `Q5_K_M` or `UD-Q4_K_XL` | candidate | use local conversion or trusted third-party GGUF by repo policy |
| Qwen daily upper | `Qwen3.5 9B` | `Q4_K_M` | candidate | prefer CPU or Vulkan first |
| Large experiment | `gemma-4-26B-A4B-it` | `Q4_K_M` | experimental | only after measured fit and speed |
| Avoid as daily | `Qwen3.5-35B-A3B` | `Q8_0` or similar | not promoted | too memory-heavy for this laptop |
| Avoid as daily | `gemma-4-31B-it` | `Q4_K_M` or larger | not promoted | too close to the RAM edge |

## Context policy

- Daily default context: `4096`
- Normal upper daily bound: `8192`
- Measured opt-in bound: `16384`
- Do not treat 128K or 256K model-card windows as practical daily defaults on this host.
- Any context above 8K should be promoted only after measured runs on the target machine.

## KV-cache policy

### Safe profile

Use for quality checks, regression checks, and harder prompts.

- `-ctk q8_0`
- `-ctv q8_0`

### Balanced profile

Use as the daily default after smoke validation.

- `-ctk q4_0`
- `-ctv q4_0`

### Lab profile

A/B only.

- `-ctk iq4_nl`
- `-ctv iq4_nl`

## Server cache posture

For repeated long prefixes on server runs, prefer:

- `--cache-prompt`
- `--cache-reuse 256`
- `--slot-save-path`
- `-cram`
- `-kvu`
- `--clear-idle`
- `-np 1` on this laptop unless measured otherwise

## Gemma 4 posture

- Gemma 4 is now released and has official GGUF surfaces in `ggml-org`.
- Small Gemma 4 models are the cleanest daily fit for this laptop.
- Treat `cache reuse` as non-promoted for Gemma 4 until the upstream issue is resolved.

## Qwen3.5 posture

- Keep daily Qwen work in the 4B or 9B class on this host.
- Prefer CPU or Vulkan first.
- Do not promote SYCL or OpenVINO for Qwen3.5 until the active issue surface improves.

## OpenVINO posture

- Useful as an additive Intel-specific lane.
- Do not promote as the main lane for this host profile yet.
- Explicitly set small context sizes on GPU/NPU runs.
- For NPU, keep the lane small and single-session.
- For GPU, use stateful execution.

## TurboQuant posture

- Keep TurboQuant out of the canonical daily path for this host right now.
- If a repo wants it, place it in a dedicated lab branch or archived track.
- Promotion gate:
  1. Intel-compatible path exists
  2. parity or acceptable degradation is measured against `q8_0` and `q4_0`
  3. build, run, and rollback instructions are reviewable
  4. the repo explicitly blesses the fork

## Future host profiles (additive)

- `vulkan_intel_arc_local`
- `sycl_intel_arc_lab`
- `openvino_intel_lab`
- `turboquant_lab_only`

## Source refs

See `SOURCES_2026-04-05.md` in this seed.
