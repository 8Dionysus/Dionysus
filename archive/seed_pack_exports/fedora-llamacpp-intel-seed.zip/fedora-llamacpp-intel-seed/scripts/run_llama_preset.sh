#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'EOF'
Usage:
  run_llama_preset.sh <preset.env> <build_dir>

The preset is a bash-compatible env file.
The build dir should be a llama.cpp build folder such as:
  ~/src/llama.cpp/build-cpu
  ~/src/llama.cpp/build-vk
  ~/src/llama.cpp/build-sycl
  ~/src/llama.cpp/build-ov
EOF
}

if [[ $# -lt 2 ]]; then
  usage >&2
  exit 2
fi

PRESET="$(cd "$(dirname "$1")" && pwd)/$(basename "$1")"
BUILD_DIR="$(cd "$2" && pwd)"

if [[ ! -f "${PRESET}" ]]; then
  echo "Preset not found: ${PRESET}" >&2
  exit 1
fi

if [[ ! -d "${BUILD_DIR}/bin" ]]; then
  echo "Expected build dir with bin/: ${BUILD_DIR}" >&2
  exit 1
fi

# shellcheck disable=SC1090
source "${PRESET}"

BIN_NAME="${BIN_NAME:-llama-cli}"
BIN_PATH="${BUILD_DIR}/bin/${BIN_NAME}"

if [[ ! -x "${BIN_PATH}" ]]; then
  echo "Binary not found or not executable: ${BIN_PATH}" >&2
  exit 1
fi

ARGS=()

case "${MODEL_SOURCE:-hf}" in
  hf)
    ARGS+=(-hf "${MODEL_SPEC}")
    ;;
  file)
    ARGS+=(-m "${MODEL_SPEC}")
    ;;
  *)
    echo "Unsupported MODEL_SOURCE: ${MODEL_SOURCE:-}" >&2
    exit 1
    ;;
esac

[[ -n "${CTX:-}" ]] && ARGS+=(-c "${CTX}")
[[ -n "${BATCH:-}" ]] && ARGS+=(-b "${BATCH}")
[[ -n "${UBATCH:-}" ]] && ARGS+=(-ub "${UBATCH}")
[[ -n "${THREADS:-}" ]] && ARGS+=(-t "${THREADS}")
[[ -n "${THREADS_BATCH:-}" ]] && ARGS+=(-tb "${THREADS_BATCH}")
[[ -n "${CACHE_TYPE_K:-}" ]] && ARGS+=(-ctk "${CACHE_TYPE_K}")
[[ -n "${CACHE_TYPE_V:-}" ]] && ARGS+=(-ctv "${CACHE_TYPE_V}")
[[ -n "${N_PREDICT:-}" ]] && ARGS+=(-n "${N_PREDICT}")
[[ -n "${PROMPT:-}" ]] && ARGS+=(-p "${PROMPT}")
[[ -n "${GPU_LAYERS:-}" ]] && ARGS+=(-ngl "${GPU_LAYERS}")
[[ -n "${FIT:-}" ]] && ARGS+=(-fit "${FIT}")
[[ -n "${FIT_CTX:-}" ]] && ARGS+=(-fitc "${FIT_CTX}")
[[ -n "${FIT_TARGET:-}" ]] && ARGS+=(-fitt "${FIT_TARGET}")
[[ -n "${DEVICE:-}" ]] && ARGS+=(-dev "${DEVICE}")
[[ -n "${REASONING:-}" ]] && ARGS+=(-rea "${REASONING}")

if [[ "${MMAP:-1}" == "1" ]]; then
  ARGS+=(--mmap)
else
  ARGS+=(--no-mmap)
fi

if [[ "${MLOCK:-0}" == "1" ]]; then
  ARGS+=(--mlock)
fi

if [[ "${KV_OFFLOAD:-1}" == "0" ]]; then
  ARGS+=(-nkvo)
fi

if [[ -n "${FLASH_ATTENTION:-}" ]]; then
  ARGS+=(-fa "${FLASH_ATTENTION}")
fi

if [[ "${BIN_NAME}" == "llama-server" ]]; then
  [[ -n "${HOST:-}" ]] && ARGS+=(--host "${HOST}")
  [[ -n "${PORT:-}" ]] && ARGS+=(--port "${PORT}")
  [[ -n "${N_PARALLEL:-}" ]] && ARGS+=(-np "${N_PARALLEL}")

  if [[ "${CACHE_PROMPT:-1}" == "1" ]]; then
    ARGS+=(--cache-prompt)
  else
    ARGS+=(--no-cache-prompt)
  fi

  [[ -n "${CACHE_REUSE:-}" ]] && ARGS+=(--cache-reuse "${CACHE_REUSE}")
  [[ -n "${SLOT_SAVE_PATH:-}" ]] && ARGS+=(--slot-save-path "${SLOT_SAVE_PATH}")
  [[ -n "${CACHE_RAM:-}" ]] && ARGS+=(-cram "${CACHE_RAM}")

  if [[ "${KV_UNIFIED:-0}" == "1" ]]; then
    ARGS+=(-kvu)
  else
    ARGS+=(-no-kvu)
  fi

  if [[ "${CLEAR_IDLE:-0}" == "1" ]]; then
    ARGS+=(--clear-idle)
  else
    ARGS+=(--no-clear-idle)
  fi

  if [[ "${WEBUI:-0}" == "1" ]]; then
    ARGS+=(--webui)
  else
    ARGS+=(--no-webui)
  fi

  if [[ "${WARMUP:-1}" == "0" ]]; then
    ARGS+=(--no-warmup)
  fi
fi

echo "Preset: ${PRESET}"
echo "Binary: ${BIN_PATH}"
echo "Command:"
printf '  %q' "${BIN_PATH}" "${ARGS[@]}"
printf '\n'

exec "${BIN_PATH}" "${ARGS[@]}"
