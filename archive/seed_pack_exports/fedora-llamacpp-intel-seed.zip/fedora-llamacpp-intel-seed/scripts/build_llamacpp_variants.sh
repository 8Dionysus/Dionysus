#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'EOF'
Usage:
  build_llamacpp_variants.sh <llama_cpp_repo_dir>

Builds multiple llama.cpp variants for a Fedora Intel host profile.

Expected outputs:
  build-cpu        oneMKL BLAS if oneAPI is available
  build-openblas   CPU fallback
  build-vk         Vulkan
  build-sycl       SYCL if oneAPI is available
  build-ov         OpenVINO if setupvars is already available
EOF
}

if [[ $# -lt 1 ]]; then
  usage >&2
  exit 2
fi

REPO_DIR="$(cd "$1" && pwd)"
if [[ ! -d "${REPO_DIR}/.git" ]]; then
  echo "Expected a git checkout at: ${REPO_DIR}" >&2
  exit 1
fi

cmake_build() {
  local build_dir="$1"
  shift
  echo
  echo "==> configuring ${build_dir}"
  cmake -S "${REPO_DIR}" -B "${REPO_DIR}/${build_dir}" -G Ninja "$@"
  echo "==> building ${build_dir}"
  cmake --build "${REPO_DIR}/${build_dir}" --config Release -j
}

echo "Repo: ${REPO_DIR}"

# OpenBLAS fallback is simple and should always be attempted first.
cmake_build build-openblas \
  -DGGML_BLAS=ON \
  -DGGML_BLAS_VENDOR=OpenBLAS

# oneMKL CPU build if oneAPI is present.
if [[ -f /opt/intel/oneapi/setvars.sh ]]; then
  # shellcheck disable=SC1091
  source /opt/intel/oneapi/setvars.sh
fi

if command -v icx >/dev/null 2>&1 && command -v icpx >/dev/null 2>&1; then
  cmake_build build-cpu \
    -DGGML_BLAS=ON \
    -DGGML_BLAS_VENDOR=Intel10_64lp \
    -DCMAKE_C_COMPILER=icx \
    -DCMAKE_CXX_COMPILER=icpx \
    -DGGML_NATIVE=ON
else
  echo "Skipping build-cpu: icx/icpx not found."
fi

# Vulkan build
if command -v vulkaninfo >/dev/null 2>&1; then
  cmake_build build-vk \
    -DGGML_VULKAN=1
else
  echo "Skipping build-vk: vulkaninfo not found."
fi

# SYCL build if oneAPI tools are present
if command -v icx >/dev/null 2>&1 && command -v icpx >/dev/null 2>&1 && command -v sycl-ls >/dev/null 2>&1; then
  cmake_build build-sycl \
    -DGGML_SYCL=ON \
    -DCMAKE_C_COMPILER=icx \
    -DCMAKE_CXX_COMPILER=icpx
else
  echo "Skipping build-sycl: oneAPI SYCL tools not found."
fi

# OpenVINO build only if already installed
if [[ -f /opt/intel/openvino/setupvars.sh ]]; then
  # shellcheck disable=SC1091
  source /opt/intel/openvino/setupvars.sh
  cmake_build build-ov \
    -DCMAKE_BUILD_TYPE=Release \
    -DGGML_OPENVINO=ON
else
  echo "Skipping build-ov: /opt/intel/openvino/setupvars.sh not found."
fi
