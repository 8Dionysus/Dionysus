#!/usr/bin/env python3
import argparse
import json
import os
import re
import shlex
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List

PROMPT_RE = re.compile(r"prompt.*?([\d.]+)\s+tokens per second", re.IGNORECASE)
PRED_RE = re.compile(r"(?:eval|predicted).*?([\d.]+)\s+tokens per second", re.IGNORECASE)

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run a small llama.cpp preset matrix and artifact logs.")
    parser.add_argument("--matrix", required=True, help="Path to preset_matrix.json")
    parser.add_argument("--llama-root", required=True, help="Path to llama.cpp repo root")
    parser.add_argument("--runs-dir", required=True, help="Where artifacts should be written")
    return parser.parse_args()

def load_matrix(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)

def parse_tps(text: str) -> Dict[str, Any]:
    result: Dict[str, Any] = {}
    m1 = PROMPT_RE.search(text)
    m2 = PRED_RE.search(text)
    if m1:
        result["prompt_tokens_per_second"] = float(m1.group(1))
    if m2:
        result["predicted_tokens_per_second"] = float(m2.group(1))
    return result

def main() -> int:
    args = parse_args()
    matrix_path = Path(args.matrix).resolve()
    llama_root = Path(args.llama_root).resolve()
    runs_dir = Path(args.runs_dir).resolve()
    runs_dir.mkdir(parents=True, exist_ok=True)

    data = load_matrix(matrix_path)
    jobs: List[Dict[str, Any]] = data.get("jobs", [])
    summary: Dict[str, Any] = {
        "matrix": str(matrix_path),
        "llama_root": str(llama_root),
        "jobs": [],
    }

    script_path = matrix_path.parent.parent / "scripts" / "run_llama_preset.sh"
    if not script_path.exists():
        print(f"run_llama_preset.sh not found at {script_path}", file=sys.stderr)
        return 1

    for job in jobs:
        name = job["name"]
        preset = (matrix_path.parent.parent / job["preset"]).resolve()
        build_dir = (llama_root / job["build_dir"]).resolve()
        job_dir = runs_dir / name
        job_dir.mkdir(parents=True, exist_ok=True)

        env = os.environ.copy()
        if "prompt" in job:
            env["PROMPT"] = job["prompt"]
        if "n_predict" in job:
            env["N_PREDICT"] = str(job["n_predict"])
        if "model_dir" in job:
            env["MODEL_DIR"] = str(job["model_dir"])

        cmd = [str(script_path), str(preset), str(build_dir)]
        proc = subprocess.run(
            cmd,
            cwd=str(matrix_path.parent.parent),
            env=env,
            capture_output=True,
            text=True,
        )

        stdout_path = job_dir / "stdout.txt"
        stderr_path = job_dir / "stderr.txt"
        cmd_path = job_dir / "command.txt"

        stdout_path.write_text(proc.stdout, encoding="utf-8")
        stderr_path.write_text(proc.stderr, encoding="utf-8")
        cmd_path.write_text(" ".join(shlex.quote(c) for c in cmd), encoding="utf-8")

        timings = parse_tps(proc.stdout + "\n" + proc.stderr)
        job_summary = {
            "name": name,
            "preset": str(preset),
            "build_dir": str(build_dir),
            "returncode": proc.returncode,
            "artifacts": {
                "stdout": str(stdout_path),
                "stderr": str(stderr_path),
                "command": str(cmd_path),
            },
            "timings": timings,
        }
        summary["jobs"].append(job_summary)

    summary_path = runs_dir / "summary.json"
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(summary_path)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
