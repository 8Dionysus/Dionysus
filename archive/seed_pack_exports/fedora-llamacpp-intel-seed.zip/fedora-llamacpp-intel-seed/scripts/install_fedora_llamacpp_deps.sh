#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'EOF'
Usage:
  install_fedora_llamacpp_deps.sh [--with-intel-oneapi-repo]

Installs Fedora-side dependencies for a llama.cpp-first Intel host.
The Intel repo step is optional.
EOF
}

WITH_ONEAPI_REPO=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --with-intel-oneapi-repo)
      WITH_ONEAPI_REPO=1
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown argument: $1" >&2
      usage >&2
      exit 2
      ;;
  esac
done

sudo dnf install -y \
  git cmake ninja-build gcc-c++ make pkgconf-pkg-config \
  python3 python3-pip jq \
  openblas-devel \
  vulkan-loader-devel vulkan-tools glslc \
  clinfo openssl-devel

if [[ "${WITH_ONEAPI_REPO}" -eq 1 ]]; then
  sudo tee /etc/yum.repos.d/oneAPI.repo >/dev/null <<'EOF'
[oneAPI]
name=Intel oneAPI repository
baseurl=https://yum.repos.intel.com/oneapi
enabled=1
gpgcheck=1
repo_gpgcheck=1
gpgkey=https://yum.repos.intel.com/intel-gpg-keys/GPG-PUB-KEY-INTEL-SW-PRODUCTS.PUB
EOF

  sudo dnf makecache
  cat <<'EOF'
Intel oneAPI repo installed.

Suggested next step:
  sudo dnf install -y intel-cpp-essentials intel-oneapi-mkl-devel intel-deep-learning-essentials
EOF
fi
