---
name: aoa-session-donor-harvest
description: Harvest reusable donor units from a reviewed session artifact, classify each one by owner layer, and draft the smallest honest next artifact. Use when a finished or reviewed session may contain technique, skill, playbook, eval, memo, or agent-layer candidates. Do not use for live execution, raw session capture or indexing, or the narrower final quest promotion verdict already handled by aoa-quest-harvest.
---

Use this skill to turn a reviewed session artifact into a bounded donor harvest pack that names reusable units, routes each one to the right AoA owner layer, and drafts the next honest artifact without forcing promotion.

## Trigger boundary

Use when:
- a session transcript, compaction note, review packet, or bounded recap exists and must be distilled into reusable donor units
- the work is post-session and reviewable rather than live execution
- candidate outputs may belong in `aoa-techniques`, `aoa-skills`, `aoa-playbooks`, `aoa-evals`, `aoa-memo`, `aoa-agents`, or a hold/quest lane
- the question is not merely "what happened?" but "what reusable object, if any, emerged here?"

Do not use when:
- the session is still active or unreviewed
- the task is raw session capture, transcript export, or local indexing
- the result is clearly one bounded repeated quest unit that only needs `aoa-quest-harvest`
- the material is only a progress log, emotional recap, or theme cloud with no bounded reusable unit
- the intended first destination is `aoa-routing` or `aoa-kag`

## Inputs

- reviewed session artifact
- session goal and closure state
- candidate repeat signals or reuse signals
- touched repos or AoA layers
- explicit uncertainty and boundary risks
- desired output posture: classify-only, draft-stub, or patch-ready proposal

## Outputs

- one bounded donor harvest pack
- named candidates, each with:
  - reusable unit name
  - unit kind: pattern, mechanic, utility, law, proof, recall, or route
  - abstraction shape: technique, skill, playbook, eval, memo, agent, or hold
  - owner repo recommendation
  - one chosen next artifact
  - one rejected nearest-wrong target
  - evidence anchors from the session artifact
- one short list of items to defer, drop, or keep as quest residue

## Procedure

1. start from a reviewed session artifact rather than transient chat memory
2. extract candidate reusable units, not topics; prefer explicit moves, laws, checklists, structures, routes, or proof patterns
3. split merged candidates until each unit has one honest owner shape
4. classify each kept candidate twice: by reuse kind and by owner shape
5. reject theme-only repetition, aesthetic resonance, and broad "good idea" residue unless a bounded reusable unit exists
6. route reusable practice meaning to `aoa-techniques`
7. route bounded executable leaf workflows to `aoa-skills`
8. route multi-step recurring scenario methods to `aoa-playbooks`
9. route rubrics, verdict postures, and proof surfaces to `aoa-evals`
10. route recall, writeback, recurrence, and memory-support patterns to `aoa-memo`
11. route role law, orchestrator class law, handoff law, and actor-boundary rules to `aoa-agents`
12. keep `aoa-routing` and `aoa-kag` out of first-authoring unless the source-owned object already exists elsewhere and the session only discovered a derivative bridge update
13. when the candidate is a repeated reviewed quest unit and the remaining ambiguity is specifically the final promotion target among quest, skill, playbook, agent, eval, or memo, hand off to `aoa-quest-harvest`
14. draft the smallest next artifact for each accepted candidate
15. record one clear reason for the chosen owner and one clear reason against the nearest wrong owner

## Contracts

- invocation stays explicit and post-session
- the skill harvests donor units; it does not treat session history as memory canon or instruction authority
- one candidate maps to one primary owner layer
- `usefulness` is a reuse signal, not an owner layer by itself
- derivative layers do not become first authoring targets for source-owned meaning
- weak evidence may end in `hold` or `keep_or_open_quest`
- drafting a next artifact is allowed; forcing promotion is not

## Verification

- confirm the source artifact is reviewed and bounded
- confirm each kept candidate names one reusable unit rather than a topic
- confirm each accepted candidate has one primary owner layer
- confirm the nearest wrong target is rejected explicitly
- confirm no candidate routes source-owned meaning first into derivative layers
- confirm hold and defer outcomes remain available
- confirm the output names the next artifact rather than only abstract categories
