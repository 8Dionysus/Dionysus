---
id: AOA-P-0030
name: component-refresh-cycle
status: experimental
summary: Carries one reviewed internal component drift signal through one bounded owner-owned refresh decision, validation route, and optional derived summary without granting hidden scheduler authority.
scenario: component_refresh_cycle
trigger: reviewed_component_drift_with_named_owner_law
participating_agents:
  - architect
  - coder
  - reviewer
  - evaluator
  - memory-keeper
required_artifacts:
  - component_drift_hint
  - component_refresh_followthrough_decision
  - component_refresh_receipt
  - component_refresh_summary
fallback_mode: review_required
return_posture: artifact_anchor
---

# component-refresh-cycle

## Intent

Use this playbook when one internal AoA component is visibly drifting and the next honest move
is one owner-owned refresh route, not open-ended self-mutation.

## Trigger boundary

Use this playbook when:
- the drifting component has a named owner repo
- a refresh law exists or can be named without ambiguity
- the route can stay bounded through validation and rollback posture
- the route remains weaker than scheduler or autonomous runner authority

Do not use this playbook when:
- the owner repo is still ambiguous
- the route really belongs to first-pass diagnosis only
- someone is trying to hide uncontrolled automation under “maintenance” language

## Expected artifacts

- `component_drift_hint`
- `component_refresh_followthrough_decision`
- `component_refresh_receipt`
- `component_refresh_summary`

## Fallback and rollback

Stop or defer when:
- the law is unclear
- the owner repo is unclear
- the validation path is missing
- rollback posture is missing
- the route widens into open-ended system mutation
