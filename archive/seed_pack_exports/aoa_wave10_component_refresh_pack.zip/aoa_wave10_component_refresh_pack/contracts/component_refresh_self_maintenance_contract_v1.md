# Component Refresh / Self-Maintenance Contract v1

## Purpose

This contract defines how AoA names, carries, and follows through on internal
component refresh work without granting hidden mutation authority.

It is for components that have:
- source-authored inputs
- generated surfaces and/or projected install surfaces
- visible drift or staleness signals
- an owner repo that can refresh them honestly

## Why it exists

AoA already has growth-refinery, lineage, owner landing, rollout cadence, and continuity lanes.
What it still needs is a law for internal technical hunger:

- something changed
- the generated surface is stale
- the same manual fix repeated
- a doctor warning repeats
- a summary window lags
- a continuity or rollout route is blocked by one drifting component

This contract turns that hunger into bounded, reviewable work.

## Real-run first

Primary signals should come from real work and real drift:
- live closeout evidence
- repeated manual refresh
- owner validation failures
- stale generated surfaces
- deploy doctor drift
- summary windows that stay open too long

Synthetic fixtures are still useful for contract validation, but they do not replace live evidence.

## Core chain

```text
component_refresh_law
  -> component_drift_hint
  -> component_refresh_followthrough_decision
  -> owner refresh receipt
  -> component_refresh_summary
  -> optional failure_lesson_memory_v1 / recovery_pattern_memory_v1
```

## 1. component_refresh_law

A source-authored owner-repo declaration.

### Required fields
- `schema_version`
- `component_ref`
- `component_title`
- `owner_repo`
- `source_authored_inputs[]`
- `generated_surfaces[]`
- `projected_or_installed_surfaces[]` (may be empty)
- `drift_signals[]`
- `refresh_routes`
- `proof_commands[]`
- `rollback_anchors[]`
- `refresh_window`
- `followthrough_home`

### Drift signal shape
Each drift signal entry should name:
- `signal`
- `drift_class`
- `meaning`
- `recommended_route_class`

### Refresh window
Should include:
- `stale_after_days`
- `repeat_trigger_threshold`
- `open_window_days`

## 2. component_drift_hint

A control-plane or route artifact that says a specific component appears to be drifting.

### Required fields
- `schema_version`
- `hint_ref`
- `component_ref`
- `owner_repo`
- `observed_at`
- `observed_by`
- `severity`
- `signals[]`
- `repeat_count`
- `evidence_refs[]`
- `recommended_route_class`
- `review_required`

### Allowed severities
- `low`
- `medium`
- `high`

### Allowed route classes
- `observe`
- `revalidate`
- `rebuild`
- `reexport`
- `regenerate`
- `reproject`
- `repair`
- `defer`

## 3. component_refresh_followthrough_decision

A reviewed decision that chooses the next bounded move for one drifting component.

### Required fields
- `schema_version`
- `decision_ref`
- `component_ref`
- `owner_repo`
- `route_class`
- `decision_status`
- `selected_refresh_path[]`
- `reason`
- `evidence_refs[]`
- `rollback_anchor`
- `stats_should_refresh`
- `memo_writeback_candidate`

### Allowed decision_status
- `chosen`
- `deferred`
- `safe_stop`

## 4. owner refresh receipt

Owner repos may name their own receipt shape.
At minimum the receipt should preserve:
- `component_ref`
- `owner_repo`
- `refresh_route`
- `executed_at`
- `validation_status`
- `evidence_refs`
- optional `rollback_used`
- optional `followup_needed`

## 5. component_refresh_summary

A derived stats surface that may summarize:
- current vs stale vs refreshing vs recovered components
- counts by owner repo
- counts by drift class
- open refresh windows
- stale summary windows
- latest refresh verdicts

It must not overrule owner validation.

## Negative rules

- `aoa-sdk` may carry hints and reviewed decisions. It does not become an automatic mutator.
- `aoa-stats` may summarize. It does not become the source of refresh truth.
- `aoa-playbooks` may coordinate recurring routes. They do not become scheduler authority.
- `aoa-memo` may preserve repeated lessons or recovery patterns. It does not become the first record of refresh truth.
- workspace-root guidance may notice drift. It does not erase owner boundaries.

## Phase alpha component set

This contract is first applied to:
- `component:codex-plane:shared-root`
- `component:skills-export:foundation`
- `component:codex-subagents:projection`
- `component:stats-derived-summaries:growth-refinery`
