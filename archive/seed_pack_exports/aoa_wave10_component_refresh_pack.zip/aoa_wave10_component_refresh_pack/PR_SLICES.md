# PR_SLICES — Wave 10

## PR-1 — Center + public route
Repos:
- `Agents-of-Abyss`
- `8Dionysus`

Land:
- `docs/COMPONENT_REFRESH_LAW.md`
- `docs/COMPONENT_REFRESH_ROUTE.md`
- minimal root `AGENTS.md` patch for component-drift signals

Verify:
- docs link cleanly to existing growth-refinery, rollout, and regeneration notes
- no owner-boundary slippage

## PR-2 — Control-plane carry
Repo:
- `aoa-sdk`

Land:
- `docs/COMPONENT_DRIFT_HINTS.md`
- patches to checkpoint and closeout handoff docs
- example shape for refresh hints / follow-through decisions

Verify:
- all new carry remains hint-only or reviewed-only
- no new automatic mutation authority

## PR-3 — Owner refresh laws
Repos:
- `aoa-skills`
- `aoa-agents`

Land:
- `docs/COMPONENT_REFRESH_LAW.md` for skills export
- `docs/CODEX_SUBAGENT_REFRESH_LAW.md` for subagent projection
- example law files / example drift receipts if helpful

Verify:
- owner repo, source inputs, generated surfaces, proof commands, and rollback anchors are explicit
- current repo validation commands are named and still bounded

## PR-4 — Derived visibility
Repo:
- `aoa-stats`

Land:
- component refresh doctrine note
- derived `component_refresh_summary` family

Verify:
- summary is visibly weaker than owner truth
- staleness windows and refresh states are explicit

## PR-5 — Recurring route + optional memory
Repos:
- `aoa-playbooks`
- `aoa-memo`

Land:
- `component-refresh-cycle` playbook
- bounded refresh writeback note

Verify:
- playbook remains recommendation / coordination only
- memo reuses existing kinds only

## Merge posture
- merge in order
- do not skip ahead to playbook or stats before laws and control-plane carry exist
- if PR-2 changes naming, rebase PR-3 through PR-5 on the final naming before merge
