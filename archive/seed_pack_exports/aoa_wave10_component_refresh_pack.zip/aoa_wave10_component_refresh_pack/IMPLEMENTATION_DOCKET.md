# IMPLEMENTATION_DOCKET — Wave 10: Component Refresh / Self-Maintenance Triggers

## Intent

AoA already has live use, growth carry, reviewed closeout, owner landing, rollout continuity,
and self-agency continuity. What it still lacks is a first-class way to say:

- a component is drifting
- this drift belongs to a specific owner repo
- reviewed closeout should raise a refresh decision
- the owner repo has an explicit refresh law
- the result can be summarized, proved, and remembered without magical autonomy

This docket lands that missing reflex.

---

## 1. Center: `Agents-of-Abyss`

### Add
- `docs/COMPONENT_REFRESH_LAW.md`

### Purpose
Give the federation one explicit law for component refresh and self-maintenance.

### Must define
- what counts as a “component” in this context
- the split between source-authored inputs, generated surfaces, and projected/install surfaces
- why live-fire drift is preferred over sterile simulation as the primary signal source
- why refresh remains owner-owned and review-governed
- the chain:
  `component_refresh_law -> component_drift_hint -> component_refresh_followthrough_decision -> owner refresh receipt -> derived summary -> optional memo writeback`

### Neighbor docs to cite
- `docs/FEDERATION_RULES.md`
- `docs/REVIEWABLE_GROWTH_REFINERY.md`
- `docs/METHOD_SPINE.md`

---

## 2. Public route / workspace surface: `8Dionysus`

### Add
- `docs/COMPONENT_REFRESH_ROUTE.md`
- one bounded patch to root `AGENTS.md`

### Purpose
Expose component-refresh intent at the workspace root without turning `8Dionysus` into a sovereign owner of every component.

### AGENTS patch should add signals such as
- generated/install drift
- repeated manual refresh patching
- doctor warnings that repeat
- stale derived summary windows
- component refresh windows left open too long

### Refresh law to publish
- `component:codex-plane:shared-root`

### Likely sources
- `config/codex_plane/runtime_manifest.v1.json`
- `config/codex_plane/profiles/*.json`

### Generated / deployed surfaces
- `.codex/config.toml`
- `.codex/hooks.json`

### Validation route
- render check
- doctor / rollout validation
- explicit rollback posture stays visible

---

## 3. Control plane: `aoa-sdk`

### Add
- `docs/COMPONENT_DRIFT_HINTS.md`
- one patch to `docs/session-growth-checkpoints.md`
- one patch to `docs/aoa-surface-detection-closeout-handoff.md`
- optional example or schema note for `closeout_component_refresh_map`

### Purpose
Let the control plane carry refresh signals honestly without auto-mutating owner repos.

### New carry surfaces
- `component_drift_hint`
- `component_refresh_followthrough_decision`

### Boundary
`aoa-sdk` may:
- detect or carry hints
- preserve evidence refs
- preserve repeat counts, severities, and route suggestions
- surface reviewed follow-through decisions

`aoa-sdk` must not:
- directly regenerate owner surfaces by itself
- mint owner truth
- treat a hint as a completed refresh
- collapse refresh law into one central scheduler

### Deterministic signal examples
- same manual repair applied twice
- source input changed while generated surface stayed stale
- deploy doctor failed after render
- stable component names drifted
- summary family out of sync by freshness window
- continuity or rollout window blocked by one identifiable component

---

## 4. Owner law: `aoa-skills`

### Add
- `docs/COMPONENT_REFRESH_LAW.md`
- one example refresh-law surface for `component:skills-export:foundation`

### Purpose
Define when the skill export foundation is stale and what its honest refresh path is.

### Law should name
- source-authored surfaces:
  - `skills/*/SKILL.md`
  - repo-authored governance / schemas where relevant
- generated or exported surfaces:
  - `.agents/skills/*`
  - generated catalogs and indexes
- drift signals:
  - source skill changed without export refresh
  - `agents/openai.yaml` drift
  - `allow_implicit_invocation` drift
  - validation failure between source and export
- refresh path:
  - rebuild catalogs
  - validate skills
  - validate agent-skill export

---

## 5. Owner law: `aoa-agents`

### Add
- `docs/CODEX_SUBAGENT_REFRESH_LAW.md`
- one example refresh-law surface for `component:codex-subagents:projection`

### Purpose
Define when the generated Codex subagent projection needs regeneration.

### Law should name
- source-authored surfaces:
  - `profiles/*.profile.json`
  - `config/codex_subagent_wiring.v2.json`
- generated surfaces:
  - `generated/codex_agents/agents/*.toml`
  - `generated/codex_agents/config.subagents.generated.toml`
  - projection manifest
- drift signals:
  - profile changed without projection refresh
  - wiring drift
  - subagent validation failure
  - repeated boundary mismatch in generated agent TOML
- refresh path:
  - regenerate published surfaces
  - validate repo
  - validate generated Codex projection

---

## 6. Owner law + derived read model: `aoa-stats`

### Add
- `docs/COMPONENT_REFRESH_SUMMARIES.md`
- `generated/component_refresh_summary.min.json` (or equivalent family surface)
- one example refresh-law surface for `component:stats-derived-summaries:growth-refinery`

### Purpose
Make component refresh visible as a derived summary layer without making stats the source of truth.

### Summary should expose
- per-component status: `current`, `stale`, `refresh_recommended`, `refresh_active`, `recovered`
- counts by owner repo
- counts by drift class
- open refresh windows
- stale summary windows
- latest observed timestamps
- last refresh verdict class

### Boundary
Stats may summarize owner refresh receipts and reviewed decisions.
Stats may not declare a component healthy when owner validation says otherwise.

---

## 7. Scenario home: `aoa-playbooks`

### Add
- `playbooks/component-refresh-cycle/PLAYBOOK.md`

### Purpose
Give repeated component-refresh work one scenario-level home without inventing hidden scheduler rights.

### Playbook should cover
- trigger boundary: reviewed drift with named owner component
- participating agents: architect, coder, reviewer, evaluator, memory-keeper
- expected artifacts:
  - `component_drift_hint`
  - `component_refresh_followthrough_decision`
  - `component_refresh_receipt`
  - `component_refresh_summary`
- fallback and rollback posture
- stop lines when refresh law is unclear or owner repo is ambiguous

---

## 8. Optional bounded writeback: `aoa-memo`

### Add
- `docs/COMPONENT_REFRESH_WRITEBACK.md`

### Purpose
Preserve repeated refresh failures or successful recovery patterns without creating a new memory empire.

### Use existing memo kinds only
- `failure_lesson_memory_v1`
- `recovery_pattern_memory_v1`

### Good writeback examples
- repeated doctor drift caused by stale generated config
- repeated subagent projection drift fixed by the same bounded regen route
- repeated export drift caused by missing validation step
- repeated stale summary windows fixed by the same build/refresh pattern

---

## 9. Suggested first component set

Do not try to cover every repo in one shot.
Land alpha on these four:

- `component:codex-plane:shared-root`
- `component:skills-export:foundation`
- `component:codex-subagents:projection`
- `component:stats-derived-summaries:growth-refinery`

Phase beta can later add:
- playbook adjunct refresh
- Dionysus registry / route map hygiene
- KAG derived-surface refresh
- deeper runtime-body refresh signals

---

## 10. Verification sequence

### Center / route
- link doctrine neighbors clearly
- no owner-boundary violations

### aoa-sdk
- docs clearly say hint-only / reviewed-only
- no hidden auto-mutation path introduced

### Owner laws
- each law lists:
  - owner repo
  - source inputs
  - generated surfaces
  - drift signals
  - refresh path
  - proof commands
  - rollback anchors

### Stats
- derived summary weaker than owner validation
- staleness window and refresh states visible

### Playbook
- no scheduler authority
- bounded route only

### Memo
- existing memo kinds reused
- refresh truth does not move into memory

---

## 11. Definition of done

This wave is done when:

1. AoA has one explicit federation law for component refresh.
2. Four owner components have named refresh laws.
3. `aoa-sdk` can carry `component_drift_hint` and `component_refresh_followthrough_decision`.
4. `aoa-playbooks` has one bounded recurring route for component refresh.
5. `aoa-stats` can summarize refresh state without pretending to own truth.
6. repeated live drift can now become reviewed, bounded refresh work instead of ad hoc patch folklore.
