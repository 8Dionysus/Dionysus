# aoa_wave10_component_refresh_pack

This pack forges the next missing organ after the growth-refinery and continuity waves:
**component refresh and self-maintenance triggers**.

The aim is not to invent hidden daemon authority.
The aim is to let AoA recognize, from real work and real drift, when one of its internal
components should be refreshed, regenerated, rebuilt, or explicitly left alone.

## Why this wave now

The current tree already has:
- workspace-root guidance that tells agents to run additive surface detection when drift, continuity questions, anchor loss, or reanchor need appear
- `aoa-sdk` checkpoint and reviewed-closeout carry that can already preserve provisional lineage hints and reviewed follow-through decisions without turning them into automatic runtime authority
- `aoa-stats` early lineage, landing, automation, rollout, and continuity summaries
- path-bound but source-owned Codex plane regeneration in `8Dionysus`
- a permanent project-core session-growth kernel in `aoa-skills`
- source-authored Codex subagent projection in `aoa-agents`

What is still missing is the reflex that says:

> this component is drifting  
> this drift has enough evidence  
> this owner repo owns the refresh law  
> this is the bounded next move

## Scope of this pack

Phase alpha covers four high-value internal component families:

1. `component:codex-plane:shared-root`
   - owner: `8Dionysus`
   - problem class: render / deploy / doctor drift

2. `component:skills-export:foundation`
   - owner: `aoa-skills`
   - problem class: source skill changed but portable export / local adapter / generated catalog drifted

3. `component:codex-subagents:projection`
   - owner: `aoa-agents`
   - problem class: profile / wiring changed but generated Codex subagent projection drifted

4. `component:stats-derived-summaries:growth-refinery`
   - owner: `aoa-stats`
   - problem class: source receipt inputs changed or windows drifted, but derived summaries are stale or out of sync

`aoa-sdk` stays a control-plane carrier for drift hints and reviewed follow-through decisions.
`aoa-playbooks` owns the recurring scenario route.
`aoa-memo` keeps optional recovery lessons and patterns.
No hidden scheduler authority is introduced in this wave.

## Pack layout

- `contracts/`
  - canonical contract for refresh laws, drift hints, and reviewed follow-through decisions
- `proposed-targets/`
  - seed docs for the center, the public workspace route, and the recurring playbook home
- `patch-guides/`
  - file-level landing notes per repo
- `examples/`
  - cross-repo example surfaces tied together by shared `component_ref`
- `tools/validate_wave10_component_refresh.py`
  - structural validator for the example bundle
- top-level docket, PR slices, Codex execution prompt, and acceptance matrix

## Landing order

1. center doctrine in `Agents-of-Abyss`
2. public route and workspace hinting in `8Dionysus`
3. control-plane carry in `aoa-sdk`
4. owner refresh laws in `aoa-skills`, `aoa-agents`, and `aoa-stats`
5. recurring route in `aoa-playbooks`
6. optional writeback seam in `aoa-memo`

## Non-goals

This wave must not:
- turn `aoa-sdk` into an automatic mutator of owner repos
- let `aoa-stats` overrule owner truth
- let `aoa-memo` become the first authority for refresh truth
- narrate scheduler authority through playbook language
- pretend that synthetic test harnesses replace live-fire evidence

## Minimal pack-local validation

```bash
python tools/validate_wave10_component_refresh.py
```
