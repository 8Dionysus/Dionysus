# CODEX_EXECUTION_PROMPT — Wave 10 Component Refresh / Self-Maintenance

You are landing the AoA component-refresh wave across sibling repos.

## Goal

Land a bounded, review-governed mechanism that lets AoA recognize when internal
components need refresh from real use and real drift, without inventing hidden
scheduler or mutation authority.

## Hard rules

- preserve source-of-truth boundaries
- do not let `aoa-sdk` mutate owner repos automatically
- do not let `aoa-stats` overrule owner validation
- do not invent a new memory family in `aoa-memo`
- do not narrate scheduler authority through playbooks
- prefer real existing repo commands, docs, and validation surfaces over invented abstractions
- keep diffs small and reviewable
- report honestly when an intended target file already exists and adapt rather than duplicate it

## Landing order

1. `Agents-of-Abyss`
2. `8Dionysus`
3. `aoa-sdk`
4. `aoa-skills`
5. `aoa-agents`
6. `aoa-stats`
7. `aoa-playbooks`
8. `aoa-memo`

## Implementation spine

### Center
Add one explicit federation doctrine note for component refresh and self-maintenance.
It should define:
- owner-owned refresh laws
- hint-only control-plane carry
- reviewed follow-through decisions
- derived summaries
- optional bounded memo writeback

### Public route
Add a workspace-facing route note in `8Dionysus` and patch root `AGENTS.md`
so additive surface detection can explicitly notice component drift signals.

### Control plane
In `aoa-sdk`, add documented carry for:
- `component_drift_hint`
- `component_refresh_followthrough_decision`

This carry must stay read-only or reviewed-only.
It must not auto-regenerate owner surfaces.

### Owner laws
In `aoa-skills`, `aoa-agents`, and `aoa-stats`, publish refresh laws for:

- `component:codex-plane:shared-root`
- `component:skills-export:foundation`
- `component:codex-subagents:projection`
- `component:stats-derived-summaries:growth-refinery`

Every law must explicitly name:
- owner repo
- source-authored inputs
- generated surfaces
- drift signals
- refresh path
- proof commands
- rollback anchors

### Recurring route
In `aoa-playbooks`, add a bounded `component-refresh-cycle` playbook.

### Optional memory
In `aoa-memo`, add bounded writeback guidance using only:
- `failure_lesson_memory_v1`
- `recovery_pattern_memory_v1`

## Verify repo-by-repo

### Agents-of-Abyss
Run existing doc checks if present.
Otherwise verify links and neighbor docs manually.

### 8Dionysus
Use the existing Codex-plane regeneration / rollout checks where applicable.

### aoa-sdk
Run repo validation and tests already used for previous waves.

### aoa-skills
Run:
```bash
python scripts/build_catalog.py --check
python scripts/validate_skills.py
python scripts/validate_agent_skills.py
python -m pytest -q tests
```

### aoa-agents
Run:
```bash
python scripts/validate_agents.py
python scripts/validate_codex_subagents.py   --profiles-root profiles   --wiring config/codex_subagent_wiring.v2.json   --agents-dir generated/codex_agents/agents   --config-snippet generated/codex_agents/config.subagents.generated.toml   --manifest generated/codex_agents/projection_manifest.json
python -m pytest -q tests
```

### aoa-stats
Run the normal build/validate/test path already used in the repo.

### aoa-playbooks
Run the normal generate/validate/test path already used in the repo.

### aoa-memo
Run the repo validation/tests normally used there.

## Report format

For each repo, report:
- files added
- files changed
- validation commands run
- pass / warn / fail
- any naming adaptation or existing-file conflict you resolved

Stop if a change would force hidden authority across repo boundaries.
