# Patch Guide — aoa-sdk

Suggested targets:
- `docs/COMPONENT_DRIFT_HINTS.md`
- `docs/session-growth-checkpoints.md`
- `docs/aoa-surface-detection-closeout-handoff.md`

Key idea:
- add control-plane carry for `component_drift_hint`
- add reviewed `component_refresh_followthrough_decision`
- keep both weaker than owner refresh law and owner receipts
