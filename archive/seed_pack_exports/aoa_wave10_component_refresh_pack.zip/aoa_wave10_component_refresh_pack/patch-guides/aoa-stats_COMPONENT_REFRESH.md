# Patch Guide — aoa-stats

Suggested targets:
- `docs/COMPONENT_REFRESH_SUMMARIES.md`
- `generated/component_refresh_summary.min.json`

Focus:
- derived-only posture
- staleness windows
- refresh states
- owner validation remains stronger
