# Patch Guide — aoa-memo

Suggested target:
- `docs/COMPONENT_REFRESH_WRITEBACK.md`

Focus:
- reuse existing memo kinds only
- repeated failure and repeated repair patterns
- memory remains weaker than owner receipts and proof
