# Patch Guide — aoa-playbooks

Suggested target:
- `playbooks/component-refresh-cycle/PLAYBOOK.md`

Focus:
- recurring route
- no scheduler authority
- bounded artifacts and stop lines
