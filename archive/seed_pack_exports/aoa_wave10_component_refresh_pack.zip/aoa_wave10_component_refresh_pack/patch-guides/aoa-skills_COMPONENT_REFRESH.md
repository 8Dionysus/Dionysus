# Patch Guide — aoa-skills

Suggested targets:
- `docs/COMPONENT_REFRESH_LAW.md`
- one example law surface under `examples/` or `docs/examples/`

Focus:
- source skill authoring vs portable export vs generated indexes
- validation and rollback posture
