# Patch Guide — Agents-of-Abyss

Suggested target:
- `docs/COMPONENT_REFRESH_LAW.md`

Possible neighbor patch:
- add one short neighbor link from `docs/REVIEWABLE_GROWTH_REFINERY.md`
- optional one-line mention in `docs/METHOD_SPINE.md`

Keep this note constitutional, not implementation-heavy.
