# Patch Guide — 8Dionysus

Suggested targets:
- `docs/COMPONENT_REFRESH_ROUTE.md`
- root `AGENTS.md`

AGENTS patch should stay small:
- add component-drift signals under additive surface detection posture
- name reviewed routing to owner repo
- avoid claiming workspace-root ownership of every component
