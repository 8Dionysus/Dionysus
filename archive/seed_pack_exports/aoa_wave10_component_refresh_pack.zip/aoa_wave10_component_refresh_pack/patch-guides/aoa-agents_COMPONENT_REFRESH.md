# Patch Guide — aoa-agents

Suggested targets:
- `docs/CODEX_SUBAGENT_REFRESH_LAW.md`
- example law surface

Focus:
- profile/wiring source surfaces
- generated Codex agent projection
- existing regeneration + validation path
