#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
from pathlib import Path

ALLOWED_SEVERITY = {"low", "medium", "high"}
ALLOWED_ROUTE = {"observe", "revalidate", "rebuild", "reexport", "regenerate", "reproject", "repair", "defer"}
ALLOWED_DECISION_STATUS = {"chosen", "deferred", "safe_stop"}


def load_json(path: Path):
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def fail(msg: str) -> None:
    raise SystemExit(f"[FAIL] {msg}")


def require(cond: bool, msg: str) -> None:
    if not cond:
        fail(msg)


def main() -> None:
    pack_root = Path(__file__).resolve().parents[1]

    law_paths = [
        pack_root / "examples/8Dionysus/codex_plane_refresh_law.example.json",
        pack_root / "examples/aoa-skills/skills_export_refresh_law.example.json",
        pack_root / "examples/aoa-agents/subagent_projection_refresh_law.example.json",
        pack_root / "examples/aoa-stats/summary_refresh_law.example.json",
    ]
    laws = [load_json(p) for p in law_paths]
    law_by_component = {}
    for law in laws:
        require(law["schema_version"] == "aoa_component_refresh_law_v1", f"bad law schema for {law.get('component_ref')}")
        comp = law["component_ref"]
        require(comp not in law_by_component, f"duplicate law for {comp}")
        require(law["owner_repo"], f"missing owner_repo for {comp}")
        require(law["source_authored_inputs"], f"missing source inputs for {comp}")
        require(law["generated_surfaces"], f"missing generated surfaces for {comp}")
        require(law["proof_commands"], f"missing proof commands for {comp}")
        require(law["rollback_anchors"], f"missing rollback anchors for {comp}")
        for signal in law["drift_signals"]:
            require(signal["recommended_route_class"] in ALLOWED_ROUTE, f"bad route class in {comp}:{signal}")
        law_by_component[comp] = law

    hints_path = pack_root / "examples/aoa-sdk/component_drift_hints.example.json"
    hints_doc = load_json(hints_path)
    require(hints_doc["schema_version"] == "aoa_component_drift_hint_set_v1", "bad hint schema")
    hint_refs = set()
    for hint in hints_doc["hints"]:
        href = hint["hint_ref"]
        require(href not in hint_refs, f"duplicate hint ref {href}")
        hint_refs.add(href)
        comp = hint["component_ref"]
        require(comp in law_by_component, f"hint references unknown component {comp}")
        require(hint["owner_repo"] == law_by_component[comp]["owner_repo"], f"owner mismatch for hint {href}")
        require(hint["severity"] in ALLOWED_SEVERITY, f"bad severity for {href}")
        require(hint["recommended_route_class"] in ALLOWED_ROUTE, f"bad route class for hint {href}")
        law_signals = {s["signal"] for s in law_by_component[comp]["drift_signals"]}
        missing = set(hint["signals"]) - law_signals
        require(not missing, f"hint {href} uses signals not declared in law for {comp}: {sorted(missing)}")

    decisions_path = pack_root / "examples/aoa-sdk/component_refresh_followthrough_decision.example.json"
    decisions_doc = load_json(decisions_path)
    require(decisions_doc["schema_version"] == "aoa_component_refresh_followthrough_decision_set_v1", "bad decision schema")
    seen_decision_components = set()
    for item in decisions_doc["decisions"]:
        comp = item["component_ref"]
        require(comp in law_by_component, f"decision references unknown component {comp}")
        require(item["owner_repo"] == law_by_component[comp]["owner_repo"], f"decision owner mismatch for {comp}")
        require(item["route_class"] in ALLOWED_ROUTE, f"bad decision route class for {comp}")
        require(item["decision_status"] in ALLOWED_DECISION_STATUS, f"bad decision status for {comp}")
        for ref in item["evidence_refs"]:
            require(ref in hint_refs, f"decision {comp} references unknown hint {ref}")
        seen_decision_components.add(comp)

    summary_path = pack_root / "examples/aoa-stats/component_refresh_summary.example.json"
    summary = load_json(summary_path)
    require(summary["schema_version"] == "aoa_stats_component_refresh_summary_v1", "bad summary schema")
    summary_components = {c["component_ref"] for c in summary["components"]}
    require(summary_components == set(law_by_component), "summary component set must match law set")
    allowed_status = {"refresh_recommended", "refresh_active", "current", "deferred", "recovered"}
    for c in summary["components"]:
        comp = c["component_ref"]
        require(c["owner_repo"] == law_by_component[comp]["owner_repo"], f"summary owner mismatch for {comp}")
        require(c["latest_route_class"] in ALLOWED_ROUTE, f"bad summary route class for {comp}")
        require(c["current_status"] in allowed_status, f"bad summary status for {comp}")

    memo_path = pack_root / "examples/aoa-memo/recovery_pattern.component_refresh.example.json"
    memo = load_json(memo_path)
    require(memo["schema_version"] == "recovery_pattern_memory_v1", "bad memo schema")
    for ref in memo["evidence_refs"]:
        if ref.startswith("hint:"):
            require(ref in hint_refs, f"memo references unknown hint {ref}")
        elif ref.startswith("decision:"):
            require(ref == decisions_doc["decision_ref"], f"memo references unknown decision {ref}")
        else:
            fail(f"memo evidence ref has unexpected format: {ref}")

    print("[OK] wave 10 component refresh example bundle is structurally consistent.")


if __name__ == "__main__":
    main()
