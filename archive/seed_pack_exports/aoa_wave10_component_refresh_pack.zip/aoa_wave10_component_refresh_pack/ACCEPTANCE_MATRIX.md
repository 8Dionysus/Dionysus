# ACCEPTANCE_MATRIX — Wave 10

| Area | Must exist | Acceptance check |
|---|---|---|
| Center doctrine | `Agents-of-Abyss/docs/COMPONENT_REFRESH_LAW.md` | Defines owner-owned refresh law, hint-only carry, reviewed follow-through, derived summary, optional memo writeback |
| Public route | `8Dionysus/docs/COMPONENT_REFRESH_ROUTE.md` plus root `AGENTS.md` patch | Workspace root can now name component-drift signals without swallowing owner meaning |
| Control plane | `aoa-sdk` docs for `component_drift_hint` and `component_refresh_followthrough_decision` | All new carry is read-only or reviewed-only; no hidden mutation path |
| Skills export law | owner law for `component:skills-export:foundation` | Source inputs, generated surfaces, drift signals, refresh path, proof commands, rollback anchors are explicit |
| Subagent projection law | owner law for `component:codex-subagents:projection` | Same contract clarity as above |
| Stats summary law | owner law for `component:stats-derived-summaries:growth-refinery` and derived summary | Derived summary is weaker than owner truth and exposes staleness / refresh status |
| Recurring route | `aoa-playbooks/playbooks/component-refresh-cycle/PLAYBOOK.md` | Trigger, participating agents, artifacts, fallback, stop line, and non-scheduler boundary are explicit |
| Optional memo seam | `aoa-memo/docs/COMPONENT_REFRESH_WRITEBACK.md` | Reuses existing memo kinds only |
| Pack-local examples | example bundle under `examples/` | shared `component_ref` chain validates structurally |
| Pack-local tool | `tools/validate_wave10_component_refresh.py` | exits 0 on bundled examples |

## Completion threshold

Treat the wave as landed when:
1. at least the four alpha component laws are present,
2. `aoa-sdk` can carry refresh hints and reviewed refresh decisions,
3. one recurring playbook home exists,
4. derived stats can show which components are stale or under refresh,
5. repeated live drift can now become explicit reviewed refresh work instead of folklore.
