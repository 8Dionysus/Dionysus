# Agon Wave X Seed: Contradiction / Closure / Summon Law

This seed lands Wave X across `Agents-of-Abyss`, `aoa-evals`, and `aoa-sdk`.

## Plant order

```text
1. Agents-of-Abyss
2. aoa-evals
3. aoa-sdk
```

## What this wave does

Wave X hardens the three arena laws reserved after Wave IX:

- open material contradiction blocks closure;
- closure is earned jurisdiction, not a default right;
- summon is costly, visible intent, not a panic button.

It defines pre-protocol law registries, eval alignment candidates, and SDK helper candidates.

## What this wave does not do

It does not create live arena sessions, execute moves, issue verdicts, write durable scars, schedule retention, mutate rank, promote anything to `Tree-of-Sophia`, or install hidden scheduler behavior.

## Validation commands

In `Agents-of-Abyss`:

```bash
python scripts/build_agon_ccs_law_registry.py --check
python scripts/validate_agon_ccs_laws.py
python -m pytest -q tests/test_agon_ccs_laws.py
```

In `aoa-evals`:

```bash
python scripts/build_agon_ccs_eval_alignment_registry.py --check
python scripts/validate_agon_ccs_eval_alignment.py
python -m pytest -q tests/test_agon_ccs_eval_alignment.py
```

In `aoa-sdk`:

```bash
python scripts/build_agon_ccs_sdk_helper_candidates.py --check
python scripts/validate_agon_ccs_sdk_helper_candidates.py
python -m pytest -q tests/test_agon_ccs_sdk_helper_candidates.py
```

## Next wave

Wave XI should bridge verdict, delta and scar candidate flows over this law surface without granting durable memory authority or live arena runtime.
