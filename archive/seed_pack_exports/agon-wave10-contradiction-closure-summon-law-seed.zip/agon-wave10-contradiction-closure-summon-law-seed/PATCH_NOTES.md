# Patch Notes

- Adds center-owned CCS law registry in `Agents-of-Abyss`.
- Adds `aoa-evals` alignment candidates for contradiction, closure and summon prechecks.
- Adds `aoa-sdk` helper candidates for typed preview / inspection only.
- Keeps all surfaces pre-protocol and non-runtime.
