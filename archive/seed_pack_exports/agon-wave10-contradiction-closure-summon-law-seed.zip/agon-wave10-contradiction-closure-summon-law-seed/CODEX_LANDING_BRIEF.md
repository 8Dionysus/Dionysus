# Codex Landing Brief

Plant `Agents-of-Abyss` first. Then plant `aoa-evals`, then `aoa-sdk`.

Do not wire these surfaces into live runtime, verdict authority, scar writes, retention scheduling or rank mutation. This wave names law; it does not awaken the arena.
