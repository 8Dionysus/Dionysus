# Agon Wave X Seed

Contradiction, closure and summon law for the pre-protocol Agon surface.

This is a multi-repo seed. It is intentionally law-first and runtime-empty.
