# Patch Notes

This seed includes the same two tiny external integration patches as the first wave because the beacon layer still lives inside the same `RecurrenceAPI` and CLI group.

## `aoa-sdk/src/aoa_sdk/api.py`

Add one import:

```python
from .recurrence import RecurrenceAPI
```

Add one field in `AoASDK.__init__`:

```python
self.recurrence = RecurrenceAPI(workspace)
```

## `aoa-sdk/src/aoa_sdk/cli/main.py`

Add one import:

```python
from ..recurrence.cli import recur_app
```

Register one Typer app:

```python
app.add_typer(recur_app, name="recur")
```

No new external patch is required beyond that. The beacon layer is wired through the same recurrence package.
