# AoA Recurrence Beacon Wave Seed

This seed carries the first programmable recurrence wave forward and adds the second contour: the beacon layer.

It is meant to be useful even if Codex lands only one archive. This pack therefore includes:

- the first-wave recurrence control plane under `aoa-sdk/src/aoa_sdk/recurrence/`
- the same small integration patches for `aoa-sdk/src/aoa_sdk/api.py` and `aoa-sdk/src/aoa_sdk/cli/main.py`
- owner manifests for the first two seeded components
- owner manifests for the beacon-sensitive layers: techniques, skills, evals, and playbooks
- beacon schemas, examples, docs, and tests

## What this wave adds

The first wave answers: "what must update now?"

This beacon wave adds a second, softer question:

- where a new technique candidate is forming
- where canonical pressure is building
- where a skill should have activated but did not
- where a portable eval boundary is starting to harden
- where a recurring scenario is becoming playbook-shaped
- where subagent and automation signals are emerging without becoming hidden orchestration

## What it does not do

- it does not auto-promote anything
- it does not auto-edit owner repos
- it does not turn metadata into judgment
- it does not create a hidden scheduler
- it does not make runtime techniques behave like auto-activated skills

## Intended landing order

1. Land `aoa-sdk/src/aoa_sdk/recurrence/`
2. Land `aoa-sdk/docs/`, `schemas/`, `examples/`, and `tests/`
3. Apply the tiny integration patches to `aoa-sdk/src/aoa_sdk/api.py` and `aoa-sdk/src/aoa_sdk/cli/main.py` if recurrence is not wired yet
4. Place the owner manifests into the owning repos
5. Let Codex adapt command names or file paths where the live repo has drifted
6. Run the repo-local tests and validators after landing

## Core split

Keep two adjacent contours:

- `planner` and `doctor` own obligation recurrence
- `observe`, `beacon`, `ledger`, and `usage-gaps` own emergence recurrence

The first contour says what is owed.
The second contour says what is trying to be born.
