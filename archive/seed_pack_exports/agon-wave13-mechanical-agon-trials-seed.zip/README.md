# Agon Wave XIII: Mechanical Agon Trials over Duel Kernel

This seed turns the earlier mechanical trial playbooks into kernel-shaped dry-run trials.

It is the first wave where Agon trial pressure can pass through a bounded local duel-kernel event log. It still does not create live verdicts, durable scars, retention execution, rank mutation, or Tree-of-Sophia promotion.

The result is a rehearsal floor: mechanical trials can produce reviewable candidate traces without pretending to be final arena sovereignty.
