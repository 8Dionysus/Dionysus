# Patch Notes

Wave XIII is a mechanical-trial rehearsal landing. It does not overwrite earlier Wave VI playbooks or Wave XII runtime kernel surfaces. It adds bindings, dry-run trial run models, and candidate-only owner surfaces.

The seed is intentionally multi-repo because the trial contour spans center law, playbook choreography, runtime dry-run substrate, court alignment, memory candidate intake, observability, and SDK helper candidates.
