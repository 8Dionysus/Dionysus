# Codex Landing Brief

Land `Agents-of-Abyss` first, then `aoa-playbooks`, then `abyss-stack`, then `aoa-evals`, `aoa-memo`, `aoa-stats`, and finally `aoa-sdk`.

Do not wire any background scheduler, database migration, daemon, live verdict path, durable scar write, retention execution, rank mutation, or ToS/KAG promotion during this landing.

This wave is allowed to produce dry-run event-log candidates only.
