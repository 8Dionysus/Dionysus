# Agon Wave XIII Seed: Mechanical Agon Trials over Duel Kernel

This seed introduces the first kernel-shaped mechanical trial suite for Agon.

It binds Wave VI trial playbooks to the Wave XII bounded local duel kernel and prepares candidate surfaces for eval, memo, stats, and SDK helpers.

## Landing order

1. `Agents-of-Abyss`
2. `aoa-playbooks`
3. `abyss-stack`
4. `aoa-evals`
5. `aoa-memo`
6. `aoa-stats`
7. `aoa-sdk`

## What this seed allows

- define the center-owned mechanical trial suite model;
- bind seven Wave VI trials to the bounded local duel kernel;
- generate reviewable dry-run event logs in `abyss-stack`;
- prepare eval suite candidates, memo intake candidates, stats observability candidates, and SDK helper candidates;
- route recurrence observations over trial run pressure without hidden automation.

## What this seed forbids

- live verdict authority;
- durable scar writes;
- retention execution;
- rank or trust mutation;
- Tree-of-Sophia or KAG promotion;
- hidden scheduler action;
- assistant contestant drift;
- unreviewed runtime service activation;
- network listeners, background daemons, or database migrations.

## Commands

In `Agents-of-Abyss`:

```bash
python scripts/build_agon_mechanical_trial_suite_registry.py --check
python scripts/validate_agon_mechanical_trial_suites.py
python -m pytest -q tests/test_agon_mechanical_trial_suites.py
```

In `aoa-playbooks`:

```bash
python scripts/build_agon_trial_kernel_binding_registry.py --check
python scripts/validate_agon_trial_kernel_bindings.py
python -m pytest -q tests/test_agon_trial_kernel_bindings.py
```

In `abyss-stack`:

```bash
python scripts/build_agon_mechanical_trial_run_registry.py --check
python scripts/validate_agon_mechanical_trial_runs.py
python scripts/simulate_agon_mechanical_trials.py --check
python -m pytest -q tests/test_agon_mechanical_trial_runs.py
```

In `aoa-evals`:

```bash
python scripts/build_agon_mechanical_trial_eval_suites.py --check
python scripts/validate_agon_mechanical_trial_eval_suites.py
python -m pytest -q tests/test_agon_mechanical_trial_eval_suites.py
```

In `aoa-memo`:

```bash
python scripts/build_agon_mechanical_trial_memo_intakes.py --check
python scripts/validate_agon_mechanical_trial_memo_intakes.py
python -m pytest -q tests/test_agon_mechanical_trial_memo_intakes.py
```

In `aoa-stats`:

```bash
python scripts/build_agon_mechanical_trial_stats_observability.py --check
python scripts/validate_agon_mechanical_trial_stats_observability.py
python -m pytest -q tests/test_agon_mechanical_trial_stats_observability.py
```

In `aoa-sdk`:

```bash
python scripts/build_agon_mechanical_trial_sdk_helpers.py --check
python scripts/validate_agon_mechanical_trial_sdk_helpers.py
python -m pytest -q tests/test_agon_mechanical_trial_sdk_helpers.py
```
