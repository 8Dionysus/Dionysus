# Local Validation Notes

This seed was locally checked for:

- JSON schema validity
- example-to-schema validation for:
  - `aoa-routing`
  - `aoa-memo`
  - `abyss-stack`
- JSON parse validity for SDK fixtures

The SDK fixtures are intentionally schema-light because the current public repository shape emphasizes docs, typed Python surfaces, CLI entrypoints, and tests rather than a dedicated public schema directory.
