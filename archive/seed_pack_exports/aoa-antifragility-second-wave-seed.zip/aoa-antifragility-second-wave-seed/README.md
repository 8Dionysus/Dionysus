# AoA Antifragility Second Wave Seed

This package is a repo-relative overlay seed for the second antifragility wave across the public AoA surface.

Wave 1 established doctrine, source-owned receipts, bounded proof, and derived vectors.
Wave 2 makes those signals travel without turning them into a new empire.

## Overlay model

Each top-level directory in this seed matches a target repository root.

Example:

- `aoa-routing/docs/STRESS_POSTURE_ROUTING.md`
- `aoa-memo/schemas/failure_lesson_memory_v1.json`
- `aoa-sdk/tests/fixtures/antifragility/stress_dispatch_input.example.json`
- `abyss-stack/schemas/service_degradation_receipt_v1.json`

Codex should treat these as **repo-relative overlays**, not blind copy instructions.
Live repository conventions remain authoritative.

## Wave 2 shape

Wave 2 is intentionally about transport and containment:

1. make routing stress-aware without making routing an owner of stress meaning
2. make repeated failure lessons recallable in `aoa-memo` without confusing memory for proof
3. make runtime degradation explicit and repair-safe in `abyss-stack`
4. make the SDK treat stress posture as a first-class control-plane input without widening automation

## Core guardrails

- owner repos remain the first source of truth for what happened
- routing may derive hints but must not author stress semantics
- memory stays explicit and reviewable, but memory is not proof
- the SDK may narrow or block activation under stress, but it must not use stress as an excuse to auto-repair
- runtime closeout remains reviewed and bounded
- do not edit `/srv/abyss-stack` as if it were the source repository

## Recommended apply order

1. `aoa-routing`
2. `aoa-memo`
3. `abyss-stack`
4. `aoa-sdk`

## What this seed intentionally is not

- not a request to centralize failure meaning in one repo
- not a license for hidden automation widening
- not a blanket instruction to parse arbitrary logs in routing
- not a replacement for wave 1 receipts, evals, or stats
- not a request to turn memo recall into proof

## Validation expectation

At minimum, Codex should leave the workspace with:

- additive docs that fit each repo's ownership boundaries
- schema-valid examples for routing, memo, and abyss-stack
- JSON-valid SDK fixtures that can become tests or docs
- no authority drift into routing or memo
- no hidden runtime auto-repair behavior
