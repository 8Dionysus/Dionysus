# Codex Handoff

Assume wave 1 is already landed, or that equivalent owner-local receipts/evals exist.

Use this seed as a **bounded transport-and-containment packet**.
The goal is to make stress state portable across navigation, recall, runtime, and the control plane without erasing source ownership.

## Primary objective

Teach the system to carry stress information across layers in a legible way:

1. source owner publishes bounded evidence
2. routing changes next-hop posture
3. memo stores reviewed lessons for later recall
4. runtime publishes degradation and reviewed repair-safe closeout
5. the SDK consumes this context to narrow activation, guard mutation, and bundle reviewed closeout evidence

## P0 deliverables

- `aoa-routing`: doctrine + machine-readable stress-navigation hint shape
- `aoa-memo`: explicit failure-lesson memory object + recall doctrine
- `abyss-stack`: service degradation receipt + repair-safe closeout receipt
- `aoa-sdk`: stress-aware control-plane and closeout seam docs + fixtures

## Acceptance criteria

1. routing hints are derived from owner receipts, bounded eval signals, or explicit reviewed manifests, not raw myth
2. memo failure lessons are reviewable, bounded, and clearly marked as non-proof context
3. abyss-stack receipts stay owner-local and preserve the source-vs-deployed path boundary
4. the SDK uses stress context only to narrow, disclose, or block, never to widen hidden automation
5. reviewed closeout can bundle stress evidence without forcing immediate cross-repo promotion
6. optional stats or memo signals never outrank source receipts

## Suggested sequence

### 1. Routing
Land stress-posture routing doctrine and one schema/example.
Prefer additive generated surfaces or additive fields in existing hint outputs over a router rewrite.

### 2. Memo
Land one explicit failure-lesson object family and bounded recall doctrine.
Do not emit one memory object per failed run.
Promote only reviewed or repeated lessons.

### 3. Runtime
Land owner-local runtime degradation receipts and repair-safe closeout receipts in `abyss-stack`.
Keep repair actions reviewed, bounded, and explicit.

### 4. SDK
Land docs and fixtures that treat stress posture as a dispatch and closeout input.
Persist stress context in stable reports only if it fits the existing `.aoa/` report surfaces cleanly.

## Hard guardrails

- do not parse arbitrary raw logs in `aoa-routing`
- do not let memo overwrite or replace source-owned evidence
- do not treat `aoa-stats` as the source of stress truth
- do not add hidden auto-remediation in `aoa-sdk` or `abyss-stack`
- do not edit `/srv/abyss-stack` as if it were the source repo
- do not create a sovereign global stress score

## Soft promotion rule

If multiple owner repos converge on nearly identical runtime or failure-lesson semantics, promote shared pieces later.
Before then, local ownership is healthier than premature centralization.
