# Later Waves

Wave 2 makes stress portable across navigation, recall, runtime, and control-plane activation.

The next clean expansion points are:

- `aoa-agents`: role posture for mutation appetite, escalation threshold, and proof threshold under stress
- `aoa-playbooks`: recurring incident families, handoff paths, and recovery method surfaces
- `aoa-kag`: provenance-aware correction loops when derived substrate lags or drifts
- `aoa-evals`: repeated-window evaluation for routing and runtime stress handling quality
- `aoa-stats`: wider multi-repo vectors after the source-owned receipt families stabilize

Do not widen to those surfaces until wave 2 yields real routing hints, memo lessons, runtime receipts, and closeout bundles worth consuming.
