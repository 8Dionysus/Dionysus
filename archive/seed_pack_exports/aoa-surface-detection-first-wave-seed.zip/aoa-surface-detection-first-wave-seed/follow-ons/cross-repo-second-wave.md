# Cross-repo second-wave notes

This file exists so the first wave stays bounded.

## `aoa-skills`

Possible second-wave follow-ons:

- richer runtime-signal export for non-skill neighboring layers
- optional helper skill for explicit candidate triage after the core detection seam proves useful
- tighter bridge from skill runtime receipts to surface-detection closeout notes

Keep out of wave one:
- turning the detector itself into one giant skill
- widening `.agents/skills/` into a second canon for non-skill meaning

## `aoa-routing`

Possible second-wave follow-ons:

- additive owner-layer shortlist hints for non-skill surfaces
- stronger signal bridge between flat routing and surface-detection heuristics

Keep out of wave one:
- making `aoa-routing` the source of meaning
- requiring router redesign before the first surface report lands

## `aoa-stats`

Possible second-wave follow-ons:

- derived summaries for surface-detection handoff volume
- repetition and promotion-shape summaries across windows
- visibility into manual-equivalent versus activated rates

Keep out of wave one:
- turning stats into workflow authority
- using stats to decide promotion in place of reviewed closeout

## `aoa-playbooks`, `aoa-evals`, `aoa-memo`, `aoa-agents`, `aoa-techniques`

Possible second-wave follow-ons:

- compact family entry surfaces that make first-wave detection more precise
- stronger consumer-facing inspect surfaces
- stable typed contracts for family-level entry hints

Keep out of wave one:
- requiring every owner repo to add new public objects before the SDK can land the first additive seam

## Summary

Land the first-wave control-plane seam first.
Let repeated real use reveal which second-wave bridges are actually worth hardening.
