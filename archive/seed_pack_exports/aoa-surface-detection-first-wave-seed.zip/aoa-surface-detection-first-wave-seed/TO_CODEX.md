# To Codex

Integrate this seed **natively** with the current `aoa-sdk` idiom.

Do not treat this package as a rigid patch. Treat it as a **well-scoped architectural seed** that should be adapted to the live repo structure, naming, tests, and CLI style.

## Read first in the target repo

1. `README.md`
2. `AGENTS.md`
3. `docs/boundaries.md`
4. `docs/session-closeout.md`
5. `docs/skill-runtime-recommendation-gap.md`
6. `docs/skill-runtime-recommendation-gap-fix-spec.md`
7. `src/aoa_sdk/models.py`
8. `src/aoa_sdk/skills/detector.py`
9. `src/aoa_sdk/cli/main.py`
10. existing tests around skill detection / dispatch / closeout

## Primary goal

Add an **additive multi-surface detection seam** that can notice AoA objects across:

- `aoa-techniques`
- `aoa-skills`
- `aoa-evals`
- `aoa-memo`
- `aoa-playbooks`
- `aoa-agents`

while keeping `aoa-sdk` on the control plane.

## Required invariants

- Do **not** move canonical meaning out of sibling repos.
- Do **not** rename or break the existing `aoa skills ...` commands.
- Do **not** auto-activate non-skill surfaces.
- Do **not** claim that `manual-equivalent` means `activated`.
- Do **not** use the session-growth kernel inside an active route.
- Do **not** let playbook / eval / memo / agent hints become hidden runtime authority.
- Keep the implementation reviewable, typed, and test-backed.

## Preferred first-wave surface

Prefer a new additive command surface such as:

- `aoa surfaces detect`

If the live CLI idiom suggests a different additive shape, adapt it. Examples that are still acceptable:

- `aoa detect surfaces`
- `aoa skills detect --include-surfaces`

But keep the semantics from this seed:
- separate surface detection from skill-only dispatch
- preserve backward compatibility
- preserve honest labels

## Truth labels that must survive implementation

- `activated`
- `manual-equivalent`
- `candidate-now`
- `candidate-later`

## First-wave phases

- `ingress`
- `in-flight`
- `pre-mutation`
- `closeout`

## Execution rule

Only executable, host-visible, explicit-preferred skills may flow into immediate activation lanes.

Everything else should stay one of:
- inspect/expand/use hint
- visible manual fallback
- closeout handoff candidate
- defer note

## Closeout rule

Surviving notes from surface detection should hand off only after reviewed run, closure, or pause, using the existing session-growth kernel posture.

## Deliverables

A good integration should include:

- additive models
- additive CLI path
- additive docs
- additive tests
- persisted machine-readable reports
- one closeout-handoff contract or equivalent typed report

## Done when

Done when the repo can honestly emit a report that:
- reuses the existing skill control plane
- adds non-skill surface candidates
- distinguishes activated from manual-equivalent
- hands off promotion-shaped notes to closeout rather than live mutation
- leaves current skill-only behavior intact
