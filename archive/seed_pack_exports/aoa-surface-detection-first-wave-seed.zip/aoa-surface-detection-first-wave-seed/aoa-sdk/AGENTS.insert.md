## AoA detection loop

At session start, keep using `aoa skills enter`.
Before repo-config, infra, runtime, or public-share mutations, keep using `aoa skills guard`.

During the session, when repetition, owner-layer ambiguity, proof needs, recall/provenance needs, or a recurring multi-step scenario appears, run the additive AoA surface-detection path if it exists.
Prefer `aoa surfaces detect` when available.
If only the skill path exists, keep the same discipline by reading the current skill report plus visible manual notes.

Use these truth labels consistently:
- `activated` = the object actually ran or was explicitly activated
- `manual-equivalent` = the same discipline was followed manually, but the object was not activated
- `candidate-now` = relevant in the current route, but not yet used
- `candidate-later` = relevant for closeout, promotion, or a later route, but not for immediate activation

Auto-activate only host-executable, explicit-preferred skills.
Do not auto-activate playbooks, evals, memo surfaces, techniques, or agents from surface detection.
Do not claim a non-skill AoA object was "used" unless the route has a real activation surface or the work is explicitly labeled `manual-equivalent`.

Keep `aoa-sdk` on the control plane:
- detect
- type
- report
- hand off

Do not let live surface detection silently mutate owner repos or replace source-owned meaning.

At closeout, surviving surface notes may hand off to the session-growth kernel only after reviewed run, closure, or pause.
The likely handoff family is:
- `aoa-session-donor-harvest`
- `aoa-automation-opportunity-scan`
- `aoa-session-route-forks`
- `aoa-session-self-diagnose`
- `aoa-session-self-repair`
- `aoa-session-progression-lift`
- `aoa-quest-harvest`
