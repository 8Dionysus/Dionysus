# AoA Surface Detection First Wave

Status: seed
Owner repo: `aoa-sdk`
Layer posture: additive control-plane seam

## Goal

Add a multi-surface detection report that can notice when a live session is touching, already touched, or may need one or more AoA owner layers without pretending that every meaningful AoA object is an executable skill.

The first-wave target layers are:

- `aoa-techniques`
- `aoa-skills`
- `aoa-evals`
- `aoa-memo`
- `aoa-playbooks`
- `aoa-agents`

## Why this belongs in `aoa-sdk`

`aoa-sdk` already owns the control-plane path for skill ingress / guard / detect / dispatch and reviewed session closeout. That makes it the cleanest place to add a new reporting seam without moving canonical meaning out of sibling repositories.

## One-sentence posture

**Skill-first for execution. Closeout-first for promotion.**

## First-wave shape

The first wave should land as four additive parts:

1. a standing Codex-facing reflex in `AGENTS.md`
2. an additive surface-detection report in the SDK
3. reuse of current skill dispatch for immediately executable skills only
4. a reviewed closeout handoff for surviving promotion-shaped notes

## Truth labels

The report must preserve four states:

- `activated`
  - a real activation or execution happened
- `manual-equivalent`
  - the same discipline was followed manually, but the object was not activated
- `candidate-now`
  - relevant during the current route, but not yet used
- `candidate-later`
  - relevant for closeout, promotion, or a later route

The key honesty rule is simple:

`manual-equivalent` is never `activated`.

## Detection phases

Wave one should support these phases:

- `ingress`
- `in-flight`
- `pre-mutation`
- `closeout`

`in-flight` is important because the original goal is not just start-of-session routing. The detector should also be able to notice that a session has drifted into proof need, recall need, recurring-route shape, or role-posture ambiguity while work is already under way.

## Owner-layer classification

Surface detection should keep the owner split explicit:

- reusable practice -> `aoa-techniques`
- bounded executable workflow -> `aoa-skills`
- bounded proof / claim surface -> `aoa-evals`
- recall / provenance / writeback posture -> `aoa-memo`
- recurring multi-step scenario with handoffs / fallbacks -> `aoa-playbooks`
- role / handoff / orchestration posture -> `aoa-agents`

## Execution lanes

Wave one should keep execution lanes narrow and explicit.

Suggested lane values:

- `skill-dispatch`
- `inspect-expand-use`
- `manual-fallback`
- `closeout-harvest`
- `defer`

Only `skill-dispatch` may lead to immediate runtime activation, and even then only when the skill is host-executable and the current posture allows it.

## Honest activation rule

When the current host inventory shows a recommended skill as router-only or otherwise non-executable:

- the skill may still be semantically important
- the report may still surface it
- the session may still keep a visible manual discipline if that discipline is genuinely preserved
- but the session must not claim that the skill was activated

## Report shape

A good first-wave report should include:

- repo root
- workspace root
- phase
- intent text
- mutation surface
- optional link to the existing skill report
- active skill names
- immediate skill-dispatch candidates
- surface items
- closeout followups
- owner-layer notes
- actionability gaps

## Persistence

Persist surface reports under a dedicated state directory such as:

- `.aoa/surface-detection/`

Keep them separate from skill-only dispatch reports so the distinction between current skill control-plane output and additive multi-surface detection remains legible.

## First-wave non-goals

Wave one should not try to do all of the following:

- build a second router canon inside `aoa-sdk`
- auto-activate playbooks, evals, memo, techniques, or agents
- invent full live object identity for every non-skill surface
- replace the current `aoa skills ...` path
- make promotion decisions during active route execution
- let closeout-family skills become hidden runtime authority

## Suggested CLI

The cleanest additive path is:

`aoa surfaces detect`

It should accept at least:

- `repo_root`
- `--phase`
- `--intent-text`
- `--mutation-surface`
- `--session-file`
- `--report-output`
- `--root`
- `--json`

If the live CLI idiom suggests a different additive path, preserve the same semantics even if the exact command name changes.

## Closeout handoff rule

Surviving notes should hand off only after reviewed run, closure, or pause.

Likely first-wave handoff targets:

- `aoa-session-donor-harvest`
- `aoa-automation-opportunity-scan`
- `aoa-session-route-forks`
- `aoa-session-self-diagnose`
- `aoa-session-self-repair`
- `aoa-session-progression-lift`
- `aoa-quest-harvest`

## Acceptance

Wave one is good enough when all of this is true:

- the repo can emit an additive surface report
- the report can point to existing skill control-plane outputs
- `manual-equivalent` never masquerades as `activated`
- non-skill surfaces remain hints, candidates, or closeout handoffs
- existing skill commands remain backward compatible
- the new seam is typed, reviewable, and test-backed
