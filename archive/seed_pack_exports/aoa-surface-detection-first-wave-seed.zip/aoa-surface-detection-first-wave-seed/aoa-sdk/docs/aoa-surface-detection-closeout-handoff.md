# AoA Surface Detection Closeout Handoff

Status: first-wave seed
Owner repo: `aoa-sdk`
Scope: reviewed closeout only

## Purpose

Surface detection during live work is intentionally light.
It should leave visible notes, not hidden authority.

The closeout handoff exists so surviving notes can become reviewed next steps instead of vanishing into session ash.

## Boundary

The handoff may run only after:

- reviewed run
- closure
- pause

It must not become live-route orchestration.

## Input

The input is a surface-detection report plus reviewed-session posture.

Good first-wave inputs:

- one machine-readable surface report
- reviewed flag or equivalent reviewed manifest posture
- optional existing closeout manifest / audit refs

## Output

A good first-wave output is a typed handoff report that:

- lists surviving items
- lists suggested session-growth kernel targets
- explains why each handoff target is relevant
- keeps promotion decisions reviewable

## Suggested handoff mapping

### `aoa-session-donor-harvest`

Use when:
- several bounded notes survived
- the session needs one reviewable harvest packet
- the aim is capture, not promotion yet

### `aoa-automation-opportunity-scan`

Use when:
- the route looks repeated
- manual process is recurring
- the real question is automation readiness or owner-layer placement

### `aoa-session-route-forks`

Use when:
- more than one honest route survives
- the detector surfaced a real next-step branch
- the session should not silently pick one path

### `aoa-session-self-diagnose`

Use when:
- the route revealed drift
- a recurring mismatch needs classification before repair
- the output should remain read-only

### `aoa-session-self-repair`

Use when:
- a diagnosis already exists
- the repair needs checkpointed explicit authoring
- silent self-mutation would be unsafe

### `aoa-session-progression-lift`

Use when:
- the session shows multi-axis movement
- the note is about progression evidence rather than promotion naming

### `aoa-quest-harvest`

Use when:
- the surviving question is promote / defer
- repeated reviewed evidence exists
- the note is mature enough for a bounded promotion verdict

## Review rule

The closeout handoff should not itself become the promotion verdict.
It only prepares the reviewed next move.

## State rule

Handoff outputs should preserve the original truth labels.
A `manual-equivalent` note stays `manual-equivalent` all the way through closeout.

## Good first-wave check

If the implementation ever turns a playbook or technique hint into live runtime authority, the closeout boundary has been crossed in the wrong direction.
