# AoA Surface Detection Heuristics

Status: first-wave seed
Scope: additive
Owner repo: `aoa-sdk`

These heuristics are intentionally coarse.
They exist to make the first wave useful without pretending that the SDK now owns the full semantic meaning of every AoA object.

## Core rule

The detector may classify, suggest, and hand off.
It may not steal ownership from the source repositories.

## Heuristic families

### 1. Proof need -> eval candidate

Use when the live route starts making bounded claims such as:

- verified
- quality improved
- regression avoided
- invariant preserved
- property held

Default mapping:
- owner repo: `aoa-evals`
- object kind: `eval`
- state: `candidate-now`
- lane: `inspect-expand-use`

### 2. Recall / provenance need -> memo candidate

Use when the route depends on:

- previous rationale
- prior decisions
- provenance
- continuity across sessions
- bounded writeback need

Default mapping:
- owner repo: `aoa-memo`
- object kind: `memo`
- state: `candidate-now`
- lane: `inspect-expand-use`

### 3. Recurring multi-surface route -> playbook candidate

Use when the shape looks like:

- repeatable sequence
- recurring handoffs
- fallback / rollback posture
- scenario route rather than one bounded workflow

Default mapping:
- owner repo: `aoa-playbooks`
- object kind: `playbook`
- state: `candidate-later`
- lane: `closeout-harvest`

Important:
do not auto-activate this.
In wave one this is promotion-shaped, not live authority.

### 4. Role / handoff posture -> agent candidate

Use when the route is really about:

- who acts
- what role contract applies
- which orchestrator / cohort / subagent boundary matters
- how handoff posture should work

Default mapping:
- owner repo: `aoa-agents`
- object kind: `agent`
- state: `candidate-now`
- lane: `inspect-expand-use`

### 5. Repeated bounded discipline -> technique candidate

Use when a reviewed pattern survives more than one route or clearly wants to become portable practice.

Default mapping:
- owner repo: `aoa-techniques`
- object kind: `technique`
- state: `candidate-later`
- lane: `closeout-harvest`

### 6. Existing skill relevance -> skill dispatch or honesty note

Use the current skill control plane first.
If a skill is host-executable and policy-compatible, it may remain an immediate runtime object.

If a skill is only router-visible or otherwise not executable in the current host surface:
- it may still be semantically important
- it may still become `manual-equivalent`
- but it must not be labeled `activated`

## Wave-one signal vocabulary

Suggested signal tags:

- `explicit-request`
- `risk-gate`
- `router-match`
- `repeated-pattern`
- `proof-need`
- `recall-need`
- `scenario-recurring`
- `role-posture`
- `closeout-chain`

## Suggested precedence

When more than one interpretation is possible, prefer:

1. existing explicit skill activation truth
2. safety / risk-gate honesty
3. proof / recall needs that affect current correctness
4. recurring-route / promotion hints
5. later-wave refinement

## Dedupe rules

A good first-wave dedupe policy:

- keep one item per `surface_ref` + `state`
- merge signals when the same surface is detected by more than one heuristic
- merge related skill names
- prefer the stronger honesty label:
  - `activated` beats `candidate-now`
  - `manual-equivalent` beats `candidate-now`
  - `candidate-now` beats `candidate-later`

## Closeout survival filter

Not every live hint deserves closeout weight.

Survive to closeout only when one or more is true:

- it changed the route
- it protected correctness or safety
- it recurred
- it reveals owner-layer ambiguity that needs review
- it points to a real promotion question

## What wave one should not guess

Do not guess:
- open-ended playbook structure
- final eval design
- final memo writeback content
- agent profile identity
- technique promotion readiness from one anecdote
