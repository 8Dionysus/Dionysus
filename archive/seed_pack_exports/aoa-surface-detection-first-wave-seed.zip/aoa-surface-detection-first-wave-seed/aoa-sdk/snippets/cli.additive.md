# CLI additive seed

Preferred command:

```bash
aoa surfaces detect REPO_ROOT       --phase ingress|in-flight|pre-mutation|closeout       --intent-text "..."       --mutation-surface none|code|repo-config|infra|runtime|public-share       --session-file /path/to/session.json       --report-output /path/to/report.json       --root /srv       --json
```

## Notes

- `REPO_ROOT` should follow the same path conventions as the current `aoa skills ...` commands.
- `--phase in-flight` is the new important addition for live-route detection.
- `--mutation-surface` should default to `none`.
- The implementation may internally reuse the existing skill-dispatch path before layering in surface hints.

## Human-readable output suggestion

1. `immediate_skill_dispatch`
2. `surface_items`
3. `closeout_followups`
4. `owner_layer_notes`
5. `actionability_gaps`

## Backward-compatibility option

If a new command group feels too heavy for the live CLI layout, an acceptable fallback is an additive flag such as:

```bash
aoa skills detect REPO_ROOT --include-surfaces ...
```

But preserve the semantic split:
- skill-only detect remains valid
- surface detection remains additive
- existing JSON consumers do not break unexpectedly
