# Surface detection acceptance tests

Suggested first-wave tests:

## 1. Backward compatibility

- existing `aoa skills enter` behavior still passes
- existing `aoa skills guard` behavior still passes
- existing `aoa skills detect` behavior still passes
- existing `aoa skills dispatch` behavior still passes

## 2. Typed report round-trip

- construct a `SurfaceDetectionReport`
- dump to JSON
- re-parse
- assert equality on key fields

## 3. Honesty test for router-only skill gap

Scenario:
- skill report indicates a router-only risk-gate skill
- surface detector emits an honesty note

Assert:
- the resulting surface item is `manual-equivalent` or `candidate-now`
- it is never `activated`

## 4. Non-skill activation boundary

Scenario:
- intent implies proof / recall / recurring-route / role-posture

Assert:
- eval / memo / playbook / agent items appear as surface candidates
- none of them appear in `immediate_skill_dispatch`

## 5. Repetition -> technique candidate

Scenario:
- session signals show repeated bounded pattern count >= 2

Assert:
- one technique candidate appears
- it is `candidate-later`
- it points to closeout-harvest rather than live activation

## 6. Closeout-only kernel handoff

Scenario:
- phase is `closeout`
- report has surviving promotion-shaped items

Assert:
- closeout followups / handoff targets are present

Scenario:
- phase is `ingress` or `in-flight`

Assert:
- no session-growth kernel handoff is emitted as live authority

## 7. CLI smoke

- run the additive CLI in `--json` mode
- validate the payload against the schema
- assert stable exit code and deterministic top-level keys
