"""Pseudocode seed for additive AoA surface detection.

Adapt field names to the live repo's existing SkillDetectionReport if they differ.
"""

from __future__ import annotations

from typing import Iterable

# from aoa_sdk.models import SurfaceDetectionReport, SurfaceOpportunityItem


def build_surface_detection_report(
    *,
    workspace,
    repo_root: str,
    phase: str,
    intent_text: str,
    mutation_surface: str,
    session_file: str | None,
    skill_report,
):
    items = []

    items.extend(
        derive_surface_items_from_skill_report(
            skill_report=skill_report,
            phase=phase,
            mutation_surface=mutation_surface,
        )
    )

    items.extend(
        derive_surface_items_from_intent(
            intent_text=intent_text,
            phase=phase,
        )
    )

    items.extend(
        derive_surface_items_from_session_signals(
            session_file=session_file,
            phase=phase,
        )
    )

    items = dedupe_surface_items(items)

    immediate_skill_dispatch = [
        skill.skill_name
        for skill in getattr(skill_report, "activate_now", [])
        if getattr(getattr(skill, "host_availability", None), "status", None) == "host-executable"
    ]

    return SurfaceDetectionReport(
        repo_root=str(repo_root),
        workspace_root=str(workspace.root),
        phase=phase,
        intent_text=intent_text,
        mutation_surface=mutation_surface,
        skill_report_path=getattr(skill_report, "report_path", None),
        skill_report_included=True,
        active_skill_names=load_active_skill_names(session_file=session_file),
        immediate_skill_dispatch=immediate_skill_dispatch,
        items=items,
        closeout_followups=derive_closeout_followups(items=items, phase=phase),
        owner_layer_notes=derive_owner_layer_notes(items=items),
        actionability_gaps=list(getattr(skill_report, "actionability_gaps", [])),
    )


def derive_surface_items_from_skill_report(*, skill_report, phase: str, mutation_surface: str):
    items = []

    # 1. Preserve explicit skill truth when a skill really ran or is ready to run.
    for dispatch_item in getattr(skill_report, "activate_now", []):
        items.append(
            make_skill_surface_item_from_dispatch(dispatch_item, phase=phase, state="candidate-now")
        )

    # 2. Convert router-only risk-gate or must-confirm situations into honesty notes.
    for dispatch_item in getattr(skill_report, "must_confirm", []):
        host_status = getattr(getattr(dispatch_item, "host_availability", None), "status", "unknown")
        if host_status == "router-only":
            items.append(
                make_manual_equivalent_risk_gate_item(
                    dispatch_item=dispatch_item,
                    phase=phase,
                    mutation_surface=mutation_surface,
                )
            )

    return items


def derive_surface_items_from_intent(*, intent_text: str, phase: str):
    lowered = intent_text.lower()
    items = []

    if any(token in lowered for token in ["verify", "proof", "regression", "quality", "score", "eval", "invariant", "property", "contract"]):
        items.append(make_eval_candidate(phase=phase))

    if any(token in lowered for token in ["recall", "memory", "previous", "prior", "provenance", "history", "earlier", "context"]):
        items.append(make_memo_candidate(phase=phase))

    if any(token in lowered for token in ["recurring", "repeat", "again", "workflow", "handoff", "runbook", "sequence", "checkpoint"]):
        items.append(make_playbook_candidate(phase=phase))

    if any(token in lowered for token in ["agent", "role", "orchestrator", "subagent", "tier", "cohort", "handoff"]):
        items.append(make_agent_candidate(phase=phase))

    return items


def derive_surface_items_from_session_signals(*, session_file: str | None, phase: str):
    if not session_file:
        return []

    # Keep wave one simple.
    # Suggested first slice:
    # - inspect activation log
    # - count repeated bounded patterns
    # - emit one technique promotion candidate when repetition >= 2
    repeat_count = infer_repeat_count(session_file=session_file)
    if repeat_count >= 2:
        return [make_technique_candidate(phase=phase)]

    return []


def dedupe_surface_items(items):
    by_key = {}
    rank = {
        "activated": 4,
        "manual-equivalent": 3,
        "candidate-now": 2,
        "candidate-later": 1,
    }

    for item in items:
        key = (item.surface_ref, item.owner_repo)
        if key not in by_key:
            by_key[key] = item
            continue

        current = by_key[key]
        if rank[item.state] > rank[current.state]:
            current.state = item.state

        current.signals = sorted(set(current.signals + item.signals))
        current.related_skill_names = sorted(set(current.related_skill_names + item.related_skill_names))
        current.closeout_family_candidates = sorted(
            set(current.closeout_family_candidates + item.closeout_family_candidates)
        )

    return list(by_key.values())


def derive_closeout_followups(*, items, phase: str):
    if phase != "closeout":
        return []

    followups = []
    if any(item.object_kind == "playbook" for item in items):
        followups.append("route recurring-route evidence through aoa-automation-opportunity-scan before any automation claim")
    if any(item.object_kind == "technique" for item in items):
        followups.append("bundle technique-shaped repetition notes into donor-harvest before promotion")
    if any(item.object_kind in {"eval", "memo"} for item in items):
        followups.append("keep proof and memory hints source-owned; the SDK only hands off")
    return followups
