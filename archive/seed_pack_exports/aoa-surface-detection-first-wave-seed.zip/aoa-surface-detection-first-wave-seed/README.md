# AoA Surface Detection First Wave Seed

Date: 2026-04-07

This package is a **zip-seed for the first wave of AoA object detection**, aimed primarily at **`aoa-sdk`**.

The goal is to give Codex and other agents a durable way to notice when a live session is touching, already touched, or is likely to need one or more AoA surfaces such as:

- techniques
- skills
- evals
- memo / recall
- playbooks
- agents

The seed is intentionally **additive**. It does not ask `aoa-sdk` to steal meaning from sibling repositories.

## First-wave shape

The intended first-wave contour is:

1. add a standing detection reflex to `AGENTS.md`
2. add an additive multi-surface detect report in `aoa-sdk`
3. reuse existing skill dispatch only for immediately executable skills
4. keep non-skill surfaces as explicit notes, candidates, or closeout handoffs
5. hand surviving notes to the reviewed session-growth closeout path rather than silently promoting them mid-route

## Why this seed centers on `aoa-sdk`

`aoa-sdk` already owns the control-plane seam for:

- `aoa skills enter`
- `aoa skills guard`
- `aoa skills detect`
- `aoa skills dispatch`
- reviewed session closeout helpers

That makes it the cleanest place for a first-wave additive detection layer.

## What is inside

- `TO_CODEX.md` — direct integration brief for Codex
- `seed_manifest.json` — machine-readable summary of the seed
- `aoa-sdk/patch_map.yaml` — likely target files and edit intent
- `aoa-sdk/AGENTS.insert.md` — exact standing-rule insert
- `aoa-sdk/docs/*` — first-wave architecture, heuristics, closeout handoff docs
- `aoa-sdk/schemas/*` — additive JSON schemas
- `aoa-sdk/examples/*` — example detection report, closeout handoff, and heuristic rules
- `aoa-sdk/snippets/*` — model, pipeline, CLI, and test skeletons
- `follow-ons/*` — second-wave notes that should stay out of the first implementation slice

## Important posture

This seed assumes:

- **skill-first for execution**
- **closeout-first for promotion**
- **manual-equivalent is not activated**
- **playbook / eval / memo / agent detection does not grant auto-activation authority**
- **owner repos keep meaning**

## Suggested integration order

1. read `TO_CODEX.md`
2. read `aoa-sdk/patch_map.yaml`
3. land the additive models and docs
4. wire the detector + CLI
5. add tests
6. add the closeout handoff seam
7. keep follow-on notes for later waves

## Recommended end state for wave one

A good wave-one landing is enough to let a session say things like:

- “this eval surface is a candidate now”
- “this memo surface is relevant now”
- “this recurring route looks playbook-shaped, but only as a closeout candidate”
- “this skill discipline was followed manually, but the skill was not actually activated”

without pretending that every meaningful AoA object is an executable skill.
