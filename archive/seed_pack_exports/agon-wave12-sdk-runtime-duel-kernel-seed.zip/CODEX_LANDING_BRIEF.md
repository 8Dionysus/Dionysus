# Codex Landing Brief

Apply directories to their matching sibling repositories. Do not merge the repo folders into a single root.

This seed intentionally introduces the first bounded runtime-shaped surface. Treat `abyss-stack` scripts as local validation and dry-run substrate only, not as service activation.
