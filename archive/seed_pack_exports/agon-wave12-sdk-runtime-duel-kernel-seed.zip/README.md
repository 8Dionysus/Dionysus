# Agon Wave XII: SDK / Runtime Duel Kernel

This seed introduces the first bounded local duel-kernel substrate for Agon. It is intentionally narrow: one mechanical duel kernel, typed helper candidates, and event-log/hash-chain validation.

The seed is not a live arena service. It is the bridge from pre-protocol surfaces to a reviewable, local mechanical duel kernel contour.
