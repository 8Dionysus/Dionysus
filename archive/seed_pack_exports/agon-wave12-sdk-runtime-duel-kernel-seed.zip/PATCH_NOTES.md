# Patch Notes

- Adds center-owned duel kernel model registry in `Agents-of-Abyss`.
- Adds requested-only SDK helper binding candidates in `aoa-sdk`.
- Adds local event-log runtime substrate skeleton in `abyss-stack`.
- Adds recurrence manifests for center, SDK, and runtime surfaces.
- Preserves all Wave XII stop-lines: no live verdict, no durable scars, no rank mutation, no ToS/KAG promotion.
