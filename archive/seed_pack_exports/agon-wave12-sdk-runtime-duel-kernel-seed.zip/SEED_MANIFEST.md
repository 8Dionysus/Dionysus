# Agon Wave XII Seed: SDK / Runtime Duel Kernel

This seed is the first bounded runtime-shaped landing for the Agon of Abyss.

It does **not** awaken the full arena. It creates a local mechanical duel kernel contour: center-owned duel kernel model, SDK typed helper candidates, and an `abyss-stack` event-log substrate skeleton.

## Landing order

1. `Agents-of-Abyss`
2. `aoa-sdk`
3. `abyss-stack`

## What this seed allows

- model a minimal two-contestant mechanical duel kernel;
- bind the kernel to already seeded Wave VIII session models, Wave IX state packets, Wave X contradiction / closure / summon law, and Wave XI verdict / delta / scar bridge;
- draft local event logs with monotonic sequence and hash-chain trace;
- validate event order, commit-before-reveal discipline, assistant boundary, and stop-lines;
- expose SDK helper candidates for future typed access.

## What this seed forbids

- live verdict authority;
- durable scar writes;
- retention execution;
- rank or trust mutation;
- Tree-of-Sophia or KAG promotion;
- hidden scheduler action;
- assistant contestant drift;
- unreviewed runtime service activation.

## Commands

In `Agents-of-Abyss`:

```bash
python scripts/build_agon_duel_kernel_model_registry.py --check
python scripts/validate_agon_duel_kernel_models.py
python -m pytest -q tests/test_agon_duel_kernel_models.py
```

In `aoa-sdk`:

```bash
python scripts/build_agon_duel_kernel_sdk_bindings.py --check
python scripts/validate_agon_duel_kernel_sdk_bindings.py
python -m pytest -q tests/test_agon_duel_kernel_sdk_bindings.py
```

In `abyss-stack`:

```bash
python scripts/build_agon_duel_runtime_kernel_registry.py --check
python scripts/validate_agon_duel_runtime_kernels.py
python scripts/simulate_agon_mechanical_duel_kernel.py --check
python -m pytest -q tests/test_agon_duel_runtime_kernels.py
```
