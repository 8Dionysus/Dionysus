# Patch Notes

- Adds `generated/agon_arena_session_model_registry.min.json`.
- Adds eight pre-protocol arena session models.
- Adds lifecycle slots for future sealed commit, reveal, adjudication, inscription, and retention.
- Adds recurrence manifests for the new arena session model surfaces.
- Does not alter runtime, SDK, eval, memo, stats, routing, agents, or Tree-of-Sophia authority.
