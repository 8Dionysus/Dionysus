# Agon Wave VIII Seed: Arena Session Model

This seed lands Wave VIII in `Agents-of-Abyss`.

## Plant order

```text
1. Agents-of-Abyss
```

## What this wave does

Wave VIII gives Agon its first pre-protocol arena session skeleton:

- session model registry;
- charter model;
- seat model;
- lifecycle slots;
- pressure profile slots;
- terminal outcome slots;
- recurrence component for the new surfaces.

It defines the shape of future arena sessions without opening the arena.

## What this wave does not do

It does not create live sessions, define sealed commit packets, execute moves, issue verdicts, write scars, schedule retention, mutate rank, or promote anything to `Tree-of-Sophia`.

## Validation commands

In `Agents-of-Abyss`:

```bash
python scripts/build_agon_arena_session_model_registry.py --check
python scripts/validate_agon_arena_session_models.py
python -m pytest -q tests/test_agon_arena_session_models.py
```

## Next wave

Wave IX should fill the reserved `sealed_commit_slot` and `reveal_slot` with state packet grammar. It must not yet create runtime sessions, verdicts, scars, rank mutation, or retention execution.
