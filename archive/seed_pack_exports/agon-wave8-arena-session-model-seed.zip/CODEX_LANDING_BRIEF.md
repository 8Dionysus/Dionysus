# Codex Landing Brief

Merge the `Agents-of-Abyss/` directory into the root of `Agents-of-Abyss`.

Run:

```bash
python scripts/build_agon_arena_session_model_registry.py --check
python scripts/validate_agon_arena_session_models.py
python -m pytest -q tests/test_agon_arena_session_models.py
```

Do not patch release checks automatically unless the owner chooses to integrate this wave into the current release gate. This seed is intentionally pre-protocol.
