# Agon Wave VIII: Arena Session Model

This seed gives `Agents-of-Abyss` the first arena-shaped protocol skeleton.

The arena still sleeps. Wave VIII only gives it bones: charter, seats, lifecycle, pressure profiles, and terminal outcome slots.
