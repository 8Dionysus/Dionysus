# Roll out order for aoa_codex_convergence_pack

1. Copy `workspace-overlay/src/aoa_codex_converge/` into the workspace root under `src/aoa_codex_converge/`
   or wherever you keep small workspace-local Python packages.
2. Copy `workspace-overlay/scripts/*.py` into `scripts/`.
3. Optionally copy the shell wrappers from `templates/workspace-root/scripts/`.
4. Merge `templates/workspace-root/.codex/config.convergence.snippet.toml` into your workspace `.codex/config.toml`.
5. Run:

```bash
python -m pytest -q workspace-overlay/tests/test_aoa_codex_converge.py
python scripts/aoa_codex_bootstrap.py --workspace-root .
python scripts/aoa_codex_doctor.py --workspace-root . --write-report
```

6. Open the Markdown report under `generated/codex/aoa_codex_convergence_report.md`.
7. Fix drift until all required seams are green.
