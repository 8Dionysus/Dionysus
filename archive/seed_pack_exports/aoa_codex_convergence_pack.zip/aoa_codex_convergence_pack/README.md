# aoa_codex_convergence_pack

This pack is the next wave after workspace MCP, repo-local MCP, skill↔MCP wiring, local plugins,
and subagent projection.

Its job is not to add another Codex surface. Its job is to make the existing surfaces converge.

It gives the AoA workspace a single **bootstrap + doctor + status** seam that can:

- anchor the sibling workspace as the project root
- inspect project-scoped Codex config
- verify MCP server presence and naming
- verify workspace-level subagent projection
- verify plugin marketplace and plugin source presence
- warn when skills are still stranded in sibling repos instead of a workspace-visible bridge
- emit one compact JSON + Markdown report for reviewed setup and drift checks

## Why this wave matters

Codex now has multiple first-class customization surfaces:

- `AGENTS.md` for repo/workspace law
- skills for reusable workflows
- plugins for installable distribution
- MCP for tools and live or derived context
- subagents for explicit role-bearing actors

AoA now has packs for each of those surfaces. The remaining pain point is operational:
even when every piece exists, drift can hide in the joins.

This pack is the join-checker.

## What is inside

- `contracts/aoa_codex_convergence_contract_v1.md`
- `workspace-overlay/src/aoa_codex_converge/convergence_state.py`
- `workspace-overlay/scripts/aoa_codex_bootstrap.py`
- `workspace-overlay/scripts/aoa_codex_doctor.py`
- `workspace-overlay/scripts/aoa_codex_status.py`
- `workspace-overlay/tests/test_aoa_codex_converge.py`
- `templates/workspace-root/.codex/config.convergence.snippet.toml`
- `templates/workspace-root/scripts/aoa-codex-doctor`
- `templates/workspace-root/scripts/aoa-codex-status`
- `templates/workspace-root/scripts/aoa-codex-bootstrap`
- `prompts/convergence_smoke_recipes.md`
- `ROLL_OUT.md`

## Core posture

This pack is still intentionally read-only by default.

The bootstrap script can create missing scaffold directories and wrapper scripts,
but it does **not** rewrite your existing `.codex/config.toml`, `.agents/plugins/marketplace.json`,
or generated subagent files unless you explicitly choose to merge those yourself.

That keeps the pack reviewable and makes drift visible before anything heavy mutates the workspace.

## What it checks

Required or near-required seams:

- workspace root marker: `AOA_WORKSPACE_ROOT`
- workspace project config: `.codex/config.toml`
- `project_root_markers` contains `AOA_WORKSPACE_ROOT`
- workspace MCP server entry: `aoa_workspace`
- subagent files under `.codex/agents/*.toml`

Recommended seams:

- repo-local MCP server config for `aoa_stats` if `aoa-stats/` exists
- repo-local MCP server config for `dionysus` if `Dionysus/` exists
- repo marketplace at `.agents/plugins/marketplace.json`
- local plugin source at `plugins/aoa-shared-launchers/.codex-plugin/plugin.json`
- a workspace-visible skill bridge, either through plugin distribution or workspace `.agents/skills`

Special warning:

If the doctor sees `aoa-skills/.agents/skills/` in a sibling repo but finds no workspace-visible
skill bridge, it raises a warning. Codex scans `.agents/skills` by walking upward from the current
working directory to the project root. That means a sibling repo’s skill folder is not automatically
discoverable from the workspace root unless you bridge it.

## Quick start

From the AoA workspace root after copying `workspace-overlay/` into place:

```bash
python scripts/aoa_codex_bootstrap.py --workspace-root .
python scripts/aoa_codex_doctor.py --workspace-root . --write-report
python scripts/aoa_codex_status.py --workspace-root . --format markdown
```

## Suggested rollout order

1. Merge this pack into the AoA workspace root.
2. Run `aoa_codex_bootstrap.py` once to create safe missing scaffolds.
3. Merge the generated status with your existing workspace `.codex/config.toml`.
4. Run the doctor until required seams are green.
5. Only then start tightening automation around the converged setup.

## What should come after this wave

Once the workspace converges cleanly, the next natural wave is **hooked or automated doctoring**:
a narrow lifecycle seam that runs the doctor or a status snapshot at chosen moments, without turning
Codex hooks into a new hidden governor.
