
from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover
    import tomli as tomllib  # type: ignore


EXPECTED_SUBAGENTS = [
    "architect",
    "coder",
    "reviewer",
    "evaluator",
    "memory-keeper",
]


@dataclass
class SurfaceStatus:
    name: str
    status: str
    required: bool
    summary: str
    evidence: list[str]
    next_step: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _read_toml(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    with path.open("rb") as fh:
        return tomllib.load(fh)


def _read_json(path: Path) -> Any:
    if not path.exists():
        return None
    with path.open("r", encoding="utf-8") as fh:
        return json.load(fh)


def _safe_exists(path: Path) -> bool:
    try:
        return path.exists()
    except OSError:
        return False


def _collect_toml_names(agents_dir: Path) -> list[str]:
    names: list[str] = []
    if not agents_dir.exists():
        return names
    for path in sorted(agents_dir.glob("*.toml")):
        try:
            data = _read_toml(path)
        except Exception:
            continue
        name = data.get("name")
        if isinstance(name, str) and name.strip():
            names.append(name.strip())
    return names


def _plugin_names(marketplace: Any) -> list[str]:
    if not isinstance(marketplace, dict):
        return []
    plugins = marketplace.get("plugins", [])
    names: list[str] = []
    if isinstance(plugins, list):
        for item in plugins:
            if isinstance(item, dict):
                name = item.get("name")
                if isinstance(name, str) and name:
                    names.append(name)
    return names


def _json_path_contains(data: Any, target: str) -> bool:
    text = json.dumps(data, ensure_ascii=False, sort_keys=True)
    return target in text


def _normalize_workspace_root(workspace_root: Path | str) -> Path:
    return Path(workspace_root).expanduser().resolve()


def build_report(workspace_root: Path | str) -> dict[str, Any]:
    root = _normalize_workspace_root(workspace_root)

    marker_path = root / "AOA_WORKSPACE_ROOT"
    codex_config_path = root / ".codex" / "config.toml"
    agents_dir = root / ".codex" / "agents"
    workspace_mcp_script = root / "scripts" / "aoa_workspace_mcp_server.py"
    workspace_doctor_script = root / "scripts" / "aoa_codex_doctor.py"
    plugin_marketplace_path = root / ".agents" / "plugins" / "marketplace.json"
    plugin_source_path = root / "plugins" / "aoa-shared-launchers" / ".codex-plugin" / "plugin.json"
    workspace_skill_dir = root / ".agents" / "skills"
    sibling_aoa_skills_dir = root / "aoa-skills" / ".agents" / "skills"
    stats_repo = root / "aoa-stats"
    stats_mcp_script = stats_repo / "scripts" / "aoa_stats_mcp_server.py"
    stats_catalog = stats_repo / "generated" / "summary_surface_catalog.min.json"
    dionysus_repo = root / "Dionysus"
    dionysus_mcp_script = dionysus_repo / "scripts" / "dionysus_mcp_server.py"
    dionysus_catalog = dionysus_repo / "generated" / "seed_route_map.min.json"

    config = _read_toml(codex_config_path)
    marketplace = _read_json(plugin_marketplace_path)
    plugin_manifest = _read_json(plugin_source_path)
    subagent_names = _collect_toml_names(agents_dir)
    mcp_servers = config.get("mcp_servers", {}) if isinstance(config, dict) else {}
    agents_cfg = config.get("agents", {}) if isinstance(config, dict) else {}
    project_root_markers = config.get("project_root_markers", []) if isinstance(config, dict) else []

    surfaces: list[SurfaceStatus] = []

    marker_exists = marker_path.exists()
    surfaces.append(
        SurfaceStatus(
            name="workspace_root_anchor",
            status="ok" if marker_exists else "missing",
            required=True,
            summary="Workspace root marker is present." if marker_exists else "Missing AOA_WORKSPACE_ROOT marker.",
            evidence=[str(marker_path)] if marker_exists else [],
            next_step="Create AOA_WORKSPACE_ROOT at the intended sibling workspace root.",
        )
    )

    config_exists = codex_config_path.exists()
    surfaces.append(
        SurfaceStatus(
            name="codex_project_config",
            status="ok" if config_exists else "missing",
            required=True,
            summary="Workspace .codex/config.toml exists." if config_exists else "Missing workspace .codex/config.toml.",
            evidence=[str(codex_config_path)] if config_exists else [],
            next_step="Create or merge a trusted project-scoped .codex/config.toml at the workspace root.",
        )
    )

    marker_listed = isinstance(project_root_markers, list) and "AOA_WORKSPACE_ROOT" in project_root_markers
    surfaces.append(
        SurfaceStatus(
            name="project_root_marker_config",
            status="ok" if marker_listed else ("warn" if config_exists else "missing"),
            required=True,
            summary="project_root_markers includes AOA_WORKSPACE_ROOT."
            if marker_listed
            else "project_root_markers does not include AOA_WORKSPACE_ROOT.",
            evidence=[f"project_root_markers={project_root_markers!r}"] if config_exists else [],
            next_step="Add AOA_WORKSPACE_ROOT to project_root_markers so sibling repos do not steal project-root discovery.",
        )
    )

    workspace_mcp_ok = (
        isinstance(mcp_servers, dict)
        and "aoa_workspace" in mcp_servers
        and workspace_mcp_script.exists()
    )
    workspace_mcp_evidence = []
    if isinstance(mcp_servers, dict) and "aoa_workspace" in mcp_servers:
        workspace_mcp_evidence.append("[mcp_servers.aoa_workspace] in .codex/config.toml")
    if workspace_mcp_script.exists():
        workspace_mcp_evidence.append(str(workspace_mcp_script))
    if workspace_doctor_script.exists():
        workspace_mcp_evidence.append(str(workspace_doctor_script))
    surfaces.append(
        SurfaceStatus(
            name="workspace_mcp",
            status="ok" if workspace_mcp_ok else "missing",
            required=True,
            summary="Workspace MCP is configured and the launcher script exists."
            if workspace_mcp_ok
            else "Workspace MCP is not fully converged.",
            evidence=workspace_mcp_evidence,
            next_step="Ensure [mcp_servers.aoa_workspace] exists and scripts/aoa_workspace_mcp_server.py is present.",
        )
    )

    stats_repo_exists = stats_repo.exists()
    stats_mcp_configured = isinstance(mcp_servers, dict) and "aoa_stats" in mcp_servers
    stats_mcp_ok = (not stats_repo_exists) or (stats_mcp_configured and stats_mcp_script.exists() and stats_catalog.exists())
    stats_evidence = []
    if stats_repo_exists:
        stats_evidence.append(str(stats_repo))
    if stats_mcp_configured:
        stats_evidence.append("[mcp_servers.aoa_stats] in .codex/config.toml")
    if stats_mcp_script.exists():
        stats_evidence.append(str(stats_mcp_script))
    if stats_catalog.exists():
        stats_evidence.append(str(stats_catalog))
    stats_status = "info" if not stats_repo_exists else ("ok" if stats_mcp_ok else "warn")
    stats_summary = (
        "aoa-stats repo not present under the workspace root."
        if not stats_repo_exists
        else ("aoa-stats MCP surface looks wired." if stats_mcp_ok else "aoa-stats repo exists but its MCP seam is incomplete.")
    )
    surfaces.append(
        SurfaceStatus(
            name="stats_mcp",
            status=stats_status,
            required=False,
            summary=stats_summary,
            evidence=stats_evidence,
            next_step="Wire aoa_stats into workspace .codex/config.toml and ensure the repo-local server plus generated catalog exist.",
        )
    )

    dionysus_repo_exists = dionysus_repo.exists()
    dionysus_mcp_configured = isinstance(mcp_servers, dict) and "dionysus" in mcp_servers
    dionysus_mcp_ok = (not dionysus_repo_exists) or (
        dionysus_mcp_configured and dionysus_mcp_script.exists() and dionysus_catalog.exists()
    )
    dionysus_evidence = []
    if dionysus_repo_exists:
        dionysus_evidence.append(str(dionysus_repo))
    if dionysus_mcp_configured:
        dionysus_evidence.append("[mcp_servers.dionysus] in .codex/config.toml")
    if dionysus_mcp_script.exists():
        dionysus_evidence.append(str(dionysus_mcp_script))
    if dionysus_catalog.exists():
        dionysus_evidence.append(str(dionysus_catalog))
    dionysus_status = "info" if not dionysus_repo_exists else ("ok" if dionysus_mcp_ok else "warn")
    dionysus_summary = (
        "Dionysus repo not present under the workspace root."
        if not dionysus_repo_exists
        else ("Dionysus MCP surface looks wired." if dionysus_mcp_ok else "Dionysus repo exists but its MCP seam is incomplete.")
    )
    surfaces.append(
        SurfaceStatus(
            name="dionysus_mcp",
            status=dionysus_status,
            required=False,
            summary=dionysus_summary,
            evidence=dionysus_evidence,
            next_step="Wire dionysus into workspace .codex/config.toml and ensure the repo-local server plus generated seed route map exist.",
        )
    )

    found_required_subagents = [name for name in EXPECTED_SUBAGENTS if name in subagent_names]
    missing_subagents = [name for name in EXPECTED_SUBAGENTS if name not in subagent_names]
    subagents_ok = len(missing_subagents) == 0 and agents_dir.exists()
    subagent_evidence = [str(agents_dir)] if agents_dir.exists() else []
    subagent_evidence.extend(f"name={name}" for name in subagent_names)
    surfaces.append(
        SurfaceStatus(
            name="subagents_surface",
            status="ok" if subagents_ok else "warn",
            required=True,
            summary="Expected AoA subagents are present." if subagents_ok else "Some expected AoA subagents are missing.",
            evidence=subagent_evidence,
            next_step="Generate or copy the AoA subagent TOML files into .codex/agents/ and register them in workspace config if needed.",
        )
    )

    plugin_names = _plugin_names(marketplace)
    plugin_marketplace_ok = plugin_marketplace_path.exists() and "aoa-shared-launchers" in plugin_names
    plugin_marketplace_evidence = [str(plugin_marketplace_path)] if plugin_marketplace_path.exists() else []
    plugin_marketplace_evidence.extend(f"plugin={name}" for name in plugin_names)
    surfaces.append(
        SurfaceStatus(
            name="plugin_marketplace",
            status="ok" if plugin_marketplace_ok else "warn",
            required=False,
            summary="Repo marketplace exposes aoa-shared-launchers."
            if plugin_marketplace_ok
            else "Repo marketplace is missing or does not expose aoa-shared-launchers.",
            evidence=plugin_marketplace_evidence,
            next_step="Create .agents/plugins/marketplace.json or add aoa-shared-launchers to the repo or personal marketplace.",
        )
    )

    plugin_manifest_ok = bool(plugin_manifest) and plugin_source_path.exists()
    plugin_manifest_name = plugin_manifest.get("name") if isinstance(plugin_manifest, dict) else None
    plugin_source_evidence = [str(plugin_source_path)] if plugin_source_path.exists() else []
    if plugin_manifest_name:
        plugin_source_evidence.append(f"plugin.name={plugin_manifest_name}")
    surfaces.append(
        SurfaceStatus(
            name="plugin_source",
            status="ok" if plugin_manifest_ok else "warn",
            required=False,
            summary="Local shared plugin source exists." if plugin_manifest_ok else "Local shared plugin source is missing.",
            evidence=plugin_source_evidence,
            next_step="Place the aoa-shared-launchers plugin under plugins/ or point a marketplace entry at its true location.",
        )
    )

    workspace_skill_exists = workspace_skill_dir.exists() and any(workspace_skill_dir.glob("*"))
    sibling_skill_exists = sibling_aoa_skills_dir.exists() and any(sibling_aoa_skills_dir.glob("*"))
    skill_bridge_ok = workspace_skill_exists or plugin_marketplace_ok or plugin_manifest_ok
    skill_evidence = []
    if workspace_skill_exists:
        skill_evidence.append(str(workspace_skill_dir))
    if sibling_skill_exists:
        skill_evidence.append(str(sibling_aoa_skills_dir))
    if plugin_marketplace_ok:
        skill_evidence.append("workspace-visible skills may arrive through the aoa-shared-launchers plugin")
    if plugin_manifest_ok:
        skill_evidence.append("local plugin source is available for installation")
    if skill_bridge_ok:
        skill_summary = "Workspace-visible skill bridge is present."
        skill_status = "ok"
    elif sibling_skill_exists:
        skill_summary = "Skills appear stranded in a sibling repo without a workspace-visible bridge."
        skill_status = "warn"
    else:
        skill_summary = "No obvious workspace-visible skill bridge was found."
        skill_status = "warn"
    surfaces.append(
        SurfaceStatus(
            name="skill_bridge",
            status=skill_status,
            required=False,
            summary=skill_summary,
            evidence=skill_evidence,
            next_step="Expose shared skills through a plugin or a workspace-visible .agents/skills bridge instead of relying on sibling-repo discovery.",
        )
    )

    counts = {"ok": 0, "warn": 0, "missing": 0, "info": 0}
    for surface in surfaces:
        counts[surface.status] = counts.get(surface.status, 0) + 1

    ready = not any(surface.required and surface.status != "ok" for surface in surfaces)
    report = {
        "workspace_root": str(root),
        "ready": ready,
        "counts": counts,
        "surfaces": [surface.to_dict() for surface in surfaces],
    }
    return report


def report_to_markdown(report: dict[str, Any]) -> str:
    lines = [
        "# AoA Codex convergence report",
        "",
        f"- workspace_root: `{report.get('workspace_root', '')}`",
        f"- ready: `{report.get('ready', False)}`",
    ]
    counts = report.get("counts", {})
    lines.append(
        f"- counts: ok={counts.get('ok', 0)}, warn={counts.get('warn', 0)}, "
        f"missing={counts.get('missing', 0)}, info={counts.get('info', 0)}"
    )
    lines.append("")
    lines.append("## Surfaces")
    lines.append("")
    for surface in report.get("surfaces", []):
        name = surface.get("name", "")
        status = surface.get("status", "")
        required = surface.get("required", False)
        summary = surface.get("summary", "")
        evidence = surface.get("evidence", [])
        next_step = surface.get("next_step", "")
        lines.append(f"### {name}")
        lines.append("")
        lines.append(f"- status: `{status}`")
        lines.append(f"- required: `{required}`")
        lines.append(f"- summary: {summary}")
        if evidence:
            lines.append("- evidence:")
            for item in evidence:
                lines.append(f"  - `{item}`")
        else:
            lines.append("- evidence: none")
        lines.append(f"- next_step: {next_step}")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


BOOTSTRAP_CONFIG_SNIPPET = """# Merge this into workspace .codex/config.toml after review.
project_root_markers = ["AOA_WORKSPACE_ROOT", ".git", ".hg", ".sl"]

[agents]
max_threads = 6
max_depth = 1
"""

BOOTSTRAP_WRAPPER_DOCTOR = """#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORKSPACE_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

python "${SCRIPT_DIR}/aoa_codex_doctor.py" --workspace-root "${WORKSPACE_ROOT}" "$@"
"""

BOOTSTRAP_WRAPPER_STATUS = """#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORKSPACE_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

python "${SCRIPT_DIR}/aoa_codex_status.py" --workspace-root "${WORKSPACE_ROOT}" "$@"
"""

BOOTSTRAP_WRAPPER_BOOTSTRAP = """#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORKSPACE_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

python "${SCRIPT_DIR}/aoa_codex_bootstrap.py" --workspace-root "${WORKSPACE_ROOT}" "$@"
"""


def write_bootstrap_scaffold(workspace_root: Path | str) -> dict[str, str]:
    root = _normalize_workspace_root(workspace_root)
    created: dict[str, str] = {}

    directories = [
        root / ".codex",
        root / ".codex" / "agents",
        root / ".agents",
        root / ".agents" / "plugins",
        root / ".agents" / "skills",
        root / "generated",
        root / "generated" / "codex",
        root / "scripts",
    ]
    for path in directories:
        path.mkdir(parents=True, exist_ok=True)
        created[str(path)] = "dir"

    marker = root / "AOA_WORKSPACE_ROOT"
    if not marker.exists():
        marker.write_text("AoA sibling workspace root marker.\n", encoding="utf-8")
        created[str(marker)] = "file"

    config_snippet = root / "generated" / "codex" / "config.convergence.generated.toml"
    config_snippet.write_text(BOOTSTRAP_CONFIG_SNIPPET, encoding="utf-8")
    created[str(config_snippet)] = "file"

    wrapper_specs = {
        root / "scripts" / "aoa-codex-doctor": BOOTSTRAP_WRAPPER_DOCTOR,
        root / "scripts" / "aoa-codex-status": BOOTSTRAP_WRAPPER_STATUS,
        root / "scripts" / "aoa-codex-bootstrap": BOOTSTRAP_WRAPPER_BOOTSTRAP,
    }
    for path, text in wrapper_specs.items():
        path.write_text(text, encoding="utf-8")
        os.chmod(path, 0o755)
        created[str(path)] = "file"

    return created
