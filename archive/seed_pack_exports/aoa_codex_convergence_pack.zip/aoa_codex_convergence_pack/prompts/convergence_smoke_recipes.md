# Convergence smoke recipes

Use these only after the workspace root, `.codex/config.toml`, and wrapper scripts are in place.

## 1. First doctor pass

Run from the AoA workspace root:

```bash
scripts/aoa-codex-doctor --write-report
```

Then open:

- `generated/codex/aoa_codex_convergence_report.md`
- `generated/codex/aoa_codex_convergence_report.json`

## 2. First Codex orientation prompt

In Codex from the workspace root:

- “Use the workspace MCP first. Map the AoA surfaces available here, name any missing seams, then stop.”
- “Check whether subagents, plugin distribution, and repo-local MCP seams look converged before doing any code work.”

## 3. Stats seam smoke test

- “Use the aoa_stats MCP surface to read the current summary catalog and tell me whether the derived observability seam is alive.”

## 4. Seed seam smoke test

- “Use the dionysus MCP surface to inspect the current route map and tell me which live seed route is next.”

## 5. Role orchestration smoke test

- “Spawn architect and reviewer. Have architect map the smallest bounded convergence repair. Have reviewer inspect whether the repair changes authority boundaries. Wait, then summarize.”

## 6. Skill bridge smoke test

- “List the shared AoA launcher skills visible in this workspace. If none are visible, diagnose whether the failure is plugin installation, marketplace visibility, or skill-bridge absence.”

## 7. Final human review question

- “Given the current AoA Codex convergence report, what is the smallest next manual merge that raises readiness without widening authority?”
