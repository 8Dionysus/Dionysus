# AoA Codex convergence contract v1

## Purpose

Create one small, reviewable convergence seam across the Codex surfaces already introduced into AoA.

This seam must not invent new semantic authority.
It exists to inspect, summarize, and bootstrap the joins between:

- workspace root anchoring
- project-scoped Codex config
- workspace MCP
- repo-local MCP surfaces
- local plugin distribution
- workspace-visible skill routing
- subagent projection

## Inputs

- AoA workspace root path
- optional expectation overrides:
  - required MCP server names
  - expected subagent names
  - expected plugin name
  - expected sibling repos

## Outputs

- JSON status report
- Markdown status report
- non-destructive scaffold creation for wrapper scripts and directories
- process exit code suitable for manual doctor runs or CI-style setup checks

## Boundaries

This pack may:

- read config, manifest, and generated state surfaces
- create missing directories that are obviously safe
- create wrapper scripts that call existing doctor and status scripts
- generate reports and next-step notes

This pack must not, by default:

- rewrite the user’s existing `.codex/config.toml`
- mutate installed plugins in `~/.codex`
- invent or regenerate subagent meaning outside `aoa-agents`
- rewrite owner-repo MCP servers
- treat `aoa-stats` or `Dionysus` as owners of source meaning

## Required workspace truths

A converged AoA workspace should satisfy these minimum expectations:

1. `AOA_WORKSPACE_ROOT` exists at the intended workspace root.
2. `.codex/config.toml` exists and is loaded from the trusted workspace root.
3. `project_root_markers` contains `AOA_WORKSPACE_ROOT`.
4. `[mcp_servers.aoa_workspace]` exists.
5. `.codex/agents/*.toml` contains the expected AoA role-bearing subagents.

## Recommended truths

6. If `aoa-stats/` exists, `aoa_stats` should appear in the workspace MCP config.
7. If `Dionysus/` exists, `dionysus` should appear in the workspace MCP config.
8. A repo marketplace should exist at `.agents/plugins/marketplace.json`.
9. The local shared plugin source should exist at `plugins/aoa-shared-launchers/.codex-plugin/plugin.json`.
10. A workspace-visible skill bridge should exist, either through plugin distribution or workspace `.agents/skills`.

## Status vocabulary

- `ok`: the seam is present and looks coherent
- `warn`: the seam is missing a recommended piece or may drift
- `missing`: a required seam is absent
- `info`: present but purely informational

## Report discipline

Every report item should include:

- `name`
- `status`
- `required`
- `summary`
- `evidence`
- `next_step`

## Exit behavior

- exit code `0` when all required seams are `ok`
- exit code `1` when any required seam is `missing`
- exit code `2` for script or argument errors
