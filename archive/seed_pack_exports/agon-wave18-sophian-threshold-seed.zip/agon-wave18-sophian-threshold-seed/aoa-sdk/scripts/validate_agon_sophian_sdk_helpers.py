#!/usr/bin/env python3
from __future__ import annotations
import json, pathlib, sys, hashlib
ROOT = pathlib.Path(__file__).resolve().parents[1]
SRC = ROOT / 'config/agon_sophian_sdk_helpers.seed.json'
OUT = ROOT / 'generated/agon_sophian_sdk_helpers.min.json'
ITEM_KEY = 'sophian_sdk_helper_candidates'
EXPECTED_COUNT = 7
ID_FIELD = 'helper_id'
REQUIRED_FORBIDDEN = ['live_verdict_authority', 'durable_scar_write', 'retention_execution', 'rank_mutation', 'trust_mutation', 'tree_of_sophia_canon_write', 'direct_tos_write', 'automatic_canonization', 'kag_as_canon', 'hidden_scheduler_action', 'assistant_contestant_drift', 'auto_doctrine_rewrite', 'center_takeover_of_owner_truth', 'eval_memo_stats_sovereignty', 'stats_as_canon_authority', 'eval_as_canon_authority', 'memo_as_canon_authority', 'sdk_hidden_write']
ALLOWED_RUNTIME = ('none', 'candidate_only', 'local_dry_run_candidate_only', 'local_rehearsal_candidate_only')

def fail(msg):
    print(msg, file=sys.stderr)
    return 1

def digest_obj(obj):
    return hashlib.sha256(json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()

def key_of(item):
    return item.get(ID_FIELD) or item.get('id')

def validate_item(item):
    key = key_of(item)
    if not key:
        return 'missing item key'
    if item.get('wave') not in (None, 'XVIII'):
        return f'unexpected wave for {key}: {item.get("wave")}'
    if item.get('live_protocol') is not False:
        return f'live_protocol must be false for {key}'
    if item.get('runtime_effect') not in ALLOWED_RUNTIME:
        return f'invalid runtime_effect for {key}: {item.get("runtime_effect")}'
    if item.get('review_status') != 'candidate_only':
        return f'review_status must be candidate_only for {key}'
    if item.get('requires_review') is not True:
        return f'requires_review must be true for {key}'
    if item.get('assistant_contestant_allowed') is True:
        return f'assistant_contestant_allowed must not be true for {key}'
    for flag in ('tos_canonization_allowed', 'direct_tos_write_allowed', 'canon_write_allowed'):
        if item.get(flag) is True:
            return f'{flag} must not be true for {key}'
    forbidden = set(item.get('forbidden_effects', []))
    for required in REQUIRED_FORBIDDEN:
        if required not in forbidden:
            return f'missing forbidden effect {required} for {key}'
    if not item.get('required_evidence'):
        return f'missing required_evidence for {key}'
    return None

def main():
    if not SRC.exists():
        return fail(f'missing seed config: {SRC}')
    if not OUT.exists():
        return fail(f'missing generated registry: {OUT}')
    seed = json.loads(SRC.read_text(encoding='utf-8'))
    reg = json.loads(OUT.read_text(encoding='utf-8'))
    items = seed.get(ITEM_KEY, [])
    if seed.get('wave') != 'XVIII':
        return fail('seed wave mismatch')
    if len(items) != EXPECTED_COUNT:
        return fail(f'expected {EXPECTED_COUNT} seed items, got {len(items)}')
    if reg.get('count') != EXPECTED_COUNT:
        return fail(f'expected generated count {EXPECTED_COUNT}, got {reg.get("count")}')
    if reg.get('digest') != digest_obj(items):
        return fail('generated digest mismatch')
    seen = set()
    for item in items:
        key = key_of(item)
        if key in seen:
            return fail(f'duplicate item key: {key}')
        seen.add(key)
        err = validate_item(item)
        if err:
            return fail(err)
    print(f'validated {EXPECTED_COUNT} XVIII {ITEM_KEY} items')
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
