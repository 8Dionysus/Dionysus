# SEED MANIFEST — Agon Wave XVIII: Sophian Threshold

This seed plants Wave XVIII across seven repositories.

It creates the first reviewable threshold from Agon/KAG-survived forms toward `Tree-of-Sophia` without declaring canon, creating ToS nodes, writing branches, rewriting doctrine, or allowing automatic promotion.

Landing order:

1. `Agents-of-Abyss`
2. `Tree-of-Sophia`
3. `aoa-kag`
4. `aoa-memo`
5. `aoa-evals`
6. `aoa-stats`
7. `aoa-sdk`

Core invariants:

`Sophian threshold candidate != ToS canon`
`ToS review packet != authored node`
`KAG threshold packet != ToS acceptance`
`branch candidate != ToS branch`
`canon entry draft candidate != canon entry`
`stats pressure != canon authority`
`eval alignment != canon decision`
`memo evidence != canon memory`
`SDK helper != hidden write path`

This is not a live arena protocol. It is not a runtime promotion path. It is a guarded threshold surface.
