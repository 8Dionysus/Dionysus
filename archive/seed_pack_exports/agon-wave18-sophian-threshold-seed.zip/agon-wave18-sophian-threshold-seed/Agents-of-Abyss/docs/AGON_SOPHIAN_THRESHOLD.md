# Agon Sophian Threshold

Defines the center-owned Sophian threshold grammar. It routes Agon/KAG-survived forms toward Tree-of-Sophia review without canonizing them.

## Wave XVIII invariant

`Sophian threshold candidate != Tree-of-Sophia canon`.

This surface is candidate-only. It does not create live arena sessions, durable scars, rank mutation, KAG promotion, Tree-of-Sophia canon entries, hidden scheduler actions, or assistant contestant drift.

## Required restraint

Threshold material may move toward review only through owner-routed evidence, explicit boundary checks, and reviewable packets. It may be rejected, deferred with cost, returned to KAG, quarantined, or prepared for authorial review. None of those states is canon.
