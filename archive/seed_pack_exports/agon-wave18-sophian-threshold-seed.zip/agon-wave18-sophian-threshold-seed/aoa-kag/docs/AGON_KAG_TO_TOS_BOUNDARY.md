# Agon Kag To Tos Boundary

KAG can lift evidence; it cannot author ToS truth or create ToS branches.

## Wave XVIII invariant

`Sophian threshold candidate != Tree-of-Sophia canon`.

This surface is candidate-only. It does not create live arena sessions, durable scars, rank mutation, KAG promotion, Tree-of-Sophia canon entries, hidden scheduler actions, or assistant contestant drift.

## Required restraint

Threshold material may move toward review only through owner-routed evidence, explicit boundary checks, and reviewable packets. It may be rejected, deferred with cost, returned to KAG, quarantined, or prepared for authorial review. None of those states is canon.
