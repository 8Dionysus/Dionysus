# Landing Brief: Seventh Recurrence Seed

## Purpose

Prepare a future pair of recurrence subagents without making them live:

- `recursor.witness`: observe, record, expose drift, prepare trace and handoff.
- `recursor.executor`: execute only an approved bounded slice and emit receipts.

## Non-goals

Do not add a live agent spawn command.  
Do not install `.codex/agents/aoa-recursor-*.toml`.  
Do not mutate `config/codex_subagent_wiring.v2.json`.  
Do not open an Agon arena.  
Do not give assistants contestant authority.  
Do not let witness become a scar owner.  
Do not let executor self-certify final truth.

## First landing path

1. Land the `aoa-agents` files.
2. Build and validate generated readiness surfaces.
3. Land the `aoa-sdk` read-only scan helpers.
4. Land the `aoa-evals` extension fixtures.
5. Run all seed tests.
6. Keep projection candidates disabled by default.

## Expected outputs

```text
aoa-agents/generated/recursor_role_readiness.min.json
aoa-agents/generated/recursor_pair_contract.min.json
aoa-agents/generated/recursor_projection_candidates.min.json
aoa-agents/generated/recursor_agon_boundary_report.min.json
```

## Forbidden command surface

The seed must not introduce any of the following commands:

```text
aoa recur agents spawn
aoa recur agents run
aoa recur agents summon
aoa recur agents open-arena
```
