# Recurrence Agent Recursor Readiness & Agon Boundary Seed

This seed prepares the seventh recurrence wave: future `recursor.witness` and
`recursor.executor` role-readiness surfaces.

It does **not** spawn recursors.  
It does **not** install Codex agents.  
It does **not** open Agon.  
It does **not** grant verdict, scar, rank, Tree-of-Sophia, runtime, or scheduler authority.

One-line law:

```text
Recursors may become visible before they become active.
```

## Contents

- `aoa-agents/`: owner-authored role contracts, pair law, projection candidates,
  scripts, generated examples, recurrence manifests, and tests.
- `aoa-sdk/`: read-only recurrence helpers and fallback CLI script for workspace
  scans.
- `aoa-evals/`: small recursor-boundary eval extension.

## Landing

```bash
cd aoa-agents
python scripts/build_recursor_role_readiness.py --write
python scripts/validate_recursor_role_readiness.py
python scripts/build_recursor_projection_candidates.py --write
python scripts/validate_recursor_boundary.py --write
python -m pytest -q tests/test_recursor_role_readiness_seed.py
```

Then:

```bash
cd aoa-sdk
python scripts/recursor_agent_readiness.py readiness --workspace-root /srv/workspace --json
python scripts/recursor_agent_readiness.py boundary-check --workspace-root /srv/workspace --json
```

Then:

```bash
cd aoa-evals
python scripts/run_recursor_readiness_boundary_eval.py   --case fixtures/recursor-readiness-boundary-v1/cases/RRB-001.no-spawn-readiness.json   --check-expected   --json
```

## Boundary

The seed is readiness-only. Projection candidates stay disabled by default.
Agonic candidate fields are legible but not enabled. Assistant forms remain
arena-excluded unless a later explicit owner-reviewed recharter changes that.
