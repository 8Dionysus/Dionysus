# aoa-agents Wave I seed

This seed is for **Act I / Wave I / agent formation** at the turning point where `aoa-agents` must become deeper without becoming wider.

The seed is intentionally **additive**.

## Keep unchanged

Do not treat this seed as permission to rewrite the current core profile surface.

Keep these intact unless a stronger migration is explicitly chosen later:

- `profiles/*.profile.json`
- `schemas/agent-profile.schema.json`
- `generated/agent_registry.min.json`
- the current five seed roles
- the current runtime seam minimal landing
- the current checkpoint-stack discipline
- the current stress-posture and progression adjunct families

## Land now

This seed adds four companion families, each attached to `agent_id` rather than embedded into the core profile shape:

- `agent_kind_v1`
- `agent_subjectivity_v1`
- `agent_office_overlay_v1`
- `agent_arena_authority_v1`

It also adds:

- source adjunct files for the current five seed roles
- one compact generated adjunct index
- one standalone validator
- one standalone builder
- one test file
- three quest stubs for the landing

## Intent

The goal is not to widen the catalog.

The goal is to make the current roles deep enough that a later Agon layer can read them without inventing their ontology on the fly.

This means:

- reserve the split between agonic and assistant kinds now
- land beliefs, self-image, affects, and thought posture now
- map existing roles into battle-facing offices without replacing them
- land explicit arena-facing readiness and bounded move rights
- keep closer and summoner absent for this wave

## First cast

This seed maps the current five public seed roles like this:

- `architect` -> `boundary_keeper` with tracer-adjacent posture
- `reviewer` -> `verifier` with skeptic-adjacent posture
- `evaluator` -> `arbiter` with bifurcator-adjacent posture
- `memory-keeper` -> `chronicler` with witness posture
- `coder` -> `executor`

These are office overlays, not new base roles.

## Wave-I invariants

This seed preserves the following invariants:

- no changes to the published core profile wire shape
- no hidden playbook canon inside `aoa-agents`
- no session protocol packets yet
- no contradiction ledger yet
- no scar writeback law yet
- no routing gate law yet
- no closer
- no summon initiator
- no direct canon promotion

## Suggested apply order

1. Land the docs and schemas.
2. Land the source adjunct files under `profiles/adjuncts/`.
3. Land the builder, validator, and tests.
4. Generate or refresh `generated/agent_wave1_adjunct_index.min.json`.
5. Decide whether to wire these helpers into broader release checks.
6. Do not widen runtime or protocol law in this wave.

## Codex note

If the live repo already contains semantically equivalent surfaces, merge by meaning rather than duplicating by filename.

If the live repo has a stronger local convention than `profiles/adjuncts/`, relocate the source adjuncts but preserve:

- the schema families
- the separation from the core profile surface
- the keep/do-not-widen rules of this seed
