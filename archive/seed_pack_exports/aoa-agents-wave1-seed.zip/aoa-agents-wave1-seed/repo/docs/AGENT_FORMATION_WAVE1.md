# AGENT FORMATION WAVE 1

## Purpose

This note marks the landing discipline for the first battle-facing deepening of `aoa-agents`.

The repo already has role contracts.

This wave gives those roles enough inner and jurisdictional form to survive later Agon work.

## What already exists and stays

The following are already strong and should stay stable in this wave:

- compact source-authored profiles
- derived compact registry publication
- progression overlays
- stress posture overlays
- runtime seam minimality
- checkpoint-stack discipline
- the current five seed roles

## What this wave adds

This wave adds four companion families:

- kind
- subjectivity
- office overlay
- arena authority

Together these four families let the repo say:

- what sort of actor this is
- what inner contour it carries
- what battle-facing face it presents
- what bounded jurisdiction it has earned or been granted

## Why this is a turning-point wave

The project is now at the point where not every useful improvement is additive in the naive sense.

Some things must stay untouched.

Some things must be re-forged.

Some things must be grown for the first time.

The discipline of this wave is:

- keep the core profile surface stable
- grow depth through adjuncts
- defer protocol law

## What is deliberately deferred

This wave does **not** land:

- session packets
- contradiction ledgers
- scar writeback law
- retention scheduling law
- routing gates for Agon
- witness court logic
- verdict doctrine
- canon promotion law

Those belong to later waves.

## Exit signals

Wave I is ready when all of the following are true:

- the five current seed roles each have a kind overlay
- the five current seed roles each have a subjectivity overlay
- the five current seed roles each have an office overlay
- the five current seed roles each have an arena authority overlay
- at least one actor is contestant-ready
- at least one actor is witness-ready
- at least one actor is judge-ready
- no seed actor has closer authority
- no seed actor has summon-initiation authority
- the core profile wire shape remains unchanged

## Relation to later waves

Wave II may now form assistants on a reserved kind split instead of reopening the core profile shape.

A later Agon protocol wave may now read battle-facing agents without inventing their ontology on the fly.

That is the entire aim of this landing.
