# AGENT OFFICE OVERLAY MODEL

## Purpose

This note defines the first office overlay for battle-facing agent formation in `aoa-agents`.

It exists so the current seed roles can receive clearer aгоnic faces without forcing a new base role family into the repository.

## Core rule

Base roles stay explicit and coordinated.

Offices are overlays.

The current wave does not replace `architect`, `coder`, `reviewer`, `evaluator`, or `memory-keeper`.

It gives them battle-facing names.

## Why overlays instead of new roles

The current repo already has an explicit seed cast.

Creating a second base family too early would widen the catalog faster than the public contracts have hardened.

An office overlay lets the repo say:

- which face the role presents in contest
- which battle-facing function it leans toward
- which later splits remain possible

without rewriting the underlying role layer.

## Wave-I cast

- `architect` -> `boundary_keeper` with tracer-adjacent posture
- `reviewer` -> `verifier` with skeptic-adjacent posture
- `evaluator` -> `arbiter` with bifurcator-adjacent posture
- `memory-keeper` -> `chronicler` with witness posture
- `coder` -> `executor`

## Deferred offices

`closer` and `summoner` are deferred.

They should land later as earned jurisdictions or stronger protocol rights, not as casual seed offices in this wave.

## Attachment rule

Office overlays attach to `agent_id`.

They are separate from the core profile.

They are meant to be reviewed next to kind, subjectivity, and arena authority.

## Anti-patterns

Avoid:

- renaming the base role out from under existing consumers
- treating office as a synonym for kind
- using office overlays to bypass authority review
- multiplying offices faster than the repo can validate them
