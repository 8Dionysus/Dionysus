# AGENT KIND MODEL

## Purpose

This note defines the first explicit kind split for agents in `aoa-agents`.

It exists to reserve a civilizational distinction before the repo hardens too far around only one kind of actor.

## Core rule

Kind is not role.

Kind is not office.

Kind answers a different question:

- how the agent is allowed to change
- where its development pressure comes from
- what history shape it accumulates

## First two kinds

### `agonic`

An agonic agent is shaped for contest, internal revision, and earned jurisdiction.

Its primary change pressure is endogenous.

It may revise itself under review.

Its history tends toward scars, ruptures, and retained deltas.

### `assistant`

An assistant agent is shaped for service contract, stability, and transparent execution.

Its primary change pressure is exogenous.

It should evolve through operator review, release, and certification.

Its history tends toward versions, incident logs, and revision logs.

## Governance law

An assistant must not silently drift into an agonic actor.

A conversion between kinds should be treated as a reissue, not as a quiet prompt drift.

## Attachment rule

Kind attaches to `agent_id`.

It does not live inside the core source profile.

The source profile remains the compact role contract.

Kind is a companion surface.

## Wave-I landing

In this wave the current five seed roles are marked `agonic` to prepare the first battle-facing cast.

This does not erase the future assistant path.

It only reserves the split early enough that Wave II can land without reopening the core profile wire shape.

## Anti-patterns

Avoid:

- hiding kind inside prose-only summaries
- treating kind as a synonym for office
- converting kind through accumulated drift
- using kind to smuggle protocol law into the core profile
