# AGENT SUBJECTIVITY MODEL

## Purpose

This note defines the first bounded subjectivity overlay for agents in `aoa-agents`.

It exists so that a role can become deeper without turning the role layer into unbounded psychology or theatrical prose.

## Core rule

Subjectivity is operational.

It is not decorative.

A subjectivity overlay should tell neighboring layers what this actor tends to defend, what wounds it, what pressures it feels, and how it revises.

## Four kernels

### Beliefs

Beliefs are bounded theses the agent treats as meaningful enough to defend, revise, or pay for.

In this layer they remain compact and reviewable.

They are not free-form doctrine archives.

### Self-image

Self-image defines the public claim the agent makes about itself, plus the honor and shame conditions that let it lose face or preserve it.

Without honor and shame conditions, the image is only branding.

### Affects

Affects are operational regulators.

They are not sentimental decoration.

Affect levels are meant to tune thresholds such as closure reluctance, contradiction pressure, witness-seeking, and claim restraint.

### Thought posture

Thought posture defines the compact shape of reasoning the role tends to use:

- concept posture
- preferred moves
- whether model-of-other is required
- whether prediction is required
- whether explicit delta is required
- what revision discipline applies

## Boundaries

This overlay does not replace:

- skills
- playbooks
- eval doctrine
- memo canon
- routing policy

It only makes the agent legible enough that those layers do not need to guess what sort of form they are dealing with.

## Relation to existing adjuncts

`agent_progression` remains the evidence-backed mastery overlay.

`agent_stress_posture` remains the stress and degradation overlay.

`agent_subjectivity_v1` sits beside them and defines the live inner contour of the role.

## Wave-I landing

The current seed lands subjectivity for the five public seed roles.

The goal is not maximal introspection.

The goal is enough interior form that later Agon protocol work can read a real actor instead of only a role card.

## Anti-patterns

Avoid:

- vague personality prose with no behavioral consequence
- belief lists with no revision conditions
- affect language that does not influence thresholds
- using subjectivity files as hidden playbooks
