# AGENT ARENA AUTHORITY MODEL

## Purpose

This note defines the first bounded arena-facing authority overlay for agents in `aoa-agents`.

It exists so that future Agon protocol work can know what an agent is allowed to do in battle-facing situations without forcing the full protocol into this repository.

## Core rule

Arena authority is not the same thing as progression.

Progression says what mastery has been earned.

Arena authority says what battle-facing rights are presently granted, withheld, or deferred.

## What this overlay may name

A compact authority overlay may name:

- arena roles such as contestant, witness, judge, or support
- readiness state
- move rights
- closure rights
- summon posture
- bounded constraints

## What this overlay must not do

It must not become:

- full protocol law
- routing law
- verdict doctrine
- memo canon
- canon promotion law

Those belong in later layers.

## Relation to progression

`agent_progression` may eventually influence arena authority.

It does not replace it.

A rank label is not enough to know whether an actor may contest, witness, judge, or deny closure.

## Wave-I limits

This wave intentionally withholds:

- closer authority
- summon initiation authority
- direct canon promotion
- protocol packet law

The repo should know who can stand on the edge of battle before it knows how the whole arena session is run.

## Readiness rule

Wave I is considered meaningful only if the repo can point to at least:

- one contestant-ready actor
- one witness-ready actor
- one judge-ready actor

without mutating the core profile surface.

## Anti-patterns

Avoid:

- burying battle rights in prose-only notes
- conflating witness posture with memory canon ownership
- using move rights to smuggle a full protocol into `aoa-agents`
- granting closure finalization too early
