from __future__ import annotations

import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def _run(*args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, *args],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )


def test_wave1_adjuncts_validate() -> None:
    result = _run("scripts/validate_agent_wave1_adjuncts.py")
    assert result.returncode == 0, result.stdout + result.stderr


def test_wave1_adjunct_index_is_current() -> None:
    result = _run("scripts/build_agent_wave1_adjunct_index.py", "--check")
    assert result.returncode == 0, result.stdout + result.stderr
