from __future__ import annotations

import argparse
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE_DIRS = {
    "kind": ROOT / "profiles" / "adjuncts" / "kind",
    "subjectivity": ROOT / "profiles" / "adjuncts" / "subjectivity",
    "office_overlay": ROOT / "profiles" / "adjuncts" / "office_overlay",
    "arena_authority": ROOT / "profiles" / "adjuncts" / "arena_authority",
}
DEFAULT_OUTPUT = ROOT / "generated" / "agent_wave1_adjunct_index.min.json"


def _load_family(directory: Path) -> list[dict]:
    if not directory.exists():
        return []
    items: list[dict] = []
    for path in sorted(directory.glob("*.json")):
        items.append(json.loads(path.read_text(encoding="utf-8")))
    return items


def build_index(root: Path = ROOT) -> list[dict]:
    source_dirs = {
        name: root / rel.relative_to(ROOT)
        for name, rel in SOURCE_DIRS.items()
    }
    families = {name: _load_family(path) for name, path in source_dirs.items()}

    by_agent: dict[str, dict[str, dict]] = {}
    for family_name, items in families.items():
        for item in items:
            agent_id = item["agent_id"]
            by_agent.setdefault(agent_id, {})[family_name] = item

    index: list[dict] = []
    for agent_id in sorted(by_agent):
        family = by_agent[agent_id]
        kind = family.get("kind", {})
        office = family.get("office_overlay", {})
        arena = family.get("arena_authority", {})
        subjectivity = family.get("subjectivity", {})

        index.append(
            {
                "agent_id": agent_id,
                "role_ref": kind.get("role_ref") or office.get("role_ref") or arena.get("role_ref"),
                "kind": kind.get("kind"),
                "evolution_mode": kind.get("evolution_mode"),
                "history_mode": kind.get("history_mode"),
                "primary_office": office.get("primary_office"),
                "secondary_offices": office.get("secondary_offices", []),
                "arena_roles": arena.get("arena_roles", []),
                "readiness_state": arena.get("readiness_state"),
                "has_subjectivity": bool(subjectivity),
            }
        )

    return index


def _minified(data: object) -> str:
    return json.dumps(data, ensure_ascii=False, separators=(",", ":")) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description="Build the Wave-I adjunct index for aoa-agents.")
    parser.add_argument(
        "--output",
        type=Path,
        default=DEFAULT_OUTPUT,
        help="Path to the generated minified JSON file.",
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="Check whether the current generated file is up to date without writing it.",
    )
    args = parser.parse_args()

    index = build_index(ROOT)
    payload = _minified(index)

    if args.check:
        if not args.output.exists():
            print(f"missing generated file: {args.output}")
            return 1
        current = args.output.read_text(encoding="utf-8")
        if current != payload:
            print(f"generated file is stale: {args.output}")
            return 1
        print(f"generated file is current: {args.output}")
        return 0

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(payload, encoding="utf-8")
    print(f"wrote {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
