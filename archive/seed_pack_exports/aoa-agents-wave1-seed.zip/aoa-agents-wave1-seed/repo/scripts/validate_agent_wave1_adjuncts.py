from __future__ import annotations

import json
from pathlib import Path

from jsonschema import Draft202012Validator

from build_agent_wave1_adjunct_index import build_index


ROOT = Path(__file__).resolve().parents[1]

SCHEMA_FILES = {
    "kind": ROOT / "schemas" / "agent_kind_v1.json",
    "subjectivity": ROOT / "schemas" / "agent_subjectivity_v1.json",
    "office_overlay": ROOT / "schemas" / "agent_office_overlay_v1.json",
    "arena_authority": ROOT / "schemas" / "agent_arena_authority_v1.json",
}

SOURCE_DIRS = {
    "kind": ROOT / "profiles" / "adjuncts" / "kind",
    "subjectivity": ROOT / "profiles" / "adjuncts" / "subjectivity",
    "office_overlay": ROOT / "profiles" / "adjuncts" / "office_overlay",
    "arena_authority": ROOT / "profiles" / "adjuncts" / "arena_authority",
}

EXAMPLE_FILES = {
    "kind": ROOT / "examples" / "agent_kind.example.json",
    "subjectivity": ROOT / "examples" / "agent_subjectivity.example.json",
    "office_overlay": ROOT / "examples" / "agent_office_overlay.example.json",
    "arena_authority": ROOT / "examples" / "agent_arena_authority.example.json",
}

GENERATED_INDEX = ROOT / "generated" / "agent_wave1_adjunct_index.min.json"


def _load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def _load_core_profiles() -> dict[str, dict]:
    profiles: dict[str, dict] = {}
    for path in sorted((ROOT / "profiles").glob("*.profile.json")):
        data = _load_json(path)
        profiles[data["id"]] = data
    return profiles


def _validator_for(path: Path) -> Draft202012Validator:
    return Draft202012Validator(_load_json(path))


def _validate_file(validator: Draft202012Validator, path: Path, errors: list[str]) -> dict | None:
    data = _load_json(path)
    found = sorted(validator.iter_errors(data), key=lambda err: list(err.path))
    for err in found:
        loc = ".".join(str(part) for part in err.path) or "<root>"
        errors.append(f"{path}: {loc}: {err.message}")
    return data if not found else None


def _family_items(family: str, validator: Draft202012Validator, errors: list[str]) -> dict[str, dict]:
    items: dict[str, dict] = {}
    directory = SOURCE_DIRS[family]
    for path in sorted(directory.glob("*.json")):
        data = _validate_file(validator, path, errors)
        if data is not None:
            items[data["agent_id"]] = data
    return items


def _check_kind_semantics(kind_items: dict[str, dict], errors: list[str]) -> None:
    for agent_id, item in kind_items.items():
        kind = item["kind"]
        history_mode = item["history_mode"]
        if kind == "agonic" and history_mode == "revision_log":
            errors.append(f"{agent_id}: agonic kind should not use revision_log history in Wave I")
        if kind == "assistant" and history_mode == "scar_ledger":
            errors.append(f"{agent_id}: assistant kind should not use scar_ledger history")


def _check_authority_semantics(authority_items: dict[str, dict], errors: list[str]) -> None:
    readiness_required_role = {
        "contestant_ready": "contestant",
        "witness_ready": "witness",
        "judge_ready": "judge",
        "support_only": "support",
    }
    seen_contestant = False
    seen_witness = False
    seen_judge = False

    for agent_id, item in authority_items.items():
        readiness = item["readiness_state"]
        roles = set(item["arena_roles"])
        moves = set(item["move_rights"])
        closure = item["closure_rights"]
        summon = item["summon_rights"]

        if readiness in readiness_required_role and readiness_required_role[readiness] not in roles:
            errors.append(f"{agent_id}: readiness_state {readiness!r} requires role {readiness_required_role[readiness]!r}")

        if closure["can_finalize"]:
            errors.append(f"{agent_id}: Wave I must not grant closer authority")
        if summon["can_initiate"]:
            errors.append(f"{agent_id}: Wave I must not grant summon initiation authority")

        if "adjudicate" in moves and "judge" not in roles:
            errors.append(f"{agent_id}: adjudicate move requires judge arena role")
        if "write_chronicle" in moves and not ({"witness", "support"} & roles):
            errors.append(f"{agent_id}: write_chronicle move requires witness or support arena role")
        if "request_summon" in moves and not summon["can_request"]:
            errors.append(f"{agent_id}: request_summon move requires can_request summon_rights")

        seen_contestant = seen_contestant or readiness == "contestant_ready"
        seen_witness = seen_witness or readiness == "witness_ready"
        seen_judge = seen_judge or readiness == "judge_ready"

    if not seen_contestant:
        errors.append("Wave I requires at least one contestant_ready actor")
    if not seen_witness:
        errors.append("Wave I requires at least one witness_ready actor")
    if not seen_judge:
        errors.append("Wave I requires at least one judge_ready actor")


def _check_cross_family_alignment(
    profiles: dict[str, dict],
    kind_items: dict[str, dict],
    subjectivity_items: dict[str, dict],
    office_items: dict[str, dict],
    authority_items: dict[str, dict],
    errors: list[str],
) -> None:
    family_sets = {
        "kind": set(kind_items),
        "subjectivity": set(subjectivity_items),
        "office_overlay": set(office_items),
        "arena_authority": set(authority_items),
    }

    first = next(iter(family_sets.values()), set())
    for family_name, ids in family_sets.items():
        if ids != first:
            errors.append(f"family mismatch for {family_name}: {sorted(ids)} vs {sorted(first)}")

    if not profiles:
        return

    for family_name, items in {
        "kind": kind_items,
        "subjectivity": subjectivity_items,
        "office_overlay": office_items,
        "arena_authority": authority_items,
    }.items():
        for agent_id, item in items.items():
            if agent_id not in profiles:
                errors.append(f"{family_name}: unknown agent_id {agent_id}")
                continue
            role_ref = item.get("role_ref")
            profile_role = profiles[agent_id]["role"]
            if role_ref is not None and role_ref != profile_role:
                errors.append(f"{family_name}: {agent_id} role_ref {role_ref!r} != core profile role {profile_role!r}")


def _check_examples(validators: dict[str, Draft202012Validator], errors: list[str]) -> None:
    for family, path in EXAMPLE_FILES.items():
        _validate_file(validators[family], path, errors)


def _check_generated_index(kind_items: dict[str, dict], office_items: dict[str, dict], authority_items: dict[str, dict], subjectivity_items: dict[str, dict], errors: list[str]) -> None:
    expected = build_index(ROOT)
    if not GENERATED_INDEX.exists():
        errors.append(f"missing generated index: {GENERATED_INDEX}")
        return
    current = json.loads(GENERATED_INDEX.read_text(encoding="utf-8"))
    if current != expected:
        errors.append(f"generated index is stale: {GENERATED_INDEX}")


def main() -> int:
    errors: list[str] = []
    validators = {name: _validator_for(path) for name, path in SCHEMA_FILES.items()}
    profiles = _load_core_profiles()

    kind_items = _family_items("kind", validators["kind"], errors)
    subjectivity_items = _family_items("subjectivity", validators["subjectivity"], errors)
    office_items = _family_items("office_overlay", validators["office_overlay"], errors)
    authority_items = _family_items("arena_authority", validators["arena_authority"], errors)

    _check_examples(validators, errors)
    _check_kind_semantics(kind_items, errors)
    _check_authority_semantics(authority_items, errors)
    _check_cross_family_alignment(
        profiles=profiles,
        kind_items=kind_items,
        subjectivity_items=subjectivity_items,
        office_items=office_items,
        authority_items=authority_items,
        errors=errors,
    )
    _check_generated_index(kind_items, office_items, authority_items, subjectivity_items, errors)

    if errors:
        print("Wave-I adjunct validation failed:")
        for err in errors:
            print(f" - {err}")
        return 1

    print("Wave-I adjunct validation passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
