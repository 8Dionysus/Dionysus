# aoa-agents Wave I seed archive

This archive is a patch-style seed.

- `repo/` contains repo-relative paths intended for merge into `aoa-agents`
- `repo/SEED_MANIFEST.md` explains the landing discipline
- the seed is additive and keeps the current core profile shape intact
