# Codex Landing Brief

Treat this seed as a disciplined insertion, not as sacred cargo.

## Required behavior

- preserve source-owned repository boundaries
- keep recurrence read-only in wave one
- do not add hidden mutation, hidden scheduler lanes, or autonomous refresh loops
- keep `aoa-routing` thin and navigation-only
- keep `aoa-kag` regrounding-only where downstream owner truth is stronger
- keep `aoa-agents` projection explicit and subordinate to source profiles and wiring
- prefer the smallest patch that lands the recurrence engine cleanly

## Concrete landing moves

1. Add `aoa-sdk/src/aoa_sdk/recurrence/`
2. Register `RecurrenceAPI` on `AoASDK`
3. Register the `aoa recur ...` CLI group
4. Add the owner manifests to the owning repos
5. Regenerate examples only if local code or paths change during landing
6. If a repo-local command in a manifest drifted, update the manifest rather than bending the engine around stale commands

## Non-goals in this wave

- no automatic edits across repos
- no background reconciliation
- no hidden graph sovereignty
- no conversion of routing, stats, or KAG into source truth
- no agent spawning yet

## Expected first-wave honesty

Some downstream edges will remain only partially closed until more owner manifests land. That is acceptable. The doctor should expose those thin seams instead of hiding them.
