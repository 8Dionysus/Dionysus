from __future__ import annotations

from pathlib import Path

from ..workspace.discovery import Workspace
from .detector import detect_change_signal
from .doctor import build_connectivity_gap_report
from .io import read_model
from .models import ChangeSignal, ConnectivityGapReport, PropagationPlan, ReturnHandoff
from .planner import build_propagation_plan
from .reentry import build_return_handoff
from .registry import RecurrenceRegistry, load_registry


class RecurrenceAPI:
    def __init__(self, workspace: Workspace) -> None:
        self.workspace = workspace

    def registry(self) -> RecurrenceRegistry:
        return load_registry(self.workspace)

    def detect(
        self,
        *,
        repo_root: str,
        diff_base: str | None = None,
        paths: list[str] | None = None,
    ) -> ChangeSignal:
        return detect_change_signal(
            self.workspace,
            repo_root=repo_root,
            diff_base=diff_base,
            paths=paths,
            registry=self.registry(),
        )

    def plan(self, report_or_path: ChangeSignal | str | Path) -> PropagationPlan:
        report = report_or_path
        if isinstance(report_or_path, (str, Path)):
            report = read_model(report_or_path, ChangeSignal)
        return build_propagation_plan(self.workspace, signal=report, registry=self.registry())

    def doctor(self, report_or_path: ChangeSignal | str | Path | None = None) -> ConnectivityGapReport:
        report = None
        if isinstance(report_or_path, (str, Path)):
            report = read_model(report_or_path, ChangeSignal)
        elif isinstance(report_or_path, ChangeSignal):
            report = report_or_path
        return build_connectivity_gap_report(self.workspace, signal=report, registry=self.registry())

    def build_return_handoff(
        self,
        plan_or_path: PropagationPlan | str | Path,
        *,
        reviewed: bool = True,
    ) -> ReturnHandoff:
        plan = plan_or_path
        if isinstance(plan_or_path, (str, Path)):
            plan = read_model(plan_or_path, PropagationPlan)
        return build_return_handoff(plan=plan, registry=self.registry(), reviewed=reviewed)
