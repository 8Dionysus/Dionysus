from __future__ import annotations

import json

import typer

from ..workspace.discovery import Workspace
from .api import RecurrenceAPI
from .io import (
    persist_change_signal,
    persist_gap_report,
    persist_propagation_plan,
    persist_return_handoff,
)

recur_app = typer.Typer(help="Plan recurrence propagation, connectivity checks, and reviewed return handoffs")


@recur_app.command("detect")
def recur_detect(
    repo_root: str = typer.Argument(".", help="Repository root where the change was observed."),
    diff_base: str | None = typer.Option(
        None,
        "--from",
        help="Diff source in the form git:<rev-spec>, for example git:HEAD~1..HEAD.",
    ),
    path: list[str] = typer.Option(
        None,
        "--path",
        help="Repeatable explicit changed path relative to repo_root. Use this instead of --from when needed.",
    ),
    report_output: str | None = typer.Option(None, "--report-output", help="Optional output path."),
    root: str = typer.Option(".", "--root", help="Workspace root used for federation discovery."),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable JSON."),
) -> None:
    workspace = Workspace.discover(root)
    api = RecurrenceAPI(workspace)
    signal = api.detect(repo_root=repo_root, diff_base=diff_base, paths=path)
    report_path = persist_change_signal(workspace, signal, output=report_output)
    payload = signal.model_dump(mode="json")
    payload["report_path"] = str(report_path)
    if json_output:
        typer.echo(json.dumps(payload, indent=2, ensure_ascii=True))
        return
    typer.echo(f"report_path: {report_path}")
    typer.echo(f"direct_components: {len(signal.direct_components)}")
    for item in signal.direct_components:
        typer.echo(f"- {item.component_ref} [{item.match_class}]")
    if signal.unmatched_paths:
        typer.echo("unmatched_paths:")
        for item in signal.unmatched_paths:
            typer.echo(f"  - {item}")


@recur_app.command("plan")
def recur_plan(
    signal_path: str = typer.Argument(..., help="Path to a persisted change signal JSON."),
    report_output: str | None = typer.Option(None, "--report-output", help="Optional output path."),
    root: str = typer.Option(".", "--root", help="Workspace root used for federation discovery."),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable JSON."),
) -> None:
    workspace = Workspace.discover(root)
    api = RecurrenceAPI(workspace)
    plan = api.plan(signal_path)
    report_path = persist_propagation_plan(workspace, plan, output=report_output)
    payload = plan.model_dump(mode="json")
    payload["report_path"] = str(report_path)
    if json_output:
        typer.echo(json.dumps(payload, indent=2, ensure_ascii=True))
        return
    typer.echo(f"report_path: {report_path}")
    typer.echo(plan.summary)
    for step in plan.ordered_steps:
        typer.echo(f"- [{step.status}] {step.owner_repo} {step.action} {step.component_ref}")


@recur_app.command("doctor")
def recur_doctor(
    signal_path: str | None = typer.Argument(None, help="Optional path to a persisted change signal JSON."),
    report_output: str | None = typer.Option(None, "--report-output", help="Optional output path."),
    root: str = typer.Option(".", "--root", help="Workspace root used for federation discovery."),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable JSON."),
) -> None:
    workspace = Workspace.discover(root)
    api = RecurrenceAPI(workspace)
    report = api.doctor(signal_path)
    report_path = persist_gap_report(workspace, report, output=report_output)
    payload = report.model_dump(mode="json")
    payload["report_path"] = str(report_path)
    if json_output:
        typer.echo(json.dumps(payload, indent=2, ensure_ascii=True))
        return
    typer.echo(f"report_path: {report_path}")
    typer.echo(f"gaps: {len(report.gaps)}")
    for gap in report.gaps:
        typer.echo(f"- [{gap.severity}] {gap.gap_kind}: {gap.recommendation}")


@recur_app.command("handoff")
def recur_handoff(
    plan_path: str = typer.Argument(..., help="Path to a persisted propagation plan JSON."),
    reviewed: bool = typer.Option(True, "--reviewed/--not-reviewed", help="Return handoff requires reviewed mode."),
    report_output: str | None = typer.Option(None, "--report-output", help="Optional output path."),
    root: str = typer.Option(".", "--root", help="Workspace root used for federation discovery."),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable JSON."),
) -> None:
    workspace = Workspace.discover(root)
    api = RecurrenceAPI(workspace)
    handoff = api.build_return_handoff(plan_path, reviewed=reviewed)
    report_path = persist_return_handoff(workspace, handoff, output=report_output)
    payload = handoff.model_dump(mode="json")
    payload["report_path"] = str(report_path)
    if json_output:
        typer.echo(json.dumps(payload, indent=2, ensure_ascii=True))
        return
    typer.echo(f"report_path: {report_path}")
    typer.echo(f"targets: {len(handoff.targets)}")
    for target in handoff.targets:
        typer.echo(f"- {target.owner_repo}:{target.target} [{target.target_kind}]")
