from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field


EdgeKind = Literal[
    "owns",
    "generates",
    "projects_to",
    "validated_by",
    "documents",
    "evaluated_by",
    "routes_via",
    "summarized_by",
    "donates_to_kag",
    "requires_regrounding",
    "handoff_home",
]

RouteClass = Literal[
    "observe",
    "revalidate",
    "rebuild",
    "reexport",
    "regenerate",
    "reproject",
    "repair",
    "reroute",
    "restat",
    "reground",
    "handoff",
    "defer",
]

SurfaceClass = Literal[
    "source",
    "generated",
    "projected",
    "contract",
    "docs",
    "test",
    "proof",
    "receipt",
    "other",
]


class StrictModel(BaseModel):
    model_config = {
        "extra": "forbid",
        "populate_by_name": True,
    }


class RefreshRoute(StrictModel):
    action: RouteClass
    commands: list[str] = Field(default_factory=list)
    notes: str = ""


class ConsumerEdge(StrictModel):
    kind: EdgeKind
    target: str
    target_repo: str | None = None
    required: bool = True
    suggested_action: RouteClass | None = None
    suggested_commands: list[str] = Field(default_factory=list)
    notes: str = ""


class DriftSignalRule(StrictModel):
    signal: str
    recommended_action: RouteClass
    severity: Literal["low", "medium", "high"] = "medium"


class FreshnessWindow(StrictModel):
    stale_after_days: int | None = None
    repeat_trigger_threshold: int | None = None
    open_window_days: int | None = None


class RecurrenceComponent(StrictModel):
    schema_version: Literal["aoa_recurrence_component_v1"] = "aoa_recurrence_component_v1"
    component_ref: str
    owner_repo: str
    description: str = ""
    source_inputs: list[str] = Field(default_factory=list)
    generated_surfaces: list[str] = Field(default_factory=list)
    projected_surfaces: list[str] = Field(default_factory=list)
    contract_surfaces: list[str] = Field(default_factory=list)
    documentation_surfaces: list[str] = Field(default_factory=list)
    test_surfaces: list[str] = Field(default_factory=list)
    proof_surfaces: list[str] = Field(default_factory=list)
    receipt_surfaces: list[str] = Field(default_factory=list)
    refresh_routes: list[RefreshRoute] = Field(default_factory=list)
    consumer_edges: list[ConsumerEdge] = Field(default_factory=list)
    drift_signals: list[DriftSignalRule] = Field(default_factory=list)
    freshness: FreshnessWindow = Field(default_factory=FreshnessWindow)
    rollback_anchors: list[str] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)


class ChangedPath(StrictModel):
    repo: str
    path: str
    matched_component_refs: list[str] = Field(default_factory=list)
    matched_classes: list[SurfaceClass] = Field(default_factory=list)


class MatchedComponent(StrictModel):
    component_ref: str
    owner_repo: str
    match_class: SurfaceClass
    matched_paths: list[str] = Field(default_factory=list)
    inferred_signals: list[str] = Field(default_factory=list)


class ChangeSignal(StrictModel):
    schema_version: Literal["aoa_change_signal_v1"] = "aoa_change_signal_v1"
    signal_ref: str
    workspace_root: str
    repo_root: str
    repo_name: str | None = None
    observed_at: datetime
    diff_base: str | None = None
    changed_paths: list[ChangedPath] = Field(default_factory=list)
    direct_components: list[MatchedComponent] = Field(default_factory=list)
    unmatched_paths: list[str] = Field(default_factory=list)


class PlanStep(StrictModel):
    step_ref: str
    order: int
    component_ref: str
    owner_repo: str
    action: RouteClass
    reason: str
    surface_refs: list[str] = Field(default_factory=list)
    commands: list[str] = Field(default_factory=list)
    depends_on: list[str] = Field(default_factory=list)
    review_required: bool = True
    status: Literal["planned", "blocked"] = "planned"


class PropagationPlan(StrictModel):
    schema_version: Literal["aoa_propagation_plan_v1"] = "aoa_propagation_plan_v1"
    plan_ref: str
    signal_ref: str
    workspace_root: str
    direct_components: list[str] = Field(default_factory=list)
    impacted_components: list[str] = Field(default_factory=list)
    impacted_targets: list[str] = Field(default_factory=list)
    ordered_steps: list[PlanStep] = Field(default_factory=list)
    unresolved_edges: list[str] = Field(default_factory=list)
    open_questions: list[str] = Field(default_factory=list)
    summary: str = ""


class ReturnTarget(StrictModel):
    owner_repo: str
    component_ref: str | None = None
    target: str
    target_kind: Literal["source", "contract", "docs", "route", "summary", "playbook"]
    reason: str


class ReturnHandoff(StrictModel):
    schema_version: Literal["aoa_return_handoff_v1"] = "aoa_return_handoff_v1"
    handoff_ref: str
    plan_ref: str
    reviewed: Literal[True] = True
    surviving_fields: list[str] = Field(default_factory=list)
    targets: list[ReturnTarget] = Field(default_factory=list)
    unresolved_items: list[str] = Field(default_factory=list)


class ConnectivityGap(StrictModel):
    gap_ref: str
    severity: Literal["low", "medium", "high"]
    gap_kind: Literal[
        "unmapped_changed_path",
        "unresolved_edge",
        "missing_refresh_route",
        "missing_proof_surface",
        "orphan_generated_surface",
        "projected_without_generation",
        "weak_owner_handoff",
        "missing_target_route",
    ]
    component_ref: str | None = None
    owner_repo: str | None = None
    evidence_refs: list[str] = Field(default_factory=list)
    recommendation: str


class ConnectivityGapReport(StrictModel):
    schema_version: Literal["aoa_connectivity_gap_report_v1"] = "aoa_connectivity_gap_report_v1"
    report_ref: str
    workspace_root: str
    signal_ref: str | None = None
    components_checked: list[str] = Field(default_factory=list)
    gaps: list[ConnectivityGap] = Field(default_factory=list)
