# Patch Notes

## `aoa-sdk/src/aoa_sdk/api.py`

Add one import:

```python
from .recurrence import RecurrenceAPI
```

Add one field in `AoASDK.__init__`:

```python
self.recurrence = RecurrenceAPI(workspace)
```

## `aoa-sdk/src/aoa_sdk/cli/main.py`

Add one import:

```python
from ..recurrence.cli import recur_app
```

Register one Typer app:

```python
app.add_typer(recur_app, name="recur")
```

If the local CLI naming prefers the full noun, `recurrence` is also acceptable. The seed uses `recur` to stay compact.
