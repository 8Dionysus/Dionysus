# AoA Recurrence First Wave Seed

This seed plants the first programmable wave of the recurrence control plane.

The landing is intentionally narrow:

- detection is programmable
- propagation planning is programmable
- connectivity gaps are surfaced explicitly
- return handoff stays reviewed and read-only
- no hidden scheduler is introduced
- no owner repo is mutated automatically

## What is inside

- `aoa-sdk/`
  - `src/aoa_sdk/recurrence/` first-wave engine
  - `docs/` doctrine and landing notes
  - `schemas/` JSON contracts
  - `examples/` generated example packets
  - `tests/` minimal verification harness
  - `patches/` small integration diffs for `api.py` and `cli/main.py`
- `8Dionysus/`
  - source-authored recurrence manifest for `component:codex-plane:shared-root`
- `aoa-agents/`
  - source-authored recurrence manifest for `component:codex-subagents:projection`

## Intended landing order

1. Land `aoa-sdk/src/aoa_sdk/recurrence/`
2. Land `aoa-sdk/docs/`, `schemas/`, `examples/`, and `tests/`
3. Apply the tiny integration patches to `aoa-sdk/src/aoa_sdk/api.py` and `aoa-sdk/src/aoa_sdk/cli/main.py`
4. Place the owner manifests into `8Dionysus/manifests/recurrence/` and `aoa-agents/manifests/recurrence/`
5. Let Codex adapt command names or file paths where the live repo has drifted
6. Run the repo-local tests and validators after landing

## Boundaries

This wave is a seed, not a blind overwrite pack.

It is designed for Codex to adapt inside the living workspace. If the local repo has already evolved, Codex should preserve existing style, wiring, and naming while keeping the recurrence contract intact.
