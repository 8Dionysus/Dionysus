# Wave 1: Codex Audit Spine

This pack prepares the first update wave for your repositories.

## Goal

Install a shared audit spine before expanding skills, evals, or deeper subdirectory rules.

This wave does **not** try to refactor the repositories themselves.
It installs the contracts that make Codex audits narrower, more reviewable, and less error-prone.

## Included files

### New files
- `Agents-of-Abyss/ECOSYSTEM_AUDIT_INDEX.md`
- `Agents-of-Abyss/docs/CODEX_AUDIT_PROTOCOL.md`
- `ATM10-Agent/AUDIT.md`
- `abyss-stack/AUDIT.md`

### Suggested AGENTS.md additions
- `Agents-of-Abyss/AGENTS.md`
- `ATM10-Agent/AGENTS.md`
- `abyss-stack/AGENTS.md`

See `PATCH_SNIPPETS.md` for the exact insertion text.

## Why this wave first

- `Agents-of-Abyss` already acts as the constitutional center and owns the ecosystem map and federation rules.
- `ATM10-Agent` already has a strong `PLAN -> DIFF -> VERIFY -> REPORT` discipline plus explicit pytest and smoke-path expectations.
- `abyss-stack` already carries the highest infra risk and has a validation workflow with `python scripts/validate_stack.py`, `shellcheck`, and bootstrap/render rehearsals.
- Codex follows layered `AGENTS.md` files and GitHub review uses the closest applicable `AGENTS.md`, so making audit rules explicit in the owning repos reduces drift.
- Codex only flags P0/P1 issues in GitHub review by default, so the repos need explicit severity mapping for what actually counts as review-critical.
- Codex stops reading `AGENTS.md` content once the combined project instruction size reaches `project_doc_max_bytes` (32 KiB by default), so keeping root AGENTS concise and moving audit detail into dedicated docs is the safer pattern.

## Application order

1. Add the new files exactly as written.
2. Insert the AGENTS snippets.
3. Run each repo's existing validation.
4. Only then start wave 2 for `aoa-skills` and `aoa-evals`.

## Validation reminders

### Agents-of-Abyss
```bash
python scripts/validate_ecosystem.py
```

### ATM10-Agent
```powershell
cd <repo>
.\.venv\Scripts\Activate.ps1
python -m pytest
```
Plus the nearest smoke path for any touched runnable entrypoint.

### abyss-stack
```bash
python scripts/validate_stack.py
```
Plus the smallest relevant bootstrap/render/profile checks for touched surfaces.

## Next wave after this one

Wave 2 should cover:
- `aoa-skills`
- `aoa-evals`
- optional `.codex/config.toml` tightening where it genuinely helps
- possible repo-local skills for audit/report synthesis
