# PATCH_SNIPPETS.md

Use the blocks below as insertion text for the existing `AGENTS.md` files.

## Agents-of-Abyss/AGENTS.md

Add near the validation/review sections:

```md
## Audit protocol
For repository audits and GitHub review, also read:
- `ECOSYSTEM_AUDIT_INDEX.md`
- `docs/CODEX_AUDIT_PROTOCOL.md`

## Review guidelines
For GitHub review in this repository, treat the following as P1:
- contradictions across `README.md`, `CHARTER.md`, `ECOSYSTEM_MAP.md`, `docs/LAYERS.md`, `docs/FEDERATION_RULES.md`, `ROADMAP.md`, and `generated/ecosystem_registry.min.json`
- changes that blur source-of-truth boundaries or silently absorb layer-owned meaning into the center
- routing changes that point readers to the wrong owning repository
- generated registry changes without corresponding source updates or without running `python scripts/validate_ecosystem.py`
- semantic changes hidden under "docs-only" or "metadata-only" wording

Ignore trivial wording nits unless the task explicitly asks for copyediting.

```

## ATM10-Agent/AGENTS.md

Add after the read-first or contribution-doctrine section:

```md
## Audit contract
For repository audits and GitHub review, read `AUDIT.md` after the core docs.

## Review guidelines
For GitHub review in this repository, treat the following as P0:
- committed secrets, tokens, or private logs
- a change that makes real input events or destructive automation the default path
- a change that silently routes a safe action to game-state-changing input

Treat the following as P1:
- weakening dry-run-by-default behavior
- widening service exposure, auth posture, or network assumptions without explicit callout
- changes to `requirements*.txt`, services, or ports made without the required ask-first posture
- semantic contract changes in scripts, gateway, retrieval, KAG, voice, or automation flows without matching tests/docs updates
- public docs leaking workstation-specific paths, internal hostnames, or sensitive runtime detail
- claiming validation that was not actually run

Ignore trivial wording nits unless the task explicitly asks for copyediting.

```

## abyss-stack/AGENTS.md

Add after the repository reading order or as a new final section:

```md
## Audit contract
For repository audits and GitHub review, read `AUDIT.md` after the core docs and also follow the nearest nested `AGENTS.md` in touched subdirectories.

## Review guidelines
For GitHub review in this repository, treat the following as P0:
- committed live secrets or secret-bearing rendered configs
- a change that widens default host exposure beyond localhost without explicit operator intent
- a bootstrap or runtime change that can destroy data without rollback guidance

Treat the following as P1:
- env examples drifting away from actual runtime consumers
- path mapping drift away from `/srv/abyss-stack`, `Configs`, or `Secrets`
- profile/preset/module changes without matching render/introspection verification
- hidden breaking changes in doctor/bootstrap/first-run helpers
- runtime substrate starting to author meaning that belongs in AoA or ToS
- claiming validation that was not actually run

Ignore trivial wording nits unless the task explicitly asks for copyediting.

```
