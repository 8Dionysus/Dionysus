# Validation Matrix

Use this file as a starting matrix.
When a command is shown as a current workflow rather than an exact command, let Codex inspect the repo's published workflow and keep that repo-native entrypoint as source of truth.

| Repo | Minimum validation after each landing |
|---|---|
| Agents-of-Abyss | `python scripts/validate_ecosystem.py`; `pytest` |
| Dionysus | `python scripts/validate_seed_surfaces.py` |
| abyss-stack | `python scripts/validate_stack.py`; repo-native workflow smoke / pytest equivalent |
| aoa-routing | `python scripts/validate_router.py ...`; `python scripts/build_router.py --check ...`; `pytest tests` |
| aoa-sdk | `python -m pytest -q`; `python -m ruff check .`; `python -m mypy src`; `python -m build` |
| aoa-playbooks | current repo-validation workflow; current compatibility-canary workflow |
| aoa-agents | current repo-validation workflow; generated drift check; `pytest` |
| aoa-memo | `python scripts/validate_memo.py`; `python scripts/validate_memory_surfaces.py`; `python scripts/validate_memory_object_surfaces.py`; `pytest` |
| aoa-kag | current repo-validation workflow; current compatibility-canary workflow |
| Tree-of-Sophia | `python scripts/validate_kag_export.py`; `pytest` |
| aoa-techniques | `python scripts/release_check.py` |
| aoa-skills | `python scripts/release_check.py`; current codex-portable-export workflow; generated drift check |
| aoa-evals | `python scripts/build_catalog.py --check`; `python scripts/validate_repo.py`; `pytest` |
| 8Dionysus profile surfaces | public-surface review only |
| ATM10-Agent | preliminary only; use repo-native validation when the dedicated audit starts |

## Extra rules

- if a landing touches a generated surface, include a rebuild or drift check in the same slice
- if a landing touches compatibility or routing, include a sibling-aware check in the same slice
- if a landing touches public governance summaries, include one assertion that missing artifacts surface as debt instead of disappearing
