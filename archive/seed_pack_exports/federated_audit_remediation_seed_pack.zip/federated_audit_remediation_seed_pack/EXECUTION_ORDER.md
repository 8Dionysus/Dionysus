# Execution Order

This order is optimized to remove lies and false-green surfaces early.

## Phase 1: remove contract lies and false greens

- **WS01** federation compatibility, inventory, and release semantics
- **WS02** control-plane hardening
- **WS03** memory and agent contract hardening
- **WS04** memo-routing return-path normalization
- **WS08** governance-surface honesty
- **WS09** aoa-skills CI hardening

Why first:
- these workstreams close false-green compatibility, false-green review summaries, hidden route bypasses, and scope grammar drift

## Phase 2: extend the nervous system

- **WS10** federation-wide canary posture
- **WS05** source-first ToS/KAG routing hardening
- **WS06** seed-garden / ecosystem-center / runtime-body hardening

Why second:
- once contracts stop lying, the canaries can be expanded without just propagating ambiguous rules

## Phase 3: refine traceability and ergonomics

- **WS07** techniques → skills → evals traceability and maturity hardening
- **WS11** onboarding, support matrix, and release clarity

Why third:
- these changes matter, but they benefit from earlier compatibility and canary cleanup

## Phase 4: separate product-edge endcap

- **WS12** ATM10-Agent preliminary endcap

Why last:
- ATM10-Agent stayed intentionally separate in the dialogue and did not receive the same deep repo-by-repo treatment here

## Smallest coherent landing examples

- if touching `aoa-sdk` compatibility logic, also land one CI check in the same slice
- if touching `aoa-skills` review truth-sync, also land one surfaced debt signal in generated output
- if touching ToS entry ABI, also land one source-side smoke or validator
- if touching `abyss-stack` mirror posture, also land at least one mirror canary or bounded smoke
