# Findings Index

This file maps the dialogue waves to the workstreams in this pack.

## Base architecture wave
- maps to **WS01**, **WS06**, **WS11**, **WS12**
- themes: federation shape, onboarding tax, release semantics, ATM10 risk as complexity sink

## Federation wave without ATM10
- maps to **WS01**, **WS02**, **WS06**, **WS11**
- themes: contract-first federation, control-plane overlap risk, generated-surface inflation, support-matrix need

## `aoa-routing` × `aoa-sdk` × `aoa-playbooks`
- maps to **WS02**
- themes: versionless surface false-green, raw fallback bypass, missing sibling canary in SDK

## `aoa-agents` × `aoa-memo`
- maps to **WS03**
- themes: split `scope` grammar, lossy public posture slices, conditional role/tier law, scenario-specific cohort leakage

## `aoa-memo` × `aoa-routing`
- maps to **WS04**
- themes: special-case `working.return`, prose-only route pointers, overloaded `route_capsule_ref`

## `Tree-of-Sophia` × `aoa-kag` × `aoa-routing`
- maps to **WS05**
- themes: source-first path structurally second-class, constitution-heavy reentry, derived retrieval density pressure

## `Agents-of-Abyss` × `Dionysus` × `abyss-stack`
- maps to **WS06**
- themes: incomplete machine inventory, prep-pack reality automation, runtime mirror canaries, platform pinning

## `aoa-techniques` → `aoa-skills` → `aoa-evals`
- maps to **WS07**
- themes: maturity legend split, proof-line drift, skill layer seam budget

## AOA-T-0001 specific traceability slice
- maps to **WS07**
- themes: exact upstream traceability good in skills, weaker in evals, adjacency/proof narrowing not yet formalized

## AOA-T-0002 / source-of-truth / ADR slice
- maps to **WS07**
- themes: lineage metadata drift in review records, proof gap for canonical ADR placement

## Governance lanes and review corpus
- maps to **WS08**
- themes: status-promotion truth sync stronger than candidate maintenance truth sync, mixed review grammars

## Governance generator audit
- maps to **WS08**
- themes: missing review files disappear from summary, total-skills count wider than visible rows, metric names too broad

## `aoa-skills` CI / validator rail
- maps to **WS09**
- themes: technique drift tool exists but is not a gate, packaging smoke hidden behind a local flag

## Federation-wide CI / canary posture
- maps to **WS10**
- themes: routing/playbooks/kag are the current towers, SDK too quiet, evals not yet a full canary tower, sources hear fractures late
