# Tasks by Priority

## P0

### WS01 · Federation compatibility, inventory, and release semantics
- Repos: Agents-of-Abyss, aoa-sdk, aoa-routing, aoa-playbooks, aoa-memo, aoa-agents, aoa-kag, aoa-techniques, aoa-skills, aoa-evals, Dionysus
- Summary: Turn compatibility and federation inventory into explicit machine-checked contracts rather than scattered repo-local assumptions.
- Key tasks:
  - Lift the compatibility map out of aoa-sdk docs into a federation-wide BOM or release matrix anchored near Agents-of-Abyss; every cross-repo machine-read surface must be listed, versioned, or explicitly strict-shape versionless.
  - Unify the vocabulary for version fields and compatibility status across repos; stop leaving meaning-bearing surfaces versionless without an explicit strict-shape policy and validator.
  - Expand Agents-of-Abyss/generated/ecosystem_registry.min.json into a true federation inventory or split it into core_inventory plus supporting_surfaces_inventory; include aoa-sdk explicitly.
  - Publish one canonical onboarding builder path across the public profile surfaces: profile -> Agents-of-Abyss -> aoa-sdk -> consumer/product edge.
  - Define federation-wide release semantics so repo tags mean compatible snapshots rather than isolated local milestones.

### WS02 · Control-plane hardening: aoa-routing × aoa-sdk × aoa-playbooks
- Repos: aoa-routing, aoa-sdk, aoa-playbooks
- Summary: Seal the control-plane seam so routing, consumer loading, and scenario composition do not drift into overlap or false-green compatibility.
- Key tasks:
  - Wrap playbook_activation_surfaces.min and playbook_federation_surfaces.min in a versioned envelope, or enforce true strict-shape validation for their versionless form inside the compatibility layer.
  - Remove the raw path fallback in RoutingAPI inspect/expand for route-directed public surfaces; new routed surfaces must not load unless an explicit compatibility rule exists.
  - Add a pinned sibling matrix and a scheduled latest-sibling canary to aoa-sdk; run the public compatibility check in CI, not only in docs.
  - Strengthen the semantic split between activation_surface and federation_surface in the SDK API and naming so validator-facing closure surfaces are not mistaken for runtime recipes.
  - Write an explicit non-overlap pact between routing, sdk, and playbooks: who decides where to go, who loads/normalizes, who composes scenarios, and what each layer must not absorb.

### WS03 · Memory and agent contract hardening
- Repos: aoa-agents, aoa-memo, aoa-playbooks
- Summary: Unify the grammar of memory rights, scopes, and return posture so agent roles, checkpoints, and memory objects stop speaking adjacent dialects.
- Key tasks:
  - Create one federation-wide memory_scope grammar and make agent-profile.schema.json, self-agent checkpoint surfaces, and memo objects all use it.
  - Add a typed posture slice to memory object catalogs/capsules for scope, access/access_class, review_state, current_recall, provenance thread refs, and route/source pointers.
  - Expand sibling-seam CI for aoa-agents and aoa-memo so the published contract is tested against routing and playbooks, not mostly against local surfaces.
  - Encode the conditional tier law that archivist/distill paths require memory-keeper participation when distillation or archivist-specific duties are active.
  - Move alpha_curated out of the agent-canonical registry into a playbook-owned or consumer-derived overlay if it remains scenario-specific.
  - Narrow and mark review_trace -> audit_event semantics so confirmed audit events cannot quietly overstate provenance or human review weight.

### WS04 · Memo-routing return-path normalization
- Repos: aoa-memo, aoa-routing
- Summary: Normalize the working/return recall corridor so the hottest re-entry path is not a private exception hiding inside otherwise clean object recall rules.
- Key tasks:
  - Make recall_contract.object.working.return.json a true inspect -> capsule -> expand contract, or explicitly declare it the only allowed two-step exception and repeat that in routing hints and docs.
  - Expose posture-critical route/source pointers in typed fields rather than only prose; consumers should not scrape sections.full body text to route safely.
  - Split route_capsule_ref into narrower fields such as next_inspect_ref and strongest_source_ref so one key does not carry mixed geometries.
  - Add a cross-repo validator that links return_navigation_hints, task_to_surface_hints.parallel_families.memory_objects, and the working.return recall contract.
  - Align routing docs that speak about inspect -> capsule with the actual memo inspect surfaces used in machine routing.

### WS06 · Seed-garden, ecosystem-center, and runtime-body hardening
- Repos: Agents-of-Abyss, Dionysus, abyss-stack
- Summary: Make the constitutional center, seed garden, and runtime body hear drift earlier and describe the real federation they already coordinate.
- Key tasks:
  - Expand or split the ecosystem registry so the machine inventory matches the federation publicly claimed by Agents-of-Abyss.
  - Add an advisory owner-repo reality canary to Dionysus that checks named target surfaces, validator anchors, and planting state before trusting staged packs.
  - Update staged notes in Dionysus with lifecycle_status, lifecycle_note, and reality_checked_at as soon as upstream landings merge; do not let staging memory outlive reality.
  - Add sibling mirror canaries in abyss-stack for memo/playbooks first, then routing and Tree-of-Sophia handoff surfaces.
  - Pin GitHub Actions in abyss-stack to commit SHAs and add at least one bounded Windows bridge smoke beyond syntax parsing.
  - Keep Dionysus transplant-focused; do not let it re-accumulate live repo-owned doctrine or runtime glue that now has a home elsewhere.

### WS08 · Governance-surface honesty and review truth-sync
- Repos: aoa-skills
- Summary: Make review-derived surfaces speak exactly as wide as they are proven, especially around candidate reviews and missing promotion records.
- Key tasks:
  - Add candidate_review_truth_sync alongside status-promotion truth sync, including lineage, governance decision, machine floor, blockers, and ideally reviewed_revision or equivalent maintenance anchor.
  - Version or migrate legacy candidate review records so mixed review grammars are explicit instead of silently coexisting under one name.
  - Rename summary metrics that currently sound broader than their detector coverage, especially review truth-sync gaps and docs truth-sync issues.
  - Treat missing status-promotion review for default_reference (and likely stay_evaluated) skills as explicit debt or a gate, not silent omission from the table.
  - Tighten default_reference semantics so public surfaces do not declare defaultness purely by canonical fallback when governance decision data is absent.
  - Add an Other tracked skills / Project overlays section to public surfaces so total skills counts do not hide omitted rows.

### WS09 · aoa-skills CI and validator rail hardening
- Repos: aoa-skills, aoa-techniques
- Summary: Turn existing local tools into mandatory gates so the skills layer hears upstream drift, packaging drift, and review debt early.
- Key tasks:
  - Promote report_technique_drift.py --fail-on-drift into published CI, first as a pinned sibling job and then as a latest-sibling canary.
  - Include packaging smoke in at least one published workflow lane; do not leave it hidden behind a local flag only.
  - Hook candidate_review_truth_sync and missing-promotion debt into the CI/maintenance surface once WS08 lands.
  - Decide whether skills-ref stays advisory or gets a stricter failure mode; if it stays advisory, mark that explicitly in the surfaced posture.
  - Optionally add one light general static gate so coarse code/config mistakes are caught before they become domain-contract noise.

### WS10 · Federation-wide CI/canary posture
- Repos: aoa-routing, aoa-playbooks, aoa-kag, aoa-evals, aoa-sdk, Agents-of-Abyss, Tree-of-Sophia, abyss-stack, aoa-memo, aoa-agents, aoa-skills, aoa-techniques
- Summary: Turn the current uneven watchtower pattern into a more even nervous system with fewer correlated blind spots.
- Key tasks:
  - Promote aoa-evals into a scheduled latest-sibling canary tower, not only a pinned sibling validator.
  - Give aoa-sdk both a pinned sibling matrix and a scheduled latest-sibling canary.
  - Add source-side smoke in Agents-of-Abyss and Tree-of-Sophia so sources hear seam fractures before or alongside downstream consumers.
  - Add abyss-stack mirror canaries for the handoff surfaces it already claims as roots.
  - Stagger or diversify canary schedules and/or shapes so routing/playbooks/kag are not perfectly synchronized blind spots.
  - Document and normalize action pinning posture across the federation.

## P1

### WS05 · Source-first ToS/KAG routing hardening
- Repos: Tree-of-Sophia, aoa-kag, aoa-routing
- Summary: Keep source-owned ToS entry stronger in ergonomics so derived retrieval never becomes the de facto throne by being easier to enter.
- Key tasks:
  - Promote a narrow tos_entry_route (or equivalent typed active kind) into the federation entry ABI instead of leaving the ToS path structurally second-class.
  - Add route-local reentry for tos-root that can return directly to the bounded tiny-entry seam, not only to the constitutional charter.
  - Add source-side federation smoke in Tree-of-Sophia against aoa-kag and aoa-routing.
  - Define a density or phase budget so KAG adjunct retrieval cannot outgrow the formal source-entry seam faster than the source path itself matures.
  - Clarify the overloaded authority vocabulary across charter authority, route authority mirror, and export entry surfaces.

### WS07 · Techniques → skills → evals traceability and maturity hardening
- Repos: aoa-techniques, aoa-skills, aoa-evals
- Summary: Tighten proof lineage and maturity language so execution, boundary coverage, and proof maturity remain distinguishable and traceable end-to-end.
- Key tasks:
  - Add a latest-sibling canary that exercises the technique -> skill -> eval rail, not only local release checks.
  - Publish a federation legend for defaultness, execution evidence, and proof maturity; stop overloading canonical/ready into multiple incompatible meanings.
  - Rename or split readiness labels in aoa-skills generated matrices so eval_floor_ready, boundary_ready, and promotion_ready are distinguishable.
  - Define a seam budget for aoa-skills so delivery/runtime/distribution surfaces know when they must move to routing/sdk/runtime.
  - Give eval bundles skill-style traceability fields: repo, commit, path, lifted sections.
  - Add secondary_skill_dependencies / secondary_technique_dependencies or adjacent_execution_lanes to eval metadata so real execution adjacency can be acknowledged without inflating the primary claim.
  - For the AOA-T-0001 change spine, either admit AOA-T-0002 as a secondary dependency where fixture logic already relies on source-of-truth boundaries, or say explicitly that the proof claim excludes it.
  - Strengthen the paper trail for aoa-change-protocol and aoa-tdd-slice so flagship canonical skills do not look orally blessed while neighbors have stronger promotion artifacts.
  - Fix aoa-adr-write lineage metadata so AOA-T-0002 does not disappear in candidate review surfaces, and add at least one proof surface for canonical ADR placement/reachability.

## P2

### WS11 · Onboarding, support matrix, and release clarity
- Repos: 8Dionysus profile surfaces, Agents-of-Abyss, aoa-sdk, aoa-skills, abyss-stack, ATM10-Agent
- Summary: Lower onboarding tax and make platform/release posture explicit for humans and downstream consumers.
- Key tasks:
  - Publish one short canonical onboarding path for understanding the ecosystem and one for standing up a consumer/product edge.
  - Publish a support matrix for Python versions, OS ownership, action pinning expectations, and external validation dependencies.
  - Make release semantics readable across the federation: what a v0.1.0 means, what snapshot cadence means, and how compatibility is expressed.
  - Document CI tiers in public navigation where the repo already has them in workflows (unit / contract / smoke / nightly / hardware-gated) so readers do not need YAML archaeology.

## P3

### WS12 · ATM10-Agent preliminary endcap
- Repos: ATM10-Agent, abyss-stack, aoa-sdk
- Summary: Carry forward the shallow first-wave ATM10 observations without pretending a deep dedicated audit has already happened.
- Key tasks:
  - Add a release train or milestone snapshot cadence so the product edge is not trusted only through main-branch drift.
  - Make the CI/test tier map explicit in root navigation: unit, contract, smoke, nightly, security, hardware-gated.
  - Write and enforce a supported-profile contract between Windows/OpenVINO/PowerShell product edge expectations and the Fedora-first abyss-stack runtime posture.
  - Watch for hidden monolith growth: keep gateway, voice, automation, pilot runtime, KAG, and hardware-specific behavior behind explicit contracts and bounded modules.
