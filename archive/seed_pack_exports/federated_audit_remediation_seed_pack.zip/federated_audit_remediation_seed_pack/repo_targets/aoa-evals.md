# aoa-evals

Proof layer; should become a louder canary and a more exact lineage carrier.

## Workstream order for this repo

### WS01 · Federation compatibility, inventory, and release semantics
- Priority: P0
- Why it matters here: Turn compatibility and federation inventory into explicit machine-checked contracts rather than scattered repo-local assumptions.
- Tasks to land here:
  - Lift the compatibility map out of aoa-sdk docs into a federation-wide BOM or release matrix anchored near Agents-of-Abyss; every cross-repo machine-read surface must be listed, versioned, or explicitly strict-shape versionless.
  - Unify the vocabulary for version fields and compatibility status across repos; stop leaving meaning-bearing surfaces versionless without an explicit strict-shape policy and validator.
  - Expand Agents-of-Abyss/generated/ecosystem_registry.min.json into a true federation inventory or split it into core_inventory plus supporting_surfaces_inventory; include aoa-sdk explicitly.
  - Publish one canonical onboarding builder path across the public profile surfaces: profile -> Agents-of-Abyss -> aoa-sdk -> consumer/product edge.
  - Define federation-wide release semantics so repo tags mean compatible snapshots rather than isolated local milestones.
- Acceptance signals:
  - A single machine-readable compatibility/BOM surface exists and is referenced by the consumer spine and canaries.
  - ecosystem_registry (or its replacement split) covers the repos publicly claimed by the federation center.
  - Versionless cross-repo surfaces are either eliminated or backed by strict-shape enforcement.

### WS07 · Techniques → skills → evals traceability and maturity hardening
- Priority: P1
- Why it matters here: Tighten proof lineage and maturity language so execution, boundary coverage, and proof maturity remain distinguishable and traceable end-to-end.
- Tasks to land here:
  - Add a latest-sibling canary that exercises the technique -> skill -> eval rail, not only local release checks.
  - Publish a federation legend for defaultness, execution evidence, and proof maturity; stop overloading canonical/ready into multiple incompatible meanings.
  - Rename or split readiness labels in aoa-skills generated matrices so eval_floor_ready, boundary_ready, and promotion_ready are distinguishable.
  - Define a seam budget for aoa-skills so delivery/runtime/distribution surfaces know when they must move to routing/sdk/runtime.
  - Give eval bundles skill-style traceability fields: repo, commit, path, lifted sections.
  - Add secondary_skill_dependencies / secondary_technique_dependencies or adjacent_execution_lanes to eval metadata so real execution adjacency can be acknowledged without inflating the primary claim.
  - For the AOA-T-0001 change spine, either admit AOA-T-0002 as a secondary dependency where fixture logic already relies on source-of-truth boundaries, or say explicitly that the proof claim excludes it.
  - Strengthen the paper trail for aoa-change-protocol and aoa-tdd-slice so flagship canonical skills do not look orally blessed while neighbors have stronger promotion artifacts.
  - Fix aoa-adr-write lineage metadata so AOA-T-0002 does not disappear in candidate review surfaces, and add at least one proof surface for canonical ADR placement/reachability.
- Acceptance signals:
  - Eval metadata can point back to exact upstream sections.
  - Maturity labels are semantically separated and legible to routing/consumers.
  - Decision-doc authority lanes have at least one bounded proof or an explicit choice to remain skill-governed.

### WS10 · Federation-wide CI/canary posture
- Priority: P0
- Why it matters here: Turn the current uneven watchtower pattern into a more even nervous system with fewer correlated blind spots.
- Tasks to land here:
  - Promote aoa-evals into a scheduled latest-sibling canary tower, not only a pinned sibling validator.
  - Give aoa-sdk both a pinned sibling matrix and a scheduled latest-sibling canary.
  - Add source-side smoke in Agents-of-Abyss and Tree-of-Sophia so sources hear seam fractures before or alongside downstream consumers.
  - Add abyss-stack mirror canaries for the handoff surfaces it already claims as roots.
  - Stagger or diversify canary schedules and/or shapes so routing/playbooks/kag are not perfectly synchronized blind spots.
  - Document and normalize action pinning posture across the federation.
- Acceptance signals:
  - At least one canary exists for each major consumer/source/control-plane cluster.
  - Canary schedules are not perfectly correlated across the core towers.
  - Action pinning policy is explicit and followed by runtime/infra repos too.

## Validation
- python scripts/build_catalog.py --check
- python scripts/validate_repo.py
- pytest