# 8Dionysus profile surfaces

Public profile and entry route surfaces; reduce onboarding tax and ambiguity.

## Workstream order for this repo

### WS11 · Onboarding, support matrix, and release clarity
- Priority: P2
- Why it matters here: Lower onboarding tax and make platform/release posture explicit for humans and downstream consumers.
- Tasks to land here:
  - Publish one short canonical onboarding path for understanding the ecosystem and one for standing up a consumer/product edge.
  - Publish a support matrix for Python versions, OS ownership, action pinning expectations, and external validation dependencies.
  - Make release semantics readable across the federation: what a v0.1.0 means, what snapshot cadence means, and how compatibility is expressed.
  - Document CI tiers in public navigation where the repo already has them in workflows (unit / contract / smoke / nightly / hardware-gated) so readers do not need YAML archaeology.
- Acceptance signals:
  - A newcomer can find the shortest path without reading every charter first.
  - Support claims across Fedora-first, Windows-usable, Python 3.11/3.12, and external validators are public and explicit.
  - Release labels are interpretable without repo-specific folklore.

## Validation
- public-surface review only