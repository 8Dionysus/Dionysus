# aoa-sdk

Consumer spine; currently too self-validated for the breadth it reads.

## Workstream order for this repo

### WS01 · Federation compatibility, inventory, and release semantics
- Priority: P0
- Why it matters here: Turn compatibility and federation inventory into explicit machine-checked contracts rather than scattered repo-local assumptions.
- Tasks to land here:
  - Lift the compatibility map out of aoa-sdk docs into a federation-wide BOM or release matrix anchored near Agents-of-Abyss; every cross-repo machine-read surface must be listed, versioned, or explicitly strict-shape versionless.
  - Unify the vocabulary for version fields and compatibility status across repos; stop leaving meaning-bearing surfaces versionless without an explicit strict-shape policy and validator.
  - Expand Agents-of-Abyss/generated/ecosystem_registry.min.json into a true federation inventory or split it into core_inventory plus supporting_surfaces_inventory; include aoa-sdk explicitly.
  - Publish one canonical onboarding builder path across the public profile surfaces: profile -> Agents-of-Abyss -> aoa-sdk -> consumer/product edge.
  - Define federation-wide release semantics so repo tags mean compatible snapshots rather than isolated local milestones.
- Acceptance signals:
  - A single machine-readable compatibility/BOM surface exists and is referenced by the consumer spine and canaries.
  - ecosystem_registry (or its replacement split) covers the repos publicly claimed by the federation center.
  - Versionless cross-repo surfaces are either eliminated or backed by strict-shape enforcement.

### WS02 · Control-plane hardening: aoa-routing × aoa-sdk × aoa-playbooks
- Priority: P0
- Why it matters here: Seal the control-plane seam so routing, consumer loading, and scenario composition do not drift into overlap or false-green compatibility.
- Tasks to land here:
  - Wrap playbook_activation_surfaces.min and playbook_federation_surfaces.min in a versioned envelope, or enforce true strict-shape validation for their versionless form inside the compatibility layer.
  - Remove the raw path fallback in RoutingAPI inspect/expand for route-directed public surfaces; new routed surfaces must not load unless an explicit compatibility rule exists.
  - Add a pinned sibling matrix and a scheduled latest-sibling canary to aoa-sdk; run the public compatibility check in CI, not only in docs.
  - Strengthen the semantic split between activation_surface and federation_surface in the SDK API and naming so validator-facing closure surfaces are not mistaken for runtime recipes.
  - Write an explicit non-overlap pact between routing, sdk, and playbooks: who decides where to go, who loads/normalizes, who composes scenarios, and what each layer must not absorb.
- Acceptance signals:
  - No route-directed public surface can bypass compatibility policy.
  - The SDK CI exercises live sibling surfaces and fails on drift.
  - playbook activation and federation surfaces are distinguishable in both docs and API shape.

### WS10 · Federation-wide CI/canary posture
- Priority: P0
- Why it matters here: Turn the current uneven watchtower pattern into a more even nervous system with fewer correlated blind spots.
- Tasks to land here:
  - Promote aoa-evals into a scheduled latest-sibling canary tower, not only a pinned sibling validator.
  - Give aoa-sdk both a pinned sibling matrix and a scheduled latest-sibling canary.
  - Add source-side smoke in Agents-of-Abyss and Tree-of-Sophia so sources hear seam fractures before or alongside downstream consumers.
  - Add abyss-stack mirror canaries for the handoff surfaces it already claims as roots.
  - Stagger or diversify canary schedules and/or shapes so routing/playbooks/kag are not perfectly synchronized blind spots.
  - Document and normalize action pinning posture across the federation.
- Acceptance signals:
  - At least one canary exists for each major consumer/source/control-plane cluster.
  - Canary schedules are not perfectly correlated across the core towers.
  - Action pinning policy is explicit and followed by runtime/infra repos too.

### WS11 · Onboarding, support matrix, and release clarity
- Priority: P2
- Why it matters here: Lower onboarding tax and make platform/release posture explicit for humans and downstream consumers.
- Tasks to land here:
  - Publish one short canonical onboarding path for understanding the ecosystem and one for standing up a consumer/product edge.
  - Publish a support matrix for Python versions, OS ownership, action pinning expectations, and external validation dependencies.
  - Make release semantics readable across the federation: what a v0.1.0 means, what snapshot cadence means, and how compatibility is expressed.
  - Document CI tiers in public navigation where the repo already has them in workflows (unit / contract / smoke / nightly / hardware-gated) so readers do not need YAML archaeology.
- Acceptance signals:
  - A newcomer can find the shortest path without reading every charter first.
  - Support claims across Fedora-first, Windows-usable, Python 3.11/3.12, and external validators are public and explicit.
  - Release labels are interpretable without repo-specific folklore.

### WS12 · ATM10-Agent preliminary endcap
- Priority: P3
- Why it matters here: Carry forward the shallow first-wave ATM10 observations without pretending a deep dedicated audit has already happened.
- Tasks to land here:
  - Add a release train or milestone snapshot cadence so the product edge is not trusted only through main-branch drift.
  - Make the CI/test tier map explicit in root navigation: unit, contract, smoke, nightly, security, hardware-gated.
  - Write and enforce a supported-profile contract between Windows/OpenVINO/PowerShell product edge expectations and the Fedora-first abyss-stack runtime posture.
  - Watch for hidden monolith growth: keep gateway, voice, automation, pilot runtime, KAG, and hardware-specific behavior behind explicit contracts and bounded modules.
- Acceptance signals:
  - ATM10 has public snapshots/releases or clearly named milestones.
  - Readers can see test tiers without opening workflow YAML.
  - Platform contracts between ATM10 and abyss-stack are explicit.

## Validation
- python -m pytest -q
- python -m ruff check .
- python -m mypy src
- python -m build