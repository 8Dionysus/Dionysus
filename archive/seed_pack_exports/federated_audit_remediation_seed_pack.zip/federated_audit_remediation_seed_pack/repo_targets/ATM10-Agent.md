# ATM10-Agent

Product edge preliminary endcap only in this pack.

## Workstream order for this repo

### WS11 · Onboarding, support matrix, and release clarity
- Priority: P2
- Why it matters here: Lower onboarding tax and make platform/release posture explicit for humans and downstream consumers.
- Tasks to land here:
  - Publish one short canonical onboarding path for understanding the ecosystem and one for standing up a consumer/product edge.
  - Publish a support matrix for Python versions, OS ownership, action pinning expectations, and external validation dependencies.
  - Make release semantics readable across the federation: what a v0.1.0 means, what snapshot cadence means, and how compatibility is expressed.
  - Document CI tiers in public navigation where the repo already has them in workflows (unit / contract / smoke / nightly / hardware-gated) so readers do not need YAML archaeology.
- Acceptance signals:
  - A newcomer can find the shortest path without reading every charter first.
  - Support claims across Fedora-first, Windows-usable, Python 3.11/3.12, and external validators are public and explicit.
  - Release labels are interpretable without repo-specific folklore.

### WS12 · ATM10-Agent preliminary endcap
- Priority: P3
- Why it matters here: Carry forward the shallow first-wave ATM10 observations without pretending a deep dedicated audit has already happened.
- Tasks to land here:
  - Add a release train or milestone snapshot cadence so the product edge is not trusted only through main-branch drift.
  - Make the CI/test tier map explicit in root navigation: unit, contract, smoke, nightly, security, hardware-gated.
  - Write and enforce a supported-profile contract between Windows/OpenVINO/PowerShell product edge expectations and the Fedora-first abyss-stack runtime posture.
  - Watch for hidden monolith growth: keep gateway, voice, automation, pilot runtime, KAG, and hardware-specific behavior behind explicit contracts and bounded modules.
- Acceptance signals:
  - ATM10 has public snapshots/releases or clearly named milestones.
  - Readers can see test tiers without opening workflow YAML.
  - Platform contracts between ATM10 and abyss-stack are explicit.

## Validation
- preliminary only: use repo-native validation when the dedicated audit starts

## Preliminary-only note

This file preserves only the shallow ATM10 observations from the first wave.
Do not treat it as a substitute for a dedicated ATM10-only audit.