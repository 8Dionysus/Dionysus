# Tree-of-Sophia

Source authority for ToS; source-first route needs stronger machine posture.

## Workstream order for this repo

### WS05 · Source-first ToS/KAG routing hardening
- Priority: P1
- Why it matters here: Keep source-owned ToS entry stronger in ergonomics so derived retrieval never becomes the de facto throne by being easier to enter.
- Tasks to land here:
  - Promote a narrow tos_entry_route (or equivalent typed active kind) into the federation entry ABI instead of leaving the ToS path structurally second-class.
  - Add route-local reentry for tos-root that can return directly to the bounded tiny-entry seam, not only to the constitutional charter.
  - Add source-side federation smoke in Tree-of-Sophia against aoa-kag and aoa-routing.
  - Define a density or phase budget so KAG adjunct retrieval cannot outgrow the formal source-entry seam faster than the source path itself matures.
  - Clarify the overloaded authority vocabulary across charter authority, route authority mirror, and export entry surfaces.
- Acceptance signals:
  - A source-first ToS route is active in the ABI and testable.
  - ToS reentry lands on a live bounded seam, not only on the constitution.
  - Derived retrieval growth is explicitly budgeted relative to source-entry maturity.

### WS10 · Federation-wide CI/canary posture
- Priority: P0
- Why it matters here: Turn the current uneven watchtower pattern into a more even nervous system with fewer correlated blind spots.
- Tasks to land here:
  - Promote aoa-evals into a scheduled latest-sibling canary tower, not only a pinned sibling validator.
  - Give aoa-sdk both a pinned sibling matrix and a scheduled latest-sibling canary.
  - Add source-side smoke in Agents-of-Abyss and Tree-of-Sophia so sources hear seam fractures before or alongside downstream consumers.
  - Add abyss-stack mirror canaries for the handoff surfaces it already claims as roots.
  - Stagger or diversify canary schedules and/or shapes so routing/playbooks/kag are not perfectly synchronized blind spots.
  - Document and normalize action pinning posture across the federation.
- Acceptance signals:
  - At least one canary exists for each major consumer/source/control-plane cluster.
  - Canary schedules are not perfectly correlated across the core towers.
  - Action pinning policy is explicit and followed by runtime/infra repos too.

## Validation
- python scripts/validate_kag_export.py
- pytest