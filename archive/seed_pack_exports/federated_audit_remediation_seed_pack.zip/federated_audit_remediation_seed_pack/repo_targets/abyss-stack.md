# abyss-stack

Runtime body and mirror substrate; must hear handoff drift earlier.

## Workstream order for this repo

### WS06 · Seed-garden, ecosystem-center, and runtime-body hardening
- Priority: P0
- Why it matters here: Make the constitutional center, seed garden, and runtime body hear drift earlier and describe the real federation they already coordinate.
- Tasks to land here:
  - Expand or split the ecosystem registry so the machine inventory matches the federation publicly claimed by Agents-of-Abyss.
  - Add an advisory owner-repo reality canary to Dionysus that checks named target surfaces, validator anchors, and planting state before trusting staged packs.
  - Update staged notes in Dionysus with lifecycle_status, lifecycle_note, and reality_checked_at as soon as upstream landings merge; do not let staging memory outlive reality.
  - Add sibling mirror canaries in abyss-stack for memo/playbooks first, then routing and Tree-of-Sophia handoff surfaces.
  - Pin GitHub Actions in abyss-stack to commit SHAs and add at least one bounded Windows bridge smoke beyond syntax parsing.
  - Keep Dionysus transplant-focused; do not let it re-accumulate live repo-owned doctrine or runtime glue that now has a home elsewhere.
- Acceptance signals:
  - Agents-of-Abyss machine inventory matches public federation claims.
  - Dionysus can detect stale prep-pack reality without manual archaeology.
  - abyss-stack can detect handoff/mirror drift across its declared source roots.

### WS10 · Federation-wide CI/canary posture
- Priority: P0
- Why it matters here: Turn the current uneven watchtower pattern into a more even nervous system with fewer correlated blind spots.
- Tasks to land here:
  - Promote aoa-evals into a scheduled latest-sibling canary tower, not only a pinned sibling validator.
  - Give aoa-sdk both a pinned sibling matrix and a scheduled latest-sibling canary.
  - Add source-side smoke in Agents-of-Abyss and Tree-of-Sophia so sources hear seam fractures before or alongside downstream consumers.
  - Add abyss-stack mirror canaries for the handoff surfaces it already claims as roots.
  - Stagger or diversify canary schedules and/or shapes so routing/playbooks/kag are not perfectly synchronized blind spots.
  - Document and normalize action pinning posture across the federation.
- Acceptance signals:
  - At least one canary exists for each major consumer/source/control-plane cluster.
  - Canary schedules are not perfectly correlated across the core towers.
  - Action pinning policy is explicit and followed by runtime/infra repos too.

### WS11 · Onboarding, support matrix, and release clarity
- Priority: P2
- Why it matters here: Lower onboarding tax and make platform/release posture explicit for humans and downstream consumers.
- Tasks to land here:
  - Publish one short canonical onboarding path for understanding the ecosystem and one for standing up a consumer/product edge.
  - Publish a support matrix for Python versions, OS ownership, action pinning expectations, and external validation dependencies.
  - Make release semantics readable across the federation: what a v0.1.0 means, what snapshot cadence means, and how compatibility is expressed.
  - Document CI tiers in public navigation where the repo already has them in workflows (unit / contract / smoke / nightly / hardware-gated) so readers do not need YAML archaeology.
- Acceptance signals:
  - A newcomer can find the shortest path without reading every charter first.
  - Support claims across Fedora-first, Windows-usable, Python 3.11/3.12, and external validators are public and explicit.
  - Release labels are interpretable without repo-specific folklore.

### WS12 · ATM10-Agent preliminary endcap
- Priority: P3
- Why it matters here: Carry forward the shallow first-wave ATM10 observations without pretending a deep dedicated audit has already happened.
- Tasks to land here:
  - Add a release train or milestone snapshot cadence so the product edge is not trusted only through main-branch drift.
  - Make the CI/test tier map explicit in root navigation: unit, contract, smoke, nightly, security, hardware-gated.
  - Write and enforce a supported-profile contract between Windows/OpenVINO/PowerShell product edge expectations and the Fedora-first abyss-stack runtime posture.
  - Watch for hidden monolith growth: keep gateway, voice, automation, pilot runtime, KAG, and hardware-specific behavior behind explicit contracts and bounded modules.
- Acceptance signals:
  - ATM10 has public snapshots/releases or clearly named milestones.
  - Readers can see test tiers without opening workflow YAML.
  - Platform contracts between ATM10 and abyss-stack are explicit.

## Validation
- python scripts/validate_stack.py
- repo-native workflow smoke / pytest equivalent