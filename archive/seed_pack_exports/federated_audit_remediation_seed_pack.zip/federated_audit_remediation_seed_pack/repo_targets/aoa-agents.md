# aoa-agents

Role and cohort contract owner; scope grammar and conditional tier law matter here.

## Workstream order for this repo

### WS01 · Federation compatibility, inventory, and release semantics
- Priority: P0
- Why it matters here: Turn compatibility and federation inventory into explicit machine-checked contracts rather than scattered repo-local assumptions.
- Tasks to land here:
  - Lift the compatibility map out of aoa-sdk docs into a federation-wide BOM or release matrix anchored near Agents-of-Abyss; every cross-repo machine-read surface must be listed, versioned, or explicitly strict-shape versionless.
  - Unify the vocabulary for version fields and compatibility status across repos; stop leaving meaning-bearing surfaces versionless without an explicit strict-shape policy and validator.
  - Expand Agents-of-Abyss/generated/ecosystem_registry.min.json into a true federation inventory or split it into core_inventory plus supporting_surfaces_inventory; include aoa-sdk explicitly.
  - Publish one canonical onboarding builder path across the public profile surfaces: profile -> Agents-of-Abyss -> aoa-sdk -> consumer/product edge.
  - Define federation-wide release semantics so repo tags mean compatible snapshots rather than isolated local milestones.
- Acceptance signals:
  - A single machine-readable compatibility/BOM surface exists and is referenced by the consumer spine and canaries.
  - ecosystem_registry (or its replacement split) covers the repos publicly claimed by the federation center.
  - Versionless cross-repo surfaces are either eliminated or backed by strict-shape enforcement.

### WS03 · Memory and agent contract hardening
- Priority: P0
- Why it matters here: Unify the grammar of memory rights, scopes, and return posture so agent roles, checkpoints, and memory objects stop speaking adjacent dialects.
- Tasks to land here:
  - Create one federation-wide memory_scope grammar and make agent-profile.schema.json, self-agent checkpoint surfaces, and memo objects all use it.
  - Add a typed posture slice to memory object catalogs/capsules for scope, access/access_class, review_state, current_recall, provenance thread refs, and route/source pointers.
  - Expand sibling-seam CI for aoa-agents and aoa-memo so the published contract is tested against routing and playbooks, not mostly against local surfaces.
  - Encode the conditional tier law that archivist/distill paths require memory-keeper participation when distillation or archivist-specific duties are active.
  - Move alpha_curated out of the agent-canonical registry into a playbook-owned or consumer-derived overlay if it remains scenario-specific.
  - Narrow and mark review_trace -> audit_event semantics so confirmed audit events cannot quietly overstate provenance or human review weight.
- Acceptance signals:
  - Scope values are normalized across agents, checkpoints, and memo objects.
  - Consumers can read posture-critical fields without prose parsing.
  - Archivist/distill flows are structurally impossible without their required role support.

### WS10 · Federation-wide CI/canary posture
- Priority: P0
- Why it matters here: Turn the current uneven watchtower pattern into a more even nervous system with fewer correlated blind spots.
- Tasks to land here:
  - Promote aoa-evals into a scheduled latest-sibling canary tower, not only a pinned sibling validator.
  - Give aoa-sdk both a pinned sibling matrix and a scheduled latest-sibling canary.
  - Add source-side smoke in Agents-of-Abyss and Tree-of-Sophia so sources hear seam fractures before or alongside downstream consumers.
  - Add abyss-stack mirror canaries for the handoff surfaces it already claims as roots.
  - Stagger or diversify canary schedules and/or shapes so routing/playbooks/kag are not perfectly synchronized blind spots.
  - Document and normalize action pinning posture across the federation.
- Acceptance signals:
  - At least one canary exists for each major consumer/source/control-plane cluster.
  - Canary schedules are not perfectly correlated across the core towers.
  - Action pinning policy is explicit and followed by runtime/infra repos too.

## Validation
- current repo-validation workflow
- generated drift check
- pytest