# Dionysus

Seed garden and transport layer; staging truth must remain weaker than owner-repo truth.

## Workstream order for this repo

### WS01 · Federation compatibility, inventory, and release semantics
- Priority: P0
- Why it matters here: Turn compatibility and federation inventory into explicit machine-checked contracts rather than scattered repo-local assumptions.
- Tasks to land here:
  - Lift the compatibility map out of aoa-sdk docs into a federation-wide BOM or release matrix anchored near Agents-of-Abyss; every cross-repo machine-read surface must be listed, versioned, or explicitly strict-shape versionless.
  - Unify the vocabulary for version fields and compatibility status across repos; stop leaving meaning-bearing surfaces versionless without an explicit strict-shape policy and validator.
  - Expand Agents-of-Abyss/generated/ecosystem_registry.min.json into a true federation inventory or split it into core_inventory plus supporting_surfaces_inventory; include aoa-sdk explicitly.
  - Publish one canonical onboarding builder path across the public profile surfaces: profile -> Agents-of-Abyss -> aoa-sdk -> consumer/product edge.
  - Define federation-wide release semantics so repo tags mean compatible snapshots rather than isolated local milestones.
- Acceptance signals:
  - A single machine-readable compatibility/BOM surface exists and is referenced by the consumer spine and canaries.
  - ecosystem_registry (or its replacement split) covers the repos publicly claimed by the federation center.
  - Versionless cross-repo surfaces are either eliminated or backed by strict-shape enforcement.

### WS06 · Seed-garden, ecosystem-center, and runtime-body hardening
- Priority: P0
- Why it matters here: Make the constitutional center, seed garden, and runtime body hear drift earlier and describe the real federation they already coordinate.
- Tasks to land here:
  - Expand or split the ecosystem registry so the machine inventory matches the federation publicly claimed by Agents-of-Abyss.
  - Add an advisory owner-repo reality canary to Dionysus that checks named target surfaces, validator anchors, and planting state before trusting staged packs.
  - Update staged notes in Dionysus with lifecycle_status, lifecycle_note, and reality_checked_at as soon as upstream landings merge; do not let staging memory outlive reality.
  - Add sibling mirror canaries in abyss-stack for memo/playbooks first, then routing and Tree-of-Sophia handoff surfaces.
  - Pin GitHub Actions in abyss-stack to commit SHAs and add at least one bounded Windows bridge smoke beyond syntax parsing.
  - Keep Dionysus transplant-focused; do not let it re-accumulate live repo-owned doctrine or runtime glue that now has a home elsewhere.
- Acceptance signals:
  - Agents-of-Abyss machine inventory matches public federation claims.
  - Dionysus can detect stale prep-pack reality without manual archaeology.
  - abyss-stack can detect handoff/mirror drift across its declared source roots.

## Validation
- python scripts/validate_seed_surfaces.py