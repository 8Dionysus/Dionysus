# aoa-kag

Derived retrieval substrate; must remain subordinate to source-owned meaning.

## Workstream order for this repo

### WS01 · Federation compatibility, inventory, and release semantics
- Priority: P0
- Why it matters here: Turn compatibility and federation inventory into explicit machine-checked contracts rather than scattered repo-local assumptions.
- Tasks to land here:
  - Lift the compatibility map out of aoa-sdk docs into a federation-wide BOM or release matrix anchored near Agents-of-Abyss; every cross-repo machine-read surface must be listed, versioned, or explicitly strict-shape versionless.
  - Unify the vocabulary for version fields and compatibility status across repos; stop leaving meaning-bearing surfaces versionless without an explicit strict-shape policy and validator.
  - Expand Agents-of-Abyss/generated/ecosystem_registry.min.json into a true federation inventory or split it into core_inventory plus supporting_surfaces_inventory; include aoa-sdk explicitly.
  - Publish one canonical onboarding builder path across the public profile surfaces: profile -> Agents-of-Abyss -> aoa-sdk -> consumer/product edge.
  - Define federation-wide release semantics so repo tags mean compatible snapshots rather than isolated local milestones.
- Acceptance signals:
  - A single machine-readable compatibility/BOM surface exists and is referenced by the consumer spine and canaries.
  - ecosystem_registry (or its replacement split) covers the repos publicly claimed by the federation center.
  - Versionless cross-repo surfaces are either eliminated or backed by strict-shape enforcement.

### WS05 · Source-first ToS/KAG routing hardening
- Priority: P1
- Why it matters here: Keep source-owned ToS entry stronger in ergonomics so derived retrieval never becomes the de facto throne by being easier to enter.
- Tasks to land here:
  - Promote a narrow tos_entry_route (or equivalent typed active kind) into the federation entry ABI instead of leaving the ToS path structurally second-class.
  - Add route-local reentry for tos-root that can return directly to the bounded tiny-entry seam, not only to the constitutional charter.
  - Add source-side federation smoke in Tree-of-Sophia against aoa-kag and aoa-routing.
  - Define a density or phase budget so KAG adjunct retrieval cannot outgrow the formal source-entry seam faster than the source path itself matures.
  - Clarify the overloaded authority vocabulary across charter authority, route authority mirror, and export entry surfaces.
- Acceptance signals:
  - A source-first ToS route is active in the ABI and testable.
  - ToS reentry lands on a live bounded seam, not only on the constitution.
  - Derived retrieval growth is explicitly budgeted relative to source-entry maturity.

### WS10 · Federation-wide CI/canary posture
- Priority: P0
- Why it matters here: Turn the current uneven watchtower pattern into a more even nervous system with fewer correlated blind spots.
- Tasks to land here:
  - Promote aoa-evals into a scheduled latest-sibling canary tower, not only a pinned sibling validator.
  - Give aoa-sdk both a pinned sibling matrix and a scheduled latest-sibling canary.
  - Add source-side smoke in Agents-of-Abyss and Tree-of-Sophia so sources hear seam fractures before or alongside downstream consumers.
  - Add abyss-stack mirror canaries for the handoff surfaces it already claims as roots.
  - Stagger or diversify canary schedules and/or shapes so routing/playbooks/kag are not perfectly synchronized blind spots.
  - Document and normalize action pinning posture across the federation.
- Acceptance signals:
  - At least one canary exists for each major consumer/source/control-plane cluster.
  - Canary schedules are not perfectly correlated across the core towers.
  - Action pinning policy is explicit and followed by runtime/infra repos too.

## Validation
- current repo-validation workflow
- current compatibility-canary workflow