# Federated Audit Remediation Seed Pack

This zip-seed turns the full audit dialogue into a bounded remediation pack for Codex.

## Read in this order

1. `seed_federated_audit_remediation_pack.md`
2. `seed_federated_audit_remediation_pack.map.yaml`
3. `WORKSTREAMS.yaml`
4. `EXECUTION_ORDER.md`
5. `repo_targets/<current-repo>.md`
6. `VALIDATION_MATRIX.md`
7. `PATCH_SNIPPETS.md` only when landing changes

## What this pack is for

- turning the dialogue into owner-repo workstreams
- preserving ordering, dependencies, and non-goals
- giving Codex both human-readable and machine-readable landing guidance
- keeping ATM10-Agent separate as a preliminary endcap rather than mixing it into the deeper federation fixes

## What this pack is not for

- treating this pack as stronger than owner-repo reality
- sweeping rewrites across unrelated folders
- silently moving meaning out of owning repos and back into a transport pack
- pretending ATM10-Agent already received a deep dedicated audit here

## Immediate landing order

1. federation compatibility and inventory hardening
2. control-plane fixes in `aoa-routing` × `aoa-sdk` × `aoa-playbooks`
3. `aoa-agents` / `aoa-memo` contract hardening and return-path normalization
4. governance-surface honesty plus `aoa-skills` CI hardening
5. federation-wide canary expansion
6. techniques → skills → evals traceability cleanup
7. onboarding/support matrix/release clarity
8. ATM10-Agent preliminary endcap

## Working rule

Prefer the smallest coherent landing slice that leaves:
- one human-readable surface
- one structural artifact
- one validation trace
- explicit non-goals

Do not treat a green summary surface as proof if the underlying review or compatibility artifact is still missing.
