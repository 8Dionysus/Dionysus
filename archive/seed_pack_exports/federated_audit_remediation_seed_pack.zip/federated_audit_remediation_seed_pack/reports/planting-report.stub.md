# Planting Report

## Metadata
- Date: 2026-04-05
- Wave: federated-audit-remediation-pack
- Seed: seed.audit.federated-audit-remediation-pack.v0
- Source ref: federated_audit_remediation_seed_pack.zip
- Target repo:
- Planting status: proposed
- PR / commit / issue:
- Maintainer:

## Donor provenance
- Donor repo / ref: audit dialogue in ChatGPT
- Transplant policy: pattern_extract
- What survives: bounded remediation workstreams, ordering, and non-goals
- What stays behind: conversational cadence, intermediate prose, duplicate explanations
- Redistribution obligations: none

## Contract being planted
Write 2 to 5 sentences on what real lie, false green, drift path, or contract ambiguity this landing removes.

## Landed surfaces
- Human-readable surface:
- Structural surface:
- Validation surface:

## Structural artifact
Name the one artifact that makes the planting materially inspectable.

## Validation
- Command run:
- Result:
- Manual review notes:

## Deferred zones / non-goals
-

## Risks / follow-ups
-

## Vocabulary preserved
- compatibility
- canary
- strict-shape
- source-first
- default_reference
- stay_evaluated
- return-ready
- smallest coherent landing
