# Patch Snippets and Surgical Entry Points

This file is not literal patch text.
It is the shortest list of likely entry points so Codex can cut bounded slices without wandering.

## WS01 federation compatibility and inventory
- `Agents-of-Abyss/generated/ecosystem_registry.min.json`
- ecosystem validator surfaces in `Agents-of-Abyss`
- `aoa-sdk/docs/versioning.md`
- any shared compatibility/BOM surface introduced near the ecosystem center
- public profile / ecosystem navigation surfaces

## WS02 control-plane hardening
- `aoa-sdk` compatibility layer
- `aoa-sdk` routing inspect/expand load path
- `aoa-playbooks` activation/federation surface docs and schemas
- `aoa-routing` docs that define public route ownership and ABI

## WS03 memory and agent contracts
- `aoa-agents/schemas/agent-profile.schema.json`
- self-agent checkpoint schema / generated bindings
- `aoa-agents/generated/cohort_composition_registry.json`
- `aoa-agents/generated/runtime_seam_bindings.json`
- `aoa-memo` object catalog / capsule / writeback builders
- `aoa-memo/generated/runtime_writeback_targets.min.json`

## WS04 memo-routing return path
- `aoa-memo/docs/ROUTING_MEMORY_ADOPTION.md`
- `aoa-memo` recall contracts for object `working.return`
- `aoa-routing/generated/return_navigation_hints.min.json`
- `aoa-routing` task-to-surface hint builders

## WS05 ToS/KAG routing hardening
- `aoa-routing/docs/FEDERATION_ENTRY_ABI.md`
- `aoa-routing` return / reentry hints
- `Tree-of-Sophia` tiny-entry route and export surfaces
- `aoa-kag` export, bridge, and canary surfaces

## WS06 seed garden / ecosystem center / runtime body
- `Dionysus/docs/codex/planting-protocol.md`
- `Dionysus/docs/codex/owner-repo-reality-check.md`
- `Dionysus/seed-registry.yaml`
- lifecycle markers in staged notes
- `abyss-stack/.github/workflows/validate-stack.yml`
- `abyss-stack/docs/PATHS.md`

## WS07 techniques / skills / evals
- `aoa-skills/generated/skill_evaluation_matrix.md`
- `aoa-skills/generated/skill_boundary_matrix.md`
- `aoa-skills/generated/public_surface.md`
- skill review records for `aoa-change-protocol`, `aoa-tdd-slice`, `aoa-source-of-truth-check`, `aoa-adr-write`
- `aoa-evals` bundle metadata and catalog builders
- `aoa-techniques` canonical/maturity guidance

## WS08 governance-surface honesty
- `aoa-skills/templates/CANDIDATE_REVIEW.template.md`
- `aoa-skills/docs/reviews/*`
- `aoa-skills/scripts/skill_review_surface.py`
- `aoa-skills/scripts/skill_governance_surface.py`
- `aoa-skills/scripts/skill_governance_backlog_surface.py`

## WS09 aoa-skills CI
- `aoa-skills/.github/workflows/repo-validation.yml`
- `aoa-skills/.github/workflows/codex-portable-export.yml`
- `aoa-skills/scripts/release_check.py`
- `aoa-skills/scripts/report_technique_drift.py`

## WS10 federation-wide canaries
- `.github/workflows/compatibility-canary.yml` in `aoa-routing`, `aoa-playbooks`, `aoa-kag`
- `aoa-evals` workflow surfaces
- `aoa-sdk` workflow surfaces
- source-side workflow surfaces in `Agents-of-Abyss` and `Tree-of-Sophia`
- `abyss-stack` validate-stack workflow

## WS11 / WS12 docs and ATM10 preliminary endcap
- public profile README
- `Agents-of-Abyss` navigation docs
- `aoa-sdk` README / consumer guidance
- `abyss-stack` platform docs
- `ATM10-Agent` README / manifest / roadmap / workflows
