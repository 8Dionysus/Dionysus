#!/usr/bin/env python3
"""Build the AoA shared-launchers plugin from the bundled template or an alternate skills root."""

from __future__ import annotations

import argparse
from pathlib import Path

from aoa_local_plugin_lib import build_plugin_from_template


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--template-plugin",
        type=Path,
        default=Path(__file__).resolve().parents[1] / "plugin-template" / "aoa-shared-launchers",
        help="Path to the plugin template folder.",
    )
    parser.add_argument(
        "--output-plugin",
        type=Path,
        required=True,
        help="Path where the built plugin folder should be written.",
    )
    parser.add_argument(
        "--skills-root",
        type=Path,
        default=None,
        help="Optional alternate skills root. Each subdirectory with SKILL.md will be copied into skills/.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    output = build_plugin_from_template(
        template_plugin_root=args.template_plugin.resolve(),
        output_plugin_root=args.output_plugin.resolve(),
        skills_root=args.skills_root.resolve() if args.skills_root is not None else None,
    )
    print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
