#!/usr/bin/env python3
"""Install the AoA shared-launchers plugin and patch the correct marketplace file."""

from __future__ import annotations

import argparse
from pathlib import Path

from aoa_local_plugin_lib import install_plugin


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-plugin", type=Path, required=True, help="Path to the plugin folder to install.")
    parser.add_argument("--scope", choices=("repo", "personal"), required=True, help="Installation scope.")
    parser.add_argument(
        "--root",
        type=Path,
        required=True,
        help="Repo/workspace root for repo scope, or HOME directory for personal scope.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    install_path, marketplace_path = install_plugin(
        source_plugin_root=args.source_plugin.resolve(),
        scope=args.scope,
        root=args.root.expanduser().resolve(),
    )
    print(f"installed: {install_path}")
    print(f"marketplace: {marketplace_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
