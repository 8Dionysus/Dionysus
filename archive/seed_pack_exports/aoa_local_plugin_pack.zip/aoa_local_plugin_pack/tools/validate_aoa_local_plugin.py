#!/usr/bin/env python3
"""Validate the AoA shared-launchers plugin against manifest, marketplace, and workspace MCP names."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from aoa_local_plugin_lib import validate_plugin


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--plugin-root", type=Path, required=True, help="Path to the plugin root.")
    parser.add_argument("--workspace-config", type=Path, default=None, help="Optional workspace .codex/config.toml")
    parser.add_argument("--marketplace", type=Path, default=None, help="Optional marketplace.json to validate against.")
    parser.add_argument("--format", choices=("text", "json"), default="text")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    report = validate_plugin(
        plugin_root=args.plugin_root.resolve(),
        workspace_config=args.workspace_config.resolve() if args.workspace_config is not None else None,
        marketplace_path=args.marketplace.resolve() if args.marketplace is not None else None,
    )
    if args.format == "json":
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        print(f"Plugin root: {report['plugin_root']}")
        print(f"Configured MCP servers: {', '.join(report['configured_mcp_servers']) or '(none)'}")
        for error in report["errors"]:
            print(f"error: {error}")
        for warning in report["warnings"]:
            print(f"warning: {warning}")
        for skill in report["skills"]:
            print(f"\n[{skill['name']}]")
            print(f"  path: {skill['path']}")
            print(f"  mcp_dependencies: {', '.join(skill['mcp_dependencies']) or '(none)'}")
            for warning in skill["warnings"]:
                print(f"  warning: {warning}")
            for error in skill["errors"]:
                print(f"  error: {error}")
        print(f"\nResult: {'OK' if report['ok'] else 'FAILED'}")
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
