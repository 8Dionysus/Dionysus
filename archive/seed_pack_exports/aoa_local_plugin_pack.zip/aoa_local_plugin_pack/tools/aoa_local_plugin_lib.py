from __future__ import annotations

import json
import shutil
import re
from pathlib import Path
from typing import Any
import tomllib

import yaml

PLUGIN_NAME = "aoa-shared-launchers"
REPO_MARKETPLACE_NAME = "aoa-local-plugins"
REPO_MARKETPLACE_DISPLAY_NAME = "AoA Local Plugins"
PERSONAL_MARKETPLACE_NAME = "aoa-personal-plugins"
PERSONAL_MARKETPLACE_DISPLAY_NAME = "AoA Personal Plugins"

MCP_REGISTRY: dict[str, dict[str, str]] = {
    "aoa_workspace": {"description": "AoA workspace orientation MCP server", "transport": "stdio"},
    "aoa_stats": {"description": "AoA derived stats MCP server", "transport": "stdio"},
    "dionysus": {"description": "Dionysus seed-route MCP server", "transport": "stdio"},
}

SKILL_SPECS: dict[str, dict[str, Any]] = {
    "aoa-workspace-recon": {
        "display_name": "AoA Workspace Recon",
        "short_description": "Map the AoA sibling workspace and ownership boundaries before cross-repo work.",
        "default_prompt": "Use AoA Workspace Recon to identify the owning repo, supporting surfaces, and the first bounded move for this cross-repo task.",
        "allow_implicit_invocation": True,
        "mcp_dependencies": ["aoa_workspace", "aoa_stats", "dionysus"],
    },
    "aoa-growth-snapshot": {
        "display_name": "AoA Growth Snapshot",
        "short_description": "Produce a bounded AoA growth snapshot across workspace, stats, and seed context.",
        "default_prompt": "Use AoA Growth Snapshot to summarize lineage, seed relevance, and one next bounded move.",
        "allow_implicit_invocation": False,
        "mcp_dependencies": ["aoa_workspace", "aoa_stats", "dionysus"],
    },
    "aoa-seed-route-inspect": {
        "display_name": "AoA Seed Route Inspect",
        "short_description": "Inspect Dionysus staging, wave context, and planting rules for a reviewed candidate.",
        "default_prompt": "Use AoA Seed Route Inspect to determine current lifecycle posture, staging context, and planting constraints.",
        "allow_implicit_invocation": False,
        "mcp_dependencies": ["dionysus"],
    },
    "aoa-config-doctor": {
        "display_name": "AoA Config Doctor",
        "short_description": "Diagnose AoA Codex wiring when launcher skills or MCP servers are missing or disconnected.",
        "default_prompt": "Use AoA Config Doctor to identify missing AoA skills or MCP wiring and the shortest fix path.",
        "allow_implicit_invocation": False,
        "mcp_dependencies": [],
    },
}


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def copy_tree(src: Path, dst: Path) -> None:
    if dst.exists():
        shutil.rmtree(dst)
    shutil.copytree(src, dst)


def find_plugin_manifest(plugin_root: Path) -> Path:
    return plugin_root / ".codex-plugin" / "plugin.json"


def load_plugin_manifest(plugin_root: Path) -> dict[str, Any]:
    path = find_plugin_manifest(plugin_root)
    data = read_json(path)
    if not isinstance(data, dict):
        raise ValueError("Plugin manifest must be a JSON object.")
    return data


def plugin_name_from_manifest(plugin_root: Path) -> str:
    manifest = load_plugin_manifest(plugin_root)
    name = manifest.get("name")
    if not isinstance(name, str) or not name:
        raise ValueError("Plugin manifest missing 'name'.")
    return name


def write_openai_yaml(skill_dir: Path, skill_name: str) -> None:
    spec = SKILL_SPECS.get(skill_name)
    if spec is None:
        return
    payload: dict[str, Any] = {
        "interface": {
            "display_name": spec["display_name"],
            "short_description": spec["short_description"],
            "default_prompt": spec["default_prompt"],
        },
        "policy": {
            "allow_implicit_invocation": bool(spec["allow_implicit_invocation"]),
        },
    }
    tools: list[dict[str, Any]] = []
    for dep in spec["mcp_dependencies"]:
        server = MCP_REGISTRY[dep]
        tools.append(
            {
                "type": "mcp",
                "value": dep,
                "description": server["description"],
                "transport": server["transport"],
            }
        )
    if tools:
        payload["dependencies"] = {"tools": tools}
    text = (
        f"# Optional Codex metadata for {skill_name}\n"
        + yaml.safe_dump(payload, sort_keys=False, allow_unicode=True)
    )
    agents_dir = skill_dir / "agents"
    agents_dir.mkdir(parents=True, exist_ok=True)
    (agents_dir / "openai.yaml").write_text(text, encoding="utf-8")


def iter_skill_dirs(skills_root: Path) -> list[Path]:
    results = []
    if not skills_root.exists():
        return results
    for child in sorted(skills_root.iterdir()):
        if child.is_dir() and (child / "SKILL.md").exists():
            results.append(child)
    return results


def build_plugin_from_template(template_plugin_root: Path, output_plugin_root: Path, skills_root: Path | None = None) -> Path:
    copy_tree(template_plugin_root, output_plugin_root)
    if skills_root is not None:
        target_skills_root = output_plugin_root / "skills"
        if target_skills_root.exists():
            shutil.rmtree(target_skills_root)
        target_skills_root.mkdir(parents=True, exist_ok=True)
        for skill_dir in iter_skill_dirs(skills_root):
            dst = target_skills_root / skill_dir.name
            shutil.copytree(skill_dir, dst)
            write_openai_yaml(dst, skill_dir.name)
    return output_plugin_root


def plugin_install_path_for(scope: str, root: Path, plugin_name: str) -> Path:
    if scope == "repo":
        return root / "plugins" / plugin_name
    if scope == "personal":
        return root / ".codex" / "plugins" / plugin_name
    raise ValueError(f"Unknown scope: {scope}")


def marketplace_path_for(scope: str, root: Path) -> Path:
    return root / ".agents" / "plugins" / "marketplace.json"


def marketplace_entry_for(scope: str, plugin_name: str) -> dict[str, Any]:
    if scope == "repo":
        path = f"./plugins/{plugin_name}"
    elif scope == "personal":
        path = f"./.codex/plugins/{plugin_name}"
    else:
        raise ValueError(f"Unknown scope: {scope}")
    return {
        "name": plugin_name,
        "source": {
            "source": "local",
            "path": path,
        },
        "policy": {
            "installation": "AVAILABLE",
            "authentication": "ON_INSTALL",
        },
        "category": "Productivity",
    }


def marketplace_defaults(scope: str) -> tuple[str, str]:
    if scope == "repo":
        return REPO_MARKETPLACE_NAME, REPO_MARKETPLACE_DISPLAY_NAME
    if scope == "personal":
        return PERSONAL_MARKETPLACE_NAME, PERSONAL_MARKETPLACE_DISPLAY_NAME
    raise ValueError(f"Unknown scope: {scope}")


def merge_marketplace(marketplace_path: Path, entry: dict[str, Any], scope: str) -> None:
    name, display_name = marketplace_defaults(scope)
    if marketplace_path.exists():
        data = read_json(marketplace_path)
        if not isinstance(data, dict):
            raise ValueError("Marketplace JSON must be an object.")
    else:
        data = {
            "name": name,
            "interface": {"displayName": display_name},
            "plugins": [],
        }
    plugins = data.setdefault("plugins", [])
    if not isinstance(plugins, list):
        raise ValueError("Marketplace 'plugins' must be a list.")
    updated = False
    for index, existing in enumerate(plugins):
        if isinstance(existing, dict) and existing.get("name") == entry["name"]:
            plugins[index] = entry
            updated = True
            break
    if not updated:
        plugins.append(entry)
    if "name" not in data or not data["name"]:
        data["name"] = name
    if not isinstance(data.get("interface"), dict):
        data["interface"] = {"displayName": display_name}
    else:
        data["interface"].setdefault("displayName", display_name)
    write_json(marketplace_path, data)


def install_plugin(source_plugin_root: Path, scope: str, root: Path) -> tuple[Path, Path]:
    plugin_name = plugin_name_from_manifest(source_plugin_root)
    install_path = plugin_install_path_for(scope, root, plugin_name)
    install_path.parent.mkdir(parents=True, exist_ok=True)
    copy_tree(source_plugin_root, install_path)
    marketplace_path = marketplace_path_for(scope, root)
    entry = marketplace_entry_for(scope, plugin_name)
    merge_marketplace(marketplace_path, entry, scope)
    return install_path, marketplace_path


def load_workspace_mcp_names(path: Path | None) -> set[str]:
    if path is None:
        return set()
    with path.open("rb") as handle:
        data = tomllib.load(handle)
    mcp_servers = data.get("mcp_servers", {})
    if isinstance(mcp_servers, dict):
        return set(mcp_servers.keys())
    return set()


def skill_name_from_skill_md(path: Path) -> str | None:
    text = path.read_text(encoding="utf-8")
    match = re.search(r"^name:\s*([A-Za-z0-9._-]+)\s*$", text, re.MULTILINE)
    if match:
        return match.group(1)
    return None


def _infer_marketplace_root(marketplace_path: Path) -> Path:
    parts = marketplace_path.parts
    if len(parts) >= 3 and parts[-3:] == (".agents", "plugins", "marketplace.json"):
        return marketplace_path.parents[2]
    return marketplace_path.parent


def validate_openai_yaml(path: Path, configured_mcp_names: set[str]) -> tuple[list[str], list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    dependencies: list[str] = []
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        return ["openai.yaml must be a YAML object"], warnings, dependencies
    interface = data.get("interface")
    if not isinstance(interface, dict):
        warnings.append("missing interface section")
    else:
        if not interface.get("display_name"):
            warnings.append("missing interface.display_name")
        if not interface.get("short_description"):
            warnings.append("missing interface.short_description")
    policy = data.get("policy")
    if not isinstance(policy, dict) or not isinstance(policy.get("allow_implicit_invocation"), bool):
        errors.append("missing or invalid policy.allow_implicit_invocation")
    deps = data.get("dependencies")
    if isinstance(deps, dict):
        tools = deps.get("tools", [])
        if isinstance(tools, list):
            for tool in tools:
                if isinstance(tool, dict) and tool.get("type") == "mcp":
                    value = tool.get("value")
                    if isinstance(value, str):
                        dependencies.append(value)
                        if configured_mcp_names and value not in configured_mcp_names:
                            errors.append(f"unknown MCP dependency: {value}")
    return errors, warnings, dependencies


def validate_plugin(plugin_root: Path, workspace_config: Path | None = None, marketplace_path: Path | None = None) -> dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []
    manifest_path = find_plugin_manifest(plugin_root)
    if not manifest_path.exists():
        return {"ok": False, "errors": ["missing .codex-plugin/plugin.json"], "warnings": [], "skills": []}
    manifest = load_plugin_manifest(plugin_root)
    name = manifest.get("name")
    if not isinstance(name, str) or not name:
        errors.append("manifest missing name")
    version = manifest.get("version")
    if not isinstance(version, str) or not version:
        errors.append("manifest missing version")
    description = manifest.get("description")
    if not isinstance(description, str) or not description:
        errors.append("manifest missing description")
    skills_rel = manifest.get("skills")
    if not isinstance(skills_rel, str) or not skills_rel.startswith("./"):
        errors.append("manifest skills must be a ./-prefixed string")
        skills_root = plugin_root / "skills"
    else:
        skills_root = (plugin_root / skills_rel).resolve()
        try:
            skills_root.relative_to(plugin_root.resolve())
        except ValueError:
            errors.append("manifest skills path escapes plugin root")
    if not skills_root.exists():
        errors.append("skills path does not exist")
    configured_mcp_names = load_workspace_mcp_names(workspace_config)
    skill_reports = []
    for skill_dir in iter_skill_dirs(skills_root if skills_root.exists() else plugin_root / "skills"):
        skill_errors: list[str] = []
        skill_warnings: list[str] = []
        skill_md = skill_dir / "SKILL.md"
        parsed_name = skill_name_from_skill_md(skill_md)
        if parsed_name and parsed_name != skill_dir.name:
            skill_warnings.append(f"skill frontmatter name differs from folder name ({parsed_name})")
        openai_yaml = skill_dir / "agents" / "openai.yaml"
        mcp_dependencies: list[str] = []
        if openai_yaml.exists():
            e, w, mcp_dependencies = validate_openai_yaml(openai_yaml, configured_mcp_names)
            skill_errors.extend(e)
            skill_warnings.extend(w)
        else:
            skill_warnings.append("missing agents/openai.yaml")
        skill_reports.append({
            "name": skill_dir.name,
            "path": str(skill_dir),
            "mcp_dependencies": mcp_dependencies,
            "errors": skill_errors,
            "warnings": skill_warnings,
        })
    if marketplace_path is not None:
        if not marketplace_path.exists():
            errors.append("marketplace file does not exist")
        else:
            marketplace = read_json(marketplace_path)
            if not isinstance(marketplace, dict):
                errors.append("marketplace must be a JSON object")
            else:
                plugins = marketplace.get("plugins", [])
                found = None
                if isinstance(plugins, list):
                    for entry in plugins:
                        if isinstance(entry, dict) and entry.get("name") == name:
                            found = entry
                            break
                if found is None:
                    errors.append("marketplace entry for plugin not found")
                else:
                    source = found.get("source", {})
                    path = source.get("path") if isinstance(source, dict) else None
                    if not isinstance(path, str) or not path.startswith("./"):
                        errors.append("marketplace source.path must start with ./")
                    else:
                        marketplace_root = _infer_marketplace_root(marketplace_path.resolve())
                        resolved = (marketplace_root / path).resolve()
                        if resolved != plugin_root.resolve():
                            errors.append("marketplace source.path does not resolve to the plugin root")
    ok = not errors and all(not report["errors"] for report in skill_reports)
    return {
        "ok": ok,
        "plugin_root": str(plugin_root),
        "configured_mcp_servers": sorted(configured_mcp_names),
        "errors": errors,
        "warnings": warnings,
        "skills": skill_reports,
    }
