# AoA plugin smoke prompts

1. `@aoa-shared-launchers Map which AoA repo owns candidate lineage and name one bounded next move.`
2. `$aoa-workspace-recon Identify the owner repo and supporting surfaces for this cross-repo task.`
3. `$aoa-growth-snapshot Summarize the growth posture across workspace, stats, and seed context.`
4. `$aoa-seed-route-inspect Check whether this reviewed candidate belongs in Dionysus and what planting constraints apply.`
5. `$aoa-config-doctor Diagnose why AoA launcher skills or MCP servers are not appearing in Codex.`
