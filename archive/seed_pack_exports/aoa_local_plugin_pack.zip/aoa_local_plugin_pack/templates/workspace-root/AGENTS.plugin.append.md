## AoA plugin posture

If the `aoa-shared-launchers` plugin is installed, prefer its bundled launcher skills for:

- cross-repo orientation
- bounded growth snapshots
- seed-route inspection
- AoA Codex wiring diagnosis

These plugin skills rely on the named MCP servers already configured for the workspace:

- `aoa_workspace`
- `aoa_stats`
- `dionysus`

Boundary rules:

- The plugin is a launcher layer, not an owning layer.
- `aoa_stats` remains derived.
- `Dionysus` remains staging and route context.
- Owner truth stays in the owning repo.
