# AoA local plugin roll-out

## Merge and install order

1. Land the workspace/project MCP pack.
2. Land the `aoa-stats` MCP pack.
3. Land the `Dionysus` MCP pack.
4. Land the skill ↔ MCP wiring pack.
5. Only then install this plugin wave.

## Recommended first install

Prefer **personal scope** first if:

- your AoA sibling workspace is not a normal repository root
- you are still proving the launcher surface
- you want the least project coupling while testing

Prefer **repo/workspace scope** when:

- the root is stable for Codex in your setup
- multiple collaborators should see the same curated plugin list from the workspace

## Smoke path

1. Install the plugin.
2. Restart Codex.
3. Open `/plugins` and confirm `aoa-shared-launchers` appears.
4. Open `/skills` and confirm the four bundled launcher skills appear.
5. Open `/mcp` and confirm:
   - `aoa_workspace`
   - `aoa_stats`
   - `dionysus`
6. Run the prompts in `prompts/plugin_smoke_prompts.md`.

## If something breaks first

Use `$aoa-config-doctor` after the plugin installs.

If the plugin is visible but tools are not, the seam to inspect first is workspace MCP config.
If the skills are missing but the plugin is installed, the seam to inspect first is plugin install / marketplace path.
