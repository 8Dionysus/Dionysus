from __future__ import annotations

import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parents[1] / "tools"))

from aoa_local_plugin_lib import validate_plugin, install_plugin  # noqa: E402


def _workspace_config(path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        """
[mcp_servers.aoa_workspace]
command = "python"

[mcp_servers.aoa_stats]
command = "python"

[mcp_servers.dionysus]
command = "python"
""".strip()
        + "\n",
        encoding="utf-8",
    )
    return path


def test_validate_plugin_ok_with_workspace_and_marketplace(tmp_path: Path) -> None:
    pack_root = Path(__file__).resolve().parents[1]
    source = pack_root / "plugin-template" / "aoa-shared-launchers"
    install_path, marketplace_path = install_plugin(source, "repo", tmp_path)
    workspace_config = _workspace_config(tmp_path / ".codex" / "config.toml")

    report = validate_plugin(install_path, workspace_config=workspace_config, marketplace_path=marketplace_path)

    assert report["ok"] is True
    assert report["errors"] == []


def test_validate_plugin_reports_unknown_mcp(tmp_path: Path) -> None:
    pack_root = Path(__file__).resolve().parents[1]
    source = pack_root / "plugin-template" / "aoa-shared-launchers"
    install_path, marketplace_path = install_plugin(source, "repo", tmp_path)
    workspace_config = tmp_path / ".codex" / "config.toml"
    workspace_config.parent.mkdir(parents=True, exist_ok=True)
    workspace_config.write_text('[mcp_servers.aoa_workspace]\ncommand = "python"\n', encoding="utf-8")

    report = validate_plugin(install_path, workspace_config=workspace_config, marketplace_path=marketplace_path)

    assert report["ok"] is False
    assert any("unknown MCP dependency: aoa_stats" in err for skill in report["skills"] for err in skill["errors"])
