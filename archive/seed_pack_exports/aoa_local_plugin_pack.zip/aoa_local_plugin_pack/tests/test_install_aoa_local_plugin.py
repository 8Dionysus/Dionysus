from __future__ import annotations

import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parents[1] / "tools"))

from aoa_local_plugin_lib import install_plugin, read_json  # noqa: E402


def test_install_repo_scope_updates_marketplace(tmp_path: Path) -> None:
    pack_root = Path(__file__).resolve().parents[1]
    source = pack_root / "plugin-template" / "aoa-shared-launchers"

    install_path, marketplace_path = install_plugin(source, "repo", tmp_path)

    assert install_path == tmp_path / "plugins" / "aoa-shared-launchers"
    assert marketplace_path == tmp_path / ".agents" / "plugins" / "marketplace.json"
    data = read_json(marketplace_path)
    assert data["plugins"][0]["source"]["path"] == "./plugins/aoa-shared-launchers"


def test_install_personal_scope_updates_marketplace(tmp_path: Path) -> None:
    pack_root = Path(__file__).resolve().parents[1]
    source = pack_root / "plugin-template" / "aoa-shared-launchers"

    install_path, marketplace_path = install_plugin(source, "personal", tmp_path)

    assert install_path == tmp_path / ".codex" / "plugins" / "aoa-shared-launchers"
    data = read_json(marketplace_path)
    assert data["plugins"][0]["source"]["path"] == "./.codex/plugins/aoa-shared-launchers"
