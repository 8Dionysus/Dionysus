from __future__ import annotations

import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parents[1] / "tools"))

from aoa_local_plugin_lib import build_plugin_from_template, load_plugin_manifest  # noqa: E402


def test_build_from_template_copies_plugin(tmp_path: Path) -> None:
    pack_root = Path(__file__).resolve().parents[1]
    template = pack_root / "plugin-template" / "aoa-shared-launchers"
    output = tmp_path / "built" / "aoa-shared-launchers"

    build_plugin_from_template(template, output)

    manifest = load_plugin_manifest(output)
    assert manifest["name"] == "aoa-shared-launchers"
    assert (output / "skills" / "aoa-workspace-recon" / "SKILL.md").exists()
    assert (output / "skills" / "aoa-workspace-recon" / "agents" / "openai.yaml").exists()


def test_build_with_alternate_skills_root_rewrites_openai_yaml(tmp_path: Path) -> None:
    pack_root = Path(__file__).resolve().parents[1]
    template = pack_root / "plugin-template" / "aoa-shared-launchers"
    skills_root = tmp_path / "skills-source"
    custom = skills_root / "aoa-config-doctor"
    custom.mkdir(parents=True)
    (custom / "SKILL.md").write_text(
        "---\nname: aoa-config-doctor\ndescription: custom doctor.\n---\ncustom\n",
        encoding="utf-8",
    )
    output = tmp_path / "built" / "aoa-shared-launchers"

    build_plugin_from_template(template, output, skills_root=skills_root)

    assert (output / "skills" / "aoa-config-doctor" / "SKILL.md").exists()
    text = (output / "skills" / "aoa-config-doctor" / "agents" / "openai.yaml").read_text(encoding="utf-8")
    assert "allow_implicit_invocation: false" in text
