# AoA local plugin pack v1

This wave packages the **shared AoA launcher skills** as a local Codex plugin.

It is the right next move after the project-level MCP spine and the skill ↔ MCP wiring work, because
it turns the shared launcher surface into one installable unit instead of a loose handful of folders.

## What this wave chooses on purpose

It uses the plugin for **distribution**, not for new authority.

- Shared launcher skills live inside the plugin.
- Skill metadata and named MCP dependencies live in each bundled `agents/openai.yaml`.
- Project-scoped `.codex/config.toml` still owns the actual MCP server configuration.
- `AGENTS.md` still owns durable workspace law.

In other words: the plugin carries the lanterns, not the throne.

## Why this shape

The safest first AoA plugin wave is a **skills-first plugin** that relies on already-landed project MCP servers.

That means you can install the shared launcher surface as one package while keeping server paths, trust, and
workspace-specific process control in the project config you already built.

## What is inside

- `plugin-template/aoa-shared-launchers/`
  - ready-to-install plugin folder
  - bundled skills
  - bundled `agents/openai.yaml` metadata
- `tools/build_aoa_local_plugin.py`
  - rebuild the plugin from the bundled template or from an alternate skills root
- `tools/install_aoa_local_plugin.py`
  - install the plugin repo-scoped or personal and patch marketplace JSON
- `tools/validate_aoa_local_plugin.py`
  - validate manifest, bundled skills, `openai.yaml`, marketplace, and workspace MCP names
- `templates/workspace-root/.agents/plugins/marketplace.json`
  - repo/workspace marketplace example
- `templates/home/.agents/plugins/marketplace.json`
  - personal marketplace example
- `templates/workspace-root/AGENTS.plugin.append.md`
  - optional AGENTS section for plugin-aware guidance
- `prompts/plugin_smoke_prompts.md`
  - quick smoke prompts
- `ROLL_OUT.md`
  - suggested merge and install order

## Bundled plugin

Plugin name: `aoa-shared-launchers`

Bundled skills:

- `aoa-workspace-recon`
- `aoa-growth-snapshot`
- `aoa-seed-route-inspect`
- `aoa-config-doctor`

## Quick path

### Repo/workspace install

Use this when your AoA root is stable for Codex and you want the plugin visible from that root.

```bash
python tools/install_aoa_local_plugin.py \
  --source-plugin plugin-template/aoa-shared-launchers \
  --scope repo \
  --root /ABSOLUTE/PATH/TO/AOA_WORKSPACE
```

### Personal install

Use this when the AoA sibling workspace is not a normal repo root or you want the safest first install.

```bash
python tools/install_aoa_local_plugin.py \
  --source-plugin plugin-template/aoa-shared-launchers \
  --scope personal \
  --root "$HOME"
```

## Validation after install

Repo/workspace example:

```bash
python tools/validate_aoa_local_plugin.py \
  --plugin-root /ABSOLUTE/PATH/TO/AOA_WORKSPACE/plugins/aoa-shared-launchers \
  --workspace-config /ABSOLUTE/PATH/TO/AOA_WORKSPACE/.codex/config.toml \
  --marketplace /ABSOLUTE/PATH/TO/AOA_WORKSPACE/.agents/plugins/marketplace.json
```

Personal example:

```bash
python tools/validate_aoa_local_plugin.py \
  --plugin-root "$HOME/.codex/plugins/aoa-shared-launchers" \
  --workspace-config /ABSOLUTE/PATH/TO/AOA_WORKSPACE/.codex/config.toml \
  --marketplace "$HOME/.agents/plugins/marketplace.json"
```

## What this wave does not do

- It does not flatten AoA into a plugin.
- It does not move MCP authority into the plugin layer.
- It does not make `aoa_stats` or `Dionysus` owner truth.
- It does not assume your sibling workspace root is a safe repo-scoped marketplace root.

## Best first use

Install this plugin only after:

1. the workspace/project MCP pack is landed
2. `aoa-stats` MCP is landed
3. `Dionysus` MCP is landed
4. the shared launcher skills have proven their shape

Then use the plugin to distribute that proven launcher surface cleanly.
