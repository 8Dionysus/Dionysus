# AoA local plugin contract v1

## Purpose

Define the first installable AoA plugin wave for Codex.

This wave distributes **shared launcher skills** as a plugin while keeping AoA owner meaning in the owning repos and keeping MCP server configuration in project-scoped Codex config.

## What this plugin owns

The plugin owns only:

- installable packaging for shared launcher skills
- install-surface metadata
- launcher-skill `agents/openai.yaml` metadata
- marketplace entry scaffolding for repo-scoped or personal installs

## What this plugin does not own

The plugin does **not** own:

- repo truth
- owner-layer meaning
- derived truth promotion
- seed-garden authority
- project-scoped MCP authority
- workspace law

## Canonical posture

- `SKILL.md` remains the execution canon for bundled launcher skills.
- `agents/openai.yaml` remains Codex-facing optional metadata and tool dependency declaration.
- `.codex/config.toml` remains the source of named MCP server configuration in this wave.
- `.codex/agents/*.toml` remains the role-bearing subagent layer.
- `AGENTS.md` remains persistent workspace and repo law.

## Bundled plugin in this pack

Plugin `name`: `aoa-shared-launchers`

Bundled skills:

- `aoa-workspace-recon`
- `aoa-growth-snapshot`
- `aoa-seed-route-inspect`
- `aoa-config-doctor`

## Dependency posture

This plugin's skills declare dependencies on named MCP servers where needed:

- `aoa_workspace`
- `aoa_stats`
- `dionysus`

These names must match the project-scoped Codex MCP config.

## Marketplace posture

Two install shapes are supported:

1. repo/workspace marketplace
2. personal marketplace

Use repo/workspace scope only when the root is stable for Codex in your setup.

If your AoA sibling workspace is not a normal repository root, the personal marketplace is the safer first install path.

## Validation contract

A valid AoA plugin wave v1 must satisfy:

- `.codex-plugin/plugin.json` exists
- manifest `name`, `version`, `description`, and `skills` are present
- `skills` path starts with `./` and resolves inside the plugin root
- each bundled skill contains `SKILL.md`
- each bundled `agents/openai.yaml` has valid policy metadata
- any named MCP dependency matches the workspace config when provided
- marketplace `source.path` starts with `./`
- marketplace entry name matches plugin manifest `name`

## Deferred seam

This first wave does not require `.mcp.json`.

If AoA later wants a plugin-bundled MCP wave, treat that as a separate contract and verify live Codex behavior first.
