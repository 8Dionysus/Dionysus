# Repo-by-repo docket

## 1. Agents-of-Abyss

### Обязательные посевы
- `docs/REVIEWABLE_GROWTH_REFINERY.md`
- `docs/CANDIDATE_LINEAGE_CROSSWALK.md`
- one short addition in federation rules or README pointing to the doctrine note

### Acceptance
- doctrine note names the refinery
- lineage chain is named
- ownership boundaries are explicit
- no working candidate ledger is introduced here

---

## 2. aoa-sdk

### Обязательные посевы
- add `cluster_ref` and related provisional lineage hints in checkpoint carry
- expand closeout handoff docs and examples
- expose reviewed-carry sidecar suitable for downstream stats or donor-harvest input
- keep `candidate_ref` out of sdk

### Suggested file targets
- `docs/session-growth-checkpoints.md`
- `docs/aoa-surface-detection-closeout-handoff.md`
- one new lineage carry doc
- fixtures/examples for checkpoint cluster and closeout handoff

### Acceptance
- `cluster_ref` exists
- reviewed closeout can carry lineage hints
- sdk does not mint reviewed candidate identity

---

## 3. aoa-skills

### Обязательные посевы
- donor-harvest mints `candidate_ref`
- receipts and contracts carry:
  - `source_cluster_refs`
  - `owner_repo`
  - `nearest_wrong_target`
  - `promotion_pressure_vector`
  - `lineage_status`
- route-forks / self-diagnose / self-repair / progression-lift read and preserve candidate identity

### Suggested file targets
- `skills/aoa-session-donor-harvest/SKILL.md`
- `skills/aoa-session-route-forks/SKILL.md`
- `skills/aoa-session-self-diagnose/SKILL.md`
- `skills/aoa-session-self-repair/SKILL.md`
- `skills/aoa-session-progression-lift/SKILL.md`
- `skills/aoa-quest-harvest/SKILL.md`
- `docs/SESSION_GROWTH_LINEAGE.md`
- receipt / reference / schema surfaces

### Acceptance
- `candidate_ref` is minted once
- downstream skills preserve it
- harvest examples show one candidate through multiple handoffs

---

## 4. Dionysus

### Обязательные посевы
- `seed_ref`
- lifecycle vocabulary for staged candidates
- links from staged seed to `candidate_ref`
- landing cleanup that records `object_ref` or merge/drop outcome

### Suggested file targets
- `seed_staging/project_growth/`
- `templates/session-growth-candidate.*`
- `docs/SEED_SURFACE_MAP.md`
- `reports/planting/` template surfaces
- maybe lightweight generated index for session-growth seeds

### Acceptance
- staged candidate gets `seed_ref`
- staging record shows lifecycle status
- planting trace can point to owner object or drop reason

---

## 5. aoa-stats

### Обязательные посевы
- derived lineage summary
- growth funnel summary
- key rates:
  - misroute
  - owner ambiguity
  - time-to-seed / time-to-plant
  - supersession
  - thin-evidence
  - repair-success-after-diagnosis

### Suggested file targets
- `docs/ARCHITECTURE.md`
- one new summary schema
- one new generated summary surface
- watcher/source registry only if reviewed inputs are needed

### Acceptance
- stats stays derived-only
- no total idol-score appears
- lineage can be observed as movement, not just as object counts

---

## 6. aoa-evals

### Обязательные посевы
- lineage-integrity bundle
- owner-fit-routing bundle
- diagnosis-cause-discipline bundle
- repair-boundedness bundle

### Suggested file targets
- new bundles under `bundles/`
- one short proof-program doc
- examples and fixtures

### Acceptance
- at least one happy-path and one failure-path per bundle
- bundles do not seize owner meaning
- bundle outputs are usable by humans and future automation

---

## 7. aoa-playbooks

### Обязательные посевы
- one `session-growth-cycle` playbook

### Should include
- entry conditions
- checkpoint / closeout relation
- donor harvest transition
- diagnose / repair / progression / quest branches
- seed/planting branch
- proof hooks
- memory writeback branch
- stop conditions and fallbacks

### Acceptance
- playbook owns the recurring route
- neighboring repos no longer need to explain the full cycle in scattered fragments

---

## 8. aoa-memo

### Обязательные посевы
- writeback seam from growth cycle into:
  - failure lessons
  - recovery patterns
  - maybe prune / supersession lessons

### Suggested file targets
- `docs/RUNTIME_WRITEBACK_SEAM.md`
- examples under appropriate memory surfaces
- one short guidance note for growth-refinery writeback

### Acceptance
- recurring misroutes and repair wins can become memo objects
- memo stays memory, not proof or routing authority

---

## 9. workspace / automation layer

### Обязательные посевы
- bounded automation cycle after Waves A-C settle

### Should include
- explicit reviewed trigger
- explicit receipts
- stop lines
- failure classes
- retry policy
- no silent sovereign loop

### Acceptance
- automation follows the refinery
- automation does not replace review
