# Measures and signals

Use these only as split-axis signals, not as one total score.

## Candidate movement
- checkpoint-to-candidate conversion rate
- candidate-to-seed conversion rate
- seed-to-object conversion rate

## Quality
- owner ambiguity rate
- nearest-wrong-target recurrence
- thin-evidence rate
- false-promotion rate

## Recovery
- diagnosis-to-repair success rate
- repeated failure pattern rate
- time-to-repair after diagnosis

## Memory
- failure-lesson writeback rate
- recovery-pattern reuse rate

## Lifecycle hygiene
- supersession rate
- merge rate
- explicit drop rate
