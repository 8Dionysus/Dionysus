# Risk register

## Risk 1. SDK becomes semantic owner
Mitigation:
- keep `candidate_ref` out of sdk
- keep sdk on carry and closeout surfaces only

## Risk 2. Dionysus becomes fake owner truth
Mitigation:
- keep seed lifecycle separate from owner object identity
- require planting trace or drop reason

## Risk 3. Stats becomes idol-score machine
Mitigation:
- use split-axis summaries
- forbid one total maturity number for refinery health

## Risk 4. Proof chases the wrong object
Mitigation:
- prove lineage integrity and owner-fit first
- do not begin with giant vague eval bundles

## Risk 5. Playbook arrives too early
Mitigation:
- only land session-growth-cycle after lineage and proof seams are minimally real

## Risk 6. Automation outruns review
Mitigation:
- automation only after Waves A-C
- explicit receipts and stop lines
