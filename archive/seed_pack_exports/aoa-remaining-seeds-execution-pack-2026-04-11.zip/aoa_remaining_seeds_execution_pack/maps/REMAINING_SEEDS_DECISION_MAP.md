# Remaining seeds map

## If the bottleneck is identity continuity
Start with Wave A.

## If the bottleneck is observability and proof
Start with Wave B, but only if Wave A is already visible enough.

## If the bottleneck is method legibility
Start with Wave C, but only after A-B are real enough.

## If the bottleneck is human toil after convergence
Start with Wave D, but only after A-C are credible.

## If the bottleneck is durable operational body
This is Wave E and should stay later unless the runtime need is already undeniable.
