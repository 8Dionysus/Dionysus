# REVIEWABLE_GROWTH_REFINERY

## Статус
Proposed center doctrine note.

## Назначение
Дать AoA один явный центральный текст, который объясняет,
что проект строит reviewable growth refinery, а не просто зоопарк repo surfaces и не просто Codex integration mesh.

## Определение

Reviewable growth refinery это такая федеративная машина роста, которая умеет:

1. замечать повторяющийся residue во время работы,
2. удерживать его через session carry без присвоения final truth,
3. переводить его после reviewed closeout в bounded reusable candidate,
4. направлять candidate в правильный owning layer,
5. доказывать, что promotion был честным,
6. помнить failure и recovery как отдельные объекты,
7. возвращать выращенное обратно в будущую работу.

## Главный сквозной нерв

Предпочтительная identity-цепь:

`cluster_ref -> candidate_ref -> seed_ref -> object_ref`

### `cluster_ref`
Local или review-carry identity для session signal cluster.

### `candidate_ref`
Reviewed reusable candidate identity.

### `seed_ref`
Staged seed identity в Dionysus.

### `object_ref`
Final owner-layer object identity.

## Границы

- центр владеет doctrine и crosswalk, но не рабочими candidate instances
- sdk владеет carry и control-plane, но не смыслом owner objects
- stats владеет derived views, но не promotion authority
- routing владеет dispatch hints, но не semantic truth
- memo владеет memory seams, но не proof
- evals владеет proof, но не owner meaning

## Axes, а не idol-score

Growth refinery должен мыслиться по осям, а не по одному total score.

Примеры осей:
- recurrence pressure
- proof pressure
- owner-fit pressure
- actionability pressure
- repair pressure
- memory pressure

## Что считается успехом

Система считается развивающейся, если:
- кандидат читается сквозь превращения,
- promotions и drops имеют trace,
- recurring methods становятся playbooks,
- failure/recovery уходит в memo,
- proof-wave догоняет реальные промоции,
- автоматизация остается governed, reviewed и bounded.
