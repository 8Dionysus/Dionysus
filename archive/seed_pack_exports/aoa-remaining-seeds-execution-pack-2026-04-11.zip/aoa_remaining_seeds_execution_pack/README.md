# AoA remaining seeds execution pack

Этот pack собирает **то, что ещё не досеяно** относительно исходного замысла текущего диалога.

Он не про новые Codex-мосты.
Он про то, как довести сам AoA до формы **reviewable growth refinery**.

## Что в фокусе

1. центральная doctrine-note для growth refinery
2. сквозной candidate-lineage nerve
3. перевод session-growth kernel из scaffold в рабочий орган
4. growth funnel и lineage summaries в observability
5. proof-wave для lineage / routing / repair / promotion
6. session-growth-cycle как playbook-owned method
7. failure / recovery writeback в memo
8. prune / supersede / drop law
9. governed automation cycle

## Как использовать

1. Прочитай `CONCEPT__WHAT_REMAINS_TO_BE_SEEDED.md`.
2. Прочитай `WAVES__EXECUTION_SEQUENCE.md`.
3. Прочитай `DOCKET__REPO_BY_REPO.md`.
4. Дай Codex prompt из `prompts/CODEX__implement_remaining_seeds.md`.
5. Пусть Codex идет волнами, а не смешивает всё в один прыжок.
6. После каждой волны заполняй receipts из `templates/`.

## Самое важное

Этот pack предполагает, что Codex-plane уже посажен достаточно хорошо.
Следующий bottleneck теперь не в bridges, а в semantic continuity, proof и memory of recovery.
