# Что ещё осталось досеять

Главная мысль проста:

мы уже неплохо научили Codex входить в AoA,
но ещё не до конца научили AoA переваривать собственный рост.

## Что уже достаточно выросло

- workspace-root guidance и marker discipline
- project-level Codex config
- repo-local MCP seams
- skill ↔ MCP wiring
- local plugin surface
- subagent projection
- convergence / hook scaffolding

Это уже достаточная почва, чтобы перестать ковать новые мосты ради самих мостов.

## Что ещё не доведено до полного цикла

### 1. Доктрина growth refinery в центре
Одна явная doctrine-note в центре нужна не для красоты, а чтобы весь маршрут роста имел один конституционный текст.

### 2. Сквозная identity-линия кандидата
Нужен нерв:
`cluster_ref -> candidate_ref -> seed_ref -> object_ref`

Без него материал уже собирается, но одна сущность ещё не читается сквозь все превращения.

### 3. Session-growth kernel должен созреть
Нужно довести family из:
- donor-harvest
- route-forks
- self-diagnose
- self-repair
- progression-lift
- quest-harvest
- checkpoint-closeout-bridge

из scaffold в реальные reviewed surfaces.

### 4. Growth funnel в stats
Нужны summaries, которые показывают путь кандидата, а не только соседние derived views.

### 5. Proof wave
Нужны bundles для:
- lineage integrity
- owner-fit routing
- diagnosis cause-discipline
- repair boundedness
- false promotion / promotion correctness

### 6. Session-growth-cycle playbook
Весь recurrent route должен стать playbook-owned method, а не жить как россыпь соседних seams.

### 7. Memo writeback
Failure lessons, recovery patterns, misroutes и successful repairs должны становиться memory objects.

### 8. Prune law
Рост должен уметь не только накапливаться, но и честно выбрасываться:
- superseded
- merged
- dropped
- deprecated

### 9. Governed automation
Полуавтоматический follow-through цикл ещё не оформлен как governed loop.

## Куда теперь смотреть

Следующий сезон работы должен идти не в расширение Codex-plane,
а в то, чтобы session-growth refinery стал:
- читаемым,
- доказываемым,
- memory-backed,
- playbook-owned,
- пригодным для bounded automation.
