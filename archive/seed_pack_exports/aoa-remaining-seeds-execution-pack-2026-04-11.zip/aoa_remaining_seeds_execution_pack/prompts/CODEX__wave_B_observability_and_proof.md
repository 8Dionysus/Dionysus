# Codex prompt: Wave B observability and proof

Implement only Wave B.

Focus:
- lineage summary
- growth funnel
- lineage-integrity bundle
- owner-fit-routing bundle
- diagnosis-cause-discipline bundle
- repair-boundedness bundle

Assume Wave A is already landed or at least source-visible.

Do not widen into automation.
