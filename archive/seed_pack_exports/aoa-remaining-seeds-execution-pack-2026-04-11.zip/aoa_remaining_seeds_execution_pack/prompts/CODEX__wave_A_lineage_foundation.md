# Codex prompt: Wave A lineage foundation

Implement only Wave A.

Focus:
- center doctrine
- lineage crosswalk
- `cluster_ref`
- `candidate_ref`
- `seed_ref`

Do not start stats, evals, playbook, memo, or automation work yet unless needed for fixtures or tiny references.

Deliver:
- docs
- schemas/contracts
- examples/fixtures
- bounded tests
