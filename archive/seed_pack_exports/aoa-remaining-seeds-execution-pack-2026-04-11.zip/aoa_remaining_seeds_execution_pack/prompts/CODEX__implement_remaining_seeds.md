# Codex prompt: implement remaining seeds

You are working inside an AoA sibling-workspace whose Codex-plane is already substantially seeded.

Your task now is **not** to build new bridges.
Your task is to implement the remaining seeds of the reviewable growth refinery.

## Read first
1. `CONCEPT__WHAT_REMAINS_TO_BE_SEEDED.md`
2. `WAVES__EXECUTION_SEQUENCE.md`
3. `DOCKET__REPO_BY_REPO.md`
4. `PR_SLICES.md`
5. `ACCEPTANCE_MATRIX.md`
6. `contracts/CANDIDATE_LINEAGE_CONTRACT_SEED_v1.md`

## Mission
Implement the remaining seeds wave by wave, preserving AoA federation boundaries.

## Rules
- Prefer the smallest correct repo-local change.
- Keep source ownership intact.
- Do not flatten meaning into Codex surfaces.
- Do not report live success where only scaffolding exists.
- After each PR slice:
  - run repo validators and tests,
  - write a receipt under `generated/codex/remaining-seeds/`,
  - update the status against `ACCEPTANCE_MATRIX.md`.

## Order
Follow `PR_SLICES.md` in order.

## Stop conditions
Pause and report when:
- lineage identity cannot be carried without contradicting repo doctrine,
- a repo-local validator fails for reasons unrelated to the current bounded change,
- proof bundles cannot be defined honestly from existing surfaces,
- playbook or automation work would outrun lineage and proof.

## Final report
At the end of each wave, summarize:
- what was seeded,
- what is still scaffolded,
- what blockers remain,
- what next wave is justified.
