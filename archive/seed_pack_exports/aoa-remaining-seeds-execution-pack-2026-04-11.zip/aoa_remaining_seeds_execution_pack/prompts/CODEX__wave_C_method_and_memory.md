# Codex prompt: Wave C method and memory

Implement only Wave C.

Focus:
- `session-growth-cycle` playbook
- memo writeback for failure/recovery
- prune / supersede / drop law where needed for method legibility

Assume Waves A-B already exist or are visible enough to target.
