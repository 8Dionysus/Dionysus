# Acceptance matrix

## A. Center doctrine
- [ ] refinery doctrine note exists
- [ ] candidate-lineage chain is named
- [ ] ownership boundaries are explicit

## B. Lineage
- [ ] `cluster_ref` exists
- [ ] `candidate_ref` exists
- [ ] `seed_ref` exists
- [ ] owner layer can point to `object_ref`
- [ ] supersede / merge / drop law is explicit

## C. Stats
- [ ] lineage summary exists
- [ ] growth funnel exists
- [ ] rates are split-axis, not one total score

## D. Evals
- [ ] lineage-integrity bundle exists
- [ ] owner-fit-routing bundle exists
- [ ] diagnosis-cause-discipline bundle exists
- [ ] repair-boundedness bundle exists

## E. Playbook
- [ ] one session-growth-cycle playbook exists
- [ ] it names branches and stop conditions

## F. Memo
- [ ] failure lessons can be written from growth cycle
- [ ] recovery patterns can be written from growth cycle

## G. Automation
- [ ] automation remains reviewed and bounded
- [ ] explicit receipts exist
- [ ] failure classes are named
