# Волны исполнения

## Wave A. Center + lineage foundation

Цель:
создать doctrinal и structural нерв для growth refinery.

### Репозитории
- `Agents-of-Abyss`
- `aoa-sdk`
- `aoa-skills`
- `Dionysus`

### Что должно появиться
- central doctrine note
- lineage crosswalk
- `cluster_ref` в carry-layer
- `candidate_ref` в reviewed harvest
- `seed_ref` в seed staging
- lifecycle status / supersede / merge / drop fields

### Stop condition
Не переходить к Wave B, пока identity-линия кандидата не читается минимум в examples и receipts.

---

## Wave B. Observability + proof

Цель:
сделать рост видимым и проверяемым.

### Репозитории
- `aoa-stats`
- `aoa-evals`

### Что должно появиться
- `candidate_lineage_summary` или эквивалентный derived view
- `growth_funnel_summary`
- lineage-integrity bundle
- owner-fit-routing bundle
- repair-boundedness bundle
- diagnosis-cause-discipline bundle

### Stop condition
Не переходить к Wave C, пока есть lineage без proof hooks и proof без surfaced summaries.

---

## Wave C. Method + memory

Цель:
сделать growth refinery recurring method, а не россыпью seams.

### Репозитории
- `aoa-playbooks`
- `aoa-memo`

### Что должно появиться
- `session-growth-cycle` playbook
- explicit memory writeback for misroutes / failure lessons / recovery patterns
- prune and supersession memory vocabulary

### Stop condition
Не переходить к Wave D, пока recurring route всё ещё живет только в adjacent docs.

---

## Wave D. Governed automation

Цель:
вынести повторяющийся follow-through в bounded automation loop.

### Репозитории
- workspace root
- `aoa-sdk`
- `aoa-skills`
- possibly `abyss-stack` later

### Что должно появиться
- explicit automation entrypoints
- review gates
- loop receipts
- bounded auto-refresh of specific surfaces

### Stop condition
Не расширять automation вглубь, пока нет доказуемой boundedness и honest failure handling.

---

## Wave E. Runtime body (позже)

Цель:
дать части refinery durable operational body.

### Репозитории
- likely `abyss-stack`
- selected owner repos

### Что должно появиться
- queues / schedulers / event body where justified
- durable runtime capture
- operational continuity beyond one session

### Stop condition
Не входить сюда, пока Waves A-D не дали устойчивого refinery spine.
