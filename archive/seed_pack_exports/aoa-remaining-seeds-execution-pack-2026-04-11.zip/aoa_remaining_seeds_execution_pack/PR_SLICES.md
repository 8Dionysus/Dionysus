# Suggested PR slices

## PR-1: center doctrine
- Agents-of-Abyss only
- doctrine note + lineage crosswalk

## PR-2: sdk lineage carry
- aoa-sdk only
- `cluster_ref`, carry hints, reviewed handoff sidecars

## PR-3: donor-harvest candidate contract
- aoa-skills only
- `candidate_ref` + expanded receipts / examples

## PR-4: seed identity
- Dionysus only
- `seed_ref`, lifecycle trace, planting links

## PR-5: stats lineage summaries
- aoa-stats only
- funnel + rates + summary surface

## PR-6: proof wave
- aoa-evals only
- four starter bundles

## PR-7: playbook-owned cycle
- aoa-playbooks only
- `session-growth-cycle`

## PR-8: memo writeback
- aoa-memo only
- failure/recovery writeback surfaces

## PR-9: governed automation
- workspace / control-plane follow-through only after earlier PRs pass
