# Candidate lineage contract seed v1

## Chain

`cluster_ref -> candidate_ref -> seed_ref -> object_ref`

## Minimal fields

### cluster carry
- `cluster_ref`
- `repeat_shape`
- `owner_hypothesis`
- `nearest_wrong_target`
- `promotion_pressure_vector`
- `evidence_refs`

### reviewed candidate
- `candidate_ref`
- `source_cluster_refs`
- `owner_repo`
- `owner_shape`
- `nearest_wrong_target`
- `promotion_pressure_vector`
- `lineage_status`

### seed stage
- `seed_ref`
- `candidate_ref`
- `lifecycle_status`
- `first_artifact_hint`
- `merged_into`
- `dropped_by`

### owner object
- `object_ref`
- `seed_ref` optional
- `candidate_ref`
- `supersedes`

## Status vocabulary

- observed
- checkpointed
- carried
- reviewed
- harvested
- staged
- planted
- proved
- promoted
- superseded
- merged
- dropped
