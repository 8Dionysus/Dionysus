# Dionysus MCP usage recipes

## Open the current live seed

Use `seed_route_catalog`, then `seed_registry_navigation`, then `seed_next_live`.
State whether the work still belongs in `Dionysus` or has already crossed into an owner repo.

## Prepare a planting from one seed

Use `seed_registry_entry(registry_id=...)`, then `seed_planting_rules`, then inspect the target repo directly.
Leave explicit notes for: seed ref, target repo, smallest coherent landing slice, structural artifact, and non-goals.

## Reality-check a staging note

Use `seed_staging_note(note_path=...)`, then verify the owner repo directly.
Treat `lifecycle_status`, `lifecycle_note`, and `reality_checked_at` as helpful markers, not sovereignty.

## Read one historical wave honestly

Use `seed_wave_context(wave=...)`.
Keep the manifest first, then source seeds, then closure note, and use the registry only as navigation.
