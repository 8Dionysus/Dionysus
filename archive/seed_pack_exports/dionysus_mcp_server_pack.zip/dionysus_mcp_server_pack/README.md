# Dionysus MCP server pack v0

This pack is the next bridge after `aoa-stats`: a read-only, route-first, seed-garden-aware STDIO MCP scaffold for `Dionysus`.

Why `Dionysus` as the second MCP surface:

- it already publishes a compact entry capsule at `generated/seed_route_map.min.json`
- it already treats `seed-registry.yaml` as the human and Codex navigation overlay
- it already fixes a clear read order: manifest -> source seed -> closure -> registry -> planting protocol -> owner repo
- it already warns that staging notes are weaker than owner-repo truth

## What is inside

- `repo-overlay/src/dionysus_mcp/`: the read-only MCP package
- `repo-overlay/scripts/dionysus_mcp_server.py`: repo-root bootstrap launcher
- `repo-overlay/tests/test_dionysus_mcp_state.py`: helper-layer tests
- `repo-overlay/requirements-mcp.txt`: minimal MCP dependency lines
- `contracts/dionysus_seed_mcp_contract_v1.md`: narrow boundary contract
- `templates/codex/config.snippet.toml`: Codex MCP config snippet
- `templates/AGENTS.dionysus-mcp.snippet.md`: optional guidance snippet
- `prompts/dionysus_mcp_usage_recipes.md`: first explicit prompt recipes
- `ROLL_OUT.md`: merge order and verification path

## Intended posture

This server is deliberately narrow.

It exposes only eight tools:

- `seed_route_catalog`
- `seed_registry_navigation`
- `seed_next_live`
- `seed_wave_context`
- `seed_registry_entry`
- `seed_staging_note`
- `seed_planting_rules`
- `seed_quest_followthrough`

That is enough to let Codex orient itself in `Dionysus` without turning the repository into a generic file browser or a hidden owner layer.

## Quick local test after merge

From the `Dionysus` repo root:

```bash
pip install -r requirements-mcp.txt
python -m pytest -q tests/test_dionysus_mcp_state.py
python scripts/dionysus_mcp_server.py
```

## Suggested Codex config

Merge the snippet from `templates/codex/config.snippet.toml` into the config layer you use for Codex.

The launcher script keeps the `src/` layout simple by inserting the repo's `src/` directory into `sys.path` before starting the server.

## What I would do immediately after this lands

1. Test `seed_route_catalog` and `seed_next_live` from Codex first.
2. Keep the server read-only while the usage shape settles.
3. Let `seed_staging_note` keep its warning posture instead of flattening staging into queue truth.
4. Only then consider a third MCP seam for richer planting-trace helpers if the repo actually needs it.
