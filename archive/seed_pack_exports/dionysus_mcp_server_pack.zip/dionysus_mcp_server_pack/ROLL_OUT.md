# Roll-out for the Dionysus MCP server pack

## Merge order

1. Copy `repo-overlay/src/dionysus_mcp/` into `Dionysus/src/dionysus_mcp/`.
2. Copy `repo-overlay/scripts/dionysus_mcp_server.py` into `Dionysus/scripts/`.
3. Copy `repo-overlay/tests/test_dionysus_mcp_state.py` into `Dionysus/tests/`.
4. Copy `repo-overlay/requirements-mcp.txt` into the repo root.
5. Optionally merge `templates/AGENTS.dionysus-mcp.snippet.md` into the guidance layer you want.
6. Merge `templates/codex/config.snippet.toml` into the Codex config layer you actually use.

## Verify after merge

Run the repo-native gates first:

```bash
python scripts/validate_seed_surfaces.py
python scripts/build_seed_route_map.py --check
python scripts/validate_seed_route_map.py
python -m pytest -q tests/test_dionysus_mcp_state.py
```

Then start the MCP server locally:

```bash
python scripts/dionysus_mcp_server.py
```

## First Codex checks

1. Call `seed_route_catalog`.
2. Call `seed_registry_navigation`.
3. Call `seed_next_live`.
4. Call `seed_planting_rules`.
5. Only then inspect a staging note if the task truly begins from staging.

## Why this order

That keeps the source-of-truth ladder intact:

1. manifest or live seed
2. source seed
3. closure note
4. registry
5. planting protocol
6. owner repo
7. staging note only when still needed
