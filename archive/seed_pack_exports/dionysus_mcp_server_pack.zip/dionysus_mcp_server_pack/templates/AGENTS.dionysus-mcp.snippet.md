## Dionysus MCP usage

When the task touches `Dionysus`, prefer this order:

1. `seed_route_catalog`
2. `seed_registry_navigation`
3. `seed_next_live` or `seed_wave_context`
4. `seed_planting_rules`
5. `seed_staging_note` only if the task truly begins from staging or lineage replay

Keep these rules intact:

- staging notes are weaker than owner-repo planting truth
- reports in `reports/planting/` preserve lineage but do not replace registry or closure state
- `Dionysus` is seed soil and dispatch layer, not the final owning home of target-repo doctrine
- if the seed has clearly landed, continue in the owner repo instead of hovering in the garden
