# Dionysus seed MCP contract v1

This contract turns the earlier concept into a concrete first implementation seam for `Dionysus`.

## Scope

The server is intentionally:

- read-only
- route-first
- registry-aware
- planting-protocol-aware
- local-repo-scoped
- non-sovereign

It exists to let Codex orient itself in the seed garden without promoting `Dionysus` into target-repo doctrine, runtime authority, or hidden queue sovereignty.

## Tools

### `seed_route_catalog`
Returns the compact route-entry capsule from `generated/seed_route_map.min.json`.

Use for:

- discovering the smallest trustworthy next surface
- locating the current live seed route
- regrounding when task scope starts to drift

### `seed_registry_navigation`
Returns a compact navigation view from `seed-registry.yaml`.

Use for:

- seeing registry version and update date
- inspecting lifecycle states
- seeing wave summaries
- locating `navigation.next_live_seed`

### `seed_next_live`
Returns the current `navigation.next_live_seed` path, the matching compact route hints, and a preview of the source seed content.

Use for:

- opening the current gated future-work seed
- checking whether a task belongs in `Dionysus` at all
- starting from the strongest live seed surface before reading staging notes

### `seed_wave_context`
Returns one wave context by `wave`.

Use for:

- reading one manifest with its wave registry entry
- previewing ordered seed slices
- previewing the closure note when one exists
- seeing supporting notes without mistaking them for stronger order surfaces

### `seed_registry_entry`
Returns one registry seed entry by `registry_id`, plus a small preview of the source seed it points to.

Use for:

- following one seed across registry metadata and source ref
- checking donor / transplant posture
- verifying repo homes and first artifact hints

### `seed_staging_note`
Returns one `seed_staging/...` note with extracted frontmatter markers when present.

Use for:

- reading staged prep packs or transport notes honestly
- checking `lifecycle_status`, `lifecycle_note`, and `reality_checked_at`
- replaying lineage without confusing it for owner-repo truth

Hard rule:

- the result must always warn that staging truth is weaker than owner-repo planting truth

### `seed_planting_rules`
Returns a compact bundle from:

- `AGENTS.md`
- `docs/SEED_SURFACE_MAP.md`
- `docs/codex/planting-protocol.md`
- `docs/codex/owner-repo-reality-check.md`
- `reports/planting/README.md`
- the nearest nested `AGENTS.md` files that frame archive, seed-expansion, reports, and codex docs

Use for:

- regrounding before a planting task
- remembering stop rules
- keeping staging and reports in their proper rank

### `seed_quest_followthrough`
Returns the compact quest follow-through bundle from:

- `QUESTBOOK.md`
- `generated/quest_catalog.min.json`
- `generated/quest_dispatch.min.json`

Use for:

- inspecting seed-garden follow-through without promoting it into a second sovereignty layer

## Resources

- `dionysus://route-map`
- `dionysus://registry/navigation`
- `dionysus://next-live-seed`
- `dionysus://wave/{wave}`
- `dionysus://registry/{registry_id}`
- `dionysus://planting-rules`
- `dionysus://questbook`

## Prompts

- `open_next_live_seed(target_repo)`
- `reality_check_staging_note(note_path, target_repo)`
- `prepare_seed_planting(target_repo, registry_id)`

These are helper launch pads, not hidden policy engines.

## Explicit non-goals

The server must not:

- mutate manifests, registry, staging notes, or reports
- present staging notes as current owner-repo truth
- replace manifest-first ordering
- replace target-repo review
- replace donor provenance judgment
- become a generic file browser for the repo
- silently collapse AoA and ToS boundaries

## Suggested merge path

- `repo-overlay/src/dionysus_mcp/*` -> `Dionysus/src/dionysus_mcp/*`
- `repo-overlay/scripts/dionysus_mcp_server.py` -> `Dionysus/scripts/dionysus_mcp_server.py`
- `repo-overlay/tests/test_dionysus_mcp_state.py` -> `Dionysus/tests/test_dionysus_mcp_state.py`
- `repo-overlay/requirements-mcp.txt` -> `Dionysus/requirements-mcp.txt`
