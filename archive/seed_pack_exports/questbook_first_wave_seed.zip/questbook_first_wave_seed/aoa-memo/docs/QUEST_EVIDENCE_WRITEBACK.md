# QUEST evidence writeback

## Purpose

This document defines what quest-related information may become memory and what must remain source-owned quest truth.

## Core rule

Quest state remains source-owned.
Memory may assist recall.
Memory must not silently replace the source questbook.

## Good writeback candidates

After non-trivial quest work, memory may keep:
- a short closure witness
- anchor references used during a reanchor or recovery
- decision summaries
- contradiction notes worth future recall
- durable links to artifacts, tests, or rollout evidence
- lessons that point toward future harvest or canon hardening

## Bad writeback candidates

Do not store memory as the authoritative place for:
- current frontier status
- hidden priorities
- private local planning notes
- raw secrets or machine-specific paths
- a mutated version of the source quest object

## Temperature posture

Suggested starting posture:
- transient frontier noise -> do not survive writeback by default
- non-trivial closure witness -> `hot` or `warm`
- durable lesson or recurring pattern -> `warm` or `cool`
- long-term historical archive -> only after explicit distillation

## Witness traces

When a route is complex enough to matter later, a compact witness trace is better than a giant narrative dump.

A useful quest witness trace can include:
- quest ID
- parent or anchor
- why the route mattered
- what changed
- what should be remembered next time

## Archivist handoff

When a quest needs durable memory candidates, hand off after verification.
Do not let pre-verification noise flood the memory layer.
