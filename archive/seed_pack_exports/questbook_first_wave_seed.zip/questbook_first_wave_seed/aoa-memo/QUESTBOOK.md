# QUESTBOOK.md — aoa-memo

This questbook tracks memory-layer obligations related to quest evidence and writeback boundaries.

## Frontier

- `AOA-MEM-Q-0001` — define quest evidence writeback boundaries
- `AOA-MEM-Q-0002` — define a compact quest witness trace example

## Near

- none yet

## Blocked / reanchor

- none yet

## Harvest candidates

- none yet
