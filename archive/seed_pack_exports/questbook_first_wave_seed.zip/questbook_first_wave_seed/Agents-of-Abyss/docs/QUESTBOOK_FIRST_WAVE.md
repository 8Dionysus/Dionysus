# QUESTBOOK first wave

## Goal

Prove QUESTBOOK in the federation without turning every repo into a bureaucracy maze.

## Included in wave 1

### `Agents-of-Abyss`
Owns:
- common QUESTBOOK model
- first-wave scope
- federation-level cross-repo quests only

### `aoa-agents`
Owns:
- quest execution passport
- difficulty, risk, control, and tier mapping
- local-wrapper allowance language

### `aoa-routing`
Owns:
- thin routing over derived quest dispatch hints
- no source quest authorship
- no live parsing of `quests/*.yaml` as authority

### `aoa-playbooks`
Owns:
- harvest thresholds for scenario-shaped repetition
- `reanchor` relation to governed return and valid anchors

### `aoa-memo`
Owns:
- closure evidence writeback boundaries
- quest witness traces that help recall without replacing truth

### `ATM10-Agent`
Owns:
- the first concrete application-level adoption
- repo-local quest catalog and dispatch examples
- later read-only operator rendering for `open_quest_book`

## Excluded from wave 1

Not excluded forever, only deferred:
- `aoa-techniques`
- `aoa-skills`
- `aoa-evals`
- `aoa-kag`
- `abyss-stack`
- `Tree-of-Sophia`

These should join after the first wave proves:
- the quest object shape is useful
- the execution passport helps delegation
- routing stays thin
- harvest and memory boundaries hold

## Success criteria

The first wave is successful when:
- repo-local questbooks stay source-owned
- cross-repo quests stay rare and center-level
- routing only consumes derived quest projections
- repeated routes start flowing toward harvest rather than lingering forever
- at least one concrete app repo uses the model without turning roadmap or local planning into duplicates
