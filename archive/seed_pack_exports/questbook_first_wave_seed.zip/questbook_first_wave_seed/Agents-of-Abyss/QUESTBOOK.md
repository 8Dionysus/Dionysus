# QUESTBOOK.md — Agents-of-Abyss

This questbook holds federation-level cross-repo obligations only.
It does not absorb repo-local quest detail from sibling repositories.

## Frontier

- `AOA-Q-0001` — publish the common QUESTBOOK model and first-wave scope
- `AOA-Q-0002` — define the source-owned quest dispatch seam without promoting routing into authority

## Near

- `AOA-Q-0003` — shape the second-wave expansion path for remaining repos after first-wave proof

## Blocked / reanchor

- none yet

## Harvest candidates

- none yet

## Backing files

- `quests/*.yaml`
- future center-level generated summaries only after a builder exists
