# Later-wave targets

The first wave focuses on the center, routing, agent tiers, playbooks, memory, and one concrete application repo.
That is enough to prove the model without flooding every sibling repository at once.

## Good second-wave candidates

### `aoa-techniques`
Questbook should track:
- canon hardening work
- donor refinement debts
- technique promotion gates
- technique validation gaps

### `aoa-skills`
Questbook should track:
- bounded execution bundle gaps
- execution-contract repairs
- skill-eval alignment debts
- repeated skill routes that want playbook promotion

### `aoa-evals`
Questbook should track:
- missing proof bundles
- regression-surface gaps
- claim-boundary tightening
- eval portability follow-ups

### `aoa-kag`
Questbook should track:
- derived export or substrate debts
- provenance guardrail gaps
- bridge-contract work
- readiness projections that remain explicitly derived

### `abyss-stack`
Questbook should track:
- runtime and deployment obligations
- infra guardrails
- host-profile rollout work
- high-risk changes that need stronger control modes

### `Tree-of-Sophia`
Questbook should be ToS-owned and adapted carefully.
It must not turn philosophical meaning or authored knowledge work into generic AoA work items.
A separate ToS-tailored wave is wiser than copy-pasting the exact first-wave shape.

### `8Dionysus` profile repo
Likely minimal or optional.
Use only if orientation-layer maintenance itself becomes large enough to deserve tracked obligations.
