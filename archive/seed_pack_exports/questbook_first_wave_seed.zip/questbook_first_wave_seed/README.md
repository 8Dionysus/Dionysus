# QUESTBOOK first-wave seed

This package is a multi-repo seed for the first public QUESTBOOK wave across the AoA ecosystem.

The package is intentionally add-first. It prefers new files, starter quests, schemas, and example generated surfaces over risky edits to existing canonical docs.
Codex can land these files, adapt names or placement where local conventions demand it, and then thread minimal README / CHARTER / SOURCE_OF_TRUTH links afterward.

## What this seed covers

First-wave repo-specific seeds are included for:

- `Agents-of-Abyss`
- `aoa-agents`
- `aoa-routing`
- `aoa-playbooks`
- `aoa-memo`
- `ATM10-Agent`

A generic repo template is also included for later-wave adoption in sibling repositories such as `aoa-techniques`, `aoa-skills`, `aoa-evals`, `aoa-kag`, `abyss-stack`, and `Tree-of-Sophia`.

## Package posture

- Human-facing document name: `QUESTBOOK.md`
- Machine-facing object name: `work_quest_v1`
- Machine-facing dispatch projection name: `quest_dispatch_v1`
- Example generated files end with `.example.json` until each target repo gains a real builder or validator
- Questbooks track deferred obligations that outlive a single diff
- Questbooks do **not** replace source-owned meaning, roadmap direction, or local ignored scratchpads

## Quick apply order

1. `Agents-of-Abyss`
2. `aoa-agents`
3. `aoa-routing`
4. `aoa-playbooks`
5. `aoa-memo`
6. `ATM10-Agent`
7. Later-wave targets using `generic-template/`

See `APPLY_ORDER.md` and `SEED_MANIFEST.yaml`.
