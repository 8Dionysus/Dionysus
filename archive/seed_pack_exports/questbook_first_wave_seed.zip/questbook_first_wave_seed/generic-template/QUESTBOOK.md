# QUESTBOOK.md — REPO_NAME

This file is the public tracked surface for deferred obligations that belong to `REPO_NAME`.

Use it for work that survives the current diff:
- follow-ups
- guardrails
- seams
- debts
- recurring route harvest candidates
- reviewable rollouts

Do not use it for:
- microsteps that die inside the current diff
- private scratch notes
- hidden priorities that belong in ignored local planning
- source meaning owned by some other repository

## Sections

### Frontier
List unblocked work that is appropriate now.

### Near
List well-anchored work that is relevant to the current direction but not urgent now.

### Blocked / reanchor
List quests that lost route shape and must return to a named anchor before continuing.

### Harvest candidates
List repeated routes that should be promoted into technique, skill, eval, playbook, memo, or agent-contract surfaces.

## Backing files

- `quests/*.yaml` — canonical quest objects
- `schemas/quest.schema.json` — quest validation contract
- `generated/quest_catalog.min.json` — compact human/model-readable index after a builder exists
- `generated/quest_dispatch.min.json` — thin delegation projection after a builder exists
