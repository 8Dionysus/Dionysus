# QUESTBOOK guide — generic repo template

## Naming

- Human surface: `QUESTBOOK.md`
- Machine object: `work_quest_v1`
- Dispatch projection: `quest_dispatch_v1`

## Minimal fields

Every tracked quest should answer:

- where does it belong
- what is the deferred obligation
- what activates it
- who may execute it
- what counts as done

## Minimal lifecycle

`captured -> triaged -> ready -> active -> done`

With side states:

- `blocked`
- `reanchor`
- `dropped`

## Minimal positioning

Use `band` instead of calendar horizons for fast-moving agentic work:

- `frontier`
- `near`
- `latent`
- `parked`

## Minimum rule for delegation

Do not send `d3+` quests directly to small local wrappers.
Split them into `d0-d2` leaves first.
