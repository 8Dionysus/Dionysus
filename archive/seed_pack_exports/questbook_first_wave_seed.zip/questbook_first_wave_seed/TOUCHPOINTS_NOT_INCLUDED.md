# Touchpoints not included in this package

This seed intentionally avoids editing existing canonical files to reduce merge friction.
After landing the new files, Codex can decide whether to add minimal links or role notes in the following places.

## `Agents-of-Abyss`
- `README.md` start-here path
- `docs/FEDERATION_RULES.md` if you want a short QUESTBOOK mention
- `ROADMAP.md` only if center-level direction changes

## `aoa-agents`
- `README.md` start-here path
- `docs/MODEL_TIER_MODEL.md` if you want a one-paragraph pointer to the execution passport

## `aoa-routing`
- `README.md` current ingestion model
- any builder or validator scripts once generated quest dispatch surfaces become real

## `aoa-playbooks`
- `README.md` start-here path
- `docs/PLAYBOOK_LIFECYCLE.md` if you want an explicit quest-harvest handoff note

## `aoa-memo`
- `README.md` start-here path
- `docs/WRITEBACK_TEMPERATURE_POLICY.md` if you want tighter quest evidence temperature language

## `ATM10-Agent`
- `README.md` canonical docs list
- `docs/SOURCE_OF_TRUTH.md` to name QUESTBOOK as the public tracked obligation layer
- `ROADMAP.md` only if direction changes, not for every quest
- automation/operator surfaces only after the read-only overlay shape is clear
