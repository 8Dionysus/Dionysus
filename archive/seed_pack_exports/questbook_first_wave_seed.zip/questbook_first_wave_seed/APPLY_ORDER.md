# Apply order

## 1. Center first

Land `Agents-of-Abyss/docs/QUESTBOOK_MODEL.md` and `Agents-of-Abyss/docs/QUESTBOOK_FIRST_WAVE.md` before anything else.
These two docs define why QUESTBOOK exists, where it belongs, and what the first-wave boundaries are.

## 2. Execution passport second

Land `aoa-agents/docs/QUEST_EXECUTION_PASSPORT.md` and `aoa-agents/schemas/quest_dispatch.schema.json`.
This gives Codex and later local wrappers a bounded contract for difficulty, risk, control mode, and tier delegation.

## 3. Routing stays derived

Land `aoa-routing/docs/QUEST_ROUTING_SEAM.md` and `aoa-routing/schemas/quest_dispatch_hint.schema.json`.
Do not let routing parse live `quests/*.yaml` as authority. Routing should only ingest generated projections once builders exist.

## 4. Scenario and memory neighbors

Land:
- `aoa-playbooks/docs/QUEST_HARVEST_AND_REANCHOR.md`
- `aoa-memo/docs/QUEST_EVIDENCE_WRITEBACK.md`

These keep repeated quest patterns from rotting in backlog form and keep memory from pretending to be source truth.

## 5. First concrete repo

Land the `ATM10-Agent` files last in the first wave.
That repo already has a public `open_quest_book` intent donor, a dry-run automation loop, and a split between public roadmap and local ignored planning.
It is the cleanest first proving ground.

## 6. Touch existing files only after landing

After the new files exist, Codex can decide whether to add minimal links from:
- `README.md`
- `CHARTER.md`
- `docs/SOURCE_OF_TRUTH.md`
- `ROADMAP.md`
- repo-specific “Start here” sections

## 7. Keep generated example surfaces honest

Do not rename `generated/*.example.json` to `generated/*.json` until the repo has a real build or validation path for them.
