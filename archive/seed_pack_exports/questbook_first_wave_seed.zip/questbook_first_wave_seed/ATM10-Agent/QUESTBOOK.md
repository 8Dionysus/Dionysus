# QUESTBOOK.md — atm10-agent

This file is the public tracked surface for deferred obligations that belong to `atm10-agent`.

It sits between the public roadmap and ignored local planning.

Use it for:
- follow-ups that survive the current diff
- dry-run automation follow-through
- operator-facing or gateway-facing guardrails
- recurrence / reanchor work
- proof and validation obligations
- harvest candidates for reusable routes

Do not use it for:
- microsteps that die inside one edit
- private scratch notes
- secrets, machine-local paths, or unsafe detail
- roadmap direction that belongs in `ROADMAP.md`

## Frontier / local-safe

- `ATM10-Q-G3-0001` — land repo-local questbook surface, schema, and starter catalog
- `ATM10-Q-G5-0001` — add validation for quest schema, example catalog, and public-safe checks

## Frontier / codex-led

- `ATM10-Q-G3-0002` — make `open_quest_book` render frontier quests from a derived catalog in dry-run/read-only mode

## Near

- `ATM10-Q-G2-0001` — feed operator recurrence recovery into quest `reanchor` candidates without adding a new endpoint or tab
- `ATM10-Q-G3-0003` — define safe local delegate wrappers for leaf quests under Codex supervision

## Blocked / reanchor

- none yet

## Harvest candidates

- none yet

## Backing files

- `quests/*.yaml`
- `schemas/quest.schema.json`
- `generated/quest_catalog.min.example.json`
- `generated/quest_dispatch.min.example.json`
