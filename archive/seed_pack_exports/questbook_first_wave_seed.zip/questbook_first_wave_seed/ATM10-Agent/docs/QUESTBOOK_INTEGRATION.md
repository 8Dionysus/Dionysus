# QUESTBOOK integration — ATM10-Agent

## Purpose

This note shows how QUESTBOOK fits into `ATM10-Agent` without bloating the public surface.

## Role split

- `ROADMAP.md` keeps public direction, milestones, horizons, and high-level risks
- `QUESTBOOK.md` keeps repo-owned open obligations that survive the current diff
- local ignored `TODO.md` and `PLANS.md` remain maintainer scratch and decomposition space

## Why ATM10 first

`ATM10-Agent` already has:
- a dry-run-first automation loop
- a public `open_quest_book` intent donor
- strong source-of-truth boundaries
- a public roadmap split from local ignored planning
- multiple active themes where follow-ups naturally emerge

That makes it a strong first proving ground for a repo-local questbook.

## Initial file layout

- `QUESTBOOK.md`
- `quests/*.yaml`
- `schemas/quest.schema.json`
- `generated/quest_catalog.min.json`
- `generated/quest_dispatch.min.json`

In this seed, generated outputs are examples only.
Keep the `.example.json` suffix until a builder or validator is added.

## Initial operator posture

`open_quest_book` should begin as a read-only or dry-run overlay.
It should render frontier quests from a derived catalog.
It should not mutate quest state directly in the first wave.

## Public-safety rule

Tracked quest content must stay public-safe.
Use quest IDs to reference richer local-only notes when necessary.
