# QUEST harvest and reanchor

## Purpose

This document explains how quest repetition should promote into playbook work and how quest `reanchor` relates to governed return.

## Quest repetition is a signal

A repeated quest route often means the system is missing a more durable object.

Typical signals:
- the same cross-layer route appears again
- the same handoff sequence is being rebuilt from scratch
- the same fallback or recovery move repeats
- the same evidence pattern is required each time

When that happens, do not keep spawning near-identical quests forever.
Open a harvest quest and decide the correct destination layer.

## Default harvest thresholds

- twice in one repo -> open a harvest candidate
- three times across repo boundaries -> evaluate cross-repo promotion

## Promotion destinations

- repeated scenario route -> `aoa-playbooks`
- repeated role contract or handoff posture -> `aoa-agents`
- repeated memory or writeback pattern -> `aoa-memo`
- repeated reusable engineering move -> `aoa-techniques`
- repeated bounded workflow -> `aoa-skills`
- repeated proof posture -> `aoa-evals`

## Reanchor

A quest state of `reanchor` means the route has lost honesty and must return to a named anchor before continuing.

Good anchors include:
- `bounded_plan`
- `verification_result`
- `route_decision`
- `decision_ledger`
- `rollout_decision`
- restartable checkpoint packs

`reanchor` is not retry.
It is a governed return to the last valid artifact or checkpoint.

## Evidence

A reanchored route should leave enough evidence to answer:
- why the route lost shape
- which anchor was chosen
- how re-entry was allowed
- whether the route should stop instead of continuing
