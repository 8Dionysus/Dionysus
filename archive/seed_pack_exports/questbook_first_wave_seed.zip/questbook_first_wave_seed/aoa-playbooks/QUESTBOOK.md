# QUESTBOOK.md — aoa-playbooks

This questbook tracks scenario-shaped harvest and reanchor work.

## Frontier

- `AOA-PB-Q-0001` — define harvest thresholds for repeated quest routes
- `AOA-PB-Q-0002` — map quest `reanchor` to valid playbook return anchors and evidence

## Near

- none yet

## Blocked / reanchor

- none yet

## Harvest candidates

- none yet
