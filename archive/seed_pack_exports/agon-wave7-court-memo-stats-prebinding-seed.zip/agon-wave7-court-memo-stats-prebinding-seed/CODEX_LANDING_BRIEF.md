# Codex Landing Brief

Plant the repository directories into their matching repo roots. Do not treat this seed as an installer.

Keep the stop-lines intact: no verdicts, no scar writes, no retention execution, no rank mutation, no hidden scheduler, no ToS promotion.

After merge, run the owner-local build checks and validators before integrating these scripts into broader release checks.
