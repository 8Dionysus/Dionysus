# Patch Notes

- Adds Wave VII center request in `Agents-of-Abyss`.
- Adds court prebinding in `aoa-evals`.
- Adds memory candidate intake prebinding in `aoa-memo`.
- Adds derived observability prebinding in `aoa-stats`.
- Adds optional Recurrence review lanes in `aoa-sdk`.
- Adds recurrence component and hook manifests for Wave VII surfaces.
