# Agon Wave VII Seed: Court / Memo / Stats Prebinding

This seed lands Wave VII between the Agon Recurrence Adapter and the future Arena Session Model.

It is a multi-repo seed:

```text
Agents-of-Abyss   center request and stop-lines
aoa-evals         court prebinding surfaces
aoa-memo          memory candidate intake prebinding surfaces
aoa-stats         derived observability prebinding surfaces
aoa-sdk           optional recurrence review lanes
```

## Plant order

```text
1. Agents-of-Abyss
2. aoa-evals
3. aoa-memo
4. aoa-stats
5. aoa-sdk
```

## What this wave does

Wave VII prepares the receiving organs of future Agon outcomes:

- court checks in `aoa-evals`, without live verdict authority;
- candidate memory intake in `aoa-memo`, without durable scar writes;
- derived observability in `aoa-stats`, without scores becoming sovereignty;
- optional Recurrence review lanes in `aoa-sdk`, without hidden scheduling.

## What this wave does not do

It does not create arena sessions, sealed commits, live move execution, verdicts, scars, retention execution, rank mutation, or Tree-of-Sophia promotion.

## Validation commands

In `Agents-of-Abyss`:

```bash
python scripts/build_agon_court_memo_stats_prebinding_request.py --check
python scripts/validate_agon_court_memo_stats_prebinding_request.py
```

In `aoa-evals`:

```bash
python scripts/build_agon_eval_prebinding_registry.py --check
python scripts/validate_agon_eval_prebindings.py
```

In `aoa-memo`:

```bash
python scripts/build_agon_memo_prebinding_registry.py --check
python scripts/validate_agon_memo_prebindings.py
```

In `aoa-stats`:

```bash
python scripts/build_agon_stats_prebinding_registry.py --check
python scripts/validate_agon_stats_prebindings.py
```

In `aoa-sdk`:

```bash
python scripts/build_agon_wave7_recurrence_lanes.py --check
python scripts/validate_agon_wave7_recurrence_lanes.py
```
