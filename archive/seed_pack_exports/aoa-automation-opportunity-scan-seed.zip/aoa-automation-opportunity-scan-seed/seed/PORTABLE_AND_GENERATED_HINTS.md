# Portable and generated surface hints

This package does not include generated `.agents/skills/*` mirrors on purpose.

Reason:
- the target repo already has builders and portable export posture
- Codex should regenerate those surfaces from the adopted canonical sources
- copying generated mirrors too early risks drift against validators and release checks

If the target repo wants a first-wave portable landing, let Codex derive it after the source bundle settles.
