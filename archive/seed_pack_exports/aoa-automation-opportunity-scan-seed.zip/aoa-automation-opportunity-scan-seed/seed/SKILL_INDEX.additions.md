# Suggested `SKILL_INDEX` additions or edits

## Add core scaffold
| name | scope | status | summary |
|---|---|---|---|
| aoa-automation-opportunity-scan | core | scaffold | Codex skill for detecting reviewed or repeated project processes that are candidates for automation, classifying whether they are seed-ready, and routing them to the right owner layer without granting schedule or mutation authority. |

## Sharpen existing family notes
- `aoa-session-donor-harvest`
  - allow `automation_candidate` as a harvest extract kind
  - keep donor-harvest as the post-session refinery nucleus rather than turning it into the automation detector for every context

- `aoa-session-route-forks`
  - allow automation and non-automation branches to appear side by side when that choice is real

- `aoa-session-self-diagnose`
  - allow blocked-automation diagnosis such as unstable inputs, hidden approvals, missing rollback, or secret coupling

- `aoa-session-self-repair`
  - allow prerequisite repair packets that make later automation honest

## Keep narrow
- `aoa-quest-harvest`
  - unresolved automation desire can remain a quest
  - do not let quest harvest absorb automation scanning itself
