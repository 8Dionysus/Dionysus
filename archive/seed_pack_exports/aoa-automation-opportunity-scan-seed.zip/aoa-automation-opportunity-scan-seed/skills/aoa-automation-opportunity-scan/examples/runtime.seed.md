# Runtime seed example for aoa-automation-opportunity-scan

```yaml
automation_candidates:
  - title: reviewed session closeout harvest
    source_window: last 8 reviewed sessions
    evidence_refs:
      - session:2026-03-closeout-wave
      - session:2026-04-donor-harvest-loop
    repeat_signal: repeated
    current_manual_route:
      - locate reviewed session artifact
      - extract reusable units
      - write harvest packet
      - publish next-route hints
    stable_inputs:
      - reviewed_session_artifact
      - project_context_note
    stable_outputs:
      - HARVEST_PACKET
      - next_route_summary
    automation_target: playbook_seed
    owner_layer: aoa-playbooks
    checkpoint_required: false
    seed_ready: true
    likely_gain: faster consistent closeout with less session loss
    likely_cost: one more composition surface to review
    likely_risk: medium risk of over-formalizing early family shape
    next_artifact: automation_seed_candidate:session-closeout
    nearest_wrong_target: direct_runtime_scheduler

  - title: auto-patch drift after diagnosis
    source_window: last 3 repair discussions
    repeat_signal: emerging
    current_manual_route:
      - detect drift
      - draft repair
      - patch repo surfaces
      - verify health
    stable_inputs:
      - diagnosis_packet
    stable_outputs:
      - repo_change
      - health_report
    automation_target: repair_quest
    owner_layer: aoa-agents
    checkpoint_required: true
    seed_ready: false
    likely_gain: lower repair latency
    likely_cost: higher governance and rollback burden
    likely_risk: high risk of silent self-mutation
    not_now_reason: approval and rollback posture are still too implicit
    next_artifact: checkpoint_aware_repair_route
    nearest_wrong_target: live_self_healing_automation
```

## What this example is showing

- one seed-ready recurring route that can become a playbook automation seed candidate
- one tempting route that is *not* honest to automate yet
- how `checkpoint_required` and `not_now_reason` should stay first-class
