---
name: aoa-automation-opportunity-scan
scope: core
status: scaffold
summary: Detect reviewed or repeated project processes that are candidates for automation, classify whether they are seed-ready, and route them to the right owner layer without granting schedule or mutation authority.
invocation_mode: explicit-only
technique_dependencies:
  - AOA-T-PENDING-AUTOMATION-FIT-MATRIX
  - AOA-T-PENDING-HUMAN-LOOP-TO-SEED-LIFT
  - AOA-T-PENDING-APPROVAL-SENSITIVITY-CHECK
---
# aoa-automation-opportunity-scan

## Intent

Use this skill to detect where repeated project work is ripe for automation and to package that finding into a bounded `AUTOMATION_OPPORTUNITY_PACKET`.

The goal is not to automate by reflex.
The goal is to notice when a process has become repetitive, stable, legible, and evidence-backed enough that automation or semi-automation becomes an honest next move.

## Trigger boundary

Use this skill when:
- a reviewed session or repeated project slice reveals a recurring manual route
- the same audit, report, hygiene pass, or triage loop keeps coming back
- a session-harvest packet includes an `automation_candidate`
- an operator wants to know whether a recurring route should stay manual, become a bounded skill, or become a playbook automation seed
- repeated friction suggests a good automation opportunity but authority and risk still need classification

Do not use this skill when:
- the work happened only once and still looks exploratory
- the route is primarily creative synthesis with no stable trigger or output
- the task is asking for live scheduling or hidden background execution authority
- the route would mutate important system surfaces without checkpoint posture
- the work still needs basic donor harvest or source-of-truth clarification first

## Inputs

- reviewed session artifact, harvest packet, or recurring project slice
- evidence of repeated manual work
- known current manual route
- known triggers, inputs, outputs, or their current ambiguity
- current risk, approval, rollback, and proof posture if known

## Outputs

- `AUTOMATION_OPPORTUNITY_PACKET`
- one or more `AUTOMATION_CANDIDATE` cards
- `seed_ready` or `not_now` verdict for each candidate
- `checkpoint_required` flag when the route crosses self-change or approval-sensitive boundaries
- next-artifact suggestion such as `skill`, `playbook_seed`, `technique_candidate`, `repair_quest`, `quest`, or `defer`

## Procedure

1. start from reviewed evidence, not from vague enthusiasm
2. isolate the current manual route as actually practiced
3. classify repeat signal, friction, determinism, input clarity, output clarity, proof surface, reversibility, secret coupling, and approval sensitivity
4. decide whether the first honest landing is a bounded skill, a playbook automation seed candidate, a technique candidate, a repair quest, or a defer verdict
5. mark `checkpoint_required` when the route would cross into self-change, hidden authority, or important mutation
6. emit `seed_ready` only when the process is stable enough to name inputs, outputs, bounded prompts or activation hints, and a likely owner surface
7. state the nearest wrong target so promotion pressure stays honest

## Contracts

- this skill detects and packages automation opportunities; it does not create live automation authority
- schedule hints remain hints, not runtime truth
- recurring scenario candidates belong in `aoa-playbooks` as seed candidates rather than hidden playbooks inside a skill
- self-changing or approval-heavy candidates must surface checkpoint posture explicitly
- unresolved candidates may become repair quests instead of fake-ready automations

## Risks and anti-patterns

- treating one exciting session as proof of repeatability
- automating unstable, under-specified, or secret-heavy work too early
- confusing a bounded skill with a recurring scenario seed
- using automation desire to bypass approval, rollback, or post-change health checks
- writing authored meaning first into derived routing or KAG surfaces
- inventing fake confidence about gains while hiding costs or risks

## Verification

- confirm each candidate names the current manual route
- confirm evidence refs justify the repeat signal
- confirm stable input and output posture is assessed explicitly
- confirm `seed_ready` or `not_now` is explicit for each candidate
- confirm a first owner layer and next artifact are named
- confirm the nearest wrong target is rejected when classification pressure exists
- confirm checkpoint posture appears for self-changing or approval-heavy routes

## Technique traceability

Pending manifest-backed techniques:
- AOA-T-PENDING-AUTOMATION-FIT-MATRIX from `8Dionysus/aoa-techniques` with `path: TBD` and `source_ref: TBD`
- AOA-T-PENDING-HUMAN-LOOP-TO-SEED-LIFT from `8Dionysus/aoa-techniques` with `path: TBD` and `source_ref: TBD`
- AOA-T-PENDING-APPROVAL-SENSITIVITY-CHECK from `8Dionysus/aoa-techniques` with `path: TBD` and `source_ref: TBD`

## Handoffs

- to `aoa-skills` when the result is one bounded executable workflow
- to `aoa-playbooks` when the result is a recurring multi-skill or schedule-shaped seed candidate
- to `aoa-techniques` when the deeper reusable practice becomes the more portable object
- to `aoa-session-self-diagnose` when blocked readiness needs root-cause classification
- to `aoa-session-self-repair` when the smallest honest next move is prerequisite repair
- to `aoa-quest-harvest` only when the residue remains repeated reviewed quest pressure rather than an automation classification task

## Adaptation points

- project overlays may add local execution modes, trigger classes, or schedule vocabularies
- project overlays may add local approval classes or environment-risk labels
- project overlays may add local candidate examples tied to recurring repo rituals
