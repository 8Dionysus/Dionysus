# Review checklist for aoa-automation-opportunity-scan

- confirm the skill detects candidates rather than granting automation authority
- confirm schedule hints remain hints instead of runtime truth
- confirm one bounded executable route lands in `aoa-skills` instead of being inflated into a playbook
- confirm recurring multi-skill or schedule-shaped routes land as `aoa-playbooks` automation seed candidates
- confirm self-changing or approval-heavy candidates surface checkpoint posture explicitly
- confirm unresolved prerequisites can become repair quests rather than fake-ready automation
- confirm derived layers such as `aoa-routing` and `aoa-kag` are not treated as first-authoring targets
- confirm the nearest wrong target is visible whenever classification pressure exists
