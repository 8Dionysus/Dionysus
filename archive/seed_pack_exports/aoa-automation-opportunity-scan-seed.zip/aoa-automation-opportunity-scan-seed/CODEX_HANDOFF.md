# Codex handoff notes

Treat this package as **raw material**, not as already-canonical repo content.

## Strong recommendation

Prefer this order:

1. inspect the live `aoa-session-donor-harvest` and session-harvest siblings
2. add `automation_candidate` as a valid harvest extract kind if the family is landing together
3. add `aoa-automation-opportunity-scan` as a standalone core skill seed or scaffold
4. wire the handoff rules to `aoa-playbooks` automation seeds, `aoa-agents` checkpoint posture, and `aoa-quest-harvest` for unresolved quest residue
5. regenerate portable exports, catalogs, policy matrices, and fixtures from repo-native builders

## What Codex should decide itself

Codex should inspect the live repo and choose:
- whether `aoa-session-donor-harvest` should mention `automation_candidate` directly in its outputs
- whether `aoa-automation-opportunity-scan` lands immediately in `SKILL_INDEX.md` as `core | scaffold`
- whether one or more project overlays should get local automation-opportunity companions
- whether the first public example should route into a playbook automation seed or remain a skill-only detection example

## Boundaries that should survive the merge

- the scan may recommend an automation seed but must not create runtime scheduling authority
- one bounded executable route still belongs first in `aoa-skills`
- recurring multi-skill or scheduled scenario candidates belong in `aoa-playbooks`
- self-changing or approval-heavy automation routes require checkpoint posture instead of silent self-mutation
- `aoa-routing` and `aoa-kag` remain downstream derived consumers after a source-owned object exists
- unresolved prerequisites may become repair quests rather than fake-ready automation seeds

## Integration hint

If the repo wants the smallest first move, land:
- `aoa-automation-opportunity-scan`
- one boundary note that adds `automation_candidate` to donor-harvest outputs
- one fixture family that tests `seed_ready`, `not_now`, and `checkpoint_required`

That is enough to preserve the family seam.
