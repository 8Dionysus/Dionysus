# aoa-automation-opportunity-scan seed

This package is a **seed**, not canonical repo truth.

It is designed for Codex to ingest inside `aoa-skills` and then land as the smallest honest bounded workflow for detecting where a project or reviewed session is ready for automation, semi-automation, or an automation seed.

## What this seed is trying to do

Detect processes that *invite automation* without confusing detection with execution.

The intended scan can work from:
- a reviewed session artifact or harvest packet
- a repeated project slice
- a recurring friction log
- a repeated manual review loop
- a recurring decision gate or hygiene ritual

## What this skill should emit

- `AUTOMATION_OPPORTUNITY_PACKET`
- `AUTOMATION_CANDIDATE` cards with evidence and owner routing
- `seed_ready` or `not_now` verdicts
- `checkpoint_required` flags for approval-heavy or self-changing routes
- next-artifact suggestions such as `skill`, `playbook_seed`, `technique_candidate`, `repair_quest`, or `quest`

## Recommended landing posture

Keep this as a **separate core skill**.

Why:
- `aoa-session-donor-harvest` should remain the broad post-session refinery nucleus
- `aoa-quest-harvest` should remain a narrow repeated-quest promotion blade
- `aoa-automation-opportunity-scan` is a distinct detector and packager for automation readiness

## Family integration

This seed is designed to plug into the session-harvest family by adding `automation_candidate` as a harvest extract kind.

That lets:
- donor-harvest detect it
- route-forks compare automation vs non-automation paths
- self-diagnose explain why automation is blocked
- self-repair create the smallest prerequisite-fix route
- progression-lift optionally mention automation-readiness hints without turning them into fake total scores

## Important posture

- detection is not schedule authority
- detection is not silent mutation
- automation seeds remain candidates until composition-owned review accepts them
- approval-heavy or self-changing routes must cross checkpoint posture
- owner layers stay explicit
- derived layers stay downstream, not first-authoring targets
