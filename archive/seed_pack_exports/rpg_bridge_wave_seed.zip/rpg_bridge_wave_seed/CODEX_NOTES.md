# Codex Notes

Read this bundle as a seed pack, not as a blind copy plan.

## Operating posture

- Preserve repo ownership boundaries.
- Prefer insertion into existing docs maps, schema folders, and generated-example lanes rather than forcing a parallel mini-tree.
- Keep the contract names stable even if local wording or formatting is adjusted.
- Treat generated example files as validator-friendly scaffolds until owner repos choose to build live generators.
- Because current project context is already rich in Codex, prefer context-sensitive splicing over literal copy.

## Important non-goals

- do not let `aoa-evals` assign mystical ranks or universal power
- do not let `aoa-playbooks` become a runtime loadout ledger
- do not let `aoa-routing` emit reward, completion, or ownership semantics
- do not let example cards silently become production inputs
- do not let this bridge overrule the architecture RFC or repo-local questbooks

## Expected merges

- merge each quest object into the repo's human questbook surfaces
- keep example ids and refs adjustable where live ids differ
- keep `unlock_proof` explicitly weaker than quest acceptance or runtime equip state
- keep `party_template` explicitly weaker than live session state
- keep `rpg_navigation` explicitly weaker than live routing or source meaning

## Safe freedom

Codex is free to adjust line wrapping, enum order, JSON formatting, local file placement, and nearby README references when needed to fit the live repo.

The hard constraint is boundary discipline and contract clarity, not byte-perfect formatting.
