# Touchpoints Not Included

This bridge wave intentionally leaves these branches for later:

- `abyss-stack` runtime collection builders or persistence updates
- `aoa-sdk` code changes or compatibility promotion
- `8Dionysus` public entry, profile, or board mirrors
- durable artifact / equipment canon beyond hints
- live reward distribution or penalty services
- production router build ingestion of bridge cards
- automatic quest completion writeback
- automatic reputation writeback
- AoA ↔ ToS counterpart expansions for this contour

The point of this wave is to lock the bridge shapes before service bloom, not to ship every later branch at once.
