# Apply Order

Use this order unless a live repo dependency makes a narrower insertion path safer.

1. `Agents-of-Abyss`
   - land the bridge-wave scope note and quest object
2. `aoa-evals`
   - land unlock-proof doctrine, schema, example cards, and quest object
3. `aoa-playbooks`
   - land party-template doctrine, build-synergy posture, schema, example cards, and quest object
4. `aoa-routing`
   - land the navigation-bridge doctrine, schema, example cards, and quest object after the upstream bridge surfaces are visible
5. `Dionysus`
   - land the prep-pack note, map, and quest object last

## Sequencing notes

- `aoa-evals` comes before `aoa-playbooks` only because the bridge uses proof language to justify unlock and readiness gates.
- `aoa-playbooks` comes before `aoa-routing` because routing should consume derived party surfaces rather than invent them.
- `aoa-routing` must keep this bridge example-only until live generated source surfaces exist.
- `Dionysus` stays last because it keeps lineage, not authority.

## Safe fallback

If the live second-wave ability or feat ids differ from the example ids here, let Codex reconcile the examples to the landed ids before validating the downstream bundle.
