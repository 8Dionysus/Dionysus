# Coverage Map

| Contour | Repo | Files |
|---|---|---|
| Common bridge-wave law | `Agents-of-Abyss` | `docs/RPG_BRIDGE_WAVE.md`, `quests/AOA-Q-0007.yaml` |
| Unlock proof | `aoa-evals` | `docs/UNLOCK_PROOF_BRIDGE.md`, `schemas/unlock_proof_catalog.schema.json`, `generated/unlock_proof_cards.min.example.json`, `quests/AOA-EV-Q-0006.yaml` |
| Party templates and build synergy | `aoa-playbooks` | `docs/PARTY_TEMPLATE_MODEL.md`, `docs/BUILD_SYNERGY_POSTURE.md`, `schemas/party_template_catalog.schema.json`, `generated/party_template_cards.min.example.json`, `quests/AOA-PB-Q-0004.yaml` |
| Derived navigation | `aoa-routing` | `docs/RPG_NAVIGATION_BRIDGE.md`, `schemas/rpg_navigation_bundle.schema.json`, `generated/rpg_navigation.min.example.json`, `quests/AOA-RT-Q-0004.yaml` |
| Transport lineage | `Dionysus` | `seed_rpg_bridge_wave_pack.md`, `seed_rpg_bridge_wave_pack.map.yaml`, `quests/DION-SEED-Q-0008.yaml` |
