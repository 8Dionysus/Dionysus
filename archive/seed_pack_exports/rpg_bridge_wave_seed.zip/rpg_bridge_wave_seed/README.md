# RPG Bridge Wave Seed

This transport seed stages the next honest bridge for the AoA RPG contour.

The bridge is deliberately narrow:
- `aoa-evals` gets bounded unlock proof
- `aoa-playbooks` gets scenario-owned party templates and build synergy posture
- `aoa-routing` gets derived RPG navigation cards that remain orientation-only
- `Dionysus` keeps lineage and transport posture explicit

This package does **not** turn routing into reward authority, does **not** turn playbooks into runtime state, and does **not** turn proof into one universal power number.

## Why this wave exists

The first wave already planted progression, chronicles, questlines, and a quest-board seam.
The second wave planted abilities and feats.
The architecture RFC fixed the vocabulary and runtime/frontend boundary.
The SDK addendum gave Codex and future loaders typed reading hands.

What remained was the bridge that lets those pieces speak to one another without collapsing repo ownership.

## Included targets

1. `Agents-of-Abyss`
   - common bridge-wave scope note
2. `aoa-evals`
   - unlock-proof doctrine, schema, and generated example cards
3. `aoa-playbooks`
   - party-template doctrine, build-synergy posture, schema, and generated example cards
4. `aoa-routing`
   - derived RPG-navigation seam, schema, and generated example cards
5. `Dionysus`
   - prep-pack note, map, and quest object

## Suggested apply order

1. `Agents-of-Abyss`
2. `aoa-evals`
3. `aoa-playbooks`
4. `aoa-routing`
5. `Dionysus`

If the second-wave ability and feat ids have not landed yet, let Codex splice their local names first and then reconcile the bridge examples against the live ids.

## What this package excludes

- `abyss-stack` live runtime persistence work
- `aoa-sdk` code changes
- `8Dionysus` public mirror surfaces
- artifact / equipment canon beyond hints
- automatic reward engines or economy loops
- production routing builder changes

## Validation posture

This bundle is transport-only.
The JSON example files are meant to validate against the included schemas.
The Markdown notes are doctrine scaffolds for owner repos, not blind copy targets.
