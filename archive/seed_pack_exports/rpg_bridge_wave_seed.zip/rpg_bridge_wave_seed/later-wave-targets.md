# Later-Wave Targets

Once this bridge wave lands cleanly, the next natural branches are:

1. `abyss-stack`
   - generated runtime collections for unlock proofs, party templates, and navigation bundles
   - bounded service aggregation that feeds frontend projections without stealing meaning

2. `aoa-sdk`
   - promote the local RPG compatibility slice into the wider SDK compatibility registry when paths stabilize
   - add typed bridge readers for unlock proof, party template, and navigation bundles

3. `8Dionysus`
   - public-facing sheet, board, and campaign projection mirrors only after owner repos and runtime contracts stabilize

4. artifact contour
   - only if durable artifact / equipment semantics become strong enough to deserve owner-repo doctrine rather than hints

5. routing promotion
   - only after `aoa-evals` and `aoa-playbooks` publish real generated min surfaces that production routing may safely ingest
