from __future__ import annotations
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
REGISTRY=ROOT/'generated'/'agon_vds_sdk_helper_candidates.min.json'
def validate():
    d=json.loads(REGISTRY.read_text(encoding='utf-8'))
    assert d['registry_id']=='agon.vds_sdk_helper_candidates.registry.v1'
    assert d['wave']=='XI' and d['live_protocol'] is False and d['runtime_effect']=='none'
    assert d['helper_count']>=6
    ids=[]
    for item in d['helpers']:
        assert item.get('must_not_emit')
        assert item.get('may_emit') is not None

    assert 'no_runtime_transition' in d['stop_lines']
    for h in d['helpers']:
        assert 'runtime_state_transition' not in h.get('may_emit', [])
        assert 'live_verdict' not in h.get('may_emit', [])
    return d
if __name__=='__main__':
    d=validate(); print('validated {count} VDS SDK helper candidates'.format(count=d['helper_count']))
