# Patch Notes

- Adds center-owned VDS bridge registry in `Agents-of-Abyss`.
- Adds `aoa-evals` verdict / delta / scar / retention alignment candidates.
- Adds `aoa-memo` candidate intakes for scars, deltas, retention requests and inscription bundles.
- Adds `aoa-stats` derived observability candidates.
- Adds `aoa-sdk` requested-only helper candidates.
- Keeps all surfaces pre-runtime, non-authoritative and owner-bound.
