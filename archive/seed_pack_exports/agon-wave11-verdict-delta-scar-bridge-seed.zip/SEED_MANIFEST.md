# Agon Wave XI Seed: Verdict / Delta / Scar Bridge

This seed lands Wave XI across `Agents-of-Abyss`, `aoa-evals`, `aoa-memo`, `aoa-stats`, and `aoa-sdk`.

## Plant order

```text
1. Agents-of-Abyss
2. aoa-evals
3. aoa-memo
4. aoa-stats
5. aoa-sdk
```

## What this wave does

Wave XI builds the first pre-runtime bridge between future arena adjudication and the artifacts that must follow it:

- verdict draft candidates;
- delta receipt candidates;
- scar request candidates;
- retention request candidates;
- inscription bundle candidates;
- stats observation hints;
- SDK helper candidates for drafting and validating those shapes.

It is bridge-only. It gives future outcomes a lawful path without giving any owner premature sovereignty.

## What this wave does not do

It does not create live arena sessions, execute moves, issue live verdicts, write durable scars, execute retention checks, mutate rank or trust, grant closure, initiate summon, promote anything to `Tree-of-Sophia`, or install hidden scheduler behavior.

## Validation commands

In `Agents-of-Abyss`:

```bash
python scripts/build_agon_vds_bridge_registry.py --check
python scripts/validate_agon_vds_bridges.py
python -m pytest -q tests/test_agon_vds_bridges.py
```

In `aoa-evals`:

```bash
python scripts/build_agon_vds_eval_alignment_registry.py --check
python scripts/validate_agon_vds_eval_alignment.py
python -m pytest -q tests/test_agon_vds_eval_alignment.py
```

In `aoa-memo`:

```bash
python scripts/build_agon_vds_memo_bridge_registry.py --check
python scripts/validate_agon_vds_memo_bridge.py
python -m pytest -q tests/test_agon_vds_memo_bridge.py
```

In `aoa-stats`:

```bash
python scripts/build_agon_vds_stats_observability_registry.py --check
python scripts/validate_agon_vds_stats_observability.py
python -m pytest -q tests/test_agon_vds_stats_observability.py
```

In `aoa-sdk`:

```bash
python scripts/build_agon_vds_sdk_helper_candidates.py --check
python scripts/validate_agon_vds_sdk_helper_candidates.py
python -m pytest -q tests/test_agon_vds_sdk_helper_candidates.py
```

## Next wave

Wave XII may begin an SDK / runtime duel kernel only after this bridge stays non-authoritative.
