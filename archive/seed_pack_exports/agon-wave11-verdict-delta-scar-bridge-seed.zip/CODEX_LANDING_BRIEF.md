# Codex Landing Brief

Plant `Agents-of-Abyss` first. Then plant `aoa-evals`, `aoa-memo`, `aoa-stats`, and `aoa-sdk`.

Do not wire these surfaces into live arena sessions, live verdict emission, durable scar writes, retention execution, rank mutation, or ToS promotion. This wave creates bridge contracts, not arena sovereignty.
