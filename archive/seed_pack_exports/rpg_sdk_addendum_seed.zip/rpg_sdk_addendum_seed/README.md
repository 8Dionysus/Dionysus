# RPG SDK Addendum Seed

This bundle stages a narrow `aoa-sdk` addendum for typed loading of the five canonical RPG contracts.

It is a transport bundle, not an authority surface. Its job is to help Codex plant a thin consumer slice that can read, validate, and query the live RPG reflection layer without moving ownership away from `Agents-of-Abyss` or `abyss-stack`.

## Core rules

- Do not move RPG meaning into `aoa-sdk`.
- Do not let the SDK become a runtime service, reward engine, or hidden orchestrator brain.
- Keep the dual vocabulary overlay source-owned upstream.
- Keep build snapshots, reputation ledgers, quest run results, and frontend projection bundles source-owned by `abyss-stack` runtime surfaces.
- Keep this pass local to `aoa-sdk`; do not widen upstream schemas here.
- Prefer typed collection readers, helper selectors, and local compatibility checks over magic joins.

## Reading path

1. `SEED_MANIFEST.yaml`
2. `APPLY_ORDER.md`
3. `CODEX_NOTES.md`
4. `COVERAGE_MAP.md`
5. `aoa-sdk/docs/RPG_SDK_ADDENDUM.md`
6. `aoa-sdk/docs/RPG_SURFACE_PATHS.md`
7. `aoa-sdk/src/aoa_sdk/rpg/*`
8. `aoa-sdk/tests/test_rpg_api.py`

## What this addendum lands

- a repo-local SDK addendum note for the RPG consumer slice
- explicit generated surface paths for the five canonical RPG contracts
- typed Pydantic models for the RPG runtime and frontend bundle contracts
- a local RPG compatibility API inside `sdk.rpg.compatibility`
- a new `sdk.rpg` façade for querying vocabulary, builds, ledgers, runs, and frontend projections
- fixture transport surfaces for tests
- focused tests that prove the reader path without claiming runtime ownership

## What this addendum does not land

- no upstream repo mutations in `Agents-of-Abyss` or `abyss-stack`
- no runtime service implementation
- no live builder for generated RPG transport files
- no global compatibility-policy rewrite in `sdk.compatibility`
- no quest claiming, reward engine, or auto-award loop
- no frontend code
- no hidden Codex-specific doctrine

## Package shape

This bundle is source-shaped rather than diff-shaped.

The target repo is only `aoa-sdk`. Codex should merge these files into the live repo, preserve local conventions, and adapt only where the current package layout already demands it.
