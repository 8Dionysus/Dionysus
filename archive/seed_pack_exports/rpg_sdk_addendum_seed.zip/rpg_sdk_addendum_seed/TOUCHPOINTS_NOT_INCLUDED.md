# Touchpoints Not Included

This addendum intentionally does not modify upstream owner repositories.

## Not included in this pass

- `Agents-of-Abyss`
  - no new docs, schemas, or generated overlays here
- `abyss-stack`
  - no live generated builder, service, or runtime persistence work here
- `aoa-evals`, `aoa-playbooks`, `aoa-memo`, `aoa-routing`
  - no new reader helpers here; the SDK only preserves refs into those surfaces
- `aoa-skills`, `aoa-techniques`, `aoa-agents`
  - no build or loadout doctrine changes here

## Why

The goal is to teach `aoa-sdk` how to read the RPG contracts that already have canonical homes.

It is not to reopen the ownership map.
