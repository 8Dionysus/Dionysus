# Apply Order

Use the lightest honest route. The default order is:

1. `aoa-sdk`

## Why this order

This is a narrow repo-local addendum.

The upstream doctrine and runtime contracts already belong elsewhere. This pass should only give the SDK enough typed structure to read those contracts cleanly when the generated transport files appear.

## Merge cues

- land docs before code so the local reader contract is explicit
- land `src/aoa_sdk/rpg/*` before updating `src/aoa_sdk/api.py`
- keep the new compatibility rules local to `sdk.rpg.compatibility` in this pass
- merge fixture files only into the existing test workspace, not into repo root
- keep tests honest about missing live builders by treating fixture surfaces as staged transport examples

## Promotion restraint

If this slice proves stable later, the local RPG compatibility rules may be promoted into the repo-wide `CompatibilityAPI`.

That promotion is intentionally out of scope for this pass.
