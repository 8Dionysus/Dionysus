# Coverage Map

This addendum covers the five canonical RPG contracts from the architecture RFC by teaching `aoa-sdk` how to read them as typed collection surfaces.

## Canonical object to SDK mapping

- `dual_vocabulary_overlay_v1`
  - `sdk.rpg.vocabulary()`
  - `sdk.rpg.label_for(canonical_key)`
- `agent_build_snapshot_v1`
  - `sdk.rpg.builds()`
  - `sdk.rpg.build(snapshot_id)`
  - `sdk.rpg.latest_build(agent_id)`
- `reputation_ledger_v1`
  - `sdk.rpg.ledgers()`
  - `sdk.rpg.ledger(subject_ref)`
- `quest_run_result_v1`
  - `sdk.rpg.runs()`
  - `sdk.rpg.run(run_id)`
- `frontend_projection_bundle_v1`
  - `sdk.rpg.bundles()`
  - `sdk.rpg.latest_bundle()`
  - `sdk.rpg.agent_sheet(agent_id)`
  - `sdk.rpg.quest_board()`
  - `sdk.rpg.reputation_panel(subject_ref)`

## Files added by purpose

- `aoa-sdk/docs/RPG_SDK_ADDENDUM.md`
  - local doctrine for the SDK slice
- `aoa-sdk/docs/RPG_SURFACE_PATHS.md`
  - expected generated transport paths and fragment rules
- `aoa-sdk/src/aoa_sdk/rpg/models.py`
  - typed Pydantic models for the five canonical contracts plus collection wrappers
- `aoa-sdk/src/aoa_sdk/rpg/surfaces.py`
  - local compatibility rules and transport loading helpers
- `aoa-sdk/src/aoa_sdk/rpg/registry.py`
  - end-user query API
- `aoa-sdk/src/aoa_sdk/api.py`
  - `self.rpg = RpgAPI(workspace)`
- `aoa-sdk/tests/test_rpg_api.py`
  - read-path proof for the new slice
- `aoa-sdk/tests/fixtures/workspace/...`
  - staged generated transport data for tests only
