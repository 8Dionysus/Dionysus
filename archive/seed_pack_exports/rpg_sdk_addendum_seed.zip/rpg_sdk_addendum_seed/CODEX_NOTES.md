# Codex Notes

Read this bundle as a narrow typed-consumer addendum, not as a repo takeover.

## Operating posture

- Preserve `aoa-sdk` as a typed consumer spine.
- Keep owner meaning upstream.
- Prefer small coherent landings.
- Keep the new `rpg` package local and legible.
- Let test fixtures stage the future generated file shapes without claiming those files already exist in live repos.

## Important non-goals

- do not move source doctrine into `aoa-sdk`
- do not turn `aoa-sdk` into a runtime service
- do not rewrite `sdk.compatibility` globally in this pass
- do not invent live reward, inventory, or quest-state mutation logic
- do not tie the SDK to Codex-only orchestration assumptions

## Safe freedom

Codex is free to adjust import style, line wrapping, helper names, and test idioms to match the live `aoa-sdk` codebase.

The hard constraints are:

- `sdk.rpg` remains consumer-only
- compatibility checks remain local in this pass
- collection wrappers stay thin transport surfaces
- upstream refs stay visible and reviewable
