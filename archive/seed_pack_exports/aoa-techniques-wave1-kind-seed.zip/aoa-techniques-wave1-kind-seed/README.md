# aoa-techniques wave1 kind seed

This package is a compact seed for landing a first `kind` axis in `aoa-techniques` without flattening or replacing the existing `domain` model.

## What this seed assumes

- `domain` stays the ownership and first-routing axis.
- `kind` becomes the new primary reusable-practice axis.
- `family` remains optional in wave1 and can land later if bulk migration noise gets too high.
- generated surfaces should be rebuilt inside the repo rather than hand-carried in this zip.

## Package contents

- `docs/TECHNIQUE_KINDS_SEED.md` for the proposed doctrine
- `config/technique_kind_registry.yaml` for the proposed `kind` values and tie-break rules
- `config/technique_family_seed.yaml` for optional family clustering hints
- `data/technique_kind_wave1.yaml` for the current catalog mapping (`id -> kind -> family`)
- `data/technique_kind_wave1.csv` for quick spreadsheet / diff use
- `notes/CODEX_HANDOFF.md` for direct landing guidance
- `reports/wave1_kind_counts.md` for sanity-check counts

## Recommended landing order

1. read `notes/CODEX_HANDOFF.md`
2. land the `kind` doctrine and registry
3. bulk patch current frontmatter or add a temporary migration overlay
4. expose `kind` in generated catalog surfaces
5. optionally land `family` if it stays cheap and clean

## Deliberate non-goals

- no domain expansion in this seed
- no generated `generated/*.json` payloads shipped here
- no feat-surface reshaping
- no attempt to turn `aoa-techniques` into `aoa-skills`, `aoa-evals`, or playbook choreography
