# Codex handoff

This seed is shaped for a Codex that already knows the repo and can land the wave contextually.
It intentionally avoids brittle generated payloads and over-prescriptive patches.

## Preferred wave1 contract

- keep `domain` unchanged
- add `kind` as exactly one primary value per technique
- expose `kind` in catalog output and selection surfaces
- keep `tags` freeform
- treat `family` as optional for wave1 unless the bulk patch remains cheap

## Primary repo touchpoints

1. `schemas/technique.schema.json`
   - add `kind` to `required`
   - add a `kind` enum sourced from the registry in this seed
   - do **not** widen or rename current `domain` values in the same wave

2. `templates/TECHNIQUE.template.md`
   - add `kind` directly below `domain`
   - keep comments short and enum-backed

3. `scripts/validate_repo.py`
   - add `KIND_VALUES` / `KIND_ORDER` or equivalent
   - validate the new field
   - surface `kind` in full and min catalog entries
   - optionally expose `kind` in capsule payloads if that stays clean
   - update selection-surface wording from `domain first` to `domain first, kind second`

4. `scripts/build_catalog.py`
   - likely no major logic change beyond generator outputs already sourced from `validate_repo.py`

5. generated surfaces
   - rebuild `generated/technique_catalog*.json`
   - rebuild `docs/TECHNIQUE_SELECTION.md`
   - rebuild `docs/SELECTION_PATTERNS.md` only if family-aware routing is landed
   - do not hand-edit generated outputs in the seed itself

## Rollout modes

### Clean wave

- add `kind` to schema + template + validator
- bulk patch current technique frontmatter from `data/technique_kind_wave1.yaml`
- rebuild generated surfaces

### Softer wave

- land doctrine + registry + mapping first
- add a temporary migration overlay in the validator that reads the mapping file for existing techniques
- later lift the mapping into frontmatter and remove the overlay

Preferred posture: **clean wave** if Codex can patch the corpus in one pass.

## Optional wave1.5 hook

`family` is included as an optional cluster axis. Land it only if one of these is true:

- selection surfaces clearly benefit from cluster navigation
- the bulk frontmatter patch stays low-risk
- Codex can keep the family registry synchronized without inventing ad hoc clusters

Otherwise, keep `family` as a seed-only annex for the next wave.

## Non-goals

- do not replace `domain`
- do not turn `kind` into score theater or promotion status
- do not mutate feat surfaces as source of truth
- do not use `kind` to smuggle scenario choreography, role contracts, or execution packaging into `aoa-techniques`

## Sanity checks after landing

- the repo still validates cleanly
- `TECHNIQUE_SELECTION.md` still starts from `domain`
- new techniques can choose a `kind` quickly from the registry without reading the whole corpus
- ambiguous cases can still be clarified with `tags` and, optionally, `family`
