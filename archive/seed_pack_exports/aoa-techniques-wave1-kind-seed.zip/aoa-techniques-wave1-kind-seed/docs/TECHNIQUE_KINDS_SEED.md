# Technique Kinds Seed

This note proposes a first `kind` axis for `aoa-techniques`.

The aim is simple:

- keep `domain` as ownership
- add `kind` as the primary answer to “what sort of reusable practice is this?”
- leave `tags` freeform
- keep `family` optional until cluster-aware routing is worth the extra surface area

## Why this axis exists

The current corpus is broad enough that `domain` alone is no longer the whole routing story.
A selector may know they need a technique in `docs` or `agent-workflows`, but still need a faster second cut:

- workflow vs guardrail
- composition vs distribution
- artifact vs lift
- validation vs assessment

`kind` gives that second cut without asking `domain` to carry too much meaning.

## Axis model

- `domain` = where the technique belongs and which review vocabulary owns it
- `kind` = what primary reusable practice it is
- `family` = optional stable cluster inside the corpus
- `tags` = freeform nuance

## Proposed frontmatter shape

```yaml
id: AOA-T-XXXX
name: technique-name
domain: docs
kind: composition
status: canonical
```

## Proposed kinds

| kind | use it when the main promise is... |
|---|---|
| `workflow` | how to do bounded work step by step |
| `guardrail` | how to block, narrow, gate, or approve unsafe paths |
| `validation` | how to emit or consume explicit proof, integrity, or contract-verification evidence |
| `composition` | how smaller pieces deterministically become one effective result |
| `distribution` | how one canonical source safely fans out to multiple targets |
| `artifact` | what durable artifact, snapshot, spec, note, transcript, or index should exist |
| `lift` | how a weaker derived surface is produced from a stronger authoritative source |
| `discovery` | how capabilities or resources are surfaced or curated without taking ownership of meaning |
| `handoff` | how work survives transfer, checkpoint, compaction, approval, or continuation |
| `ingest` | how raw external inputs become structured reviewable intermediates |
| `assessment` | how routes, diagnoses, causes, or options are classified without mutating anything yet |
| `recovery` | how degraded continuation, repair, rollback, or regrounding stays bounded |

## Tie-break rules

### Workflow vs guardrail

Choose `workflow` when the technique explains how to do the work.
Choose `guardrail` when the technique explains where the work must stop, narrow, or request approval.

### Artifact vs lift

Choose `artifact` when the technique defines a primary durable artifact or storage shape.
Choose `lift` when the technique derives a bounded secondary surface from a stronger authoritative source.

### Composition vs distribution

Choose `composition` when many parts become one result.
Choose `distribution` when one canonical source reaches many targets.

### Validation vs assessment

Choose `validation` when the main output is proof, health, integrity, or correctness evidence.
Choose `assessment` when the main output is classification, diagnosis, or route comparison.

### Handoff vs workflow

Choose `handoff` when continuation across seams is the center of gravity.
Choose `workflow` when the center of gravity is the work loop itself.

### Ingest vs lift

Choose `ingest` for raw external inputs.
Choose `lift` for bounded derived surfaces from authoritative internal artifacts.

## What wave1 should expose

Minimum:

- `kind` in markdown frontmatter
- `kind` in full and min catalog JSON
- `kind` visible in selection guidance as a second narrowing question after `domain`

Optional:

- `kind` in capsule payloads
- `family` in frontmatter and selection surfaces

## What wave1 should avoid

- changing the current `domain` map
- inventing new domains just to fit individual techniques
- replacing technique meaning with feat labels or reader overlays
- turning `kind` into status, score, or promotion theater

## Future hook

If cluster-aware routing becomes worth it, land `family` as a separate registry-backed axis.
Do not overload `kind` with cluster semantics just because `family` has not landed yet.
