# Coverage Map

## Included now

### `Agents-of-Abyss`
Common second-wave model and scope.

### `aoa-techniques`
Derived feat / perk reflection and mastery-harvest posture.

### `aoa-skills`
Derived ability-card reflection and pack-profile-aware loadout posture.

### `Dionysus`
Prep-pack note, map, and quest object for seed-garden staging.

## Reused from first wave

- `aoa-agents` progression contract
- `aoa-evals` progression evidence
- `aoa-playbooks` questline / campaign outline
- `aoa-memo` chronicle writeback
- `aoa-routing` derived quest-board seam

## Excluded now

See `TOUCHPOINTS_NOT_INCLUDED.md` and `later-wave-targets.md`.
