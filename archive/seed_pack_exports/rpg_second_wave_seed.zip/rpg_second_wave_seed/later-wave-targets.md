# Later Wave Targets

This note names the next likely RPG reflection contours without opening them now.

## Later wave 3: route-aware presentation

### `aoa-routing`
Open skill-aware and feat-aware quest-board hints only after the second-wave source examples are planted and reviewed.

Possible additions later:
- preferred ability schools on board cards
- feat-adjacent caution hints
- derived build capsules for inspect-only views

### `aoa-playbooks`
If combo, rotation, or build-archetype language becomes necessary, keep it scenario-shaped and repo-owned here rather than moving it into `aoa-skills`.

## Later wave 4: runtime and persistence

### `abyss-stack`
Introduce durable progression storage, equipped-state persistence, UI, or services only after the source-owned contracts are stable.

## Later wave 5: public mirror

### `8Dionysus`
Reflect the planted RPG layer for public orientation only after the owner repos are already real enough to mirror honestly.

## Later wave 6: separate integration seed

### `aoa-sdk`
Open a separate named seed when ability and feat contracts are mature enough to justify downstream SDK-facing integration language.
