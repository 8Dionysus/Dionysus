# RPG Second Wave Seed

This bundle stages the second adjunct RPG reflection layer on top of the live AoA questbook contour and the first-wave progression/proof spine.

It is a transport bundle, not an authority surface. Its job is to help Codex plant repo-owned docs, schemas, generated example surfaces, and quest objects for the abilities-and-feats contour without mutating existing skill bundles, technique canon, playbook method, routing authority, or runtime ownership.

## Core rules

- Do not mutate `work_quest_v1`, `quest_dispatch_v1`, or the first-wave progression contracts in this pass.
- Do not add volatile RPG fields to `skills/*/SKILL.md`, `techniques/*/TECHNIQUE.md`, or existing portable export frontmatter in this pass.
- Do not create a live loadout manager, combo engine, cooldown system, or cross-repo score service in this pass.
- Keep skill ability cards derived from existing skill sources.
- Keep technique feat cards derived from technique canon, readiness, and evidence surfaces.
- Keep pack profiles as loadout posture hints, not runtime inventory.
- Keep playbooks as the home of scenario method and rotations if that contour arrives later.
- Keep generated example files reviewable and non-authoritative until a real builder and validator exist.

## Reading path

1. `SEED_MANIFEST.yaml`
2. `APPLY_ORDER.md`
3. `CODEX_NOTES.md`
4. `Agents-of-Abyss/docs/RPG_SKILLS_AND_FEATS.md`
5. repo-local docs, schemas, generated examples, and quest files
6. `Dionysus/seed_rpg_second_wave_pack.md`
7. `Dionysus/seed_rpg_second_wave_pack.map.yaml`

## What this second wave lands

- a common AoA-level second-wave model for skills as abilities and techniques as feats
- one bounded second-wave scope note
- a skill-ability catalog contract in `aoa-skills`
- a skill loadout posture note in `aoa-skills` grounded in existing pack profiles and adapter seams
- a technique-feat catalog contract in `aoa-techniques`
- a mastery-harvest posture note in `aoa-techniques`
- a `Dionysus` prep-pack note and map for seed-garden staging

## What this second wave does not land

- no direct mutation of existing `SKILL.md` or `TECHNIQUE.md` author surfaces
- no playbook combo / rotation / build-archetype system
- no routing expansion or quest-board builder changes
- no runtime persistence, UI, storage, or services in `abyss-stack`
- no public mirror rollout in `8Dionysus`
- no inventory, loot, health, mana, stamina, or combat simulation layer
- no automatic ability equip, quest claiming, or progression award service
- no live cross-repo rank aggregation

## Package shape

This bundle is source-shaped rather than diff-shaped.

Each repo folder contains the proposed author surfaces that belong to that repo. Codex should merge them into the current repo context, update the human-facing questbook where appropriate, and preserve local naming and formatting conventions.
