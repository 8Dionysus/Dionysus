# Apply Order

Use the lightest honest route. The default order is:

1. `Agents-of-Abyss`
2. `aoa-techniques`
3. `aoa-skills`
4. `Dionysus`

## Why this order

### 1. `Agents-of-Abyss`
Land the common second-wave model first so the skills/feats contour does not get invented separately inside sibling repos.

### 2. `aoa-techniques`
Land feat and mastery-harvest reflection before skill ability cards try to speak about inherited feat adjacency or reusable-practice mastery.

### 3. `aoa-skills`
Land skill ability cards and loadout posture after the feat vocabulary exists, so ability reflection can stay grounded in upstream technique canon and existing pack-profile reality.

### 4. `Dionysus`
Reflect the package as a named prep pack only after the upstream repo-owned surfaces are legible.

## Merge cues

For each target repo:

- plant the new docs, schema, generated example, and quest files
- update `QUESTBOOK.md` to mention the new quest ID in the correct band
- add README or docs-map route links only if the target repo already curates that kind of route list
- keep generated example surfaces clearly non-authoritative
- do not build a live generator in this pass unless that repo already has the right builder and validator seams
- keep the repo as the owner of its own meaning

## Live-surface restraint

This pack intentionally leaves all new RPG surfaces example-only.

If a target repo wants a live builder later, open that as a later quest rather than sneaking it into this wave.

## Source-surface restraint

This pack should not widen or rewrite:

- `skills/*/SKILL.md`
- `skills/*/techniques.yaml`
- `.agents/skills/*`
- `techniques/*/TECHNIQUE.md`
- `TECHNIQUE_INDEX.md`
- existing install, trust, or release profiles

The second-wave gain is a better reader layer for abilities and feats, not a stealth rewrite of current source ownership.
