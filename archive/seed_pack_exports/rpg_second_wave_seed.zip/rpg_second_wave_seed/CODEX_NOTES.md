# Codex Notes

Read this bundle as a seed pack, not as a blind copy plan.

## Operating posture

- Preserve repo ownership boundaries.
- Prefer small coherent landings.
- Keep the bundle vocabulary intact, but let file formatting follow local repo conventions.
- Treat generated example surfaces as review scaffolds unless the target repo already has the right builder and validator seams.
- Prefer grounding examples in live skill names, technique IDs, and pack-profile names that already exist in the target repo.
- If a local profile name or generated-surface name has drifted, adjust the example values instead of forcing stale literals.

## Important non-goals

- do not add RPG frontmatter to committed `SKILL.md` bundles
- do not add feat/perk doctrine into `TECHNIQUE.md` frontmatter
- do not let `aoa-skills` become a playbook or runtime inventory service
- do not let `aoa-techniques` become a second skill catalog
- do not let `Dionysus` become the owner of ability or feat doctrine
- do not widen routing, runtime, or profile surfaces in this wave

## Expected merges

- merge each new quest object into the repo's human questbook surface
- keep generated example surfaces clearly marked as examples
- keep ability cards derived from live skill state, not manually embellished lore
- keep feat cards derived from technique canon, readiness, and evidence posture
- add minimal README or docs-map routing only when that repo already curates those routes

## Safe freedom

Codex is free to adjust local wording, line wrapping, JSON formatting, and README insertion points when needed to fit the live repo.

The hard constraint is ownership and boundary discipline, not byte-perfect formatting.
