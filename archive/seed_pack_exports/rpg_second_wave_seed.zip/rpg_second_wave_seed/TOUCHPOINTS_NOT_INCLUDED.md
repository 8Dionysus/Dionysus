# Touchpoints Not Included

This second wave intentionally excludes the following repo homes and topic seams.

## Repos not included now

- `aoa-agents`
  - first-wave progression contract is reused as-is
- `aoa-evals`
  - first-wave progression evidence is reused as-is
- `aoa-playbooks`
  - future combo / build archetype or rotation language only if it stays scenario-shaped
- `aoa-memo`
  - future chronicle enrichment only after source-owned ability/feat surfaces are real
- `aoa-routing`
  - future ability-aware or feat-aware quest-board hints after source examples exist
- `abyss-stack`
  - future persistence, UI, storage, and services
- `8Dionysus`
  - future public orientation mirror after owner-repo reality is planted
- `aoa-sdk`
  - separate named seed later
- `ATM10-Agent`
  - outside this contour
- `Tree-of-Sophia`
  - outside this contour
- `aoa-kag`
  - outside this contour

## Surfaces not included now

- live loadout manager
- per-agent equipment state
- cooldowns, action points, stamina, mana, or hit points
- combo engine or rotation simulator
- quest-specific build solver
- direct mutation of `.agents/skills/*`
- direct mutation of `TECHNIQUE.md` or `SKILL.md` source bodies to carry RPG doctrine
- runtime services or databases
- auto-generated leaderboards
- automatic progression award services

## Why these are excluded

The honest second-wave win is better legibility around skill abilities and technique feats while reusing the first-wave progression/proof spine. It should not outrun the owning repos with runtime mechanics, public mirrors, or decorative game systems.
