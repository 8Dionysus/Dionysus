# aoa-stats MCP contract v1

This contract turns the earlier read-only concept into a concrete first implementation seam.

## Scope

The server is intentionally narrow:

- read-only
- generated-surface-first
- boundary-aware
- local-repo-scoped
- non-sovereign

It exists to let Codex inspect `aoa-stats` as derived observability without promoting `aoa-stats` into workflow authority, proof authority, or quest-state authority.

## Tools

### `stats_catalog`
Returns the compact runtime-entry catalog from `generated/summary_surface_catalog.min.json`.

Use for:

- discovering available derived surfaces
- reading validation refs
- choosing the smallest useful next read

### `stats_surface_read`
Reads one generated surface by `surface_name` or `surface_ref`.

Arguments:

- `surface_name` or `surface_ref` (exactly one required)
- `mode = "preview" | "full"`
- `limit` for preview truncation

Rules:

- preview is the default
- full should be used only when needed
- refs must stay inside the repo root

### `stats_source_registry`
Returns `config/live_receipt_sources.json`.

Use for:

- seeing which owner-local logs feed the stats layer
- understanding the read model intake boundary

### `stats_boundary_rules`
Returns a small bundle from `docs/BOUNDARIES.md` and `docs/ARCHITECTURE.md`.

Use for:

- regrounding when an agent starts treating stats as authority
- reminding Codex that owner repos still own meaning

## Resources

- `aoa-stats://catalog`
- `aoa-stats://source-registry`
- `aoa-stats://boundaries`
- `aoa-stats://surface/{name}`

## Prompts

- `inspect_stats_surface(name)`
- `compare_stats_surfaces(left, right)`

These are helper launch pads, not hidden policy engines.

## Explicit non-goals

The server must not:

- tail raw receipt JSONL files directly
- write or mutate stats outputs
- infer new owner meaning
- emit one global score
- replace `aoa-evals` verdicts
- replace routing or quest-state logic
- become a generic file browser for the repo

## Suggested merge path

- `repo-overlay/src/aoa_stats_mcp/*` -> `aoa-stats/src/aoa_stats_mcp/*`
- `repo-overlay/scripts/aoa_stats_mcp_server.py` -> `aoa-stats/scripts/aoa_stats_mcp_server.py`
- `repo-overlay/tests/test_aoa_stats_mcp_state.py` -> `aoa-stats/tests/test_aoa_stats_mcp_state.py`
- `repo-overlay/requirements-mcp.txt` -> `aoa-stats/requirements-mcp.txt`
