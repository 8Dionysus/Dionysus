"""Read-only MCP server surfaces for aoa-stats."""

from __future__ import annotations

__all__ = ["__version__"]

__version__ = "0.1.0"
