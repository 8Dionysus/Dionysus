from __future__ import annotations

from aoa_stats_mcp.server import main

if __name__ == "__main__":
    main()
