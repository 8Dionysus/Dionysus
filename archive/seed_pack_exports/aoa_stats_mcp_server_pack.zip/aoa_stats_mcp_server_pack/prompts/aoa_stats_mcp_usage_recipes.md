# aoa-stats MCP usage recipes

## 1. Read the runtime capsule first

> Use `stats_boundary_rules`, then `stats_catalog`, and tell me which generated aoa-stats surface is the smallest honest next read for understanding current closeout posture.

## 2. Inspect one surface without overclaiming

> Use `stats_boundary_rules` and `stats_surface_read(surface_name="runtime_closeout_summary", mode="preview")`. Summarize what the derived surface says and what still belongs to owner repos.

## 3. Compare two surfaces

> Use `stats_boundary_rules`, then compare `surface_detection_summary` and `runtime_closeout_summary` in preview mode. Call out where the signals align and where they should not be treated as authority.

## 4. Understand intake boundaries

> Use `stats_source_registry` and explain which owner-local logs aoa-stats consumes, without implying that aoa-stats owns those source meanings.
