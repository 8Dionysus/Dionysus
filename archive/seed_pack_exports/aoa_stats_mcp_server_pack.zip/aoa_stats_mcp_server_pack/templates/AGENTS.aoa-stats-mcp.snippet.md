## aoa-stats MCP posture

- Treat the `aoa_stats` MCP server as derived-only context.
- Start with `stats_catalog` before reading any specific surface.
- Prefer `stats_surface_read(..., mode="preview")` first; expand to `full` only when truly necessary.
- Use `stats_boundary_rules` whenever there is risk of treating counts or summaries as owner meaning.
- Never let `aoa-stats` override canonical meaning from `aoa-skills`, `aoa-evals`, `aoa-playbooks`, `aoa-techniques`, `aoa-agents`, `aoa-memo`, or `abyss-stack`.
- Do not extend this server toward raw receipt tailing, write actions, route authority, proof authority, or quest-state authority.
