# aoa-stats MCP server pack v0

This pack is the next strike after the crosswalk and bridge pack: a real, read-only, local STDIO MCP scaffold for `aoa-stats`.

Why `aoa-stats` first:

- it already has a compact runtime-entry capsule in `generated/summary_surface_catalog.min.json`
- it already has strong derived-only boundaries
- it already points back to owner-local sources instead of pretending to own their meaning

## What is inside

- `repo-overlay/src/aoa_stats_mcp/`: the read-only MCP package
- `repo-overlay/scripts/aoa_stats_mcp_server.py`: repo-root bootstrap launcher
- `repo-overlay/tests/test_aoa_stats_mcp_state.py`: helper-layer tests
- `repo-overlay/requirements-mcp.txt`: minimal MCP dependency line
- `contracts/aoa_stats_mcp_contract_v1.md`: narrow boundary contract
- `templates/codex/config.snippet.toml`: Codex MCP config snippet
- `templates/AGENTS.aoa-stats-mcp.snippet.md`: optional guidance snippet
- `prompts/aoa_stats_mcp_usage_recipes.md`: first explicit prompts
- `ROLL_OUT.md`: merge order

## Intended posture

This server is intentionally small.

It exposes only four tools:

- `stats_catalog`
- `stats_surface_read`
- `stats_source_registry`
- `stats_boundary_rules`

It also exposes a few matching resources and two prompt recipes.

That is deliberate. The point is to open one honest read path into `aoa-stats`, not to turn it into a file browser or a hidden authority layer.

## Quick local test after merge

From the `aoa-stats` repo root:

```bash
pip install -r requirements-mcp.txt
python -m pytest -q tests/test_aoa_stats_mcp_state.py
python scripts/aoa_stats_mcp_server.py
```

## Suggested Codex config

Merge the snippet from `templates/codex/config.snippet.toml` into the config layer you use for Codex.

The launcher script keeps the `src/` layout simple by inserting the repo's `src/` directory into `sys.path` before starting the server.

## What I would do immediately after this lands

1. Test the server from Codex with `stats_catalog` and one preview read.
2. Add only the AGENTS guidance that keeps `aoa-stats` derived-only.
3. Keep the server read-only until the usage shape is calm.
4. Then prepare the second MCP surface for `Dionysus`.
