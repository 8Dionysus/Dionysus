# Rollout order

1. Copy `repo-overlay/src/aoa_stats_mcp/` into the `aoa-stats` repo.
2. Copy `repo-overlay/scripts/aoa_stats_mcp_server.py` into `aoa-stats/scripts/`.
3. Copy `repo-overlay/tests/test_aoa_stats_mcp_state.py` into `aoa-stats/tests/`.
4. Add `requirements-mcp.txt` or merge `mcp[cli]>=1.2.0,<2` into the repo's chosen dependency surface.
5. From the repo root, run:
   - `python -m pytest -q tests/test_aoa_stats_mcp_state.py`
6. Start the server locally:
   - `python scripts/aoa_stats_mcp_server.py`
7. Merge `templates/codex/config.snippet.toml` into the Codex config layer you actually use.
8. Optionally merge `templates/AGENTS.aoa-stats-mcp.snippet.md` into workspace or repo guidance.
