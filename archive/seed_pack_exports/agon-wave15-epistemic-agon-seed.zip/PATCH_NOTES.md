# Patch Notes

Adds Wave XV pre-protocol epistemic surfaces across the federation.
No live verdicts, durable scars, rank mutations, hidden scheduling, KAG promotion, or Tree-of-Sophia promotion are introduced.
