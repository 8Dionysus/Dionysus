# Codex Landing Brief

Merge each repo directory into the matching repository root in the listed order. Run the owner-local build and validate scripts before wiring this into broader release checks.
