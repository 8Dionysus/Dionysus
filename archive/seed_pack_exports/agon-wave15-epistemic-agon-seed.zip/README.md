# Agon Wave XV Seed: Epistemic Agon

This seed introduces the first epistemic layer of Agon: hypotheses, model-of-other predictions, concept-map deltas, inference-chain challenges, bifurcation candidates, epistemic rupture candidates, and doctrine revision requests.

It lands after Wave XIV Retention and Rank Economy. Wave XV does not replace mechanical trials; it builds on them by making knowledge itself contestable, witnessable, and reviewable.
