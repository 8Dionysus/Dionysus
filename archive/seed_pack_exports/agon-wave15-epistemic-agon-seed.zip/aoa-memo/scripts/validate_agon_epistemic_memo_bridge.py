#!/usr/bin/env python3
from __future__ import annotations
import json, pathlib, sys
ROOT = pathlib.Path(__file__).resolve().parents[1]
SRC = ROOT / 'config/agon_epistemic_memo_bridge.seed.json'
OUT = ROOT / 'generated/agon_epistemic_memo_bridge_registry.min.json'
ITEM_KEY = 'bridges'
EXPECTED_COUNT = 7
KEY_FIELDS = ['bridge_id']
REQUIRED_FIELDS = ['bridge_id', 'owner_repo', 'status', 'intake_for', 'candidate_outputs', 'forbidden_effects']
ALLOWED_RUNTIME = ('none', 'candidate_only', 'local_dry_run_candidate_only', 'local_rehearsal_candidate_only')

def fail(msg):
    print(msg, file=sys.stderr)
    return 1

def item_key(item):
    for k in KEY_FIELDS:
        if item.get(k):
            return item[k]
    return item.get('id')

def validate_item(item):
    for field in REQUIRED_FIELDS:
        if field not in item:
            return f'missing required field {field} in {item}'
    if item.get('live_protocol') is not False:
        return f'live_protocol must be false for {item_key(item)}'
    if item.get('runtime_effect') not in ALLOWED_RUNTIME:
        return f'invalid runtime_effect for {item_key(item)}: {item.get("runtime_effect")}'
    forbidden_effects = set(item.get('forbidden_effects', []))
    for forbidden in ('live_verdict_authority', 'durable_scar_write', 'rank_mutation', 'tree_of_sophia_promotion', 'auto_doctrine_rewrite'):
        if forbidden not in forbidden_effects:
            return f'missing forbidden_effect {forbidden} in {item_key(item)}'
    return None

def main():
    if not SRC.exists():
        return fail(f'missing source {SRC}')
    data = json.loads(SRC.read_text(encoding='utf-8'))
    items = data.get(ITEM_KEY, [])
    if len(items) != EXPECTED_COUNT:
        return fail(f'expected {EXPECTED_COUNT} items in {ITEM_KEY}, got {len(items)}')
    seen = set()
    for item in items:
        key = item_key(item)
        if not key:
            return fail(f'missing item key in {item}')
        if key in seen:
            return fail(f'duplicate item key {key}')
        seen.add(key)
        err = validate_item(item)
        if err:
            return fail(err)
    if OUT.exists():
        reg = json.loads(OUT.read_text(encoding='utf-8'))
        if reg.get('count') != len(items):
            return fail('generated count does not match source item count')
    print(json.dumps({'ok': True, 'item_key': ITEM_KEY, 'count': len(items)}, sort_keys=True))
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
