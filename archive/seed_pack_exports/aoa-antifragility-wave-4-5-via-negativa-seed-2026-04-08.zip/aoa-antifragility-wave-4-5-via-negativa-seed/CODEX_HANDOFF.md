# Codex Handoff

Assume waves 1 through 4 are already landed, or that equivalent owner-local receipts, proof surfaces, routing hints, memory objects, playbook lanes, handoff envelopes, and runtime receipts exist.

Use this seed as a bounded pruning instrument.
The goal is not to build a new layer.
The goal is to reduce fragility by subtracting duplicated meaning, shadow authority, stale convenience, and misplaced public surface.

## Primary objective

Teach the ecosystem to do five things before it adds more:

1. identify duplicated or misplaced surfaces
2. map each surface back to its real owner
3. choose the lightest corrective action: keep, merge, move, suppress, quarantine, deprecate, or delete
4. preserve provenance, receipts, proof, and explicit boundaries while pruning
5. leave behind fewer sovereign-seeming convenience surfaces

## P0 deliverables

- `Agents-of-Abyss/docs/VIA_NEGATIVA.md`
- `Agents-of-Abyss/docs/ANTI_AUTHORITY_RULES.md`
- `Agents-of-Abyss/docs/ONE_IN_ONE_OUT.md`
- `DELETION_CANDIDATES.json`
- repo-local `docs/VIA_NEGATIVA_CHECKLIST.md` overlays for the repositories touched by waves 1 through 4

## Acceptance criteria

1. every deletion or merge candidate is inspect-first and owner-aware
2. no center or convenience layer becomes more authoritative as a side effect of cleanup
3. public surfaces get smaller, clearer, or more canonical after the pass
4. archived or historical material moves to the right home instead of polluting active runbooks
5. stale, low-evidence, or duplicative derived outputs are suppressed, merged, quarantined, or removed
6. no via negativa action destroys provenance, source receipts, or bounded proof anchors
7. one-in-one-out is applied with documented exemptions rather than blindly

## Suggested method

### 1. Inventory current surfaces
List tracked docs, schemas, examples, bundles, route hints, memory object kinds, agent profiles, playbook lanes, helper wrappers, and runtime repair surfaces touched by the first four waves.

### 2. Reconcile with source-of-truth docs
Use each repo's existing canonical roles first.
If a repository already has a source-of-truth file, contribution guide, or public-surface policy, fold the checklist there unless a standalone checklist is materially cleaner.

### 3. Compare against deletion candidates
Use `DELETION_CANDIDATES.json` as an inspect-first list.
A candidate is a question, not a verdict.

### 4. Choose the lightest corrective action
Prefer this order:

1. keep
2. merge
3. move
4. suppress
5. quarantine
6. deprecate
7. delete

Deleting should be the last move when no better home or safer narrower posture exists.

### 5. Record rationale
Use local decision logs, commit messages, ADR notes, or repo-native change records.
Do not rely on memory alone for why something was removed or merged.

## Stop conditions

Stop and preserve the current surface when:

- the real owner is unclear
- the deletion would sever provenance or proof links
- the candidate hides an active operator workflow that has no replacement
- the candidate removes a schema or example still required by tests or validation
- the package guidance conflicts with a stricter owner-local rule

## Merge-first note

This seed intentionally includes many checklist files.
That does not mean every checklist should survive as its own permanent tracked doc.
If an existing canonical surface can absorb the content cleanly, merge there and delete the temporary checklist proposal.
