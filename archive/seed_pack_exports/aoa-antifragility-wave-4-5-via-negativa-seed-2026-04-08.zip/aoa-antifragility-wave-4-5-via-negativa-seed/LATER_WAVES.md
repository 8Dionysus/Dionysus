# Later Waves

Via negativa should stay mostly manual until real convergence appears across repositories.

Later automation is only justified after multiple manual pruning passes agree on the same smells and the same safe corrective moves.

## Plausible later work

- a shared duplicate-surface detector for docs, schemas, and examples
- a bounded eval bundle for public-surface sprawl and authority drift
- optional stats views for pruning debt, only if they stay derived and split-axis
- source-of-truth linting rules for repo-local canonical surfaces
- migration helpers for deprecating wrappers, stale view families, or shadow object kinds

## What not to automate yet

- automatic file deletion
- cross-repo authority arbitration
- memo-driven cleanup
- scorecards ranking repos by "purity"
- broad refactors that rewrite owner-local doctrine without review

Earn automation the hard way:
first show that humans and Codex repeatedly make the same safe subtraction choices.
