# AoA Antifragility Wave 4.5 Via Negativa Seed

This package is a repo-relative overlay seed for a via negativa pruning pass across the public AoA surface touched by antifragility waves 1 through 4.

The posture here is simple:
make the system safer and clearer by removing exposures before adding new protective ornament.

## Overlay model

Each top-level directory in this seed matches a target repository root.

Examples:

- `Agents-of-Abyss/docs/VIA_NEGATIVA.md`
- `aoa-routing/docs/VIA_NEGATIVA_CHECKLIST.md`
- `aoa-memo/docs/VIA_NEGATIVA_CHECKLIST.md`
- `ATM10-Agent/docs/VIA_NEGATIVA_CHECKLIST.md`

Codex should treat these as repo-relative overlays and merge candidates, not blind copy instructions.
If a target repository already has a canonical source-of-truth or contribution surface, merge the guidance there instead of spawning another long-lived file.

## Package shape

This seed has four jobs:

1. define via negativa as a constitutional pruning posture in `Agents-of-Abyss`
2. define anti-authority rules and a one-in-one-out discipline at the ecosystem center
3. provide a machine-readable `DELETION_CANDIDATES.json` list for inspect-first pruning
4. give each touched repository a local checklist for merge, move, suppress, quarantine, deprecate, or delete decisions

## Recommended sequence

1. read the target repo's existing source-of-truth and canonical docs first
2. merge or land the center rules in `Agents-of-Abyss`
3. inspect `DELETION_CANDIDATES.json` against the live workspace
4. apply repo-local via negativa checklists
5. only after subtraction, decide whether any new wave artifacts still need to be added

## Core guardrails

- prefer merge, move, suppress, quarantine, or deprecate before adding new tracked surfaces
- do not delete source receipts, provenance anchors, required examples, or bounded proof artifacts just to satisfy a quota
- use one-in-one-out as a forcing function against sprawl, not as a blind ritual
- keep source-owned meaning in owner repos
- keep proof, derived observability, routing, memory, and runtime boundaries explicit
- when in doubt, preserve the owner surface and mark a candidate for later human review

## What this seed is not

- not a mass deletion order
- not a license to erase useful history without a better home
- not permission for convenience layers to seize authority while "cleaning up"
- not a reason to replace canonical repo docs with seed docs
- not a new sovereign pruning layer

## Validation expectation

At minimum, Codex should leave the workspace with:

- a smaller or clearer public surface in the touched repos
- fewer duplicate meanings and fewer shadow authorities
- machine-readable deletion candidates that remain inspect-first and evidence-aware
- no silent loss of receipts, provenance, or proof anchors
