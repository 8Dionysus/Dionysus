# Local Validation

Minimum local validation for this seed:

1. parse `MANIFEST.json`
2. validate `DELETION_CANDIDATES.json` against `schemas/deletion_candidate_list_v1.json`
3. confirm every repo listed in `MANIFEST.json.targets` has a corresponding file in the seed
4. confirm the deletion candidates remain inspect-first and owner-review-aware
5. confirm no candidate defaults to deleting source receipts, provenance anchors, or bounded proof surfaces

Suggested Python snippet:

```python
import json
from pathlib import Path
from jsonschema import Draft202012Validator

root = Path(".")
schema = json.loads((root / "schemas" / "deletion_candidate_list_v1.json").read_text())
instance = json.loads((root / "DELETION_CANDIDATES.json").read_text())
Draft202012Validator(schema).validate(instance)
json.loads((root / "MANIFEST.json").read_text())
print("validation ok")
```
