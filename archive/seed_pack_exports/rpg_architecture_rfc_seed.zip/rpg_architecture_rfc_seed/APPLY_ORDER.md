# Apply Order

Use this order unless the live repositories show a stronger local dependency path.

1. `Agents-of-Abyss`
   - land the federation-level RFC, terminology note, boundary map, vocabulary schema, example, and quest object
2. `abyss-stack`
   - land the runtime/frontend posture note, service schemas, examples, and quest object
3. `Dionysus`
   - land the prep-pack note, map, and quest object after the target repos are ready

## Important sequencing notes

- The `Agents-of-Abyss` RFC should land first because it defines the ownership law and vocabulary law that the runtime/frontend contracts depend on.
- The `abyss-stack` schemas should land second because they are service contracts that must read upstream meaning rather than rewrite it.
- The `Dionysus` pack should land last because it is lineage and transport, not authority.

## Optional follow-up after this seed

- `aoa-sdk` typed model and loader support for the new contracts
- `aoa-routing` projection adapters that feed quest-board cards into the runtime bundle
- `aoa-playbooks` party/build projections once the third-wave synergy contour is ready
- `8Dionysus` public entry mirrors only after the runtime contracts and owner repos stabilize
