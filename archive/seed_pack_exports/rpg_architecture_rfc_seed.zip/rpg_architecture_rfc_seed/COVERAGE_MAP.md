# Coverage Map

| Repo | Role in this seed | Files |
|---|---|---|
| `Agents-of-Abyss` | federation-level RFC, terminology, boundary law, vocabulary contract | 6 |
| `abyss-stack` | runtime/frontend posture and service contracts | 10 |
| `Dionysus` | seed-garden staging and lineage map | 3 |

## Not planted here

- `aoa-agents`, `aoa-evals`, `aoa-playbooks`, `aoa-memo`, `aoa-routing`, `aoa-skills`, and `aoa-techniques` are referenced as upstream owners but do not receive new files in this pass.
- `aoa-sdk` is a follow-up target for typed loader support, not a direct landing target in this RFC seed.
