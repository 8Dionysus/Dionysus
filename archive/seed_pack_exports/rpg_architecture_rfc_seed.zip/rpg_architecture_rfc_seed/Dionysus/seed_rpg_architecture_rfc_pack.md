# seed_rpg_architecture_rfc_pack

## Purpose

This prep pack stages the hard architectural RFC for the AoA RPG runtime/frontend contour.

It exists to keep the transport lineage explicit while the owner repos plant:
- federation-level architecture law
- canonical terminology law
- boundary law
- the first runtime/frontend service contracts

## Priority

high

## Why this is a prep pack and not a new numbered wave

The project already has a live staged RPG contour in multiple owner repos.

This pack is narrower than a fresh broad wave:
- it does not widen source doctrine
- it does not open a public mirror
- it does not ship UI code
- it does not create a service runtime yet

It simply fixes the architecture law before later runtime and frontend work grows branches.

## Targets

- `Agents-of-Abyss`
- `abyss-stack`

## Exclusions

- `aoa-sdk` typed implementation
- `8Dionysus` public mirror
- `aoa-routing` live expansion
- `aoa-playbooks` build-archetype or party-template work
- artifact canon
- reward-engine or economy loops

## Final rule

The seed garden keeps the lineage.

The target repos keep the meaning.
