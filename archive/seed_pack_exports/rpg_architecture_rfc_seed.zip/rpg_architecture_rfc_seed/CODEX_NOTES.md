# Codex Notes

Read this bundle as a seed pack, not as a blind copy plan.

## Operating posture

- Preserve repo ownership boundaries.
- Prefer small coherent landings.
- Keep the bundle vocabulary intact, but let file formatting follow local repo conventions.
- Treat schema examples as review scaffolds unless the target repo already has the right validators and builders.
- If a target repo already has adjacent docs or schema directories, splice this material into the live structure instead of forcing a parallel mini-tree.
- Because the live project context is already present in Codex, prefer context-sensitive insertion over literal copy.

## Important non-goals

- do not move quest meaning into runtime contracts
- do not let frontend view models become a second doctrine layer
- do not let `abyss-stack` overrule upstream role, skill, technique, playbook, eval, memo, or routing meaning
- do not let `Agents-of-Abyss` become the owner of runtime session state
- do not let `Dionysus` become the owner of the RFC itself
- do not create a global score, secret reward function, or hidden reputation engine

## Expected merges

- merge each new quest object into the repo's human questbook surface
- keep examples clearly marked as examples
- keep the dual-vocabulary contract machine-readable and theme-safe
- keep runtime contracts explicit about source refs and owner refs
- keep Codex-specific values in examples adjustable rather than frozen into doctrine
- add minimal docs-map routing only when that repo already curates those routes

## Safe freedom

Codex is free to adjust local wording, line wrapping, JSON formatting, enum order, and README insertion points when needed to fit the live repo.

The hard constraint is ownership and boundary discipline, not byte-perfect formatting.
