# RPG Architecture RFC Seed

This bundle stages the hard architectural RFC for the AoA RPG reflection layer after the first-wave progression spine and the second-wave skills/feats contour.

It is a transport bundle, not an authority surface. Its job is to help Codex plant one strict architecture note, one canonical terminology note, one boundary map, one federation-level vocabulary contract, and the first runtime/frontend service contracts without turning the frontend into a secret source of meaning or letting runtime state leak back into repos that do not own runtime.

## Core rules

- Keep source meaning upstream and reviewable.
- Keep runtime state in `abyss-stack`.
- Keep frontend as a reader of derived projections, not an author of doctrine.
- Keep progression multi-axis and evidence-backed.
- Keep reputation scoped, cited, and slice-based rather than global and mystical.
- Keep quest completion, quest state, and playbook meaning in their owner repos.
- Keep Codex as the current orchestrator driver, but do not hard-code the system to Codex forever.
- Keep the canonical vocabulary stable while allowing themed presentation overlays on top.

## Reading path

1. `SEED_MANIFEST.yaml`
2. `APPLY_ORDER.md`
3. `CODEX_NOTES.md`
4. `Agents-of-Abyss/docs/RPG_ARCHITECTURE_RFC.md`
5. `Agents-of-Abyss/docs/RPG_CANONICAL_TERMINOLOGY.md`
6. `Agents-of-Abyss/docs/RPG_BOUNDARY_MAP.md`
7. `Agents-of-Abyss/schemas/dual_vocabulary_overlay.schema.json`
8. `abyss-stack/docs/RPG_RUNTIME_FRONTEND_POSTURE.md`
9. `abyss-stack/schemas/*.json`
10. `Dionysus/seed_rpg_architecture_rfc_pack.md`
11. `Dionysus/seed_rpg_architecture_rfc_pack.map.yaml`

## What this package lands

- one hard AoA-level RPG architecture RFC
- one canonical terminology note that separates machine-stable keys from themed labels
- one repo boundary map that fixes ownership and non-ownership
- one federation-level dual-vocabulary contract
- one runtime/frontend posture note in `abyss-stack`
- four minimal runtime/frontend service contracts in `abyss-stack`
- one `Dionysus` prep-pack note and map for seed-garden lineage
- new quest objects that give the RFC landing stable follow-through IDs

## What this package does not land

- no live reward engine or loot service
- no combat, economy, stamina simulator, or hidden punishment loop
- no direct frontend implementation
- no automatic quest claiming or automatic quest completion writeback
- no public mirror rollout in `8Dionysus`
- no typed `aoa-sdk` implementation in this pass
- no artifact canon repository in this pass
- no new routing authority or playbook runtime engine in this pass

## Package shape

This bundle is source-shaped rather than diff-shaped.

Each repo folder contains the proposed author surfaces that belong to that repo. Codex should merge them into the live repo context, update the human-facing questbook where appropriate, and preserve local naming and formatting conventions.
