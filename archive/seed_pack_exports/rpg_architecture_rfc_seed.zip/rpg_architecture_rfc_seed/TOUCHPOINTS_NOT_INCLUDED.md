# Touchpoints Not Included

This seed intentionally leaves these contours for later passes:

- `aoa-sdk` typed loader and model classes for the new runtime/frontend contracts
- `aoa-routing` live projection adapters beyond the already-bounded quest discovery seam
- `aoa-playbooks` party templates, build archetypes, rotation notes, and campaign-loadout projections
- `aoa-evals` a dedicated runtime-to-verdict bridge update for reputation ledger automation
- `aoa-memo` stronger chronicle projection surfaces for the frontend timeline
- `8Dionysus` public-facing agent sheets or quest-board mirrors
- any dedicated artifact canon owner repository
- UI implementation, transport APIs, persistence engines, or auth surfaces

## Why these are excluded

The current goal is to fix the architecture law before growing more branches.

That means:
- define what is canonical
- define what is runtime-only
- define what the frontend is allowed to read
- define what the frontend is not allowed to invent
