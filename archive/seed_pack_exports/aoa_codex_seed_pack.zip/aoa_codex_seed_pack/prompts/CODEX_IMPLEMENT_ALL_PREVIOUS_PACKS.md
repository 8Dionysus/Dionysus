# Prompt to give Codex

You are landing a set of AoA Codex integration packs into the current AoA sibling workspace.

Read first:
- `aoa_wave1_change_map.md`
- `aoa_codex_surface_crosswalk.md`
- this seed pack's `README.md`
- this seed pack's `doctrine/CONCEPT_FILE_PLACEMENT.md`

Before merging any operational pack, land the concept anchor from:
- `proposed-targets/Agents-of-Abyss/docs/REVIEWABLE_GROWTH_REFINERY.md`

Treat `aoa_codex_bridge_pack.zip` as **reference-only** unless a later pack leaves a narrow missing gap.

Then integrate the remaining packs in this exact order:

1. `aoa_project_mcp_pack.zip`
2. `aoa_stats_mcp_server_pack.zip`
3. `dionysus_mcp_server_pack.zip`
4. `aoa_skill_mcp_wiring_pack.zip`
5. `aoa_local_plugin_pack.zip`
6. `aoa_subagent_projection_pack.zip`
7. `aoa_codex_convergence_pack.zip`
8. `aoa_codex_hooks_doctor_pack.zip`

For each wave:

1. unpack and inspect the pack
2. read its `README.md` and `ROLL_OUT.md` before editing files
3. compare the proposed overlay with the current repo state
4. make the smallest defensible merge that preserves existing repo law
5. keep source-owned meaning in source repos
6. do not flatten AoA into one skill/plugin/MCP empire
7. run the validation path named by the pack
8. update one running landing ledger using the template in `templates/CODEX_LANDING_LEDGER.template.md`

Working rules:
- prefer minimal, reviewable merges over bulk copying
- if later packs supersede earlier files, keep the stronger later shape
- do not silently widen destructive automation
- keep MCP read-only where the packs intend it to stay read-only
- keep subagent depth and role boundaries narrow unless the current repo strongly justifies a change
- if you hit a conflict that changes architecture, stop and explain it before widening the merge

At the end:
- run the convergence and hooks doctors
- produce a reviewed landing report
- summarize what landed, what validated, what drift remains, and what should be the next internal AoA wave
