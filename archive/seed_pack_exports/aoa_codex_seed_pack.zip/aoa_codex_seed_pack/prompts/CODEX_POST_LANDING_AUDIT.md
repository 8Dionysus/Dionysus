# Post-landing audit prompt for Codex

Audit the current AoA workspace after the Codex packs have been landed.

Goals:
- verify what actually landed
- measure how much of the intended control plane is now alive
- detect drift between doctrine and implementation
- name what still blocks the deeper session-growth / lineage wave

Use these sources first:
- `Agents-of-Abyss/docs/REVIEWABLE_GROWTH_REFINERY.md`
- `aoa_wave1_change_map.md`
- `aoa_codex_surface_crosswalk.md`
- the current workspace `.codex/config.toml`
- the current workspace `AGENTS.md`
- `.codex/agents/`
- plugin marketplace and installed plugin roots
- repo-local MCP server code and config for `aoa-stats` and `Dionysus`
- any convergence or hooks reports under `generated/`

Answer in five parts:

1. **Landed surfaces**
   - what exists now across AGENTS, skills, MCP, plugins, subagents, convergence, hooks

2. **Operational health**
   - what validates cleanly
   - what is partially landed
   - what is configured but not yet proven

3. **Boundary integrity**
   - whether any derived layer is starting to overreach
   - whether repo ownership still looks honest

4. **Readiness for the deeper AoA wave**
   - what remains before candidate-lineage, reviewed donor refinement, seed identity, and proof bundles can land cleanly

5. **Next move**
   - the smallest high-value internal AoA implementation wave to do next

Do not just describe files.
Judge whether the landed system behaves like an access nervous system for AoA,
rather than a flattening layer that distorts the federation.
