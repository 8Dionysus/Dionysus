# Reviewable Growth Refinery

## Why this document exists

AoA is not only a federation of repos.
It is a system for turning repeated work, recurring residue, and reviewable session signals into reusable, bounded, source-owned growth.

This document names that system clearly so the rest of the federation can stay narrow without losing the shape of the whole.

## One-sentence definition

AoA is a **reviewable growth refinery**:
a federation that notices recurring operational residue,
captures it without granting it premature authority,
refines it through reviewed closeout,
routes it to the correct owning layer,
proves it where proof belongs,
remembers failure and recovery patterns,
and returns the resulting forms back into live use.

## The core problem

Without a stable refinery, the same work keeps repeating in disguised forms:

- useful routes stay trapped inside individual sessions
- good repair moves disappear after one fix
- repeated mistakes return because they were never shaped into memory
- promising fragments jump to the wrong repo and become noisy clutter
- derived layers overreach and start pretending to own meaning
- automation grows faster than review discipline

AoA exists to metabolize that recurrence without flattening the federation into one hidden empire.

## The governing law

### 1. Source repos own meaning
The repo that owns a kind of object should remain the authority for that object.

### 2. Derived layers stay derived
Observability, routing, graph, and convenience layers may summarize, point, and assist, but they must not silently become the owner of meaning.

### 3. Review comes before promotion
Session residue can be captured early, but promotion into reusable form happens only through reviewed seams.

### 4. Growth stays legible
Every meaningful promotion should leave a trace:
what was observed,
what was refined,
where it was routed,
what superseded it,
what was dropped,
and why.

### 5. Progress is multi-axis
The system should not worship one total score.
Readiness, proof discipline, change legibility, boundary integrity, reuse pressure, and repair quality may move differently.

## The growth loop

### During work
The system observes recurring residue:
repeated actions,
proof needs,
workflow recurrence,
role posture,
repair opportunities,
routing ambiguity,
and other session signals.

These are captured as local, reviewable checkpoint clusters.
They are signals, not authority.

### Reviewed closeout
At closeout, the system decides what should remain a note,
what should become a candidate,
what should branch into diagnosis or repair,
and what should be left behind.

### Donor refinement
A reviewed donor-harvest step turns the best residue into bounded reusable candidates.
This is where the system starts naming likely owner layers and nearest wrong targets.

### Seeding
Candidates that should not yet land directly in an owning repo pass through Dionysus as seeds.
Seeds are staging forms, not final truth.

### Planting
A seed or candidate lands in the correct owner repo as an actual object:
skill,
technique,
playbook,
agent surface,
eval,
memo object,
or another bounded form.

### Proof
Claims about the promotion are tested where proof belongs.
The system should be able to show that the object belongs where it landed and that the promotion was bounded.

### Memory and observability
Failure lessons, recovery patterns, and derived summaries feed back into future work without stealing ownership from source repos.

## Identity and lineage

The system should keep one reviewable nerve through promotion:

- `cluster_ref` for local checkpoint carry
- `candidate_ref` for reviewed reusable candidates
- `seed_ref` for Dionysus staging and seed registry
- `object_ref` for planted owner-repo artifacts

This lineage exists for legibility and accountability.
It does not create a new sovereignty layer.

## What self-diagnosis means here

Self-diagnosis is not the system congratulating itself with clever narration.
It is the disciplined recognition of repeated failure shapes, weak joins, route ambiguity, proof gaps, and repair pressure.

A good diagnosis names:
- what failed
- where the boundary was weak
- what evidence supports the diagnosis
- which repo or layer should own the response

## What self-repair means here

Self-repair is not unlimited autonomous mutation.
It is a bounded, reviewable response to a grounded diagnosis.

A good repair:
- preserves repo ownership boundaries
- changes the smallest honest surface first
- leaves receipts
- can be superseded later
- does not hide itself inside derived or convenience layers

## Where Codex fits

Codex is not the heart of this system.
Codex is the access nervous system.

Its job is to help the federation use its own forms more effectively through:
- project guidance
- skills
- MCP surfaces
- subagents
- plugins
- lifecycle seams

Those surfaces should increase access, not change ownership law.

## Anti-goals

This system should not become:
- a single giant skill empire
- a hidden routing monarchy
- a stats-driven idol machine
- a seed garden pretending to be final truth
- a memory layer that swallows source meaning
- a self-repair theater with no proof discipline

## What success looks like

The same valuable patterns should stop dying at session boundaries.
The same mistakes should become rarer because they are remembered and routed honestly.
New reusable forms should land in the correct owner repos more often.
Derived layers should become more useful without becoming more imperial.
Codex should gain better access to the federation without flattening it.

## Practical implication

Whenever a new surface, automation, or bridge is introduced, ask:

1. what kind of object is this
2. which repo should own it
3. what review seam promotes it
4. what lineage should remain visible
5. how will proof and supersession work
6. how will the system remember both failure and recovery

If those questions stay answerable, the refinery is still healthy.
