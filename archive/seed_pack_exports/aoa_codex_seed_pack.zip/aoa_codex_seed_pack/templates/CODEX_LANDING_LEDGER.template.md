# Codex landing ledger

Use this ledger while landing the AoA Codex packs.
Keep it terse, factual, and wave-shaped.

## Workspace
- workspace root:
- date:
- operator:
- current branch or branches:
- trust state:

## Read-first understanding
- `aoa_wave1_change_map.md` reviewed:
- `aoa_codex_surface_crosswalk.md` reviewed:
- concept anchor accepted:

## Wave log

### Wave 1: concept anchor
- files landed:
- conflicts:
- validations:
- notes:

### Wave 2: project MCP spine
- files landed:
- config merges:
- validations:
- notes:

### Wave 3: aoa-stats MCP
- files landed:
- config merges:
- validations:
- notes:

### Wave 4: Dionysus MCP
- files landed:
- config merges:
- validations:
- notes:

### Wave 5: skill ↔ MCP wiring
- files landed:
- config merges:
- validations:
- notes:

### Wave 6: local plugin
- files landed:
- install path:
- validations:
- notes:

### Wave 7: subagent projection
- files landed:
- generated outputs:
- validations:
- notes:

### Wave 8: convergence
- files landed:
- reports:
- validations:
- notes:

### Wave 9: hooks doctor
- files landed:
- hook paths:
- validations:
- notes:

## Final snapshot
- what is fully landed:
- what is partially landed:
- what stayed reference-only:
- what drift remains:
- recommended next AoA internal wave:
