# AoA Codex seed pack v1

This seed pack is the **landing brain** for the earlier AoA Codex packs.

Its job is not to introduce one more integration surface.
Its job is to give Codex a clear order of operations, an explicit concept anchor, and one reviewable ledger
for integrating the earlier packs into the AoA federation without flattening the repos into one hidden empire.

## What this seed is for

Use this pack only **after** you have dropped the earlier AoA packs and the two foundational docs into the project.

This pack tells Codex:

- which earlier artifacts are **authoritative context**
- which earlier pack is now **reference-only**
- which packs should be landed in what order
- where the **concept document** should live in the federation
- what acceptance gates to check after each wave
- how to write one running landing ledger so the integration stays reviewable

## Core posture

Codex is the access nervous system, not the heart.
The heart remains the AoA federation's own growth-refinery logic.

That means this seed keeps four laws in view:

1. source repos own meaning
2. derived layers stay derived
3. routing stays thin
4. automation must remain reviewable and bounded

## Contents

- `manifests/pack_classification.json`
- `manifests/pack_landing_order.json`
- `doctrine/CONCEPT_FILE_PLACEMENT.md`
- `proposed-targets/Agents-of-Abyss/docs/REVIEWABLE_GROWTH_REFINERY.md`
- `prompts/CODEX_IMPLEMENT_ALL_PREVIOUS_PACKS.md`
- `prompts/CODEX_POST_LANDING_AUDIT.md`
- `checklists/LANDING_ACCEPTANCE_GATES.md`
- `templates/CODEX_LANDING_LEDGER.template.md`

## Intended landing sequence

0. Read the two foundational docs first:
   - `aoa_wave1_change_map.md`
   - `aoa_codex_surface_crosswalk.md`

1. Land the concept anchor from:
   - `proposed-targets/Agents-of-Abyss/docs/REVIEWABLE_GROWTH_REFINERY.md`

2. Treat `aoa_codex_bridge_pack.zip` as **reference-only**
   unless a later pack is missing a narrow file that still matters.

3. Then land the concrete packs in this order:

   1. `aoa_project_mcp_pack.zip`
   2. `aoa_stats_mcp_server_pack.zip`
   3. `dionysus_mcp_server_pack.zip`
   4. `aoa_skill_mcp_wiring_pack.zip`
   5. `aoa_local_plugin_pack.zip`
   6. `aoa_subagent_projection_pack.zip`
   7. `aoa_codex_convergence_pack.zip`
   8. `aoa_codex_hooks_doctor_pack.zip`

4. After every wave, update the landing ledger and run that wave's validation path.

5. After the full landing, run the post-landing audit prompt and produce one reviewed report.

## Why the bridge pack is reference-only now

The early bridge pack was a useful crosswalk prototype, but later packs turned most of its live surfaces into sharper,
more repo-appropriate waves:
workspace MCP, repo-local MCP, skill↔MCP wiring, plugin distribution, subagent projection,
convergence, and hooks-doctor seams.

So the bridge pack should now be mined for missing hints, not merged bluntly ahead of the more specific waves.

## What I would expect Codex to leave behind

- one landed concept document in `Agents-of-Abyss/docs/`
- one workspace-visible Codex control plane rooted at the AoA workspace
- repo-local read-only MCP seams for `aoa-stats` and `Dionysus`
- explicit skill↔MCP wiring in `aoa-skills`
- a local plugin bundle for shared launcher skills
- projected custom subagents from `aoa-agents`
- one convergence doctor and one hooked lifecycle seam
- one landing ledger that records what happened, what was validated, and what remains open
