# Concept file placement

## Recommended canonical target

Place the concept anchor here:

`Agents-of-Abyss/docs/REVIEWABLE_GROWTH_REFINERY.md`

## Why this file belongs there

This concept is not owned by one execution repo.

It is not:
- just an `aoa-sdk` control-plane note
- just a `aoa-skills` workflow note
- just a `Dionysus` seed-garden note
- just a `aoa-stats` observability note
- just a Codex integration note

It is federation doctrine about **how growth is observed, reviewed, refined, seeded, planted, proved, remembered, and re-used across the whole AoA system**.

That makes `Agents-of-Abyss/docs/` the right home:
central enough to define law and boundaries,
but not a place that should absorb implementation ownership from the layer repos.

## What Codex should do with this file

Land it early.
Use it as the concept anchor while integrating the packs.
Then let repo-local files stay narrower and more operational.

## What this file should not become

- not a second `METHOD_SPINE.md`
- not a dump of every implementation detail
- not a replacement for repo-local contracts
- not a changelog
- not a pile of Codex-specific tricks

It should stay a clear doctrinal explanation of the intended machine.
