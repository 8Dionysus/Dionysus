# Landing acceptance gates

Use these gates after every wave.
The point is not perfect beauty. The point is bounded, reviewable progress.

## Global gates

- the AoA workspace root remains explicit and trusted
- the workspace still has one readable `AGENTS.md` law surface
- no pack silently turns a derived layer into owner truth
- no pack silently widens destructive automation
- the running landing ledger is updated

## Wave 0: read-first docs

Success looks like:
- Codex can state the difference between source-owned meaning, derived layers, and Codex access surfaces
- Codex can explain why the bridge pack is reference-only
- the concept anchor target path is accepted

## Wave 1: concept anchor

Success looks like:
- `Agents-of-Abyss/docs/REVIEWABLE_GROWTH_REFINERY.md` is landed
- its language matches the federation, not only the Codex layer
- it names lineage, review seams, self-diagnosis, self-repair, and anti-goals clearly

## Wave 2: project MCP spine

Success looks like:
- the workspace root is anchored
- `.codex/config.toml` exists at the intended workspace root
- the workspace MCP server is registered and discoverable
- the workspace launcher and doctor can run

## Wave 3: repo-local stats MCP

Success looks like:
- the `aoa-stats` server code lands cleanly
- named server wiring appears in workspace config
- tests or smoke checks from the pack pass
- the surface remains read-only and derived-only

## Wave 4: repo-local Dionysus MCP

Success looks like:
- the `Dionysus` server code lands cleanly
- named server wiring appears in workspace config
- staging notes keep their weaker-than-owner truth posture
- the surface remains route-first and read-only

## Wave 5: skill ↔ MCP wiring

Success looks like:
- `aoa-skills` gains explicit wiring doctrine and validation
- at least the early route families are wired cleanly
- `openai.yaml` examples or real files align with workspace MCP names
- local adapter law is preserved

## Wave 6: local plugin

Success looks like:
- shared launcher skills become one installable plugin surface
- plugin distribution does not steal MCP authority from workspace config
- plugin validation passes

## Wave 7: subagent projection

Success looks like:
- `aoa-agents` role profiles project into `.codex/agents/*.toml`
- generated agents remain roles, not disguised skills
- project config registers them cleanly
- subagent posture stays bounded

## Wave 8: convergence

Success looks like:
- bootstrap, doctor, and status seams land
- the doctor sees the workspace as one coherent Codex control plane
- drift is visible in reports instead of hidden in guesses

## Wave 9: hooks doctor

Success looks like:
- hooks are enabled deliberately, not accidentally
- `SessionStart`, `UserPromptSubmit`, and `Stop` seams work without becoming a hidden governor
- reports land under the expected generated path
- user-level hooks overlap is understood if present

## Final integration gate

The whole landing is healthy when:
- Codex can orient at workspace level
- Codex can query `aoa-stats` and `Dionysus` through narrow MCP surfaces
- Codex can use explicit AoA launcher skills
- Codex can call projected AoA subagents
- the convergence doctor sees the control plane clearly
- the hooks layer adds observability without taking the throne
