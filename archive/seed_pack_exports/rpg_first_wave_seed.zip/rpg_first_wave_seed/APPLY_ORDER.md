# Apply Order

Use the lightest honest route. The default order is:

1. `Agents-of-Abyss`
2. `aoa-agents`
3. `aoa-evals`
4. `aoa-playbooks`
5. `aoa-memo`
6. `aoa-routing`
7. `Dionysus`

## Why this order

### 1. `Agents-of-Abyss`
Land the common model first so the reflection layer does not get invented separately inside sibling repos.

### 2. `aoa-agents`
Land the adjunct progression contract before any quest-board or chronicle surface tries to reference rank, mastery axes, or unlock posture.

### 3. `aoa-evals`
Land the progression-evidence contract before campaign reflection or routing hints start treating advancement as if it were already legible.

### 4. `aoa-playbooks`
Land questline and campaign reflection after progression evidence exists, so quest arcs stay scenario-shaped and evidence-backed.

### 5. `aoa-memo`
Land chronicle writeback after questline and evidence surfaces exist, so memory receives a real witness target rather than inventing one.

### 6. `aoa-routing`
Land the quest-board seam after progression, evidence, and chronicle surfaces are already defined. Routing should consume, not author.

### 7. `Dionysus`
Reflect the package as a named prep pack only after the upstream repo-owned surfaces are legible.

## Merge cues

For each target repo:

- plant the new docs, schema, example, and quest files
- update `QUESTBOOK.md` to mention the new quest ID in the correct band
- add README or docs-map route links only if the target repo already curates that kind of route list
- do not generate new live derived surfaces in this pass unless a real builder and validator already exist in that repo
- keep the repo as the owner of its own meaning

## Live-surface restraint

This pack intentionally leaves all new derived RPG surfaces example-only. If a target repo wants a live builder later, open that as a later quest rather than sneaking it into this wave.
