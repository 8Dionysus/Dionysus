# RPG First Wave Seed

This bundle stages the first adjunct RPG reflection layer on top of the live AoA questbook contour.

It is a transport bundle, not an authority surface. Its job is to help Codex plant repo-owned docs, schemas, examples, and quest objects without mutating the existing quest model, agent-profile surface, or routing authority boundaries.

## Core rules

- Do not mutate `work_quest_v1`, `quest_dispatch_v1`, or `quest_dispatch_hint_v2` in this pass.
- Do not add volatile progression fields to `profiles/*.profile.json` in this pass.
- Do not introduce a live runtime ledger, auto-award engine, or cross-repo score service in this pass.
- Keep routing derived-only.
- Keep memo as witness and chronicle, never source quest owner.
- Keep playbooks scenario-shaped, not run-ledger shaped.
- Keep examples and generated example files reviewable and non-authoritative until a real builder and validator exist.

## Reading path

1. `SEED_MANIFEST.yaml`
2. `APPLY_ORDER.md`
3. `CODEX_NOTES.md`
4. `Agents-of-Abyss/docs/RPG_LAYER_MODEL.md`
5. repo-local docs, schemas, examples, and quest files
6. `Dionysus/seed_rpg_first_wave_pack.md`
7. `Dionysus/seed_rpg_first_wave_pack.map.yaml`

## What this first wave lands

- a common AoA-level RPG reflection model
- one bounded first-wave scope note
- an adjunct agent progression contract in `aoa-agents`
- a progression-evidence contract in `aoa-evals`
- a questline / campaign outline model in `aoa-playbooks`
- a quest chronicle writeback model in `aoa-memo`
- a derived quest-board entry seam in `aoa-routing`
- a `Dionysus` prep-pack note and map for seed-garden staging
- new quest objects that give the reflection layer stable follow-through IDs

## What this first wave does not land

- no skill-as-ability rewrite in `aoa-skills`
- no technique-as-feat rewrite in `aoa-techniques`
- no runtime persistence or UI in `abyss-stack`
- no public orientation mirror in `8Dionysus`
- no inventory, loot, health, mana, economy, or combat simulation layer
- no live quest-board builder
- no automatic progression award service

## Package shape

This bundle is source-shaped rather than diff-shaped.

Each repo folder contains the proposed author surfaces that belong to that repo. Codex should merge them into the current repo context, update the human-facing questbook where appropriate, and preserve local naming and formatting conventions.
