# Touchpoints Not Included

This first wave intentionally excludes the following repo homes and topic seams.

## Repos not included now

- `aoa-skills`
  - future abilities, loadouts, and skill-unlock reflection
- `aoa-techniques`
  - future feat / perk / tactic harvest reflection
- `abyss-stack`
  - future persistence, runtime state, UI, storage, and services
- `8Dionysus`
  - future public orientation mirror after upstream reality is planted
- `aoa-sdk`
  - separate named seed later
- `ATM10-Agent`
  - outside this contour
- `Tree-of-Sophia`
  - outside this contour
- `aoa-kag`
  - outside this contour

## Surfaces not included now

- inventory
- loot tables
- combat or encounter simulation
- hit points, mana, stamina, or derived life bars
- universal currency or economy rules
- auto-generated global leaderboards
- automatic quest claiming or completion writes
- automatic progression award services
- live quest-board builders
- live cross-repo rank aggregation
- profile mutation inside `profiles/*.profile.json`
- quest schema mutation inside `work_quest_v1`

## Why these are excluded

The current live AoA contour already has a disciplined quest model, execution passport, thin routing seam, playbook harvest boundary, memo witness boundary, and repo-local questbooks. This wave should build the RPG reflection layer on top of those surfaces, not outrun them with decorative runtime mechanics.
