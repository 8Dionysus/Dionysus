# Coverage Map

## Included now

### `Agents-of-Abyss`
Common model and first-wave scope.

### `aoa-agents`
Adjunct progression contract keyed by `agent_id`.

### `aoa-evals`
Progression evidence contract for multi-axis advancement.

### `aoa-playbooks`
Questline and campaign outline model.

### `aoa-memo`
Quest chronicle writeback model.

### `aoa-routing`
Derived quest-board entry seam as example-only routing reflection.

### `Dionysus`
Prep-pack note, map, and quest object for seed-garden staging.

## Excluded now

See `TOUCHPOINTS_NOT_INCLUDED.md` and `later-wave-targets.md`.
