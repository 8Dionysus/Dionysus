# Later Wave Targets

This note names the next likely RPG reflection contours without opening them now.

## Later wave 2: abilities and feats

### `aoa-skills`
Treat skill bundles and bounded execution recipes as the first honest ability surfaces.

### `aoa-techniques`
Treat repeated reusable tactics and canonized engineering moves as feat / perk candidates.

## Later wave 3: routing expansion

### `aoa-routing`
Open a later quest-board builder contour only after the first-wave contracts have real source examples and validators.

Possible additions later:
- pair
- recall
- reviewed quest-board rendering
- safe tiny-wrapper entry beyond current source-only routing

## Later wave 4: runtime and persistence

### `abyss-stack`
Introduce durable progression storage, campaign state, UI, or services only after the source-owned contracts are stable.

## Later wave 5: public mirror

### `8Dionysus`
Reflect the planted RPG layer for orientation only after the owner repos are already real enough to mirror honestly.
