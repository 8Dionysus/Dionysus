# Codex Notes

Read this bundle as a seed pack, not as a blind copy plan.

## Operating posture

- Preserve repo ownership boundaries.
- Prefer small coherent landings.
- Keep the bundle vocabulary intact, but let file formatting follow local repo conventions.
- Treat new examples as review scaffolds unless the target repo already has the right builder and validator seams.

## Important non-goals

- do not add progression fields to `agent-profile` source files
- do not widen `work_quest_v1`
- do not let `aoa-routing` become a source of quest or progression meaning
- do not let `aoa-playbooks` become a run ledger
- do not let `aoa-memo` become a second quest authority
- do not let `Dionysus` become the owner of RPG doctrine

## Expected merges

- merge each new quest object into the repo's human questbook surface
- keep examples clearly marked as examples
- keep generated example surfaces clearly non-authoritative
- add minimal README or docs-map routing only when that repo already curates those routes
- leave untouched any repo that is only named in `TOUCHPOINTS_NOT_INCLUDED.md`

## Safe freedom

Codex is free to adjust local wording, line wrapping, JSON formatting, and README insertion points when needed to fit the live repo. The hard constraint is ownership and boundary discipline, not byte-perfect formatting.
