# Codex Landing Brief: Recurrence Review Surfaces

Land this after the hook pack.

## Aim

Convert recurrence beacons into owner-facing review surfaces:

- prioritized review queues
- per-candidate dossiers
- owner summaries by lane, kind, and status

## Boundaries to preserve

- `aoa-techniques`: signals may pressure cross-layer intake or canonical review, but they do not change status.
- `aoa-skills`: omission and trigger drift should stay reviewable and should not rewrite skill meaning from outside.
- `aoa-evals`: repeated runtime evidence may justify a review packet, not a broad proof claim.
- `aoa-playbooks`: repeated scenario shapes may become candidates, never hidden orchestration.

## Suggested landing order

1. Replace the changed recurrence package files under `aoa-sdk/src/aoa_sdk/recurrence/`.
2. Add the new schemas and examples.
3. Run the recurrence tests plus the nearest repo validators.
4. Start writing review queues from real beacon output before widening any automation.
