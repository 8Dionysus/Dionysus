# Patch Notes

This is a delta-on-hook-pack seed.

## External integration patches

No new external integration patch is required beyond the earlier `aoa-sdk/src/aoa_sdk/api.py` and `aoa-sdk/src/aoa_sdk/cli/main.py` insertions.

## New recurrence commands

The pack extends `aoa recur ...` with:

- `aoa recur review-queue`
- `aoa recur review-dossiers`
- `aoa recur review-summary`

## New control-plane surfaces

The pack writes new families under `.aoa/recurrence/`:

- `review-queues/`
- `review-dossiers/`
- `review-summaries/`
