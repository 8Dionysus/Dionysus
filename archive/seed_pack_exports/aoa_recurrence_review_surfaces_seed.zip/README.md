# Recurrence Review Surfaces Seed

Delta seed on top of the planted hook pack.

This pack adds owner-facing review surfaces so beacon signals become transparent queues and dossiers instead of a growing pile of raw packets.

## What it adds

- `review-queue`: turns beacon output into a prioritized owner queue
- `review-dossiers`: emits one review packet per queued candidate
- `review-summary`: emits owner-level counts by lane, status, and kind

## What it does not do

- auto-promote techniques, skills, evals, or playbooks
- replace owner decision surfaces
- introduce hidden scheduling or agent autonomy
