# aoa-session-harvest-family seed

This package is a **seed**, not canonical repo truth.

It is designed for Codex to ingest inside `aoa-skills` and then choose the smallest honest integration path based on the repo's current builders, validators, portable exports, and neighboring AoA surfaces.

## What this seed is trying to do

Turn the end of every reviewed session into a bounded growth surface that can harvest:
- technique candidates
- skill candidates
- scenario or playbook candidates
- agent-role or orchestrator-law candidates
- quest residue and promotion paths
- progression evidence
- explicit decision forks
- self-diagnosis signals
- bounded self-repair routes

## Recommended shape

Keep the **existing** `aoa-session-donor-harvest` as the nucleus and teach it to emit a richer `HARVEST_PACKET`.

Add these sibling skills around it:
- `aoa-session-route-forks`
- `aoa-session-self-diagnose`
- `aoa-session-self-repair`
- `aoa-session-progression-lift`

Keep `aoa-quest-harvest` narrow as the leaf promotion-triage skill for repeated reviewed quest units.

## Adoption paths

### Minimal
1. expand `aoa-session-donor-harvest`
2. add `aoa-session-route-forks`
3. wire a narrow handoff to `aoa-quest-harvest`

### Growth path
1. donor-harvest
2. route-forks
3. self-diagnose
4. self-repair
5. progression-lift

### Conservative
Keep everything inside `aoa-session-donor-harvest` first, but preserve the sibling boundaries from this seed so later extraction stays easy.

## Important posture

- session harvest is **post-session** and **reviewed**
- session harvest is not transcript capture and not memory canon
- owner layers stay explicit
- RPG and quest language stay **reflection layers**, not hidden replacement ontology
- self-repair stays bounded and checkpoint-governed
- progression stays evidence-backed and multi-axis
