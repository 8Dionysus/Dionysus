# Codex handoff notes

Treat this package as **raw material**, not as already-canonical repo content.

## Strong recommendation

Because the target repo already has `aoa-session-donor-harvest` and `aoa-quest-harvest`, prefer this order:

1. inspect the current donor-harvest bundle
2. expand it into a richer harvest-packet nucleus
3. add siblings only where the current repo surface can support them cleanly
4. keep `aoa-quest-harvest` narrow
5. regenerate portable exports, catalogs, policy matrices, and tests from repo-native builders

## What Codex should decide itself

Codex should inspect the live repo and choose:
- whether `aoa-session-donor-harvest` absorbs part of `route-forks`, `self-diagnose`, or `progression-lift` for the first landing
- whether the new skills land immediately as scaffold entries or first as seed docs plus fixture ideas
- how to wire portable exports, generated catalogs, policy matrices, and evaluation fixtures
- whether any existing project overlays should gain local session-harvest companions

## Boundaries that should survive the merge

- session harvest remains explicit and post-session
- reviewed artifacts remain the starting point
- owner-layer routing stays visible
- `aoa-routing` and `aoa-kag` remain downstream derived consumers, not first-authoring targets
- quest reflection stays adjunct-only
- progression stays multi-axis and evidence-backed
- self-repair passes through checkpoint posture instead of silent self-mutation

## Integration hint

If the repo prefers smaller first moves, land:
- donor-harvest expansion
- route-forks
- one boundary note that positions self-diagnose, self-repair, and progression-lift as next-wave siblings

That still preserves the family shape.
