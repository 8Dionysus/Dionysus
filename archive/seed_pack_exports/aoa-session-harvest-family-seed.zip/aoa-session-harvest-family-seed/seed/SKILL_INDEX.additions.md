# Suggested `SKILL_INDEX` additions or edits

## Keep and sharpen
- `aoa-session-donor-harvest`
  - keep as `core | scaffold`
  - broaden summary toward harvest packet, owner routing, quest residue, diagnosis hooks, progression hooks, and fork handoff

## Add siblings
| name | scope | status | summary |
|---|---|---|---|
| aoa-session-route-forks | core | scaffold | Codex skill for turning reviewed session evidence into explicit next-route forks with likely gains, costs, risks, owner targets, and stop conditions. |
| aoa-session-self-diagnose | core | scaffold | Codex skill for classifying drift, friction, proof gaps, ownership confusion, and repeated failure patterns from a reviewed session into a bounded diagnosis packet. |
| aoa-session-self-repair | core | scaffold | Codex skill for turning reviewed diagnosis into the smallest honest repair packet with checkpoint posture, rollback markers, health checks, and explicit owner-layer targets. |
| aoa-session-progression-lift | core | scaffold | Codex skill for lifting reviewed session evidence into a multi-axis progression delta with bounded unlock hints, quest reflection cues, and no fake single-score authority. |

## Keep narrow
- `aoa-quest-harvest`
  - keep as the leaf skill for repeated reviewed quest promotion triage
  - do not let it absorb the whole family
