# Owner-layer map for session harvest

Use this map when Codex or a human needs to decide where a harvested unit belongs first.

| harvested unit shape | first owner | notes |
|---|---|---|
| reusable engineering practice | `aoa-techniques` | stable practice meaning, reusable beyond one bounded execution |
| bounded executable workflow | `aoa-skills` | leaf execution package, reviewable and portable |
| recurring scenario route | `aoa-playbooks` | multi-step composition, handoffs, fallbacks, outline posture |
| proof rubric or verdict surface | `aoa-evals` | bounded proof, verdict logic, evidence framing |
| memory, chronicle, recall, writeback | `aoa-memo` | witness and recall surfaces, not active quest authority |
| role law, orchestrator class law, handoff law | `aoa-agents` | who acts, under what contract |
| repeated reviewed quest residue | `aoa-skills` via `aoa-quest-harvest` | quest stays adjunct to promotion triage here |
| derived navigation or board hint | downstream only | `aoa-routing` or `aoa-kag` after source-owned object exists |

## Wrong-first targets to reject

Reject these as first moves:
- writing authored source meaning first into `aoa-routing`
- writing authored source meaning first into `aoa-kag`
- hiding role law inside a skill
- hiding scenario method inside one skill
- hiding eval doctrine inside memo
- treating one session theme as a technique
