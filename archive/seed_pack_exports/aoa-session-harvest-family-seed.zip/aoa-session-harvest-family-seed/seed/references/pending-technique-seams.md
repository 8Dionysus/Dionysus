# Pending technique seams to extract later

These are not technique canon yet. They are likely refinement seams after the skill family stabilizes.

- session-donor-harvest
- owner-layer-triage
- harvest-packet-contract
- decision-fork-cards
- repair-shape-from-diagnosis
- checkpoint-bound-self-repair
- progression-evidence-lift
- quest-residue-vs-promotion-triage
