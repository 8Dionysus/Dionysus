# Boundary between donor-harvest family and quest-harvest

## `aoa-session-donor-harvest` family
Use when the reviewed session still contains multiple candidate reusable units or multiple owner-layer possibilities.

## `aoa-quest-harvest`
Use when the remaining object is already a repeated reviewed quest-shaped unit and the main question is:
- keep or open quest
- promote to skill
- promote to playbook
- promote to agent surface
- promote to eval surface
- promote to memo surface

## Smell test
If the route still needs owner-layer harvest, diagnosis, or fork cards, stay in the donor-harvest family first.
