# Runtime seed example for aoa-session-self-repair

```yaml
repair_candidates:
  - title: add route-forks scaffold and donor-harvest handoff note
    owner_repo: aoa-skills
    approval_needed: false
    rollback_marker: revert donor-harvest expansion commit
    health_check: validate_skills + trigger fixtures
    improvement_log_entry: record session-harvest family split rationale
```

## What this example is showing

- the minimal shape of a bounded output packet
- the kind of routing or review information that should survive a session
- how this skill can hand work to neighboring owner layers without collapsing them
