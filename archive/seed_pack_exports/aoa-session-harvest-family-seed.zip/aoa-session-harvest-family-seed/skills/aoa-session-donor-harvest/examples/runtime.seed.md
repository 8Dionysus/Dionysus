# Runtime seed example for aoa-session-donor-harvest

```yaml
session_ref: docs/sessions/2026-04-05-review.md
reviewed_artifacts:
  - docs/sessions/2026-04-05-review.md
extracts:
  - title: session-harvest packet contract
    kind: skill_candidate
    owner_repo: aoa-skills
    chosen_next_surface: skills/aoa-session-donor-harvest/SKILL.md
    nearest_wrong_target: aoa-playbooks
  - title: decision fork card pattern
    kind: technique_candidate
    owner_repo: aoa-techniques
    chosen_next_surface: techniques/.../TECHNIQUE.md
    nearest_wrong_target: aoa-routing
  - title: repeated quest residue for repair lane
    kind: quest_residue
    owner_repo: aoa-skills
    chosen_next_surface: aoa-quest-harvest
    nearest_wrong_target: aoa-memo
deferrals:
  - no evidence yet for canonizing a campaign surface
```

## What this example is showing

- the minimal shape of a bounded output packet
- the kind of routing or review information that should survive a session
- how this skill can hand work to neighboring owner layers without collapsing them
