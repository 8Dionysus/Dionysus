# Family shape around `aoa-session-donor-harvest`

Recommended relation graph:

- `aoa-session-donor-harvest`
  - author `HARVEST_PACKET`
  - may hand off to:
    - `aoa-session-route-forks`
    - `aoa-session-self-diagnose`
    - `aoa-session-progression-lift`
    - `aoa-quest-harvest`

- `aoa-session-self-diagnose`
  - may hand off to `aoa-session-self-repair`

- `aoa-session-self-repair`
  - may emit repair quests or repo-owner deltas

This keeps the nucleus strong while avoiding one giant bag-of-everything skill.
