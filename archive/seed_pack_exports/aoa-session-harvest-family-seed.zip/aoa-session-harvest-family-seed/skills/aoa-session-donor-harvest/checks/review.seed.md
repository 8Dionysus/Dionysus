# Review checklist for aoa-session-donor-harvest

- confirm the trigger boundary matches a reviewed post-session route
- confirm the skill stays bounded and does not absorb neighboring owner-layer doctrine
- confirm the output names explicit artifacts or packets
- confirm `aoa-routing` and `aoa-kag` are not treated as first-authoring targets
- confirm RPG or quest language stays reflective rather than authoritative
- confirm the nearest wrong target is visible whenever routing decisions matter
