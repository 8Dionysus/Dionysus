---
name: aoa-session-donor-harvest
scope: core
status: scaffold
summary: Harvest reusable donor units from a reviewed session into a bounded harvest packet, route each unit to the right AoA owner layer, and draft the smallest honest next artifact without forcing promotion.
invocation_mode: explicit-only
technique_dependencies:
  - AOA-T-PENDING-SESSION-DONOR-HARVEST
  - AOA-T-PENDING-OWNER-LAYER-TRIAGE
  - AOA-T-PENDING-HARVEST-PACKET-CONTRACT
---
# aoa-session-donor-harvest

## Intent

Use this skill to metabolize a reviewed session into a bounded `HARVEST_PACKET`.

The packet should name what reusable units emerged, which owner layer each unit belongs to first, which items remain quest residue, and which follow-up skills should run next.

## Trigger boundary

Use this skill when:
- a session transcript, recap, compaction packet, review note, or closure artifact already exists
- the question is no longer only "what happened?" but "what should survive this session?"
- the session may have yielded technique candidates, skill candidates, scenario routes, agent-law candidates, proof posture, memory posture, quest residue, progression evidence, or decision forks
- Codex or a human needs one bounded post-session refinement pass rather than free-form reflection

Do not use this skill when:
- the session is still live or unreviewed
- the task is raw capture, export, or indexing of session history
- the main remaining object is already one repeated reviewed quest unit that only needs final promotion triage
- the material is only mood, theme, or aesthetic resonance without a bounded reusable unit
- the first intended destination is a derivative layer such as routing or KAG

## Inputs

- reviewed session artifact
- closure state and original goal
- touched repos or AoA layers
- candidate repeat signals
- named uncertainties and boundary risks
- desired output posture: classify-only, draft-stub, or patch-proposal

## Outputs

- one bounded `HARVEST_PACKET`
- accepted extracts with owner repo, next surface, and nearest wrong target
- quest residue or deferrals that should not be forced upward yet
- optional handoff list to `aoa-session-route-forks`, `aoa-session-self-diagnose`, `aoa-session-progression-lift`, or `aoa-quest-harvest`

## Procedure

1. start from reviewed artifacts rather than transient chat memory
2. extract candidate reusable units, not topics; prefer moves, laws, checklists, structures, routes, proof patterns, role rules, or memory postures
3. split merged candidates until each one has one honest first owner layer
4. classify each candidate by both unit kind and owner shape
5. reject theme-only residue unless a bounded reusable unit exists
6. route reusable practice meaning toward `aoa-techniques`
7. route bounded executable workflows toward `aoa-skills`
8. route recurring scenario shapes toward `aoa-playbooks`
9. route proof or verdict posture toward `aoa-evals`
10. route memory and chronicle surfaces toward `aoa-memo`
11. route role law or orchestrator law toward `aoa-agents`
12. tag quest-shaped residue without forcing promotion
13. emit explicit handoff hints for forking, diagnosis, repair, progression, or quest triage when needed

## Contracts

- explicit and post-session only
- one candidate maps to one primary owner layer
- usefulness is a reuse signal, not an owner layer
- session harvest does not convert reviewed history into memory canon or instruction authority
- RPG language may annotate outputs but cannot replace owner-layer truth
- drafting is allowed; forced promotion is not

## Risks and anti-patterns

- collapsing technique, skill, playbook, eval, memo, and agent into one reuse bucket
- routing authored meaning first into derivative layers
- over-harvesting one session into too many thin artifacts
- mistaking raw transcript packaging for donor harvest
- inflating one emotional resonance into a reusable practice

## Verification

- confirm the source artifact is reviewed and bounded
- confirm each kept extract names one reusable unit
- confirm each accepted extract has a primary owner and nearest wrong target
- confirm derivative layers are not first-authoring targets
- confirm hold, defer, and quest residue remain available
- confirm the packet names the next honest surface rather than only vague categories

## Technique traceability

Pending manifest-backed techniques:
- AOA-T-PENDING-SESSION-DONOR-HARVEST from `8Dionysus/aoa-techniques` with `path: TBD` and `source_ref: TBD`
- AOA-T-PENDING-OWNER-LAYER-TRIAGE from `8Dionysus/aoa-techniques` with `path: TBD` and `source_ref: TBD`
- AOA-T-PENDING-HARVEST-PACKET-CONTRACT from `8Dionysus/aoa-techniques` with `path: TBD` and `source_ref: TBD`

## Adaptation points

- project overlays may add local review packet entrypoints
- project overlays may add repo-relative destination paths
- project overlays may add local stop conditions for hold-only outcomes
