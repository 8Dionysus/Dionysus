# Runtime seed example for aoa-session-route-forks

```yaml
fork_cards:
  - option: deepen donor-harvest into a family nucleus
    likely_gain: clean reusable center for session metabolism
    likely_cost: broader bundle and more fixture work
    likely_risk: overloading one skill
    likely_owner_repo: aoa-skills
    stop_conditions:
      - if bundle starts swallowing playbook method
    passport:
      difficulty: medium
      risk: medium
      control_mode: manual
      delegate_tier: codex
  - option: land route-forks first as sibling
    likely_gain: immediate branch legibility
    likely_cost: one more scaffold surface
    likely_risk: premature family split
    likely_owner_repo: aoa-skills
```

## What this example is showing

- the minimal shape of a bounded output packet
- the kind of routing or review information that should survive a session
- how this skill can hand work to neighboring owner layers without collapsing them
