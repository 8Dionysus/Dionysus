# Progression axes used by the seed

- `boundary_integrity`
- `execution_reliability`
- `change_legibility`
- `review_sharpness`
- `proof_discipline`
- `provenance_hygiene`
- `deep_readiness`

Use qualitative movement and named evidence.
Avoid one universal score.
