# Runtime seed example for aoa-session-progression-lift

```yaml
progression:
  axes:
    boundary_integrity: +1 evidence-backed
    execution_reliability: hold
    change_legibility: +1 from clean packet and review notes
    review_sharpness: +1 from explicit owner-layer rejection
    proof_discipline: hold
    provenance_hygiene: hold
    deep_readiness: not enough evidence
  verdict: advance
  unlock_hints:
    - route-forks may be safe as a scaffold sibling
quest_hooks:
  - session-harvest-family first wave
chronicle_stub: first session where harvest became a growth engine instead of a recap
```

## What this example is showing

- the minimal shape of a bounded output packet
- the kind of routing or review information that should survive a session
- how this skill can hand work to neighboring owner layers without collapsing them
