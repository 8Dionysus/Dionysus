---
name: aoa-session-self-diagnose
scope: core
status: scaffold
summary: Classify drift, friction, proof gaps, ownership confusion, and repeated failure patterns from a reviewed session into a bounded diagnosis packet without mutating anything yet.
invocation_mode: explicit-only
technique_dependencies:
  - AOA-T-PENDING-SESSION-DRIFT-TAXONOMY
  - AOA-T-PENDING-DIAGNOSIS-FROM-REVIEWED-EVIDENCE
---
# aoa-session-self-diagnose

## Intent

Use this skill to turn a reviewed session into a `DIAGNOSIS_PACKET`.

It should answer: what drifted, what hurt, what boundary blurred, what proof is missing, and what repair shape is most plausible.

## Trigger boundary

Use this skill when:
- a reviewed session contains repeated friction, contradiction, or drift
- the next honest move is diagnosis before repair
- boundary confusion or missing proof may be more important than immediate output production
- the same class of problem may be appearing across sessions

Do not use this skill when:
- the session is still live
- the issue is already fully diagnosed and only needs repair execution
- the material is a celebration recap with no meaningful friction
- the route is actually a single quest-promotion decision

## Inputs

- reviewed session artifact or harvest packet
- observed frictions, failures, or contradictions
- relevant owner layers and touched repos
- previous related session evidence if available

## Outputs

- `DIAGNOSIS_PACKET` with drift types, symptoms, probable causes, repair shapes, and owner hints
- severity or urgency notes when evidence supports them
- explicit unknowns when diagnosis remains incomplete
- optional handoff to `aoa-session-self-repair`

## Procedure

1. gather reviewed symptoms and evidence refs
2. separate symptom from probable cause
3. classify drift types such as boundary drift, proof debt, role leakage, memory contamination, route collapse, compaction damage, or repeated blocker patterns
4. map each diagnosis toward the likely owner layer
5. suggest a repair shape without silently performing it
6. preserve unknowns where evidence does not justify stronger claims

## Contracts

- diagnosis is read-only
- one odd anecdote is not enough for structural certainty
- probable cause must remain probabilistic when evidence is thin
- owner hints must not override owner-layer law
- no hidden mutation or silent patching

## Risks and anti-patterns

- mistaking symptom for cause
- using vague vibes as diagnosis
- smuggling repair work into diagnosis
- turning every inconvenience into a system flaw
- blaming one owner layer for a cross-layer issue

## Verification

- confirm each diagnosis cites evidence refs
- confirm symptoms and causes are separated
- confirm a likely owner layer is named
- confirm unknowns are preserved where needed
- confirm no mutation happened

## Technique traceability

Pending manifest-backed techniques:
- AOA-T-PENDING-SESSION-DRIFT-TAXONOMY from `8Dionysus/aoa-techniques` with `path: TBD` and `source_ref: TBD`
- AOA-T-PENDING-DIAGNOSIS-FROM-REVIEWED-EVIDENCE from `8Dionysus/aoa-techniques` with `path: TBD` and `source_ref: TBD`

## Adaptation points

- project overlays may add local drift taxonomies
- project overlays may add repo-specific failure classes
- project overlays may add severity bands
