# Runtime seed example for aoa-session-self-diagnose

```yaml
diagnosis:
  - drift_type: owner-layer collapse
    symptom: technique and skill language were repeatedly merged
    probable_cause: donor-harvest lacks explicit extraction boundary for reusable practice meaning
    repair_shape: add owner-layer map and fixture coverage
    owner_repo: aoa-skills
    evidence_refs:
      - docs/sessions/2026-04-05-review.md#L18-L30
```

## What this example is showing

- the minimal shape of a bounded output packet
- the kind of routing or review information that should survive a session
- how this skill can hand work to neighboring owner layers without collapsing them
