# Apply Order

1. `Agents-of-Abyss`
   - `docs/RPG_RUNTIME_PROJECTION_WAVE.md`
   - `quests/AOA-Q-0008.yaml`

2. `abyss-stack`
   - `docs/RPG_RUNTIME_COLLECTIONS.md`
   - `docs/RPG_RUNTIME_BUILDERS.md`
   - `docs/RPG_ROUTE_API_SEAM.md`
   - `docs/RPG_FRONTEND_PROJECTION_SEAM.md`
   - `schemas/*_collection.schema.json`
   - `generated/rpg/*.json`
   - `quests/ABY-Q-0002.yaml`

3. `Dionysus`
   - `seed_rpg_runtime_projection_pack.md`
   - `seed_rpg_runtime_projection_pack.map.yaml`
   - `quests/DION-SEED-Q-0009.yaml`

## Notes for Codex

- Keep the collection file paths stable under `generated/rpg/` because the SDK addendum expects them there.
- Do not add a new port. Keep the future `/rpg/*` seam under the existing localhost-only `route-api`.
- Do not require `aoa-skills` or `aoa-techniques` runtime mirrors in this pass. Ability and feat ids remain pass-through refs until those mirrors are reviewed.
- Preserve source refs in generated bundles instead of replacing them with hidden summaries.
