# RPG Runtime Builders

## Purpose

This note records the minimal builder order for the RPG runtime/body slice.

The builders may start as small scripts, SDK-driven helpers, or route-api support utilities.
The important thing is the order and the boundaries, not the exact implementation language.

## Builder rule

Builders may assemble runtime-owned collections.

Builders may not invent upstream meaning.

## Recommended order

### Phase 0. Sync upstream public-safe mirrors

Refresh the runtime-local federation surfaces that already exist for:
- `aoa-agents`
- `aoa-routing`
- `aoa-memo`
- `aoa-evals`
- `aoa-playbooks`
- `aoa-kag`
- `tos-source`

This keeps current upstream refs locally inspectable.

### Phase 1. Refresh build snapshots

Build snapshots should combine:
- role and progression refs
- current wrapper/orchestrator posture
- current runtime budgets
- current ability/feat/artifact ids
- capability envelope
- reputation refs if already known

Important:
- do not require runtime-local `aoa-skills` or `aoa-techniques` mirrors yet
- ability and feat ids may remain pass-through refs in this phase

### Phase 2. Append quest run results

A run result should be written after one bounded run completes or fails safe.

It should capture:
- quest ref
- orchestrator posture
- party and build refs
- output summary
- proof refs
- chronicle refs
- penalty previews
- next-hop hints

It must not claim to be the quest itself.

### Phase 3. Refresh reputation ledgers

Reputation comes after evidence and runs.

A ledger refresh may consume:
- run results
- unlock or progression evidence refs
- campaign review refs
- reanchor records

Do not let the ledger become a hidden emotional model.
Keep every slice scoped and cited.

### Phase 4. Refresh frontend bundles

Projection bundles should be the last derived layer.

They assemble:
- build cards
- quest board cards
- campaign cards
- timeline entries
- artifact case cards
- reputation panels
- a vocabulary overlay ref

Bundles should stay public-safe and source-cited.

## Validation step

After each refresh pass:

1. validate the collection file against its schema
2. keep fragment ids stable
3. confirm that source refs are still intact
4. reject outputs that silently overclaim authority

## Storage step

The first honest posture is filesystem-first:
- source-managed transport under `generated/rpg/`
- live runtime materialization under `Logs/rpg/latest/`
- historical records under `Logs/rpg/records/`

Do not force a database first if the collection files already solve the immediate need.

## Anti-patterns

- recomputing unlock proof inside the builder
- awarding progression in the bundle stage
- hiding cause refs behind pretty labels
- turning route-api into the builder itself
- requiring mature mirrors for layers that do not have them yet
- treating ToS language as a replacement for canonical runtime keys

## Final rule

Build upstream, collect downstream, project last.
