# RPG Route API Seam

## Purpose

This note defines the first read-only `/rpg/*` seam for the existing localhost-only `route-api`.

The seam exists to make the runtime RPG collections inspectable by orchestrators, SDK consumers, and future frontend readers without adding a new authority layer or a new host port.

## Core rule

`/rpg/*` is advisory and read-only.

It reads runtime-owned collection files.
It does not write them.
It does not write upstream repos.

## Backing data

Preferred read order:

1. `${AOA_STACK_ROOT}/Logs/rpg/latest/*.json`
2. source-managed `generated/rpg/*.json` when running in source or dry-run mode

The seam may also keep source refs to upstream mirrors and docs, but it must not fetch sibling repos live.

## Raw read surfaces

The first thin raw reads should be:

- `GET /rpg/builds`
- `GET /rpg/reputation`
- `GET /rpg/runs`
- `GET /rpg/projections`

These return the collection wrappers as currently materialized.

## Structured advisory reads

The first structured reads should stay narrow:

- `POST /rpg/agent-sheet`
- `POST /rpg/quest-board`
- `POST /rpg/campaign-lane`
- `POST /rpg/reputation-panel`
- `POST /rpg/run-inspect`

These endpoints may:
- filter existing collection data
- resolve one card or panel by ref
- keep source refs visible
- preserve canonical keys

These endpoints must not:
- claim quests
- mark quests complete
- award progression
- grant unlocks
- rewrite ledgers
- mutate source state

## Frontend posture

A frontend may call `/rpg/*`, but the seam remains a data reader, not a gameplay engine.

If a UI wants to trigger action, it should still route through existing owner or orchestrator surfaces.
The card itself is not the command.

## Visibility posture

Keep the seam localhost-only with the existing `route-api` posture.

Do not add:
- a new public port
- a browser-facing write service
- hidden mutation endpoints
- hidden operator shortcuts that bypass review

## Anti-patterns

- treat bundle cards as the quest itself
- let a convenience filter rewrite the canonical keys
- compute proof or reputation deltas inside the route layer
- widen route-api into the owner of RPG doctrine

## Final rule

The seam should read like a lantern, not a wand.
