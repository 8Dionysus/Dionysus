# RPG Frontend Projection Seam

## Purpose

This note defines how future frontend readers should consume the AoA RPG contour from `abyss-stack`.

The frontend is expected to read one bounded bundle shape rather than scrape many repositories ad hoc.

## Core rule

The frontend reads derived bundles.

It does not become a new authority surface.

## Bundle shape

A good first bundle contains:

- `agent_sheet_cards`
- `quest_board_cards`
- `campaign_lane_cards`
- `progression_timeline_entries`
- `artifact_case_cards`
- `reputation_panels`

The bundle must also preserve:
- a `vocabulary_overlay_ref`
- collection refs for builds, ledgers, and runs
- source refs for quest and campaign surfaces

## Vocabulary posture

The UI may theme labels through the dual-vocabulary overlay.

It must still preserve the canonical keys in data or view-model form.

Good example:
- display `integrity_budget` as “Integrity” or another themed label
- keep the canonical key available in the payload or component model

Bad example:
- replace the canonical key entirely and make the system opaque

## Public-safe default

Frontend bundles should be public-safe by default.

If a UI needs stronger internal detail later, that should be a different reviewed surface, not a silent widening of the public bundle.

## Action posture

Bundle cards may show actions such as:
- inspect
- expand
- handoff
- verify
- reanchor

The visual affordance is not authority.
Action execution still belongs to owner repos, orchestrators, or reviewed runtime commands.

## Reputation posture

Reputation panels should remain:
- slice-based
- cited
- scoped
- capable of negative motion

Do not flatten them into a single prestige meter.

## Artifact posture

Artifacts remain runtime reflections in this phase.

A frontend may display them.
A frontend may not imply that a stronger artifact canon already exists if it does not.

## Final rule

Let the UI sing.
Keep the source refs audible.
