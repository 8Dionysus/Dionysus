# Coverage Map

## Common contour

- `Agents-of-Abyss/docs/RPG_RUNTIME_PROJECTION_WAVE.md`
- `Agents-of-Abyss/quests/AOA-Q-0008.yaml`

## Runtime/body owner

- `abyss-stack/docs/RPG_RUNTIME_COLLECTIONS.md`
- `abyss-stack/docs/RPG_RUNTIME_BUILDERS.md`
- `abyss-stack/docs/RPG_ROUTE_API_SEAM.md`
- `abyss-stack/docs/RPG_FRONTEND_PROJECTION_SEAM.md`
- `abyss-stack/schemas/agent_build_snapshot_collection.schema.json`
- `abyss-stack/schemas/reputation_ledger_collection.schema.json`
- `abyss-stack/schemas/quest_run_result_collection.schema.json`
- `abyss-stack/schemas/frontend_projection_bundle_collection.schema.json`
- `abyss-stack/generated/rpg/agent_build_snapshots.json`
- `abyss-stack/generated/rpg/reputation_ledgers.json`
- `abyss-stack/generated/rpg/quest_run_results.json`
- `abyss-stack/generated/rpg/frontend_projection_bundles.json`
- `abyss-stack/quests/ABY-Q-0002.yaml`

## Seed-garden lineage

- `Dionysus/seed_rpg_runtime_projection_pack.md`
- `Dionysus/seed_rpg_runtime_projection_pack.map.yaml`
- `Dionysus/quests/DION-SEED-Q-0009.yaml`
