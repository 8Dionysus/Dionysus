# RPG Runtime Projection Seed

This transport seed stages the first honest body-facing slice for the AoA RPG contour.

The goal is not to create a hidden game engine.
The goal is to let `abyss-stack` hold runtime-owned read models and frontend-ready projection bundles without stealing authored meaning from the upstream AoA layers.

## What this seed lands

- `Agents-of-Abyss`
  - one common runtime/projection wave note
  - one cross-repo quest object for the body-facing pass
- `abyss-stack`
  - runtime collection posture
  - builder posture
  - read-only `/rpg/*` route-api seam
  - frontend projection posture
  - collection wrapper schemas
  - source-managed generated transport collections under `generated/rpg/`
  - one repo-local quest object
- `Dionysus`
  - one prep-pack note
  - one prep-pack map
  - one seed-garden quest object

## Why this wave exists

The first wave planted progression, chronicles, questlines, and a quest-board seam.
The second wave planted abilities and feats.
The architecture RFC fixed the vocabulary and the runtime/frontend law.
The SDK addendum fixed the typed collection paths.
The bridge wave connected proof, party composition, and navigation.

What remained was the body:
- live runtime-owned collections
- source-managed generated transport files
- a narrow read-only `/rpg/*` seam
- one bounded frontend bundle shape that a later UI can consume directly

## Suggested apply order

1. `Agents-of-Abyss`
2. `abyss-stack`
3. `Dionysus`

If the architecture RFC seed has not landed yet, merge it before or together with this seed.
If the bridge-wave ids differ from the examples here, let Codex reconcile the refs while preserving the collection shapes and file paths.

## What this seed does not land

- no new host port
- no standalone `rpg-api` service
- no quest claiming or quest completion writeback
- no unlock grant or reputation award endpoint
- no runtime-local `aoa-skills` or `aoa-techniques` mirrors in this pass
- no public mirror rollout in `8Dionysus`
- no collapse of AoA into ToS

## Validation posture

This bundle is transport-shaped.
The collection JSON files are meant to validate against the included collection wrapper schemas.
The Markdown notes are doctrine scaffolds for owner repos, not blind-copy truth.

## Final rule

Let the runtime become a body, not a throne.
