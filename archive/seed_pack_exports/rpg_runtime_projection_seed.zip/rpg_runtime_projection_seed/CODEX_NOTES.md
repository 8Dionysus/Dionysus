# Codex Notes

## Merge posture

Treat this pack as the runtime/body follow-through after the RPG architecture RFC, SDK addendum, and bridge wave.

The key thing to preserve is not the exact prose.
It is the shape:

- collection wrappers exist under `abyss-stack/schemas/`
- source-managed transport examples live under `abyss-stack/generated/rpg/`
- docs clearly separate runtime ownership from upstream meaning
- `/rpg/*` is read-only and advisory
- bundle cards keep cited source refs

## Important reconciliations

1. If `Agents-of-Abyss/generated/dual_vocabulary_overlay.json` lands under a slightly different path, update only the refs.
2. If bridge-wave files use different ids for unlock-proof, party-template, or navigation cards, update only the refs in the generated examples.
3. If `abyss-stack` already has a generated-surface convention, preserve it as long as the public relative paths under `generated/rpg/` remain available.

## Deliberate omissions

Do not silently add:

- automatic XP grant logic
- automatic reputation decay
- quest-state mutation
- a hidden reward daemon
- a new service port
- unreviewed ability/feat mirrors
