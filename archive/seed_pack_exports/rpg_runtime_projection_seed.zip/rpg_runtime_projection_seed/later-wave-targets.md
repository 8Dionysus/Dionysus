# Later-Wave Targets

After this runtime/body slice is planted, the next believable follow-ups are:

1. `8Dionysus`
   - public-safe orientation shell
   - non-authoritative quest board and agent-sheet reader
   - never the owner of runtime truth

2. `abyss-stack` implementation follow-through
   - actual route-api handlers for `/rpg/*`
   - optional refresh helpers for `generated/rpg/`
   - optional promotion from filesystem-first collections to a small runtime store

3. `aoa-skills` and `aoa-techniques` runtime mirrors
   - only after a reviewed public-safe mirror posture exists
   - until then, ability and feat ids remain pass-through refs

4. dedicated artifact contour
   - only when runtime reflections need stronger source ownership
   - not before

5. ToS-facing counterpart overlays
   - later reader bridges only
   - never identity collapse between AoA runtime state and ToS meaning
