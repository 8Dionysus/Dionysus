seed_id: seed.rpg.runtime-projection-pack.v0
title: RPG Runtime Projection Pack
profile_anchor: 8Dionysus
projects:
  - AoA
kind: prep-pack-note
status: pending_archive
priority: next
parent_seed: seed.rpg.bridge-wave-pack.v0
tags:
  - rpg
  - runtime
  - frontend
  - collections
  - projections

# Seed Note: RPG Runtime Projection Pack

## Purpose

Prepare the body-facing RPG runtime slice as a named prep pack without turning `Dionysus` into runtime doctrine authority.

This pack stages collection wrappers, generated transport files, and the future `/rpg/*` seam posture so later service work and frontend work can build on one honest runtime shape.

## Why this belongs in Dionysus

`Dionysus` is the seed garden and dispatch layer.

This prep pack belongs here because:
- the rollout spans the ecosystem center and the runtime body
- it should stay transport-shaped until the owner repos accept the landings
- the package needs lineage relative to the architecture RFC, SDK addendum, and bridge wave
- runtime/body promotion is a staging event, not a new doctrine owner

## Bundle contents to preserve

The source artifact is `archive/seed_pack_exports/rpg_runtime_projection_seed.zip`.

It carries:
- `rpg_runtime_projection_seed/README.md`
- `rpg_runtime_projection_seed/APPLY_ORDER.md`
- `rpg_runtime_projection_seed/CODEX_NOTES.md`
- `rpg_runtime_projection_seed/SEED_MANIFEST.yaml`
- `rpg_runtime_projection_seed/COVERAGE_MAP.md`
- `rpg_runtime_projection_seed/TOUCHPOINTS_NOT_INCLUDED.md`
- `rpg_runtime_projection_seed/later-wave-targets.md`
- repo-local runtime/projection surfaces for `Agents-of-Abyss` and `abyss-stack`
- this `Dionysus` prep-pack note, map, and quest object

## Ownership posture

Read the later plantings under these repo-home boundaries:

- `Agents-of-Abyss` owns the common runtime/projection wave law
- `abyss-stack` owns the runtime collections and future `/rpg/*` read seam
- `Dionysus` owns only seed-garden staging and transport lineage

## Scope exclusions

This pack explicitly excludes:

- `8Dionysus`
- live UI code
- route-api implementation code
- new service ports
- runtime-local skill or technique mirrors
- dedicated artifact doctrine
- Tree-of-Sophia runtime overlays

## Suggested planting order

Bias toward:
1. `Agents-of-Abyss`
2. `abyss-stack`
3. `Dionysus`

## Final rule

Land the body before the costume.
The honest win here is that future UI and orchestrator readers can load one cited runtime bundle instead of inventing an opaque game layer.
