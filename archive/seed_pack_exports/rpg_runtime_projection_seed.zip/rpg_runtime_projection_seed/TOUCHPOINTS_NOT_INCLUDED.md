# Touchpoints Not Included

This seed intentionally does **not** include:

- compose module changes
- route-api implementation code
- new helper-service build contexts
- a standalone projection database
- live UI code
- public mirror work in `8Dionysus`
- dedicated artifact-owner doctrine
- dedicated runtime mirrors for `aoa-skills` or `aoa-techniques`
- ToS counterpart overlays inside runtime cards
- hidden quest automation or hidden reward loops

These are deferred, not rejected.
