# KAG QUARANTINE ROUTE HINTS

## Purpose

Wave 4 gives `aoa-routing` a cleaner way to react when derived knowledge is unhealthy or quarantined.

The route should bend back toward source-backed footing.

## Healthy quarantine behavior

When projection health is weak, routing should prefer one of:

- source-first inspection
- playbook-guided regrounding
- human review before re-entry
- route-around posture for mutation-adjacent paths

## Unsafe quarantine behavior

Routing drifts when it:

- routes back into a quarantined surface without explicit re-entry conditions
- treats ticket creation as equivalent to health
- hides the reason for route avoidance
- silently widens mutation posture because a direct source path feels expensive

## Evidence chain

A good route hint for quarantine should be able to cite:

- the projection-health receipt
- the regrounding ticket or explicit playbook lane
- any bounded eval report that shaped confidence
- any owner receipt that shows why the derived surface became risky

Without that chain, prefer suppression.
