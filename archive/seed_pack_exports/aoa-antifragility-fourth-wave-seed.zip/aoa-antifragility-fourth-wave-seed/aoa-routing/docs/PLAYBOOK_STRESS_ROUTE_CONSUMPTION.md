# PLAYBOOK STRESS ROUTE CONSUMPTION

## Goal

Teach `aoa-routing` to consume playbook stress lanes and re-entry gates as additive navigation signals.

Routing should become more explicit under stress, not more sovereign.

## Why wave 4 needs this

Wave 2 made stress posture routable in a general sense.
Wave 3 created sharper scenario objects:

- playbook stress lanes
- playbook re-entry gates
- agent stress handoff envelopes

Wave 4 lets routing read those objects so the next hop can honor scenario-level recovery logic.

## Input discipline

Routing should prefer, in order:

1. source-owned owner receipts and owner-local artifacts
2. explicit agent handoffs and playbook gates tied to the same surface family
3. bounded eval reports for the same window or family
4. derived stats summaries as secondary shaping context
5. memo pattern objects as recall-only context

Do not let a route hint become the only reason to trust a re-entry path.

## Preferred route postures

Wave 4 extends the earlier vocabulary with a scenario-aware family:

- `route_to_playbook`
- `reground_first`
- `human_review_first`
- `stop_before_mutation`
- `route_around_unhealthy_surface`

A route may mention a playbook lane, a re-entry gate, or a handoff envelope, but those remain their owner-local truths.

## Output posture

A healthy landing can publish one additive hint family such as:

- `schemas/composite_stress_route_hint_v1.json`

or map the same fields into an existing generated hint family if that fits better.

## Guardrails

- do not let routing invent a re-entry gate that the playbook does not own
- do not let routing flatten agent handoff evidence into vague confidence
- do not bypass a stop condition just because a route seems short
- do not treat a memo object as present-tense proof
