# Later Waves

Wave 4 makes wave-3 stress signals provable, derivable, routable, and recallable.

The next clean expansion points are:

- `ATM10-Agent` and other owner repos: direct consumption of composite route hints and repeated-window eval feedback in live operator surfaces
- `abyss-stack`: reuse of recovery-window proof and derived windows for service degradation and repair-safe closeout families
- `aoa-agents` and `aoa-playbooks`: tighter alignment between stress handoff fields and repeated-window proof axes where convergence is real
- `aoa-sdk`: optional typed consumption of repeated-window summaries and composite route hints as narrow dispatch context
- `aoa-kag`: optional generation of projection-health families shaped for repeated-window derivation, but only if derived boundaries stay clean

Do not widen there until wave 4 produces stable eval reports, derived summaries, route hints, and recovery-pattern memory worth consuming.
