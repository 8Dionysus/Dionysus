# AoA Antifragility Fourth Wave Seed

This package is a repo-relative overlay seed for the fourth antifragility wave across the public AoA surface.

Wave 1 established doctrine, source-owned receipts, bounded proof, and derived vectors.
Wave 2 made stress portable across routing, recall, runtime, and the control plane.
Wave 3 made agent handoffs, playbook stress lanes, re-entry gates, and KAG regrounding explicit.
Wave 4 makes those signals earn their keep in proof, derived windows, routing consumption, and reviewed recall.

## Overlay model

Each top-level directory in this seed matches a target repository root.

Example:

- `aoa-evals/bundles/aoa-stress-recovery-window/EVAL.md`
- `aoa-stats/schemas/stress_recovery_window_summary_v1.json`
- `aoa-routing/schemas/composite_stress_route_hint_v1.json`
- `aoa-memo/schemas/recovery_pattern_memory_v1.json`

Codex should treat these as **repo-relative overlays**, not blind copy instructions.
Live repository conventions remain authoritative.

## Wave 4 shape

Wave 4 is intentionally about proof, derivation, and consumption:

1. make repeated-window stress handling provable in `aoa-evals`
2. make cross-repo recovery windows derivable in `aoa-stats`
3. make routing consume playbook and KAG stress signals without becoming their owner
4. make memo remember reviewed recovery patterns without pretending to know live health

## Core guardrails

- source repos still own what happened and what it means
- `aoa-evals` owns proof posture, not workflow meaning
- `aoa-stats` derives windows and summaries, but does not become dashboard sovereignty
- `aoa-routing` may consume playbook lanes, re-entry gates, and KAG health as navigation inputs, but it must not author new stress truth
- `aoa-memo` may store reviewed recovery patterns, but memory remains context, not proof
- do not collapse repeated-window stress handling into one prestige scalar
- do not add hidden autonomous repair, re-entry, or republishing behavior

## Recommended apply order

1. `aoa-evals`
2. `aoa-stats`
3. `aoa-routing`
4. `aoa-memo`

## What this seed intentionally is not

- not a request to centralize stress meaning in proof or stats
- not a replacement for owner-local receipts, handoffs, playbook gates, or KAG regrounding tickets
- not a license for routing to overrule owner evidence
- not a request to turn memo into a live health oracle
- not a demand for new services if existing generated or schema-backed surfaces can absorb the shape additively

## Validation expectation

At minimum, Codex should leave the workspace with:

- additive docs that fit each repo's ownership boundaries
- schema-valid examples for eval reports, derived summaries, routing hints, and memo pattern objects
- no authority drift from source repos into stats, routing, or memo
- repeated-window proof that can speak about wave-3 objects without seizing ownership of them
