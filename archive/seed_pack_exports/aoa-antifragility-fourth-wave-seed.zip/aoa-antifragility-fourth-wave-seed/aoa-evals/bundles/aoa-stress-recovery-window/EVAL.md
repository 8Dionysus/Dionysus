# Eval Bundle: AoA Stress Recovery Window

## Status
Proposed bounded eval bundle

## Purpose

Evaluate whether a named stressor family is handled more cleanly across a bounded recovery window using explicit handoffs, playbook gates, KAG health signals, and owner-local evidence.

## Intended scope

This bundle is best used for:

- one bounded stressor family
- one owner surface or tightly related surface family
- one explicit review window
- one or more adjacent AoA layers only when they are directly implicated

Example wave-4 contour:

- owner repo: `ATM10-Agent`
- owner surface: `hybrid-query`
- adjacent layers: `aoa-agents`, `aoa-playbooks`, `aoa-kag`, `aoa-routing`, `aoa-memo`
- stressor family: retrieval succeeds while KAG expansion is unhealthy or quarantined

## Inputs

Required:

- source-owned stressor receipts
- owner-local artifacts for the same runs or bounded windows
- one or more explicit wave-3 objects such as:
  - stress handoff envelopes
  - playbook stress lanes
  - playbook re-entry gates
  - projection-health receipts
  - regrounding tickets

Optional:

- composite route hints
- reviewed memo pattern objects
- adaptation deltas
- bounded repeated-window comparisons

## Axes

### Handoff fidelity
Did the handoff narrow behavior, carry evidence, and block inappropriate widening.

### Route discipline
Did routing steer toward regrounding, playbook lanes, or safe review rather than convenience drift.

### Re-entry quality
Were re-entry decisions explicit, evidence-backed, and narrower than naive restoration.

### Regrounding effectiveness
Did derived-surface recovery actually reconnect consumers to source-backed footing.

### Evidence continuity
Can the chain from owner receipt through handoff, lane, gate, and route hint be followed without gaps.

### False-promotion prevention
Did the system avoid pretending that quarantine exit, ticket creation, or route churn alone equals health.

### Operator burden
Did recovery remain manageable and legible for a human operator.

### Trust calibration
Did the surfaces communicate degradation, uncertainty, and recovery boundaries honestly.

## Required output

The machine-readable report should conform to:

- `schemas/stress_recovery_window_eval_report_v1.json`

## Blind spots

This bundle does not prove:

- global project health
- correctness of unrelated surfaces
- long-horizon trend health without repeated windows
- that all future re-entry attempts will be safe

## Verdict posture

Axis-level status:

- `pass`
- `warn`
- `fail`
- `na`

An overall posture may be summarized narratively, but the split axes must remain visible.

## Wave 4 note

The first landing should stay documentation-first and schema-backed.
Repo-native runners, builders, and promotion into catalogs can follow once the object families settle.
