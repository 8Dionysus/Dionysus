# RECOVERY PATTERN MEMORY

## Purpose

Wave 4 adds one bounded memo object family for reviewed recovery patterns.

This family exists so the system can remember a repeated lesson such as:

- what evidence chain usually precedes safe re-entry
- what route posture tends to keep damage contained
- what false promotions to avoid
- what operator burden shows up again and again

It remains memory, not proof.

## When to create one

A `recovery_pattern_memory_v1` object is appropriate when at least one of the following is true:

- the same recovery pattern appears across multiple stress windows
- the same route and re-entry lesson keeps being relearned
- a bounded eval report and derived summary both point to the same cautionary pattern
- operators repeatedly need the same recovery reminder

Do not create one for every window.

## What it should carry

A healthy recovery pattern object includes:

- a bounded scope with primary and related repos
- a named pattern family
- source and evidence refs
- a counted occurrence window
- a concise lesson summary
- a recommended entry posture
- successful re-entry signals
- trust, salience, and review posture
- optional supersession or expiry

## Boundary reminder

The object may help answer:

- have we seen this recovery pattern before
- what route posture usually helps
- what evidence should we inspect before re-entry

The object should not claim:

- that the current run definitely matches the pattern
- that the owner repo is healthy now
- that a mutation is safe by itself
