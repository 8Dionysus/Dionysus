# RECOVERY PATTERN RECALL

## Goal

Teach `aoa-memo` to recall reviewed recovery patterns without turning them into a live control plane.

## Good recall behavior

A healthy recall path can surface a recovery pattern when:

- the current stressor family matches closely
- the same owner surface family is involved
- the lesson is reviewed and not superseded
- the pattern points the reader back to source receipts, playbook gates, or proof surfaces

## Unsafe recall behavior

Recall drifts when it:

- asserts that the current run is already healthy
- outranks a fresh owner receipt with older memory
- routes directly to mutation because a past pattern ended well
- suppresses uncertainty because the pattern feels familiar

## Suggested recall posture

When surfacing a recovery pattern, include:

- the confidence or trust posture
- the pattern window and occurrence count
- the source refs and proof refs worth reading next
- the explicit reminder that memory is context, not proof

## Wave 4 note

The most useful recovery memories are not victory laps.
They are lanterns that point back toward evidence.
