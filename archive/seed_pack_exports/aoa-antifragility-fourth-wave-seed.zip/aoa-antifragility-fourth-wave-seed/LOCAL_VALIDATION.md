# Local Validation Notes

This seed was locally checked for:

- JSON schema validity
- example-to-schema validation for:
  - `aoa-evals`
  - `aoa-stats`
  - `aoa-routing`
  - `aoa-memo`

The proposed objects are intentionally additive.
They are designed to fit beside existing bundle, summary, hint, and memory-object conventions rather than replacing them.
