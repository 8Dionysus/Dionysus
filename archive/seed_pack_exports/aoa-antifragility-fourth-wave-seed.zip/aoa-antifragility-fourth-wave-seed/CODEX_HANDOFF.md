# Codex Handoff

Assume waves 1 through 3 are already landed, or that equivalent owner-local receipts, handoff envelopes, playbook stress lanes, re-entry gates, projection-health receipts, and regrounding tickets exist.

Use this seed as a **bounded proof-and-consumption packet**.
The goal is to make wave-3 stress signals measurable, derivable, routable, and recallable without turning any convenience layer into the source of truth.

## Primary objective

Teach the system to do four things with explicit stress signals:

1. **prove** repeated-window handling quality with bounded evals
2. **derive** cross-repo recovery summaries without inventing new ownership
3. **route** using playbook and KAG stress signals as additive next-hop posture
4. **remember** reviewed recovery patterns as memo context for later runs

## P0 deliverables

- `aoa-evals`: doctrine + one repeated-window eval bundle + one report schema/example
- `aoa-stats`: doctrine + one derived recovery-window summary schema/example
- `aoa-routing`: doctrine + one composite stress-route hint schema/example
- `aoa-memo`: doctrine + one reviewed recovery-pattern memory schema/example

## Acceptance criteria

1. eval reports bind agent handoffs, playbook gates, KAG health, and owner receipts into a bounded proof surface
2. repeated-window eval results stay split-axis and disclose blind spots
3. stats summaries remain clearly derived and suppress themselves when evidence is thin
4. routing hints consume playbook and KAG signals additively, with owner receipts and eval evidence still winning precedence
5. memo pattern objects summarize repeated recovery lessons without claiming that the present run is healthy
6. no layer introduces hidden re-entry, hidden repair, or hidden republishing behavior
7. no layer compresses this family into one sovereign score

## Suggested sequence

### 1. Evals first
Land the repeated-window eval doctrine and report schema so downstream stats and routing work can point at a stable proof shape.

### 2. Stats second
Land the derived summary surface next so route builders and readers can consume bounded windows without inventing their own aggregators.

### 3. Routing third
Land composite stress-route consumption after eval and stats shapes exist.
Prefer additive fields or new generated hint families over a router rewrite.

### 4. Memo fourth
Land the reviewed recovery-pattern object last so memo can summarize repeated lessons from already-stabilized proof and derivation surfaces.

## Hard guardrails

- do not let `aoa-evals` rewrite workflow meaning that belongs to owner repos, playbooks, or agents
- do not let `aoa-stats` become the canonical voice for health or readiness
- do not let `aoa-routing` infer route posture from raw anecdotes or unsourced confidence
- do not let `aoa-memo` act as a live health sensor or auto-escalation trigger
- do not silently route back into a previously unhealthy surface without explicit re-entry conditions
- do not create one global recovery score

## Soft promotion rule

If repeated-window evals, derived summaries, route hints, and memo pattern objects converge on nearly identical shared fragments, promote those fragments later.
Before then, local ownership is cleaner than premature unification.
